// Zerfallsgesetz der Radioaktivit�t, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 27.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];    
var text03 = "Diagramma";  

var author = "W. Fendt 1998";
var translator = "Translated by PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text04 = "Wagt:";                                      
var text05 = "Entek b\u00F6l\u00FCnme bolmady:";
var text06 = "Indi b\u00F6l\u00FCnme boldy:";
var text07 = ["\u00FDadrolar", "\u00FDadro", "\u00FDadrolar", "\u00FDadrolar"];     // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
