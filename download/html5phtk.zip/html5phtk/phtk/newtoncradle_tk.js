// Newtons Wiege, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = "Ba&scedil;la";
var text03 = "Sarlar sany:";

var author = "W. Fendt 1997";
var translator = "Translated by PICT Turkmenistan";
