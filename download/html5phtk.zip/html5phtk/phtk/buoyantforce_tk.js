// Messung der Auftriebskraft, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 19.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Jisimin d&uuml;&yacute;p me&yacute;dany:"; 
var text02 = "Jisimin be&yacute;ikligi:";
var text03 = "Jisimin dykyzlygy:";
var text04 = "Suwuklygyn dykyzlygy:";   
var text05 = "&Ccedil;ekisi:";
var text06 = "&Ccedil;alsyrlan g&ouml;wr&uuml;m:"; 
var text07 = "&Yacute;&uuml;z&uuml;jilik g&uuml;&yacute;ji:";
var text08 = "Jisimin agramy:";
var text09 = "&Ouml;l&ccedil;enen g&uuml;&yacute;&ccedil;:";
var text10 = "&Ouml;l&ccedil;enil&yacute;&auml;n &ccedil;&auml;kler:";

var author = "W. Fendt 1998,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Maksimum dereje a\u015Fyrylan!";
