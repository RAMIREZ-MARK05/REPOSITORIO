// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 16.03.2018

// Texte in HTML-Schreibweise:

var text01 = "2 tigir&ccedil;ek";
var text02 = "4 tigir&ccedil;ek";
var text03 = "6 tigir&ccedil;ek";
var text04 = "Agram:";
var text05 = "Tigir&ccedil;ek(lerin)agramy:";
var text06 = "Gerekli g&uuml;&yacute;&ccedil;:";
var text07 = "Pru&zcaron;in masstaby";
var text08 = "G&uuml;&yacute;&ccedil; wektorlar";

var author = "W. Fendt 1998";
var translator = "Translated by PICT Turkmenistan";

// Symbole:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = "&divide;";                           // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                   
