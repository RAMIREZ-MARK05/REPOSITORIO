// Fadenpendel, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];
var text03 = "Ha&yacute;al hereket";
var text04 = "Uzynlyk:";
var text05x = "Agyrlyk g&uuml;&yacute;&ccedil; bilen";     // Zus�tzliche Zeile!
var text05 = "bagly tizlenme:";
var text06 = "Massa:";
var text07 = "Amplituda:";
var text08 = "Uzalma";
var text09 = "Tizlik";
var text10 = "Tizlenme";
var text11 = "G&uuml;&yacute;&ccedil;";
var text12 = "Energi&yacute;a";

var author = "W. Fendt 1998,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

var meter = "m";                                    
var meterPerSecond2 = "m/s&sup2;";                  
var kilogram = "kg";                                
var degree = "&deg;";                               

// Texte in Unicode-Schreibweise:

var text13 = "Maksimum";
var text14 = "Uzalma";
var text15 = "Tizlik"; 
var text16 = "Tizlenme (tangensial komponenti)";
var text17 = "G\u00FC\u00FD\u00E7 (tangensial komponenti)";
var text18 = "Potential energi\u00FDa";
var text19 = "Kinetik energi\u00FDa";
var text20 = "Jemi energi\u00FDa";
var text21 = "(s)";
var text22 = "(m)";
var text23 = "(m/s)";
var text24 = "(m/s\u00B2)";
var text25 = "(N)";
var text26 = "(J)";
var text27 = "Yrgyldy periody";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolTangential = "tang";                             // Symbol f�r tangential
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                   
var meterUnicode = "m";                             
var meterPerSecond = "m/s";                         
var meterPerSecond2Unicode = "m/s\u00B2";           
var newton = "N";                                   
var joule = "J";                                    


