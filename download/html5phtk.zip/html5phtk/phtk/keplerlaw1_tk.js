// Erstes Kepler-Gesetz, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 18.03.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Uly &yacute;arym-os ok:";
var text03 = "Ekssentriklik san:";
var text04 = "Ki&ccedil;i &yacute;arym-os ok:";
var text05 = ["Arakesme", "Dowam et"];
var text06 = "Ha&yacute;al hereket";
var text07 = "G&uuml;nden aralyk:";
var text08 = "Su wagtky:";
var text09 = "Minimum:";
var text10 = "Maksimum:";
var text11 = "Elliptik orbita";
var text12 = "Oklar";
var text13 = "Birlesdiriji &ccedil;yzyklar";

var author = "W. Fendt 2000,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Merkuri\u00FD", "Wenera", "\u00DDer", "Mars", "\u00DDupiter", "Saturn", "Uran", "Neptun",
              "Pluton", "Galle\u00FDa Kometasy", ""];

var text14 = "G\u00FCn";
var text15 = "Planeta";
var text16 = "Kometa";
var text17 = "Perigeli\u00FD";
var text18 = "Afeli\u00FD";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "AU";

