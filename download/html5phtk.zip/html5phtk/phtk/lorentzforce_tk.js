// Leiterschaukel-Versuch zur Lorentzkraft, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 20.03.2018

// Texte in HTML-Schreibweise:

var text01 = "A&ccedil; / &Yacute;ap";
var text02 = "Rewers tok";
var text03 = "A&ccedil; magnity";
var text04 = "Tok ugry";
var text05 = "Magnit me&yacute;dan";
var text06 = "Lorentz g&uuml;&yacute;&ccedil;";

var author = "W. Fendt 1998";
var translator = "Translated by PICT Turkmenistan";
