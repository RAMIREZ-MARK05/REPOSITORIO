// Gleichgewicht dreier Kr�fte, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 16.03.2018

// Texte in HTML-Schreibweise:

var text01 = "G&uuml;&yacute;&ccedil;ler:";
var text02 = "&ccedil;ep:";
var text03 = "sag:";
var text04 = "asakky:";
var text05 = "Parallelogram g&uuml;&yacute;&ccedil;ler";
var text06 = "Bur&ccedil;lar:";
var text07 = "&ccedil;ep:";
var text08 = "sag:";

var author = "W. Fendt 2000";
var translator = "Translated by PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00B0";                              
var newton = "N";                                   
