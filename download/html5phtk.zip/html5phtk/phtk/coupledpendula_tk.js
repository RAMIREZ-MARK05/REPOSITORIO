// Gekoppelte Pendel, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";                           
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];                
var text03 = "Ha&yacute;al hereket";
var text04 = "Basdaky &yacute;agda&yacute;:";

var author = "W. Fendt 1998";
var translator = "Translated by PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      

// Texte in Unicode-Schreibweise:

var text05 = "ma\u00FDatnik 1";                            // Erstes Pendel (links)
var text06 = "ma\u00FDatnik 2";                            // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
