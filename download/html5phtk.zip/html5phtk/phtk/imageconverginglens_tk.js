// Bilderzeugung Sammellinse, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 25.03.2018

// Texte in HTML-Schreibweise:
    
var text01 = "Fokal uzynlyk:";
var text02 = "Ob&yacute;ekt aralygy:";
var text03 = "Ob&yacute;ektin be&yacute;ikligi:";
var text04 = "Sekil aralygy:";
var text05 = "Sekil be&yacute;ikligi:";    
var text06 = "Sekilin g&ouml;rn&uuml;si:"
var text07 = ["hakyky", "wirtual"];
var text08 = ["ters", "dik"];
var text09 = ["ki&ccedil;eldilen", "den ululuk", "ulaldylan", "&ccedil;&auml;ksiz ulaldylan"];
var text10 = "&Yacute;eke &yacute;agtylyk s&ouml;hleleri";
var text11 = "Toplumly &yacute;agtylyk s&ouml;hleleri";
var text12 = "&Auml;hmi&yacute;et berilmeli:";

var author = "W. Fendt 2008,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var centimeter = "cm";
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text13 = ["ob\u00FDekt", 
              "ob\u00FDekt aralygy", 
              "ob\u00FDekt be\u00FDikligi",
              "linza", 
              "linza tekizligi", 
              "optiki ok",
              "fokal nokatlar", 
              "fokal uzynlyk", 
              "sekil", 
              "sekil aralyk", 
              "sekil be\u00FDiklik",
              "ekran"];
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "o";
var symbolGG = "O"; 
var symbolB = "i";
var symbolBB = "I";


