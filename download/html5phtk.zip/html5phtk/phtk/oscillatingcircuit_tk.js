// Elektromagnetischer Schwingkreis, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];
var text03 = "Ha&yacute;al hereket (10 &times;)";
var text04 = "Ha&yacute;al hereket (100 &times;)";
var text05 = "Sygym:";
var text06 = "Induktiwlik:";
var text07 = "Gar&scedil;ylyk:";
var text08 = "Maks. napr&yacute;a&zcaron;enie:";
var text09 = "Napr&yacute;a&zcaron;enie, Tok";
var text10 = "Energi&yacute;a";

var author = "W. Fendt 1999,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                     
var henry = "H";                              
var ohm = "&Omega;";                          
var volt = "V";                               

// Texte in Unicode-Schreibweise:

var text11 = "Yrgyldylar periody:";
var text12 = "Elektrik me\u00FDdandaky energi\u00FDa:";
var text13 = "Magnitic me\u00FDdandaky energi\u00FDa:";
var text14 = "I\u00E7ki energi\u00FDa:";
var text15 = "S\u00F6nme\u00FD\u00E4n yrgyldy";
var text16 = "S\u00F6n\u00FD\u00E4n yrgyldy";
var text17 = "Kritiki \u00F6\u00E7me";
var text18 = "G\u00FD\u00FD\u00E7li \u00F6\u00E7me";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                  
var voltUnicode = "V";                             
var ampere = "A";                                  
var joule = "J";                                   
