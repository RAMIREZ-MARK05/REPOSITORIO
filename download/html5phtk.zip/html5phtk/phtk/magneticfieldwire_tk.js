// Magnetfeld eines geraden stromdurchflossenen Leiters, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 20.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ters tok";

var author = "W. Fendt 2000";
var translator = "Translated by PICT Turkmenistan";
