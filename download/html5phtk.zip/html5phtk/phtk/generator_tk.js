// Generator, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise;

var text01 = "Kollektorsyz";
var text02 = "Kollektor bilen";
var text03 = "&Ccedil;als ugry";
var text04 = ["Ba&scedil;la", "Arakesme", "Dowam et"];
var text05 = "Hereket ugry";
var text06 = "Magnit me&yacute;dan";
var text07 = "&Yacute;&uuml;ze &ccedil;ykan tok";

var author = "W. Fendt 1998";  
var translator = "Translated by PICT Turkmenistan";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "a&yacute;law/min";               // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
