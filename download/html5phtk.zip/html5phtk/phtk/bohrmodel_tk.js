// Bohrsches Atommodell, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 27.03.2018

// Texte in HTML-Schreibweise:

var text01 = "B&ouml;lejik modeli";
var text02 = "Tolkun modeli";
var text03 = "Bas kwant sany:";


var author = "W. Fendt 1999"; 
var translator = "Translated by PICT Turkmenistan";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



