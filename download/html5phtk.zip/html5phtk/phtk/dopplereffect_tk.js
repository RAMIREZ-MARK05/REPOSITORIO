// Beispiel zum Doppler-Effekt, turkmenische Texte
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ba&scedil;la";
var text02 = ["Arakesme", "Dowam et"]; 

var author = "W. Fendt 1998";
var translator = "Translated by PICT Turkmenistan";

// Texte in Unicode-Schreibweise:   

var text03 = [                                             // Erl�uterungstext
  ["Tiz k\u00F6mek masyn",
  "gola\u00FDlanda the adama,",
  "arasyndaky interwal",
  "gel\u00FD\u00E4n tolkun front \u00FC\u00E7in",
  "gysgal\u00FDar."],
  ["Indi masyn daslas\u00FDar",
  "adamdan. Sonda tolkun front",
  "adama has uzak",
  "aralyklarda \u00FDet\u00FD\u00E4r."]];


  

