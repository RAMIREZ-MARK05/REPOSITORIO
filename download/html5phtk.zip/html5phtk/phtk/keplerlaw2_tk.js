// Zweites Kepler-Gesetz, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 18.03.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Uly &yacute;arym-os ok:";
var text03 = "Ekssentriklik san:";
var text04 = ["Arakesme", "Dowam et"];
var text05 = "Ha&yacute;al hereket";
var text06 = ["Aralyk", "G&uuml;nden bolan aralyk:"];
var text07 = "Tizlik:";
var text08 = "Su wagtky:";
var text09 = "Minimum:";
var text10 = "Maksimum:";
var text11 = "Sektorlar";
var text12 = "Tizlik wektory";

var author = "W. Fendt 2000,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Merkuri\u00FD", "Wenera", "\u00DDer", "Mars", "\u00DDupiter", "Saturn", "Uran", "Neptun",
              "Pluton", "Galle\u00FDa Kometasy", ""];

// Symbole und Einheiten: 

var auUnicode = "AU";
var symbolPeriod = "T";

