// Ersatzkraft mehrerer Kr�fte, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 16.03.2018

// Texte in HTML-Schreibweise:

var text01 = "G&uuml;&yacute;&ccedil;ler sany:";
var text02 = "Ahyrkyny tap";
var text03 = "Gurlusy arassala";

var author = "W. Fendt 1998";
var translator = "Translated by PICT Turkmenistan";
