// Bewegung mit konstanter Beschleunigung, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];
var text03 = "Ha&yacute;al hereket";
var text04 = "Basdaky &yacute;agda&yacute;:";
var text05 = "Basdaky tizlik:";
var text06 = "Tizlenme:";
var text07 = "Tizligin wektory";
var text08 = "Tizlenm&auml;n wektory";

var author = "W. Fendt 2000";
var translator = "Translated by PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text09 = "(s)";                                        // Einheitenangabe f�r Zeit-Achse
var text10 = "(m)";                                        // Einheitenangabe f�r Weg-Achse
var text11 = "(m/s)";                                      // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(m/s\u00B2)";                                // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                     
var meter = "m";                                      
var meterPerSecond = "m/s";                            
var meterPerSecond2 = "m/s\u00B2";                     
