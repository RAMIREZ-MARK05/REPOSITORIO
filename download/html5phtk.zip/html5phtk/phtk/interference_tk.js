// Interferenz zweier Kreis- oder Kugelwellen, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 20.03.2018

// Texte in HTML-Schreibweise:

var text01 = ["Arakesme", "Dowam et"];                     // Schaltknopf (Pause/Weiter)
var text02 = "Ha&yacute;al hereket";
var text03 = "Aralyk ikisinin arasynda";
var text04 = "&ccedil;esmeler:";
var text05 = "Tolkun uzynlyk:";

var author = "W. Fendt 1999";
var translator = "Translated by PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                         

// Texte in Unicode-Schreibweise:

var text06 = "Aratapawut uzynlyklar \u00FC\u00E7in:";
var text07 = "G\u00FC\u00FD\u00E7len\u00FD\u00E4n interferensi\u00FDa (maksimal amplituda)";
var text08 = "S\u00F6n\u00FD\u00E4n interferensi\u00FDa (minimal amplituda)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03BB";                           // Symbol f�r Wellenl�nge (Lambda)
