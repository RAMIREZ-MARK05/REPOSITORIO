// Elastischer und unelastischer Sto�, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 17.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Elastik &ccedil;akysma";
var text02 = "Elastik d&auml;l &ccedil;akysma";
var text03 = "Ga&yacute;tar";
var text04 = "Start";
var text05 = "Ha&yacute;al hereket";
var text06 = "Araba 1:";
var text07 = "Araba 2:";
var text08 = "Massa:";
var text09 = "Tizlik:";
var text10 = "Tizlik";
var text11 = "Impuls";
var text12 = "Kinetic energi&yacute;a";

var author = "W. Fendt 1998,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                          

// Texte in Unicode-Schreibweise:

var text13 = "Araba 1:";
var text14 = "Araba 2:";
var text15 = "\u00C7akysmadan \u00F6n tizlikler:";
var text16 = "\u00C7akysmadan son tizlikler:";
var text17 = "\u00C7akysmadan \u00F6n impulsler:";
var text18 = "\u00C7akysmadan son impulslar:";
var text19 = "Kinetik energi\u00FDa \u00E7akysmadan \u00F6n:";
var text20 = "Kinetik energi\u00FDa \u00E7akysmadan son:";
var text21 = "Jemi impuls:";
var text22 = "Jemi kinetik energi\u00FDa:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                     
var kilogramMeterPerSecond = "kg m/s";                 
var joule = "J";                                       
