// Kettenkarussell, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 18.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Karusel";
var text02 = "Karusel g&uuml;&yacute;&ccedil;ler bilen";
var text03 = "&Ccedil;yzgy";
var text04 = "San bahalary";
var text05 = ["Arakesme", "Dowam et"];
var text06 = "Ha&yacute;al hereket";
var text07 = "Period:";
var text08 = ["Iki asma arasyndaky aralyk", "A&yacute;law oky:"]; 
var text09 = "&Yacute;&uuml;p uzynlyklary:";
var text10 = "Massa:";

var author = "W. Fendt 1999,&nbsp; PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text11 = "\u00DDygylygy:";
var text12 = "Bur\u00E7ly tizlik:";
var text13 = "Radius:";
var text14 = "Tizlik:";
var text15 = "Bur\u00E7:";
var text16 = "Agram:";
var text17 = "Merkeze ymtyl\u00FDan g\u00FC\u00FD\u00E7:";
var text18 = "\u00DD\u00FCpin dartylmasy:";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




