// Stehende L�ngswellen, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 20.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Turbanyn sekili:";
var text02 = "iki tarapy a&ccedil;yk";
var text03 = "bir tarapy a&ccedil;yk";
var text04 = "iki tarapy &yacute;apyk";
var text05 = "Wibrasion re&zcaron;im:";
var text06 = ["fundamental",  "1-nji oberton",             // Bezeichnungen der Eigenschwingungen 
              "2-nji oberton", "3-nji oberton", 
              "4-nji oberton", "5-nji oberton"];
var text07 = "Pesr&auml;k";
var text08 = "&Yacute;okaryrak";
var text09 = "Turba uzynlygy:";
var text10 = "Tolkun uzynlyk:";
var text11 = "&Yacute;ygylyk:";

var author = "W. Fendt 1998,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                           // Meter
var hertz = "Hz";                                          // Hertz

// Texte in Unicode-Schreibweise:

var text12 = "B\u00F6lejiklerin s\u00FC\u00FDsmesi";       // �berschrift des ersten Diagramms
var text13 = "Orta\u00E7a basysdan gysarma";               // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "N";                                      // Symbol f�r Knoten
var symbolAntinode = "A";                                  // Symbol f�r Bauch

