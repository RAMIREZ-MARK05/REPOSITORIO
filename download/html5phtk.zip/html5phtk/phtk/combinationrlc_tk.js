// Kombinationen von Widerst�nden, Spulen und Kondensatoren, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2020

// Texte in HTML-Schreibweise:

var text01 = "&Uuml;&yacute;tge&yacute;&auml;n napr&yacute;a&zcaron;enie &ccedil;esmesi:";
var text02 = "Napr&yacute;a&zcaron;enie:";
var text03 = "&Yacute;ygylyk:";
var text04 = "Komponent:";
var text06 = ["Garsylyk:", "Induktiwlik:", "Sygym:"];
var text07 = "&Ccedil;als";
var text08 = "Gos (yzygider)";
var text09 = "Gos (parallel)";
var text10 = "A&yacute;yr";
var text11 = "&Ouml;l&ccedil;e&yacute;jiler:";
var text12 = "Napr&yacute;a&zcaron;enie";
var text13 = "Tok";

var author = "W. Fendt 2004";
var translator = "Translated by PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text05 = ["Resistor", "Induktor", "Kondensator"];
var text14 = "Napr\u00FDa\u017Eenie:";
var text15 = "Tok:";
var text16 = "Gosma garsylygy:";
var text17 = "Doly garsylyk:";
var text18 = "Faza bur\u00E7y:";
var text19 = "\u00F6r\u00E4n ki\u00E7i";                   // Stromst�rke Voltmeter
var text20 = "\u00F6r\u00E4n ki\u00E7i";                   // Spannung Amperemeter
var text21 = "\u00F6r\u00E4n ki\u00E7i";                   // Impedanz/Widerstand Amperemeter
var text22 = "\u00F6r\u00E4n uly";                         // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)