// Zerfallsreihen, turkmenische Texte (PICT Turkmenistan, unvollst�ndig!)
// Letzte �nderung 27.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Decay chain:"; // ???
var text03 = "Indiki b&ouml;l&uuml;nme (dargama)";

var author = "W. Fendt 1998"; 
var translator = "Translated by PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text02 = ["Tor hatary", "Neptuni\u00FD hatary", "Radi\u00FD hatary", "Aktini\u00FD hatary"];          





