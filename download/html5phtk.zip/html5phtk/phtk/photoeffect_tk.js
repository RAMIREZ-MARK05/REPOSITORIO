// Photoelektrischer Effekt, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 26.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Katod material:";
var text03 = "Spektral &ccedil;yzyk (Hg):";
var text04 = "Sakla&yacute;an napr&yacute;a&zcaron;enie:";
var text05 = "&Yacute;ygylygy:";
var text06 = ["Energi&yacute;a", "foton &uuml;&ccedil;in:"];
var text07 = "I&scedil; funksi&yacute;asy:";
var text08 = ["Maksimal kinetik energi&yacute;a", "elektron &uuml;&ccedil;in:"];
var text09 = "&Ouml;l&ccedil;emeleri arassala";

var author = "W. Fendt 2000,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                
var terahertz = "THz";                         
var electronvolt = "eV";                       

// Texte in Unicode-Schreibweise:

var text02 = ["sezi\u00FD", "natri\u00FD"];
var text10 = ["sary", "\u00FDasyl", "benewse", "ultrabenewse", "ultrabenewse"];
var text11 = "(THz)";
var text12 = "(V)";
var text13 = [
             ["Fotonyn energi\u00FDasy emissi\u00FDa bolmagyna \u00FDeterli d\u00E4l", "elektron \u00FC\u00E7in."],
             ["K\u00F6pelt sakla\u00FDan napr\u00FDa\u017Eenieni se\u00FDlelikde hi\u00E7", "electron anoda \u00FDetip bilmez \u00FDaly!"],
             ["Sakla\u00FDan napr\u00FDa\u017Eenie se\u00FDle bir uly - elektronlar", "katoda ga\u00FDd\u00FDarlar."],
             ["T\u00E4ze \u00E7l\u00E7emeleri edip basla", "basga spektral \u00E7yzyk \u00FC\u00E7in!"],
             ["T\u00E4ze \u00E7l\u00E7emeleri edip basla", "basga kathod materialy \u00FC\u00E7in!"],
             ["\u00D6l\u00E7emeler gutardy."]
             ];

var symbolCathode = "C";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
