// Kr�fte an der schiefen Ebene, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];
var text03 = "Ha&yacute;al hereket";
var text04 = "Pru&zcaron;in masstaby";
var text05 = "G&uuml;&yacute;&ccedil; wektorlar";
var text06 = "&Yacute;apgytlyk bur&ccedil;y:";
var text07 = "Agram:";
var text08 = "Parallel komponent:";
var text09 = "Normal g&uuml;&yacute;&ccedil;:";
var text10 = "S&uuml;rt&uuml;lme koeffisienti:";
var text11 = "S&uuml;rt&uuml;lme g&uuml;&yacute;ji:";
var text12 = "Gerekli g&uuml;&yacute;&ccedil;:";

var author = "W. Fendt 1999,&nbsp; PICT Turkmenistan";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                               
var newton = "N";                                   
