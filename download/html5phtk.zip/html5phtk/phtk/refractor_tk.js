// Kepler-Fernrohr, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 25.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Fokal uzynlyklary:"; 
var text02 = "Ob&yacute;ektiw:";
var text03 = "Okul&yacute;ar:";
var text04 = "Bur&ccedil;lar:";
var text05 = "Ulaldylysy:";

var author = "W. Fendt 2000";
var translator = "Translated by PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite

