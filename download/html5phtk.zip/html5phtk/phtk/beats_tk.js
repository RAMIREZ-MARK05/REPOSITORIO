// Schwebungen, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];
var text03 = "Ha&yacute;al hereket";
var text04 = "&Yacute;ygylyklar:";
var text05 = "1-nji tolkun:";
var text06 = "2-nji tolkun:";

var author = "W. Fendt 2001"; 
var translator = "Translated by PICT Turkmenistan";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



