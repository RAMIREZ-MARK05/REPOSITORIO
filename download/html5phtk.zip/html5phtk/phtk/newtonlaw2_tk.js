// Fahrbahnversuch zum 2. Newtonschen Gesetz, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 17.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = ["Start", "Maglumaty belle"];
var text03 = "Diagramma";
var text04 = "Massa (arabanky):";
var text05 = "Asylan massa:";
var text06 = "S&uuml;rt&uuml;lme koeffisienti:";
var text07 = "Maglumat:";

var author = "W. Fendt 1997,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "LB";
var text09 = "(s)";
var text10 = "(m)";
var text11 = "Juda k\u00F6p s\u00FCrt\u00FClme!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


