// Ohmsches Gesetz, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Maks. napr&yacute;a&zcaron;enie:";
var text02 = "Maks. tok:";
var text03 = "K&ouml;pelt gar&scedil;ylygy";
var text04 = "Azalt gar&scedil;ylygy";
var text05 = "K&ouml;pelt napr&yacute;a&zcaron;enieni";
var text06 = "Azalt napr&yacute;a&zcaron;enieni";

var author = "W. Fendt 1997";
var translator = "Translated by PICT Turkmenistan";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Maksimum dereje asyrylan!";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
