// Stehende Welle, Erkl�rung durch Reflexion, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Serpikdirme";
var text02 = "berkidilen tarapdan";
var text03 = "erkin tarapdan";
var text04 = "Ga&yacute;tar";
var text05 = ["Ba&scedil;la", "Arakesme", "Dowam et"];
var text06 = "Ha&yacute;al hereket";
var text07 = "Animasi&yacute;a";
var text08 = "&Yacute;eke &auml;dimler bilen";
var text09 = "Ga&ccedil;&yacute;an tolkun";
var text10 = "Serpikdirilen tolkun";
var text11 = "Ahyrky duran tolkun";

var author = "W. Fendt 2003"; 
var translator = "Translated by PICT Turkmenistan";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "N";
var symbolAntiNode = "A";

