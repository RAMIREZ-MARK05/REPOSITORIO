// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 24.03.2018

// Texte in HTML-Schreibweise:

var text01 = "T&auml;zeden a&ccedil;";
var text02 = "Indiki &auml;dim";
var text03 = ["Arakesme", "Dowam et"];                  
var text04 = "1-nji refraksi&yacute;a (d&ouml;w&uuml;lme) koeffisienti:";
var text05 = "2-nji refraksi&yacute;a (d&ouml;w&uuml;lme) koeffisienti:";
var text06 = "Ga&ccedil;&yacute;an bur&ccedil;:";

var author = "W. Fendt 1998";
var translator = "Translated by PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise:

var text07 = [

  ["Tekiz tolkun front gidn\u00E4r",                       // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "diagonal ugur bo\u00FDun\u00E7a",
   "iki serisdelerin arasynda.",
   "Tolkunyn d\u00FCrli tizlikleri",
   "bar her serisde \u00FC\u00E7in."],
   
  ["Tekiz tolkun front bar\u00FDar",                       // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "perpendikul\u00FDar ugurda",
   "iki serisdelerin arasynda.",
   "Tolkunyn d\u00FCrli tizligi",
   "bar her serisdede."],
 
  ["Tolkun front gelenden son",                            // i == 2 (step == 1, n1 > n2) 
   "ara\u00E7\u00E4kde \u00FDerlesen nokatlar",
   "\u00F6z\u00FCni alyp bar\u00FDarlar G\u00FC\u00FDgens'",
   "prinsipe g\u00F6r\u00E4. Her nokata",
   "sar g\u00F6rn\u00FCsli \u00FDagtylyk",
   "\u00E7esme \u00FDaly garap bol\u00FDar.",
   "Serisdede bu 2 elementar",
   "tolkunlar has \u00E7alt hereket ed\u00FD\u00E4rler \u00E7\u00FCnki",
   "refraksi\u00FDa d\u00F6w\u00FClme koeffisi\u00FDenti has ki\u00E7idir."],
   
  ["Tolkun front gelenden son",                            // i == 3 (step == 1, n1 < n2) 
   "ara\u00E7\u00E4kdaky nokatlar",
   "Gu\u00FDgens prinsipe g\u00F6r\u00E4 \u00F6z\u00FCni alyp bar\u00FDarlar.",
   "Her nokata garap",
   "bol\u00FDar sar g\u00F6rn\u00FCsli",
   "\u00FDagtylyk \u00E7esme h\u00F6km\u00FCnde.",
   "Serisde 2-de bu elementar",
   "tolkunlar has ha\u00FDal hereket ed\u00FD\u00E4rler \u00E7\u00FCnki",
   "refraksi\u00FDa d\u00F6w\u00FClme koeffisi\u00FDenti has uly bol\u00FDar."], 

  ["\u00DCst-\u00FCst\u00FCnden go\u00FDlan \u00E4hli",    // i == 4 (step == 2, total == false, eps1 > 0) 
   "elementar tolkunlar emele getir\u00FD\u00E4r",
   "t\u00E4ze tekiz tolkuny. \u00DCns berin",
   "\u00FDa\u00FDrama ugry tekiz",
   "tolkun \u00FC\u00E7in \u00FC\u00FDtge\u00FD\u00E4r ha\u00E7an-da",
   "ol serisde 1-den serisde 2-k\u00E4 baranda."], 

  ["\u00DCst-\u00FCst\u00FCnden go\u00FDlan \u00E4hli",    // i == 5 (step == 2, total == false, eps1 == 0)
   "elementar tolkunlar emele getir\u00FD\u00E4r a",
   "t\u00E4ze tekiz tolkuny."],  
   
  ["\u00DCst-\u00FCst\u00FCnden go\u00FDlan \u00E4hli",    // i == 6 (step == 2, total == true)
   "elementar tolkunlar emele getir\u00FD\u00E4r a",
   "t\u00E4ze tekiz tolkuny serisde 1-de",
   "(serpikdirlen tolkun).",
   "Bu tolkun ge\u00E7enok serisde 2-\u00E4",
   "(jemi i\u00E7ki serpikdirme)."],
   
  ["\u00DDa\u00FDrama ugry",                               // i == 7 (step == 3)
   "tolkunda indi emele geldi.",
   "Ol \u00E7yzykly perpendikul\u00FDar",
   "bolar tolkun fronta g\u00F6r\u00E4."],   

  ["Tolkun front se\u00FDrek \u00FDagda\u00FDda",          // i == 8 (step == 4)
   "\u00FDeke \u00F6zi gel\u00FD\u00E4r!"],
   
  ["Eger d\u00F6w\u00FClme refraksi\u00FDa koeffisienti iki",        // i == 9 (n1 == n2)
   "serisde \u00FC\u00E7in hem birmenzes",
   "hi\u00E7 \u00FC\u00FDtgesik zat \u00FD\u00FCze \u00E7ykanok."]];
          
var text08 = "Ga\u00E7\u00FDan bur\u00E7:"; 
var text09 = "Serpikdirme bur\u00E7y:";
var text10 = "D\u00F6w\u00FClme bur\u00E7y:"; 
var text11 = "Serisde 1";
var text12 = "Serisde 2";      
var text13 = ["Bur\u00E7 kritiki bolar", "Jemi i\u00E7erki serpikdirme \u00FC\u00E7in:"];

// Einheiten:

var degreeUnicode = "\u00B0";                              // Grad
