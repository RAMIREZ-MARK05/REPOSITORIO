// Gleichstrom-Elektromotor, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise;

var text01 = "Ga&yacute;tar";
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];             
var text03 = "&Uuml;&yacute;tget ugry";
var text04 = "Tok ugry";
var text05 = "Magnit me&yacute;dan";
var text06 = "Lorents g&uuml;&yacute;&ccedil;";

var author = "W. Fendt 1997";             
var translator = "Translated by PICT Turkmenistan";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "a&yacute;law/min";               // Umdrehungen pro Minute
