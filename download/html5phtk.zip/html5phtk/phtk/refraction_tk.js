// Reflexion und Brechung von Licht, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 24.03.2018

// Texte in HTML-Schreibweise:
    
var text01 = "1-nji refraksi&yacute;a (d&ouml;w&uuml;lme) koeffisienti:";
var text02 = "2-nji refraksi&yacute;a (d&ouml;w&uuml;lme) koeffisienti:";
var text03 = "Ga&ccedil;&yacute;an bur&ccedil;:";
var text04 = "Serpikdirme bur&ccedil;y:";
var text05 = "D&ouml;w&uuml;lme bur&ccedil;y:";    
var text06 = ["Minimum bur&ccedil; jemi", "I&ccedil;erki serpikdirme:"];

var author = "W. Fendt 1997,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                             

// Texte in Unicode-Schreibweise:

var text07 = [["wakuum", "1"], ["howa", "1.0003"],         // Stoffe und Brechungsindizes
    ["suw", "1.33"], ["etanol", "1.36"],
    ["kwarts a\u00FDna", "1.46"], ["benzol", "1.49"], 
    ["kron (a\u00FD) a\u00FDna N-K5", "1.52"], ["mineral duz", "1.54"], 
    ["kron (a\u00FD) a\u00FDna LF5", "1.58"], ["kron (a\u00FD) a\u00FDna N-SK4", "1.61"],
    ["kron (a\u00FD) a\u00FDna SF6", "1.81"], ["almaz", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03B5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03B5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00B0";                     
