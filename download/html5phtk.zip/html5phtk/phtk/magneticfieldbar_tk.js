// Magnetfeld eines Stabmagneten, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 20.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Arassala me&yacute;dan &ccedil;yzyklary";
var text02 = "A&ccedil; magnity";

var author = "W. Fendt 2001";
var translator = "Translated by PICT Turkmenistan";
