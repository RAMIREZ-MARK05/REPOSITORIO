// Druckdose (hydrostatischer Druck), turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 06.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Suwuklyk:";
var text03 = "Dykyzlyk:";
var text04 = "&Ccedil;unluk:";
var text05 = "Gidrostatik basy&scedil;:";

var author = "W. Fendt 1999";                              // Autor
var translator = "Translated by PICT Turkmenistan";        // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["belli d\u00E4l", "suw", "etanol", "benzol", "d\u00F6rt hlorly uglerod", "simap"]; 
