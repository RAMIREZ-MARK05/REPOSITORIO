// Beispiel zur Zeitdilatation, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 26.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Tizligi peselt";
var text02 = "Tizligi k&ouml;pelt";
var text03 = "Ga&yacute;tar";
var text04 = ["Ba&scedil;la", "Arakesme", "Dowam et"];

var author = "W. Fendt 1997,&nbsp; PICT Turkmenistan";

var decimalSeparator = ".";

// Texte in Unicode-Schreibweise:

var text05 = "Aralyk:";
var text06 = "5 \u00FDagtylyk sagat";
var text07 = "Tizlik:";
var text08 = "U\u00E7\u00FDan wagt (\u00FDer sistemasy):";
var text09 = "sagat";
var text10 = "U\u00E7\u00FDan wagt (raketa sistemasy):";