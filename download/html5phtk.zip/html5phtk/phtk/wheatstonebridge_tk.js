// Wheatstonesche Br�ckenschaltung, turkmenische Texte
// Letzte �nderung 21.03.2018

// Texte in HTML-Schreibweise:

var text01 = "T&auml;ze &ouml;l&ccedil;e&yacute;is";
var text02 = "Denesdirme rezistor:";
var text03 = "Typ&yacute;an rezistor:";
var text04 = "Typ&yacute;an kontaktyn &yacute;agda&yacute;y:";
var text05 = "Napr&yacute;a&zcaron;enie kuwwat &ccedil;esmeden:";
var text06 = "Gar&scedil;ylyk enjamda:";
var text07 = "Hasapla gar&scedil;ylygy";
var text08 = "G&ouml;rkez napr&yacute;a&zcaron;enie";
var text09 = "G&ouml;rkez tok g&uuml;&yacute;ji";
var author = "W. Fendt 2006,&nbsp; PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text10 = ["Typ\u00FDan kontakty s\u00FC\u00FDs\u00FCr",
  	          "nol baha \u00FDet\u00FD\u00E4n\u00E7\u00E4!"];
var text11 = "Indi gar&scedil;ylygy hasaplap bol\u00FDar.";         

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var milliampere = "mA";
var ohm = "\u03A9";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00D7";                              
