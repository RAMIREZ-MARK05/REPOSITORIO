// Beugung von Licht am Einfachspalt, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 26.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Tolkun uzynlyk:";
var text02 = "De&scedil;igi&ncaron; ini:";
var text03 = "Bur&ccedil;:";
var text04 = "Maksimal:";
var text05 = "Minimal:";
var text06 = "Otnositel intensiwlik:";
var text07 = "Diffraksi&yacute;anyn surady";
var text08 = "Intensiwlik profili";

var author = "W. Fendt 2003,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
