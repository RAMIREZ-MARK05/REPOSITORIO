// Potentiometerschaltung, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Napr&yacute;a&zcaron;enie kuwwat &ccedil;esmeden:";
var text02 = "Typ&yacute;an rezistor:";
var text03 = "Typ&yacute;an kontaktyn &yacute;agda&yacute;y:";
var text04 = "Gar&scedil;ylyk enjamda:";
var text05 = "G&ouml;rkez napr&yacute;a&zcaron;enieni";
var text06 = "G&ouml;rkez tok g&uuml;&yacute;ji";
var author = "W. Fendt 2006";
var translator = "Translated by PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "U";                                  // Symbol f�r Spannung
var symbolVoltage2 = "a";                                  // Index f�r Verbraucher
                      
