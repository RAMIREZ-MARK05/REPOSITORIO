// Zerlegung einer Kraft in zwei Komponenten, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 16.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Berlen ululygy";                       
var text02 = "G&uuml;&yacute;&ccedil;:";
var text03 = "Bur&ccedil;laryn ululygy:";
var text04 = "1-nji bur&ccedil;:";
var text05 = "2-nji bur&ccedil;:";
var text06 = "Komponentlaryn ululygy:";
var text07 = "1-nji komponent";
var text08 = "2-nji komponent";
var text09 = "Tap komponentleri";
var text10 = "Gurlusy arassala";

var author = "W. Fendt 2003";
var translator = "Translated by PICT Turkmenistan";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                           
var newton = "N";                               

// Texte in Unicode-Schreibweise:

var text11 = "1-nji komponent";                            // Text f�r erste Komponente
var text12 = "2-nji komponent";                            // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                        