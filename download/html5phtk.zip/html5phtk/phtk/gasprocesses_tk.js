// Spezielle Prozesse eines idealen Gases, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 10.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Izobar prosess";
var text02 = "Izohor prosess";
var text03 = "Isotermik prosess";
var text04 = "Basdaky &yacute;agda&yacute;:";
var text05 = "Basy&scedil;:";
var text06 = "G&ouml;wr&uuml;m:";
var text07 = "Temperatura:";
var text08 = "Final &yacute;agda&yacute;:";
var text09 = "Basdaky &yacute;agda&yacute;";
var text10 = "Start";

var author = "W. Fendt 1999,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Isle";
var text12 = "Gyzdyr";
var text13 = "Gazyn i\u00E7ki energi\u00FDasy";
var text14 = "ulal\u00FDar.";
var text15 = "Gazyn i\u00E7ki energi\u00FDasy";
var text16 = "hemi\u015Felik.";
var text17 = "Gazyn i\u00E7ki energi\u00FDasy";
var text18 = "pesel\u00FD\u00E4r.";
var text19 = "Basy\u015F juda ki\u00E7i!";
var text20 = "Basy\u015F juda uly!";
var text21 = "G\u00F6wr\u00FCm juda ki\u00E7i!";
var text22 = "G\u00F6wr\u00FCm juda uly!";
var text23 = "Temperatura juda ki\u00E7i!";
var text24 = "Temperatura juda uly!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


