// Kombinationen von Widerst�nden, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 20.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = "Napr&yacute;a&zcaron;enie batare&yacute;anky:";
var text03 = "Garsylyk:";
var text04 = "Gos rezistory (Yzygider birlesdirme)";
var text05 = "Gos rezistory (Parallel birlesdirme)";
var text06 = "&Ouml;l&ccedil;e&yacute;ji:";
var text07 = "Napr&yacute;a&zcaron;enie";
var text08 = "Tok g&uuml;&yacute;ji";

var author = "W. Fendt 2002";
var translator = "Translated by PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text09 = "Napr\u00FDa\u017Eenie:";
var text10 = "Tok g\u00FC\u00FDji:";
var text11 = "Garsylyk:";
var text12 = "Ekwiwalent garsylyk:";
var text13 = "\u00F6r\u00E4n ki\u00E7i";
var text14 = "\u00F6r\u00E4n uly";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

