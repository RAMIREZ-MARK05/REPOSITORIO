// Schiefer Wurf, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";                    
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];          
var text03 = "Ha&yacute;al hereket";
var text04 = "Basdaky be&yacute;klik:";
var text05 = "Basdaky tizlik:";
var text06 = "&Yacute;apgytlyk bur&ccedil;y:";
var text07 = "Massa:"; 
var text08 = "Agyrlyk g&uuml;&yacute;&ccedil; astynda tizlenme:";
var text09 = "&Yacute;agda&yacute;";
var text10 = "Tizlik";
var text11 = "Tizlenme";
var text12 = "G&uuml;&yacute;&ccedil;";
var text13 = "Energi&yacute;a";

var author = "W. Fendt 2000,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:  

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                     
var meterPerSecond = "m/s";                           
var meterPerSecond2 = "m/s&sup2;";                    
var kilogram = "kg";                                  
var degree = "&deg;";                                 

// Texte in Unicode-Schreibweise:

var text14 = "(m)";                                        // Einheitenangabe f�r Koordinatenachsen 
var text15 = "\u00DDagda\u00FD:";
var text16 = "(gorizontal)";
var text17 = "(wertical)";
var text18 = "Gorizontal aralyk:";
var text19 = "Maksimum be\u00FDklik:";
var text20 = "Wagt:";
var text21 = "Tizlik komponentleri:";
var text22 = "Tizlik ululygy:";
var text23 = "\u00DDapgytlyk bur\u00E7y:";
var text24 = "Tizlenme:";
var text25 = "G\u00FC\u00FD\u00E7:";
var text26 = "Kinetik energi\u00FDa:";
var text27 = "Potensial energi\u00FDa:";
var text28 = "Jemi energi\u00FDa:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                             
var secondUnicode = "s";                            
var meterPerSecondUnicode = "m/s";                  
var meterPerSecond2Unicode = "m/s\u00B2";           
var newtonUnicode = "N";                            
var jouleUnicode = "J";                             
var degreeUnicode = "\u00B0";                       



