// Resonanz, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];
var text03 = "Ha&yacute;al hereket";
var text04 = "Rezonator:";
var text05 = "Pru&zcaron;in hemi&scedil;eligi:";
var text06 = "Massa:";
var text07 = "In&ccedil;elmesi:";
var text08 = "Tolkundyryjy:";
var text09 = "Bur&ccedil; &yacute;ygylyk:";
var text10 = "Uzalma diagramma";
var text11 = "Amplituda diagrammasy";
var text12 = "Faza aratapawudyn diagrammasy";

var author = "W. Fendt 1998,&nbsp; PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                              
var newtonPerMeter = "N/m";                       
var perSecond = "1/s";                             
var radPerSecond = "rad/s";                         

// Texte in Unicode-Schreibweise:

var text13 = "Rezonans hel\u00E4k\u00E7iligi!";
var text14 = "(Simul\u00FDasi\u00FDa indi hakyky d\u00E4l!)";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                                
var radPerSecondUnicode = "rad/s";                    


