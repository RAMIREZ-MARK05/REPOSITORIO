// Kreisbewegung mit konstanter Winkelgeschwindigkeit, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 22.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = ["Ba&scedil;la", "Arakesme", "Dowam et"];
var text03 = "Ha&yacute;al hereket";
var text04 = "Radius:";
var text05 = "Period:";
var text06 = "Massa:";
var text07 = "&Yacute;agda&yacute;";
var text08 = "Tizlik";
var text09 = "Tizlenme";
var text10 = "G&uuml;&yacute;&ccedil;";

var author = "W. Fendt 2007";
var translator = "Translated by PICT Turkmenistan";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                   
var second = "s";                                  
var kilogram = "kg";                               

// Texte in Unicode-Schreibweise:

var text11 = "\u00DDagda\u00FD:";
var text12 = "Tizlik:";
var text13 = "Bur\u00E7ly tizlik:";
var text14 = "Merkeze ymtyl\u00FDan tizlenme:";
var text15 = "Merkeze ymtyl\u00FDan g\u00FC\u00FD\u00E7:";
var text16 = "(s)";
var text17 = "(m)";
var text18 = "(m/s)";
var text19 = "(m/s\u00b2)";
var text20 = "(N)";
var text21 = "(x komponent)";
var text22 = "(y komponent)";
var text23 = "(ululygy)";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03c9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "m";                           
var meterPerSecond = "m/s";                       
var meterPerSecond2 = "m/s\u00b2";                
var newton = "N";                                 
var radPerSecond = "rad/s";                       




