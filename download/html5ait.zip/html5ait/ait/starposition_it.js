// Position eines Gestirns, italienische Texte und Defaultwerte
// Letzte �nderung 22.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Longitudine:";
var text03 = "Latitudine:";
var text05 = "Data:";
var text06 = "Tempo:";
var text07 = "h (CET)";
var text08 = "Ascensione retta:";
var text09 = "Declinazione:";
var text10 = "Reset";
var text11 = ["Avanti", "Pausa", "Riprendi"];
var text12 = "Evidenziare:"; // ???

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var dateSeparator = ".";
var timeSeparator = ":";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var text02 = ["(est)", "(ovest)"];
var text04 = ["(nord)", "(sud)"];
var text13 = ["", "osservatore", "orizzonte",
              "punto nord", "punto ovest", "punto sud", "punto est", 
              "zenit", "nadir", "meridiano", "cerchio verticale",
              "polo celeste nord", "polo celeste sud", "asse celeste", "equatore celeste",
              "punto vernale", "cerchio orario", "tempo siderale",
              "angolo orario", "stella", "traccia della stella",
              "ascensione retta", "declinazione", "azimut", "altezza", "triangolo di posizione"];
var text14 = "Tempo:";
var text15 = "Tempo siderale:";
var text16 = "Azimut:";
var text17 = "Angolo orario:";
var text18 = "Altezza:";

// Symbole und Einheiten:

var symbolObserver = "O";                                  // Beobachtungsort
var symbolNorth = "N";                                     // Nordpunkt
var symbolWest = "W";                                      // Westpunkt
var symbolSouth = "S";                                     // S�dpunkt
var symbolEast = "E";                                      // Ostpunkt
var symbolZenith = "Ze";                                   // Zenit
var symbolNadir = "Na";                                    // Nadir
var symbolNorthPole = "PN";                                // Himmelsnordpol
var symbolSouthPole = "PS";                                // Himmelss�dpol
var symbolVernalEquinox = "V";                             // Fr�hlingspunkt
var symbolStar = "St";                                     // Stern
var symbolHour = "h";                                      // Stunde

// Defaultwerte:

var defaultLongitude = 12*DEG;                             // Geographische L�nge (London)
var defaultLatitude = 42*DEG;                              // Geographische Breite (London)
var defaultDay = 1;                                        // Tag
var defaultMonth = 1;                                      // Monat
var defaultYear = 2000;                                    // Jahr
var defaultTimeZone = 1;                                   // Zeitzone relativ zu UT (h)
