// Himmelspole, italienische Texte
// Letzte �nderung 22.01.2021

// Texte in Unicode-Schreibweise:

var text01 = "equatore";
var	text02 = "Polo Nord";
var text03 = "Polo Sud";
var text04 = "asse terrestre";
var text05 = "piano orizzontale";
var text06 = "sfera celeste";
var	text07 = "zenit";
var text08 = "polo celeste Nord";
var	text09 = "polo celeste Sud";
var text10 = "nord";
var text11 = "sud";

var author = "W. Fendt 1998";
