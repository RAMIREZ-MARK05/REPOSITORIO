// 1. und 2. Ableitungsfunktion, franz�sische Texte
// Letzte �nderung 25.02.2020

// Texte in HTML-Schreibweise:

var text01 = "&Eacute;quation de la fonction:";
var text02 = "f(x) =";
var text03 = "D&eacute;riv&eacute;e premi&egrave;re";
var text04 = "D&eacute;riv&eacute;e seconde";
var text05 = "Bord gauche:";
var text06 = "Bord droit:";
var text07 = "Bord inf&eacute;rieur:";
var text08 = "Bord sup&eacute;rieur:";
var text09 = "Repr&eacute;sentation graphique";

var author = "W. Fendt 1999";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text10 = "\u00C9quation incorrecte!";
var text11 = "Erreur de diff\u00E9rentiation!";

var symbolX = "x";
var symbolY = "y";
