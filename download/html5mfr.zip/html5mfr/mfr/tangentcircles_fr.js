// Ber�hrkreise, franz�sische Texte
// Letzte �nderung 25.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Donn&eacute;:";
var text02 = "Deux points";
var text03 = "Point et droite";
var text04 = "Point et cercle";
var text05 = "Deux droites";
var text06 = "Droite et cercle";
var text07 = "Deux cercles";

var author = "W. Fendt 2017";

