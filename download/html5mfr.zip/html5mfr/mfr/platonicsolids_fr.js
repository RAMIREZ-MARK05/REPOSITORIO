// Platonische K�rper, franz�sische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Tetra&egrave;dre";
var text02 = "Hexa&egrave;dre (cube)";
var text03 = "Octa&egrave;dre";
var text04 = "Dod&eacute;ca&egrave;dre";
var text05 = "Icosa&egrave;dre";
var text06 = "Changer l'axe de rotation";
var text07 = "Sph&egrave;re circonscrite";
var text08 = "Sph&egrave;re moyenne";
var text09 = "Sph&egrave;re inscrite";

var author = "W. Fendt 1998";
