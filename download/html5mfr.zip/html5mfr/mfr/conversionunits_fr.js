// Umrechnung von Einheiten, franz�sische Texte
// Letzte �nderung 25.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = "D&eacute;marrer";
var text03 = "Longueur";
var text04 = "Aire";
var text05 = "Volume";
var text06 = "Masse";
var text07 = "Temps";
var text08 = "Niveau de difficult&eacute;:";

// Texte in Unicode-Schreibweise

var text09 = ["1 t\u00E2che", 
              "x t\u00E2ches"];  
var text10 = ["1 hit", 
              "x hits"];        
     
var author = "W. Fendt 2001";                              // Autor (und �bersetzer)

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

