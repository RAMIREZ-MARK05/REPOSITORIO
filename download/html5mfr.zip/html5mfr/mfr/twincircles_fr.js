// Zwillingskreise des Archimedes, franz�sische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Lignes auxiliaires:";
var text02 = "&agrave; gauche";
var text03 = "&agrave; droite";

var author = "W. Fendt 2000";
