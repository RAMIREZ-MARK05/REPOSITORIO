// Besondere Linien und Kreise im Dreieck, franz�sische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "M&eacute;diatrices";
var text02 = "Cercle circonscrit";
var text03 = "Bissectrices";
var text04 = "Cercle inscrit";
var text05 = "Cercles exinscrits";
var text06 = "Triangle des milieux";
var text07 = "M&eacute;dianes";
var text08 = "Hauteurs";
var text09 = "Droite d'Euler";
var text10 = "Cercle d'Euler";

var author = "W. Fendt 1998";
var translator = "";
