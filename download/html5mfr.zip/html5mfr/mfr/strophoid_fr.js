// Gerade Strophoide, franz�sische Texte
// Letzte �nderung 09.11.2020

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;but", "Pause", "Recommence"];  

var author = "W. Fendt 2020";    

                




