// Primzahlentabelle, franz�sische Texte
// Letzte �nderung 22.01.2016

var textError = "Erreur!";                                 // Text f�r Fehlermeldung
var textPrime = "est un nombre premier.";                  // Text f�r Primzahl
var symbolMult = "&times;";                                // Multiplikationszeichen (HTML)
