// Regelm��ige Vielecke, franz�sische Texte
// Letzte �nderung 25.02.2020

// Texte in HTML-Schreibweise:

var text11 = "Nombre de sommets:";
var text12 = "Cercle circonscrit";
var text13 = "Cercle inscrit";
var text14 = "Triangles";
var text15 = "Diagonales";

var text21 = "Symbole de Schl&auml;fli:";

var author = "W. Fendt 2018";
var translator1 = "";
var translator2 = "";





