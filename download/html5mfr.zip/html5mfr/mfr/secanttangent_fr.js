// Sekanten- und Tangentensteigung, franz�sische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Point fix&eacute;:";
var text02 = "Point variable:";
var text03 = "Pente de la s&eacute;cante:";
var text04 = "Pente de la tangente:";

var author = "W. Fendt 1998";
var translator = "";

var decimalSeparator = ",";                      // Dezimaltrennzeichen (Komma oder Punkt)
var textUndefValue = "non d&eacute;fini";        // Text f�r "nicht definiert"
