// Primyphos, franz�sische Texte (unter anderem DeepL)
// Letzte �nderung 25.02.2020

// Texte in HTML-Schreibweise:

var text01 = "D&eacute;composer en facteurs:";

var author = "W. Fendt 1998";

var symbolMultiply = "&times;";

// Texte in Unicode-Schreibweise:

var text02 = ["F&eacute;licitations!", 
              "C'&eacute;tait g&eacute;nial!", 
              "Remarquable!", 
              "Pas trop mal!", 
              "Une grande r&eacute;ussite!", 
              "Impressionnant!",
              "Fantastique!"];
              
var text03 = ["Si vous voulez relancer le jeu:",
              "Un clic de souris suffit!"];

var symbolMultiplyUnicode = "\u00D7";


