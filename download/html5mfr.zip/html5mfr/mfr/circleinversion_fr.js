// Kreisspiegelung, franz�sische Texte
// Letzte �nderung 25.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Nouvelle esquisse"; // ???
var text03 = "Ajouter";
var text04 = "Effacer";
var text05 = "Image";

var author = "W. Fendt 2017";
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["point", "droite", "demi-droite", "segment", "cercle", "triangle", "quadrilat\u00E8re"];

