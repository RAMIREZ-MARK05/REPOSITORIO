// Winkel am Kreis, franz�sische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Valeur del'angle:";
var text02 = "Angle au centre:";
var text03 = "Angle inscrit:";
var text04 = "Angle de la corde et d'une tangente:";

var author = "W. Fendt 1997";
var translator = "";
