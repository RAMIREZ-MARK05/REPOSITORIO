// Tangenten von Funktionsgraphen, franz�sische Texte
// Letzte �nderung 25.02.2020

// Texte in HTML-Schreibweise:

var text01 = "&Eacute;quation de la fonction:";
var text02 = "f(x) =";
var text03 = "Bord gauche:";
var text04 = "Bord droit:";
var text05 = "Bord inf&eacute;rieur:";
var text06 = "Bord sup&eacute;rieur:";
var text07 = "Repr&eacute;sentation graphique";

var author = "W. Fendt 2017";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text08 = "\u00C9quation incorrecte!";
var text09 = "Erreur de diff\u00E9rentiation!";

var symbolX = "x";
var symbolY = "y";
