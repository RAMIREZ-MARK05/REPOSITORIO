// Geradengleichung, franz�sische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Point A:";
var text02 = "Point B:";

//var decimalSeparator = ",";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text03 = "Droite AB pas d\u00E9fini!";

var symbolPoint1 = "A";
var symbolPoint2 = "B";
var symbolX = "x_1";
var symbolY = "x_2";
var symbolZ = "x_3";
var symbolPositionVector = "X";
var symbolParameter = "\u03BB";
