// Winkelfunktionen am Einheitskreis, franz�sische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Sinus";
var text02 = "Cosinus";
var text03 = "Tangente";

var author = "W. Fendt 1997";
var translator = "";

var decimalSeparator = ",";                      // Dezimaltrennzeichen (Komma)

// Texte in Unicode-Schreibweise:

var symbolSine = "sin";                          // Symbol f�r Sinus
var symbolCosine = "cos";                        // Symbol f�r Cosinus
var symbolTangent = "tan";                       // Symbol f�r Tangens
var undef = "pas d\u00E9fini";                   // F�r Definitionsl�cken der Tangensfunktion
