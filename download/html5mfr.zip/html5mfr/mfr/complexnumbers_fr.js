// Rechnen mit komplexen Zahlen, franz�sische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Op&eacute;ration:";
var text02 = "Addition";
var text03 = "Soustraction";
var text04 = "Multiplication";
var text05 = "Division";
var text06 = "Syst&egrave;me de coordonn&eacute;es:";
var text07 = "Coordonn&eacute;es cart&eacute;siennes";
var text08 = "Coordonn&eacute;es polaires";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1998";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "non d\u00E9fini!";

var symbolOperation = ["+", "\u2212", "\u00B7", ":"];      // Rechenzeichen
