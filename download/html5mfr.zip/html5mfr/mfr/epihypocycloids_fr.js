// Epizykloiden und Hypozykloiden, franz�sische Texte
// Letzte �nderung 24.02.2020

// Texte in HTML-Schreibweise:

var text01 = "&Eacute;picyclo&iuml;de";
var text02 = "Hypocyclo&iuml;de";
var text03 = "Ratio des rayons:";
var text04 = "Remise &agrave; z&eacute;ro";
var text05 = ["D&eacute;but", "Pause", "Recommence"];  

var author = "W. Fendt 2017";    

// Texte in Unicode-Schreibweise:

var text06 = "Cas particulier: Cardio\u00EFde";  
var text07 = "Cas particulier: N\u00E9phro\u00EFde";
var text08 = "Cas particulier: Diam\u00E8tre du cercle";
var text09 = "Cas particulier: Delto\u00EFde";
var text10 = "Cas particulier: Astro\u00EFde";                   




