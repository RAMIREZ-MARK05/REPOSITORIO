// Einfache geometrische Abbildungen, franz�sische Texte
// Letzte �nderung 25.02.2020

// Texte in HTML-Schreibweise:

var text02 = "Nouvelle esquisse"; // ???
var text04 = "Ajouter";
var text05 = "Effacer";
var text06 = "Image";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text01 = ["r\u00E9flexion axiale", "r\u00E9flexion centrale" /* ??? */, "translation", "rotation"];
var text03 = ["point", "droite", "demi-droite", "segment", "cercle", "triangle", "quadrilat\u00E8re"];

