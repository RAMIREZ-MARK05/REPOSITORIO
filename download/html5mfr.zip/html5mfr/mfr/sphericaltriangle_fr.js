// Kugeldreieck, franz�sische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "C&ocirc;t&eacute;s:";
var text02 = "a = ";
var text03 = "b = ";
var text04 = "c = ";
var text05 = "Somme des c&ocirc;t&eacute;s: ";
var text06 = "Angles:";
var text07 = "&alpha; = ";
var text08 = "&beta; = ";
var text09 = "&gamma; = ";
var text10 = "Somme des angles: ";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var symbolA = "A";
var symbolB = "B";
var symbolC = "C";


