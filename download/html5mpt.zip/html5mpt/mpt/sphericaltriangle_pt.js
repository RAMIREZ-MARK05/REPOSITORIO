// Kugeldreieck, portugiesische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Lados:";
var text02 = "a = ";
var text03 = "b = ";
var text04 = "c = ";
var text05 = "Soma dos lados: ";
var text06 = "&Acirc;ngulos:";
var text07 = "&alpha; = ";
var text08 = "&beta; = ";
var text09 = "&gamma; = ";
var text10 = "Soma dos &acirc;ngulos: ";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var symbolA = "A";
var symbolB = "B";
var symbolC = "C";


