// Platonische K�rper, portugiesische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Tetraedro";
var text02 = "Hexaedro (cubo)";
var text03 = "Octaedro";
var text04 = "Dodecaedro";
var text05 = "Icosaedro";
var text06 = "Modificar o eixo de rota&ccedil;&atilde;o"; // ???
var text07 = "Raio da esfera circunscrita";
var text08 = "Raio da esfera tangente a todas as arestas";
var text09 = "Raio da esfera inscrita";

var author = "W. Fendt 1998";
