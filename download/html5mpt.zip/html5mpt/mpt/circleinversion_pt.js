// Kreisspiegelung, portugiesische Texte
// Letzte �nderung 01.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Novo desenho";
var text03 = "Adicionar";
var text04 = "Apagar";
var text05 = "Imagem";

var author = "W. Fendt 2017";
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["ponto", "reta", "semirreta", "segmento de reta", "circunfer\u00EAncia", "tri\u00E2ngulo", "quadril\u00E1tero"];

