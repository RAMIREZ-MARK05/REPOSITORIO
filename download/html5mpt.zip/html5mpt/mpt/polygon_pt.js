// Regelm��ige Vielecke, portugiesische Texte
// Letzte �nderung 01.03.2020

// Texte in HTML-Schreibweise:

var text11 = "N&uacute;mero de v&eacute;rtices:";
var text12 = "Circunfer&ecirc;ncia circunscrita";
var text13 = "Circunfer&ecirc;ncia inscrita";
var text14 = "Tri&acirc;ngulos";
var text15 = "Diagonais";

var text21 = "S&iacute;mbolo de Schl&auml;fli:";

var author = "W. Fendt 2018";
var translator1 = "";
var translator2 = "";





