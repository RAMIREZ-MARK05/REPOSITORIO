// Geradengleichung, portugiesische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Ponto A:";
var text02 = "Ponto B:";

//var decimalSeparator = ",";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text03 = "Reta AB n\u00E3o definida!";

var symbolPoint1 = "A";
var symbolPoint2 = "B";
var symbolX = "x_1";
var symbolY = "x_2";
var symbolZ = "x_3";
var symbolPositionVector = "X";
var symbolParameter = "\u03BB";
