// Rechnen mit komplexen Zahlen, portugiesische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Opera&ccedil;&atilde;o:";
var text02 = "adi&ccedil;&atilde;o";
var text03 = "subtra&ccedil;&atilde;o";
var text04 = "multiplica&ccedil;&atilde;o";
var text05 = "divis&atilde;o";
var text06 = "Sistema de coordenadas:";
var text07 = "Coordenadas cartesianas";
var text08 = "Coordenadas polares";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1998";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "n\u00E3o definido!";

var symbolOperation = ["+", "\u2212", "\u00B7", ":"];      // Rechenzeichen
