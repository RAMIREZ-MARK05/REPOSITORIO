// Winkel am Kreis, portugiesische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Medida do &acirc;ngulo:";
var text02 = "&Acirc;ngulo central:";
var text03 = "&Acirc;ngulo inscrito:";
var text04 = "&Acirc;ngulo entre a corda e a tangente:";

var author = "W. Fendt 1997";
var translator = "";
