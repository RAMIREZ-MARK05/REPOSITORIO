// Umrechnung von Einheiten, portugiesische Texte
// Letzte �nderung 10.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Start";
var text03 = "Comprimento";
var text04 = "&Aacute;rea";
var text05 = "Volume";
var text06 = "Massa";
var text07 = "Tempo";
var text08 = "Grau de dificuldade:";
var text09 = ["1 problema", 
              "x problemas"]; 
var text10 = ["1 correcto", 
              "x correctos"];
     
var author = "W. Fendt 2001";                              // Autor (und �bersetzer)

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

