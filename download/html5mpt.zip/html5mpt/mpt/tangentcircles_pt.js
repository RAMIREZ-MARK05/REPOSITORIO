// Ber�hrkreise, portugiesische Texte
// Letzte �nderung 01.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Objectos dados:";
var text02 = "Dois pontos";
var text03 = "Ponto e reta";
var text04 = "Ponto e circunfer&ecirc;ncia";
var text05 = "Duas retas";
var text06 = "Reta e circunfer&ecirc;ncia";
var text07 = "Duas circunfer&ecirc;ncias";

var author = "W. Fendt 2017";

