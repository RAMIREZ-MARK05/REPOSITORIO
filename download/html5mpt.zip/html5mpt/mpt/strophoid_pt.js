// Gerade Strophoide, portugiesische Texte
// Letzte �nderung 06.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];  

var author = "W. Fendt 2020";    

                




