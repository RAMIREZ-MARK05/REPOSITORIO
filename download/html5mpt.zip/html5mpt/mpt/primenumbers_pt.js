// Primzahlentabelle, portugiesische Texte
// Letzte �nderung 21.01.2016

var textError = "Error!";                                  // Text f�r Fehlermeldung (?)
var textPrime = "&eacute; um n&uacute;mero primo.";        // Text f�r Primzahl
var symbolMult = "&middot;";                               // Multiplikationszeichen (HTML)
