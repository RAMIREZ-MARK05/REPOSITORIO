// Winkel an parallelen Geraden, portugiesische Texte
// Letzte �nderung 01.03.2020

// Texte in HTML-Schreibweise:

var text01 = "&Acirc;ngulos correspondentes";
var text02 = "&Acirc;ngulos alternos (int./ext.)";
var text03 = "&Acirc;ngulos conjugados internos"; // ???
var text05 = "Algarismos decimais:";
var text06 = "Medidas dos &acirc;ngulos:";

var author = "W. Fendt 2006";
var translator = "";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text04 = ["1st pair of angles", "2nd pair of angles", "3rd pair of angles", "4th pair of angles"];

var angle1 = ["\u03B1",                                    // Alpha 
              "\u03B2",                                    // Beta
              "\u03B3",                                    // Gamma
              "\u03B4"];                                   // Delta
              
var angle2 = ["\u03B1'",                                   // Alpha Strich 
              "\u03B2'",                                   // Beta Strich
              "\u03B3'",                                   // Gamma Strich
              "\u03B4'"];                                  // Delta Strich
              

