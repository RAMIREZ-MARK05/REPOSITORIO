// Tangenten von Funktionsgraphen, portugiesische Texte
// Letzte �nderung 01.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Equa&ccedil;&atilde;o da fun&ccedil;&atilde;o:";
var text02 = "f(x) =";
var text03 = "Margem esquerda:";
var text04 = "Margem direita:";
var text05 = "Margem inferior:";
var text06 = "Margem superior:";
var text07 = "Desenhar";

var author = "W. Fendt 2017";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text08 = "Equa\u00E7\u00E3o incorreta!";
var text09 = "Erro na differencia\u00E7\u00E3o!";

var symbolX = "x";
var symbolY = "y";
