// Sekanten- und Tangentensteigung, portugiesische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Ponto fixo:";
var text02 = "Ponto vari&aacute;vel:";
var text03 = "Declive da secante:";
var text04 = "Declive da tangente:";

var author = "W. Fendt 1998";
var translator = "";

var decimalSeparator = ",";                      // Dezimaltrennzeichen (Komma oder Punkt)
var textUndefValue = "n\u00E3o definido";        // Text f�r "nicht definiert"
