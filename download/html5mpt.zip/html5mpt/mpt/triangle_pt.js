// Besondere Linien und Kreise im Dreieck, portugiesische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Mediatrizes";
var text02 = "Circunfer&ecirc;ncia circunscrita";
var text03 = "Bissetrizes";
var text04 = "Circunfer&ecirc;ncia inscrita";
var text05 = "Circunfer&ecirc;ncias exinscritas";
var text06 = "Bases m&eacute;dias"; 
var text07 = "Medianas";
var text08 = "Alturas";
var text09 = "Reta de Euler";
var text10 = "Circunfer&ecirc;ncia dos nove pontos";

var author = "W. Fendt 1998";
var translator = "";
