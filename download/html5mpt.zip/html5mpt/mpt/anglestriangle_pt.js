// Innenwinkelsumme eines Dreiecks, portugiesische Texte (www.saladematematica.com.br)
// Letzte �nderung 01.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Medidas dos &acirc;ngulos internos:";
var text02 = "Algarismos decimais:";

var author = "W. Fendt 1998";
var translator = "";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Winkelgrad

// Texte in Unicode-Schreibweise:

var angle1 = ["\u03B1",                                    // Alpha 
              "\u03B2",                                    // Beta
              "\u03B3"];                                   // Gamma
              
var angle2 = ["\u03B1'",                                   // Alpha Strich 
              "\u03B2'"];                                  // Beta Strich
              
var vertex = ["A", "B", "C"];                              // Ecken

        
              

