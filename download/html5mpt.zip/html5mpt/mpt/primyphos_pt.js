// Primyphos, portugiesische Texte
// Letzte �nderung 01.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Escreva como produto:";

var author = "W. Fendt 1998";

var symbolMultiply = "&times;";

// Texte in Unicode-Schreibweise:

var text02 = ["Parab\u00E9ns!", 
              "Foi espectacular!", 
              "Excelente!", 
              "Nada mal!", 
              "Bem feito!", 
              "Impressionante!",
              "Fant\u00E1stico!"];
              
var text03 = ["Se queres reiniciar o jogo:",
              "Um clique do rato \u00E9 suficiente!"];

var symbolMultiplyUnicode = "\u00D7";
