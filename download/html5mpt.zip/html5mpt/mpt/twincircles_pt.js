// Zwillingskreise des Archimedes, portugiesische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Linhas:"; // ???
var text02 = "&agrave; equerda";
var text03 = "&agrave; direita";

var author = "W. Fendt 2000";
