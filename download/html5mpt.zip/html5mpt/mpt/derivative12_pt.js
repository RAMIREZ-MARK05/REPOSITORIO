// 1. und 2. Ableitungsfunktion, portugiesische Texte
// Letzte �nderung 01.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Equa&ccedil;&atilde;o da fun&ccedil;&atilde;o:";
var text02 = "f(x) =";
var text03 = "Primeira derivada";
var text04 = "Segunda derivada";
var text05 = "Margem esquerda:";
var text06 = "Margem direita:";
var text07 = "Margem inferior:";
var text08 = "Margem superior:";
var text09 = "Desenhar";

var author = "W. Fendt 1999";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text10 = "Equa\u00E7\u00E3o incorreta!";
var text11 = "Erro na differencia\u00E7\u00E3o!";

var symbolX = "x";
var symbolY = "y";
