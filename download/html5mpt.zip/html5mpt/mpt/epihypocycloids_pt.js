// Epizykloiden und Hypozykloiden, portugiesische Texte
// Letzte �nderung 29.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Epicicloide";
var text02 = "Hipocicloide";
var text03 = "Raz&atilde;o de raios:";
var text04 = "Reset";
var text05 = ["Start", "Pausa", "Continuar"];  

var author = "W. Fendt 2017";    

// Texte in Unicode-Schreibweise:

var text06 = "Caso especial: Cardioide";  
var text07 = "Caso especial: Nefroide";
var text08 = "Caso especial: Di\u00E2metro do c\u00EDrculo";
var text09 = "Caso especial: Curva deltoide";
var text10 = "Caso especial: Astroide";                   




