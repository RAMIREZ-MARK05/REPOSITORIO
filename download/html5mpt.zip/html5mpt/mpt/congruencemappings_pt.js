// Einfache geometrische Abbildungen, portugiesische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text02 = "Novo desenho"; 
var text04 = "Adicionar";  
var text05 = "Apagar"; 
var text06 = "Imagem";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text01 = ["reflex\u00E3o axial", "reflex\u00E3o central", "transla\u00E7\u00E3o", "rota\u00E7\u00E3o"];
var text03 = ["ponto", "reta", "semirreta", "segmento de reta", "circunfer\u00EAncia", "tri\u00E2ngulo", "quadril\u00E1tero"];

