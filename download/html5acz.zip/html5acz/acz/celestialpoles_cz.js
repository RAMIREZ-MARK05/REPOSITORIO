// Himmelspole, tschechische Texte (Miroslav Panos)
// Letzte �nderung 20.11.2017

// Texte in Unicode-Schreibweise:

var text01 = "Rovn\u00EDk";
var text02 = "Severn\u00ED p\u00F3l";
var text03 = "Ji\u017En\u00ED p\u00F3l";
var text04 = "Zemsk\u00E1 osa";
var text05 = "Vodorovn\u00E1 rovina";
var text06 = "Sv\u011Btov\u00E1 sf\u00E9ra";
var	text07 = "Zenit";
var text08 = "Sv\u011Btov\u00FD severn\u00ED p\u00F3l";
var	text09 = "Sv\u011Btov\u00FD ji\u017En\u00ED p\u00F3l";
var text10 = "Sever";
var text11 = "Jih";

var author = "W. Fendt 1998,\u0020 M. Pano\u0161 2016";
