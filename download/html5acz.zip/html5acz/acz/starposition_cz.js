// Position eines Gestirns, tschechische Texte (Miroslav Panos)
// Letzte �nderung 20.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Zem&ecaron;pisn&aacute; d&eacute;lka:";
var text03 = "Zem&ecaron;pisn&aacute; &scaron;&iacute;&rcaron;ka:";
var text05 = "Datum:";
var text06 = "\u010Cas:";
var text07 = "hod. (SE\u010C)";
var text08 = "Rektascenze:";
var text09 = "Deklinace:";
var text10 = "Reset";
var text11 = ["Start", "Zastavit", "D\u00E1le"];
var text12 = "Zv\u00FDraznit:";

var author = "W. Fendt 1999,&nbsp; M. Pano&scaron; 2016";

// Symbole und Einheiten:

var dateSeparator = ".";
var timeSeparator = ":";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var text02 = ["(v\u00FDchodn\u00ED d\u00E9lka)", "(z\u00E1padn\u00ED d\u00E9lka)"];
var text04 = ["(severn\u00ED \u0161\u00ED\u0159ka)", "(ji\u017En\u00ED \u0161\u00ED\u0159ka)"];
var text13 = ["", "M\u00EDsto pozorov\u00E1n\u00ED", "Obzorn\u00EDk (Horizont)", "Severn\u00ED bod", "Z\u00E1padn\u00ED bod", 
              "Ji\u017En\u00ED bod", "V\u00FDchodn\u00ED bod", "Zenit", "Nadir", "M\u00EDstn\u00ED poledn\u00EDk", "V\u00FD\u0161kov\u00E1 kru\u017Enice", 
              "Severn\u00ED sv\u011Btov\u00FD p\u00F3l", "Ji\u017En\u00ED sv\u011Btov\u00FD p\u00F3l", "Sv\u011Btov\u00E1 osa", "Sv\u011Btov\u00FD rovn\u00EDk", 
              "Jarn\u00ED bod", "Deklina\u010Dn\u00ED kru\u017Enice", "Hv\u011Bzdn\u00FD \u010Das", "Hodinov\u00FD \u00FAhel", "Hv\u011Bzda", 
              "Dr\u00E1ha hv\u011Bzdy", "Rektascenze", "Deklinace", "Azimut", "V\u00FD\u0161ka hv\u011Bzdy", "Nautisk\u00FD troj\u00FAheln\u00EDk"];
var text14 = "Denn\u00ED doba:";
var text15 = "Hv\u011Bzdn\u00FD \u010Das:";
var text16 = "Azimut:";
var text17 = "Hodinov\u00FD \u00FAhel:";
var text18 = "V\u00FD\u0161ka hv\u011Bzdy:";

// Symbole und Einheiten:

var symbolObserver = "P";                                  // Beobachtungsort
var symbolNorth = "S";                                     // Nordpunkt
var symbolWest = "Z";                                      // Westpunkt
var symbolSouth = "J";                                     // S�dpunkt
var symbolEast = "V";                                      // Ostpunkt
var symbolZenith = "Ze";                                   // Zenit
var symbolNadir = "Na";                                    // Nadir
var symbolNorthPole = "SSP";                               // Himmelsnordpol
var symbolSouthPole = "JSP";                               // Himmelss�dpol
var symbolVernalEquinox = "JB";                            // Fr�hlingspunkt
var symbolStar = "Hv";                                     // Stern
var symbolHour = "h";                                      // Stunde

// Defaultwerte:

var defaultLongitude = 10*DEG;                             // Geographische L�nge (Frankfurt)
var defaultLatitude = 50*DEG;                              // Geographische Breite (Frankfurt)
var defaultDay = 1;                                        // Tag
var defaultMonth = 1;                                      // Monat
var defaultYear = 2000;                                    // Jahr
var defaultTimeZone = 1;                                   // Zeitzone relativ zu UT (h)
