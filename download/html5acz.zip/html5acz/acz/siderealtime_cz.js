// Online-Rechner Sternzeit, tschechische Texte (Miroslav Panos)
// Letzte �nderung 29.05.2023

var english = false;                                       // F�r die Reihenfolge beim Datum

// Texte in HTML-Schreibweise:

var text01 = "Datum (UT):";
var text02 = "&Ccaron;as (UT):";
var text03 = "Zem&ecaron;pisn&aacute; d&eacute;lka:";
var text04 = "Juli&aacute;nsk&eacute; datum (JD):";
var text05 = "Greenw. st&rcaron;edn&iacute; hv&ecaron;zdn&yacute; &ccaron;as (GMST):";
var text06 = "M&iacute;stn&iacute; st&rcaron;edn&iacute; slune&ccaron;n&iacute; &ccaron;as (LMST):";
var text07 = "OK";
var text08 = ["v. d.", "z. d."];

var author = "W. Fendt, M. Pano&scaron; 2023";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var dateSeparator = ".";                                   // Trennzeichen Datum
var timeSeparator = ":";                                   // Trennzeichen Uhrzeit
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var unitHour = "h";
var unitMinute = "min";
var unitSecond = "s";
var unitDeg = "\u00B0";
var unitArcMin = "'";
var unitArcSec = "''";


