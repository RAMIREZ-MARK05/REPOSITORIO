// Julianisches Datum, tschechische Texte (Miroslav Panos)
// Letzte �nderung 29.05.2023

var english = false;

// Texte in HTML-Schreibweise:

var text01 = "V&yacute;po&ccaron;et juli&aacute;nsk&eacute;ho data";
var text02 = "V&yacute;po&ccaron;et kalend&aacute;&rcaron;n&iacute;ho data a &ccaron;asu";

var text03 = "&Ccaron;asov&eacute; p&aacute;smo:";
var text07 = "Datum:";
var text09 = "&Ccaron;as:";
var text10 = "Juli&aacute;nsk&eacute; datum (UTC):";
var text11 = "OK";

var author = "W. Fendt 2022, M. Pano&scaron; 2023";

// Texte in Unicode-Schreibweise:

var text04 = ["UTC", "UTC + 1 h", "UTC + 2 h"];
var text05 = ["Z\u00E1padoevropsk\u00FD \u010Das (ZE\u010C)",
              "St\u0159edoevropsk\u00FD \u010Das (SE\u010C)",
              "V\u00FDchodoevropsk\u00FD \u010Das (VE\u010C)"];
var text06 = ["Greenwichsk\u00FD st\u0159edn\u00ED \u010Das (GMT)",
              "Z\u00E1padoevropsk\u00FD letn\u00ED \u010Das (ZEL\u010C)",
              "St\u0159edoevropsk\u00FD letn\u00ED \u010Das (SEL\u010C)"];
var text08 = ["p\u0159. n. l.", "n. l."];

var errorDate = "Zad\u00E1n\u00ED neplatn\u00E9ho data!";

// Symbole und Einheiten:

var dateSeparator = ".";                                   // Trennzeichen Datum
var timeSeparator = ":";                                   // Trennzeichen Uhrzeit
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var unitHour = "h";
var unitMinute = "min";
var unitSecond = "s";


