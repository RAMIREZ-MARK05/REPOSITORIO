// Position eines Gestirns, franz�sische Texte und Defaultwerte
// Letzte �nderung 20.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Longitude g&eacute;ogr.:";
var text03 = "Latitude g&eacute;ogr.:";
var text05 = "Date:";
var text06 = "Temps:";
var text07 = "h (CET)";
var text08 = "Ascension droite:";
var text09 = "D&eacute;clinaison:";
var text10 = "Remise &agrave; z&eacute;ro";
var text11 = ["Rotation", "Pause", "Rotation"];
var text12 = "Mise en &eacute;vidence:";

var author = "W. Fendt, Y. Weiss, 1999";

// Symbole und Einheiten:

var dateSeparator = ".";
var timeSeparator = ":";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var text02 = ["(long. est)", "(long. ouest)"];
var text04 = ["(lat. nord)", "(lat. sud)"];
var text13 = ["", "point d'observation", "horizon",
              "point nord", "point ouest", "point sud", "point est", 
              "z\u00E9nith", "nadir", "m\u00E9ridien", "cercle altitude", 
              "p\u00F4le nord c\u00E9leste", "p\u00F4le sud c\u00E9leste", 
              "axe c\u00E9leste", "\u00E9quateur c\u00E9leste",
              "\u00E9quinoxe vernal", "cercle horaire", "temps sid\u00E9ral",
              "angle horaire", "\u00E9toile", "d\u00E9placement de l'\u00E9toile",
              "ascension droite", "d\u00E9clinaison", "azimut", "altitude", "triangle nautique"];
var text14 = "Temps:";
var text15 = "Temps sid\u00E9ral:";
var text16 = "Azimut:";
var text17 = "Angle horaire:";
var text18 = "Altitude:";

// Symbole und Einheiten:

var symbolObserver = "O";                                  // Beobachtungsort
var symbolNorth = "N";                                     // Nordpunkt
var symbolWest = "W";                                      // Westpunkt
var symbolSouth = "S";                                     // S�dpunkt
var symbolEast = "E";                                      // Ostpunkt
var symbolZenith = "Ze";                                   // Zenit
var symbolNadir = "Na";                                    // Nadir
var symbolNorthPole = "PN";                                // Himmelsnordpol
var symbolSouthPole = "PS";                                // Himmelss�dpol
var symbolVernalEquinox = "V";                             // Fr�hlingspunkt
var symbolStar = "\u00C9t";                                // Stern
var symbolHour = "h";                                      // Stunde

// Defaultwerte:

var defaultLongitude = 10*DEG;                             // Geographische L�nge (Frankfurt)
var defaultLatitude = 50*DEG;                              // Geographische Breite (Frankfurt)
var defaultDay = 1;                                        // Tag
var defaultMonth = 1;                                      // Monat
var defaultYear = 2000;                                    // Jahr
var defaultTimeZone = 1;                                   // Zeitzone relativ zu UT (h)
