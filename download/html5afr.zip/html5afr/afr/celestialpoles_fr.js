// Himmelspole, franz�sische Texte
// Letzte �nderung 20.11.2017

// Texte in Unicode-Schreibweise:

var text01 = "\u00C9quateur";
var	text02 = "P\u00F4le Nord";
var text03 = "P\u00F4le Sud";
var text04 = "Axe terrestre";
var text05 = "Plan horizontal";
var text06 = "Sph\u00E8re c\u00E9leste";
var	text07 = "Z\u00E9nith";
var text08 = "P\u00F4le nord c\u00E9leste";
var	text09 = "P\u00F4le sud c\u00E9leste";
var text10 = "Nord";
var text11 = "Sud";

var author = "W. Fendt, Y. Weiss, 1998";
