// Gleichstrom-Elektromotor, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];             
var text03 = "Inverter a polaridade";
var text04 = "Sentido da corrente";
var text05 = "Campo magn&eacute;tico";
var text06 = "For&ccedil;a de Lorentz (Laplace)";

var author = "W. Fendt 1997";               
var translator = "Casa das Ci&ecirc;ncias 2009";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";                        // Umdrehungen pro Minute
