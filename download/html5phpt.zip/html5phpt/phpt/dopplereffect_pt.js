// Beispiel zum Doppler-Effekt, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Novo Start";
var text02 = ["Pausa", "Continuar"]; 

var author = "W. Fendt 1998";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                        
  ["Pelo facto de a ambul\u00E2ncia de pri-",
   "meiros socorros se aproximar",
   "da pessoa, as frentes de onda",
   "chegam a intervalos de tempo",
   "menores."], 
  ["Quando o ve\u00EDculo se afasta da",
   "pessoa, os intervalos de tempo",
   "entre as frentes de onda v\u00EAm",
   "prolongados."]];
  

