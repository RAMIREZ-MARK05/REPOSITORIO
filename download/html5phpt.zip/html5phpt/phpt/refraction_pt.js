// Reflexion und Brechung von Licht, portugiesische Texte (WWW-Recherche)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = "1&ordm; &iacute;ndice de refrac&ccedil;&atilde;o:";
var text02 = "2&ordm; &iacute;ndice de refrac&ccedil;&atilde;o:";
var text03 = "&Acirc;ngulo de incid&ecirc;ncia:";
var text04 = "&Acirc;ngulo de reflex&atilde;o:";
var text05 = "&Acirc;ngulo de refrac&ccedil;&atilde;o:";    
var text06 = ["&Acirc;ngulo limite da", "reflex&atilde;o total:"];

var author = "W. Fendt 1997";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise (Quarzglas???):

var text07 = [["v\u00E1cuo", "1"], ["ar", "1.0003"],         // Stoffe und Brechungsindizes
    ["\u00E1gua", "1.33"], ["etanol", "1.36"],
    ["fused quartz", "1.46"], ["benzeno", "1.49"], 
    ["vidro crown N-K5", "1.52"], ["sal-gema", "1.54"], 
    ["vidro flint LF5", "1.58"], ["vidro crown N-SK4", "1.61"],
    ["vidro flint SF6", "1.81"], ["diamante", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                              // Grad
