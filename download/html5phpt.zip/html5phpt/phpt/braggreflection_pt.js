// Schwebungen, portugiesische Texte
// Letzte �nderung 10.02.2022

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];
var text03 = "C&acirc;mara lenta";
var text04 = "Dist&acirc;ncia entre os planos:";
var text05 = "Comprimento de onda:";
var text06 = "&Acirc;ngulo:";
var text07 = "N&uacute;mero de planos:";
var text08 = "Diferen&ccedil;a de caminho:";

var author = "W. Fendt 2021";
var translator = "";

// Text in Unicode-Schreibweise:

var text09 = "Condi\u00E7\u00E3o de Bragg satisfeita!";

// Einheiten und Symbole:

var decimalSeparator = ",";
var picometer = "pm";
var degree = "\u00B0";
var symbolDeltaS = "\u0394s";
var symbolLambda = "\u03BB";