// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "2 roldanas";
var text02 = "4 roldanas";
var text03 = "6 roldanas";
var text04 = "Peso:";
var text05 = "Peso das roldanas m&oacute;veis:";
var text06 = "For&ccedil;a necess&aacute;ria:";
var text07 = "Dinam&oacute;metro";
var text08 = "Vectores for&ccedil;a";

var author = "W. Fendt 1998";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                               
