// Kombinationen von Widerst�nden, Spulen und Kondensatoren, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 21.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Fonte de tens&atilde;o:";
var text02 = "Tens&atilde;o:";
var text03 = "Frequ&ecirc;ncia:";
var text04 = "Componente:";
var text06 = ["Resist&ecirc;ncia:", "Indut&acirc;ncia:", "Capacidade:"];
var text07 = "Substituir";
var text08 = "Acrescentar (em s&eacute;rie)";
var text09 = "Acrescentar (em paralelo)";
var text10 = "Retirar";
var text11 = "Aparelhos de medi&ccedil;&atilde;o:";
var text12 = "Tens&atilde;o";
var text13 = "Corrente";

var author = "W. Fendt 2004";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:

var text05 = ["Resist\u00EAncia", "Bobina", "Condensador"];
var text14 = "Tens\u00E3o:";
var text15 = "Corrente:";
var text16 = "Imped\u00E2ncia:";
var text17 = "Imped\u00E2ncia (grandeza):";
var text18 = "Desfasamento:";
var text19 = "muito pequena";                              // Stromst�rke Voltmeter
var text20 = "muito pequena";                              // Spannung Amperemeter
var text21 = "muito pequena";                              // Impedanz/Widerstand Amperemeter
var text22 = "muito grande";                               // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)