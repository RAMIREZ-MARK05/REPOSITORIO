// Zerfallsgesetz der Radioaktivit�t, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];    
var text03 = "Gr&aacute;fico";  

var author = "W. Fendt 1998";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:

var text04 = "Tempo:";                                      
var text05 = "Ainda n\u00E3o decairam:";
var text06 = "J\u00E1 decairam:";
var text07 = ["n\u00FAcleos", "n\u00FAcleo", "n\u00FAcleos", "n\u00FAcleos"];  // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
