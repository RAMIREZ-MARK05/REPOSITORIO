// Leiterschaukel-Versuch zur Lorentzkraft, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Ligar / Desligar";
var text02 = "Inverter a polaridade";
var text03 = "Inverter o &iacute;m&atilde;";
var text04 = "Sentido da corrente";
var text05 = "Campo magn&eacute;tico";
var text06 = "For&ccedil;a de Lorentz";

var author = "W. Fendt 1998";
var translator = "Casa das Ci&ecirc;ncias 2009";
