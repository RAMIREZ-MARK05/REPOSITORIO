// Newtons Wiege, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Start";
var text03 = "N&uacute;mero de esferas:";

var author = "W. Fendt 1997";
var translator = "Casa das Ci&ecirc;ncias 2009";
