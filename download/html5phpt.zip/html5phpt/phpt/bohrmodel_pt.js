// Bohrsches Atommodell, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Modelo part&iacute;cula";
var text02 = "Modelo onda";
var text03 = "N&uacute;mero qu&acirc;ntico principal:";


var author = "W. Fendt 1999"; 
var translator = "Casa das Ci&ecirc;ncias 2009";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



