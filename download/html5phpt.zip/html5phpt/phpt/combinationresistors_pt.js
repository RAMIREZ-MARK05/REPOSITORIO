// Kombinationen von Widerst�nden, portugiesische Texte
// Letzte �nderung 19.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Tens&atilde;o da bateria:";
var text03 = "Resist&ecirc;ncia:";
var text04 = "Acrescentar resist&ecirc;ncia (em s&eacute;rie)";
var text05 = "Acrescentar resist&ecirc;ncia (em paralelo)";
var text06 = "Aparelhos de medi&ccedil;&atilde;o:";
var text07 = "Tens&atilde;o";
var text08 = "Corrente";

var author = "W. Fendt 2002";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:

var text09 = "Tens\u00E3o:";
var text10 = "Corrente:";
var text11 = "Resist\u00EAncia:";
var text12 = "Resist\u00EAncia equivalente:";
var text13 = "muito pequena";
var text14 = "muito grande";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

