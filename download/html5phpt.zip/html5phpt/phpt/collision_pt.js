// Elastischer und unelastischer Sto�, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Choque el&aacute;stico";
var text02 = "Choque inel&aacute;stico";
var text03 = "Reset";
var text04 = "Start";
var text05 = "C&acirc;mara lenta";
var text06 = "Carro 1:";
var text07 = "Carro 2:";
var text08 = "Massa:";
var text09 = "Velocidade:";
var text10 = "Velocidade";
var text11 = "Momento linear";
var text12 = "Energia cin&eacute;tica";

var author = "W. Fendt 1998,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                             
var meterPerSecond = "m/s";                      

// Texte in Unicode-Schreibweise:

var text13 = "Carro 1:";
var text14 = "Carro 2:";
var text15 = "Velocidades antes do choque:";
var text16 = "Velocidades ap\u00F3s o choque:";
var text17 = "Momento linear antes do choque:";
var text18 = "Momento linear ap\u00F3s o choque:";
var text19 = "Energia cin\u00E9tica antes do choque:";
var text20 = "Energia cin\u00E9tica ap\u00F3s o choque:";
var text21 = "Momento linear total:";
var text22 = "Energia cin\u00E9tica total:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                  
var kilogramMeterPerSecond = "kg m/s";           
var joule = "J";                                 
