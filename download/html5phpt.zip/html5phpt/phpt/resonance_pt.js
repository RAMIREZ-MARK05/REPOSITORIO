// Erzwungene Schwingungen, Resonanz, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];
var text03 = "C&acirc;mara lenta";
var text04 = "Ressoador:";
var text05 = "Constante da mola:";
var text06 = "Massa:";
var text07 = "Amortecimento:";
var text08 = "Excita&ccedil;&atilde;o:";
var text09 = "Frequ&ecirc;ncia angular:";
var text10 = "Gr&aacute;fico da elonga&ccedil;&atilde;o";
var text11 = "Gr&aacute;fico da amplitude";
var text12 = "Gr&aacute;fico da diferen&ccedil;a de fase";

var author = "W. Fendt 1998,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";            
var newtonPerMeter = "N/m";         
var perSecond = "1/s";         
var radPerSecond = "rad/s";       

// Texte in Unicode-Schreibweise:

var text13 = "Fim da resson\u00E2ncia!";
var text14 = "(A simula\u00E7\u00E3o j\u00E1 n\u00E3o \u00E9 realista)";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz (omega)
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz (omega_0)
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                      
var radPerSecondUnicode = "rad/s";


