// Photoelektrischer Effekt, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Material do c&aacute;todo:";
var text03 = "Risca espectral (Hg):";
var text04 = "Tens&atilde;o de oposi&ccedil;&atilde;o:";
var text05 = "Frequ&ecirc;ncia:";
var text06 = ["Energia de um", "Fot&atilde;o:"];
var text07 = "Trabalho de extrac&ccedil;&atilde;o:";
var text08 = ["Energia cin&eacute;tica m&aacute;xima", "de um electr&atilde;o:"];
var text09 = "Apagar os resultados das medi&ccedil;&otilde;es";

var author = "W. Fendt 2000,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var terahertz = "THz";
var electronvolt = "eV";

// Texte in Unicode-Schreibweise:

var text02 = ["C\u00E9sio", "S\u00F3dio"];
var text10 = ["amarelo", "verde", "violeta", "ultravioleta", "ultravioleta"];
var text11 = "(em THz)";
var text12 = "(em V)";
var text13 = [
             ["A energia de um fot\u00E3o \u00E9 insuficiente para libertar", "um electr\u00E3o."],
             ["Aumentar a tens\u00E3o de oposi\u00E7\u00E3o at\u00E9 que j\u00E1", 
              "n\u00E3o haja mais electr\u00F5es a atingir o \u00E2nodo!"], 
             ["A tens\u00E3o de oposi\u00E7\u00E3o \u00E9 t\u00E3o elevada que os", "electr\u00F5es voltam para o c\u00E1todo."],
             ["Executar nova s\u00E9rie de medi\u00E7\u00F5es", "para outra risca espectral!"],
             ["Executar nova s\u00E9rie de medi\u00E7\u00F5es para outro", "material de c\u00E1todo!"],
             ["Terminaram as medi\u00E7\u00F5es.", ""]
             ];

var symbolCathode = "C";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
