// Bewegung mit konstanter Beschleunigung, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];
var text03 = "C&acirc;mara lenta";
var text04 = "Posi&ccedil;&atilde;o inicial:";
var text05 = "Velocidade inicial:";
var text06 = "Acelera&ccedil;&atilde;o:";
var text07 = "Vector velocidade";
var text08 = "Vector acelera&ccedil;&atilde;o";

var author = "W. Fendt 2000";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:

var text09 = "(em s)";                                     // Einheitenangabe f�r Zeit-Achse
var text10 = "(em m)";                                     // Einheitenangabe f�r Weg-Achse
var text11 = "(em m/s)";                                   // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(em m/s\u00b2)";                             // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                    
var meter = "m";                                   
var meterPerSecond = "m/s";                         
var meterPerSecond2 = "m/s\u00b2";        
