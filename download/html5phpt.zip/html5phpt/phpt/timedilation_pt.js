// Beispiel zur Zeitdilatation, portugiesische Texte (Casa das Ci&ecirc;ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Diminuir a velocidade";
var text02 = "Aumentar a velocidade";
var text03 = "Voltar";
var text04 = ["Start", "Pausa", "Continuar"];

var author = "W. Fendt 1997,&nbsp; Casa das Ci&ecirc;ncias 2009";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:                          // Dezimaltrennzeichen (Komma/Punkt)

var text05 = "Trajecto de voo:";
var text06 = "5 horas-luz";
var text07 = "Velocidade:";
var text08 = "Tempo de voo no referencial Terra:";
var text09 = "horas";
var text10 = "Tempo de voo no referencial foguet\u00E3o:";