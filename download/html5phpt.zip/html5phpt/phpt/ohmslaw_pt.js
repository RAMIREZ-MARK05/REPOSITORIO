// Ohmsches Gesetz, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Tens&atilde;o m&aacute;xima:";
var text02 = "Corrente m&aacute;xima:";
var text03 = "Aumentar a resist&ecirc;ncia";
var text04 = "Diminuir a resist&ecirc;ncia";
var text05 = "Aumentar a tens&atilde;o";
var text06 = "Diminuir a tens&atilde;o";

var author = "W. Fendt 1997";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Excedida a gama de medi\u00E7\u00E3o!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
