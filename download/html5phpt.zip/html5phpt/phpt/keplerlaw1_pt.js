// Erstes Kepler-Gesetz, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "Semieixo maior:";
var text03 = "Excentricidade:";
var text04 = "Semieixo menor:";
var text05 = ["Pausa", "Continuar"];
var text06 = "C&acirc;mara lenta";
var text07 = "Dist&acirc;ncia ao Sol:";
var text08 = "Valor actual:";
var text09 = "M&iacute;nimo:";
var text10 = "M&aacute;ximo:";
var text11 = "&Oacute;rbita el&iacute;ptica";
var text12 = "Eixos";
var text13 = "Liga&ccedil;&otilde;es aos focos";

var author = "W. Fendt 2000,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "UA";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Merc\u00FArio", "V\u00E9nus", "Terra", "Marte", "J\u00FApiter", "Saturno", "Urano", "Neptuno",
              "Plut\u00E3o", "Cometa Halley", ""];

var text14 = "Sol";
var text15 = "Planeta";
var text16 = "Cometa";
var text17 = "Peri\u00E9lio";
var text18 = "Af\u00E9lio";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "UA";

