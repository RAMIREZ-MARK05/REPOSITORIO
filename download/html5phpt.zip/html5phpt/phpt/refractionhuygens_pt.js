// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Come&ccedil;ar de novo";
var text02 = "Passo seguinte";
var text03 = ["Pausa", "Continuar"];                  
var text04 = "1&ordm; &iacute;ndice de refrac&ccedil;&atilde;o:";
var text05 = "2&ordm; &iacute;ndice de refrac&ccedil;&atilde;o:";
var text06 = "&Acirc;ngulo de incid&ecirc;ncia:";

var author = "W. Fendt 1998";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";       

// Texte in Unicode-Schreibweise:

var text07 = [

  ["Uma frente de onda plana",                             // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "desloca-se obliquamente",
   "para a interface de dois meios,",
   "em que as velocidades de fase",
   "t\u00EAm diferentes grandezas."],

  ["Uma frente de onda plana",                             // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "desloca-se perpendicularmente",
   "para a interface de dois meios,",
   "em que as velocidades de fase",
   "t\u00EAm diferentes grandezas."],
    
  ["Quando a frente de onda atinge",                       // i == 2 (step == 1, n1 > n2)
   "a interface, segundo o princ\u00EDpio",
   "Huygens, s\u00E3o geradas ondas",
   "esf\u00E9ricas (ondas elementares).",
   "No meio 2 estas ondas ele-",
   "mentares propagam-se mais",
   "rapidamente porque o \u00EDndice",
   "de refrac\u00E7\u00E3o a\u00ED \u00E9 menor."], 
   
  ["Quando a frente de onda atinge",                       // i == 3 (step == 1, n1 < n2)
   "a interface, segundo o princ\u00EDpio",
   "Huygens, s\u00E3o geradas ondas",
   "esf\u00E9ricas (ondas elementares).",
   "No meio 2 estas ondas ele-",
   "mentares propagam-se mais",
   "lentamente porque o \u00EDndice",
   "de refrac\u00E7\u00E3o a\u00ED \u00E9 maior."], 
   
  ["Por sobreposi\u00E7\u00E3o das ondas",                 // i == 4 (step == 2, total == false, esp1 > 0)
   "elementares originam-se novas",
   "frentes de onda planas.",
   "No meio 1 forma-se uma onda",
   "reflectida, no meio 2 pelo con-",
   "tr\u00E1rio uma onda refractada."],   
 
  ["Por sobreposi\u00E7\u00E3o das ondas",                 // i == 5 (step == 2, total == false, esp1 == 0)
   "elementares originam-se novas",
   "frentes de onda planas.",
   "No meio 1 forma-se uma onda",
   "reflectida, no meio 2 pelo con-",
   "tr\u00E1rio uma onda refractada."],   
 
  ["Por sobreposi\u00E7\u00E3o das ondas",                 // i == 6 (step == 2, total == true)
   "elementares origina-se no",
   "meio 1 uma nova frente de",
   "onda plana (onda reflectida).",
   "No meio 2, pelo contr\u00E1rio, n\u00E3o se",
   "forma qualquer frente de onda",
   "(Reflex\u00E3o total)."],  
  
  ["Adicionalmente est\u00E3o represen-",                  // i == 7 (step == 3)
   "tados os raios de onda, que",
   "permitem identificar a direc\u00E7\u00E3o",
   "de propaga\u00E7\u00E3o da onda."],
   
  ["Uma frente de onda s\u00F3 raramente",                 // i == 8 (step == 4)
   "aparece isolada."],
   
  ["Quando os \u00EDndices de refrac\u00E7\u00E3o",        // i == 9 (n1 == n2)
   "s\u00E3o semelhantes, n\u00E3o acontece",
   "nada de especial."]];
          
var text08 = "\u00C2ngulo de incid\u00EAncia:"; 
var text09 = "\u00C2ngulo de reflex\u00E3o:";
var text10 = "\u00C2ngulo de refrac\u00E7\u00E3o:"; 
var text11 = "Meio 1";
var text12 = "Meio 2";      
var text13 = ["\u00C2ngulo limite da", "reflex\u00E3o total:"];

// Einheiten:

var degreeUnicode = "\u00b0";                   
