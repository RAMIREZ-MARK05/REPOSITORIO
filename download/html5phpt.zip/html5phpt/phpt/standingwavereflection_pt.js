// Stehende Welle, Erkl�rung durch Reflexion, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reflex&atilde;o";
var text02 = "na extremidade fixa";
var text03 = "na extremidade livre";
var text04 = "Reset";
var text05 = ["Start", "Pausa", "Continuar"];
var text06 = "C&acirc;mara lenta";
var text07 = "Anima&ccedil;&atilde;o";
var text08 = "Passo a passo";
var text09 = "Onda incidente";
var text10 = "Onda reflectida";
var text11 = "Onda estacion&aacute;ria resultante";

var author = "W. Fendt 2003"; 
var translator = "Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "N";
var symbolAntiNode = "A";

