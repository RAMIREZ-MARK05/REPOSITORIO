// Stehende L�ngswellen, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Forma do tubo:";
var text02 = "aberto de ambos os lados";
var text03 = "aberto de um lado";
var text04 = "fechado de ambos os lados";
var text05 = "Oscila&ccedil;&atilde;o pr&oacute;pria:";
var text06 = ["Oscila&ccedil;&atilde;o fundamental", "1&ordm; harm&oacute;nico", // Bezeichnungen der Eigenschwingungen 
              "2&ordm; harm&oacute;nico", "3&ordm; harm&oacute;nico", 
              "4&ordm; harm&oacute;nico", "5&ordm; harm&oacute;nico"];
var text07 = "Inferior";
var text08 = "Superior";
var text09 = "Comprimento do tubo:";
var text10 = "Comprimento de onda:";
var text11 = "Frequ&ecirc;ncia:";

var author = "W. Fendt 1998,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";               
var hertz = "Hz";      

// Texte in Unicode-Schreibweise:

var text12 = "Elonga\u00E7\u00E3o das part\u00EDculas";    // �berschrift des ersten Diagramms
var text13 = "Desvio da press\u00E3o m\u00E9dia";          // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "N";                                      // Symbol f�r Knoten
var symbolAntinode = "A";                                  // Symbol f�r Bauch

