// Potentiometerschaltung, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Tens&atilde;o da fonte de corrente:";
var text02 = "Resist&ecirc;ncia deslizante:";
var text03 = "Posi&ccedil;&atilde;o do contacto deslizante:";
var text04 = "Resist&ecirc;ncia de carga:";
var text05 = "Indicar a tens&atilde;o";
var text06 = "Indicar a corrente";
var author = "W. Fendt 2006";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "U";                                  // Symbol f�r Spannung
var symbolVoltage2 = "V";                                  // Index f�r Verbraucher
                      
