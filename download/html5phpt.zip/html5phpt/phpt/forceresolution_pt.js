// Zerlegung einer Kraft in zwei Komponenten, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Intensidade da";                       
var text02 = "for&ccedil;a dada:";
var text03 = "Amplitude dos &acirc;ngulos:";
var text04 = "1&ordm; &acirc;ngulo:";
var text05 = "2&ordm; &acirc;ngulo:";
var text06 = "Intensidades das for&ccedil;as:";
var text07 = "1&ordf; componente:";
var text08 = "2&ordf; componente:";
var text09 = "Determinar as componentes";
var text10 = "Apagar a constru&ccedil;&atilde;o";

var author = "W. Fendt 2003";
var translator = "Casa das Ci&ecirc;ncias 2009";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                              
var newton = "N";                                

// Texte in Unicode-Schreibweise:

var text11 = "1\u00AA componente";                    
var text12 = "2\u00AA componente";                        

// Symbole und Einheiten:

var newtonUnicode = "N";                          