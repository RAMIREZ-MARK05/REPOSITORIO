// Fahrbahnversuch zum 2. Newtonschen Gesetz, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Apagar resultados";
var text02 = ["Start", "Registar acontecimento"];
var text03 = "Gr&aacute;fico";
var text04 = "Massa do carro:";
var text05 = "Massa suspensa:";
var text06 = "Coeficiente de atrito:";
var text07 = "Dados:";

var author = "W. Fendt 1997,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "LS";
var text09 = "(em s)";
var text10 = "(em m)";
var text11 = "Demasiado atrito!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


