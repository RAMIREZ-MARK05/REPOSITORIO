// Zweites Kepler-Gesetz, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "Semieixo maior:";
var text03 = "Excentricidade:";
var text04 = ["Pausa", "Continuar"];
var text05 = "C&acirc;mara lenta";
var text06 = ["Dist&acirc;ncia", "ao Sol:"];
var text07 = "Velocidade:";
var text08 = "Valor actual:";
var text09 = "M&iacute;nimo:";
var text10 = "M&aacute;ximo:";
var text11 = "Sectores";
var text12 = "Vector velocidade";

var author = "W. Fendt 2000,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "UA";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Merc\u00FArio", "V\u00E9nus", "Terra", "Marte", "J\u00FApiter", "Saturno", "Urano", "Neptuno",
              "Plut\u00E3o", "Cometa Halley", ""];

// Symbole und Einheiten: 

var auUnicode = "UA";
var symbolPeriod = "T";

