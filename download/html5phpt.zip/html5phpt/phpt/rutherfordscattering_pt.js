// Rutherford-Streuung, portugiesische Texte
// Letzte �nderung 01.11.2020

// Texte in HTML-Schreibweise:

var text01 = "Apagar trajet&oacute;rias";                   
var text02 = "Start";         
var text03 = "N&uacute;cleo alvo:";
var text04 = "N&uacute;mero at&oacute;mico:";
var text05 = "Part&iacute;cula alfa:";
var text06 = "Velocidade:";
var text07 = "Par&acirc;metro de impacto:";
var text08 = "&Acirc;ngulo de dispers&atilde;o:";
var text09 = "Dist&acirc;ncia m&iacute;nima:";
var text10 = "Ass&iacute;ntotas, par&acirc;metro de impacto";
var text11 = "Ass&iacute;ntotas, &acirc;ngulo de dispers&atilde;o";


var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var femtometer = "fm";
var kilometerPerSecond = "km/s";
var degree = "\u00B0";




