// Beugung von Licht am Einfachspalt, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Comprimento de onda:";
var text02 = "Largura da fenda:";
var text03 = "&Acirc;ngulo:";
var text04 = "M&aacute;ximo:";
var text05 = "M&iacute;nimo:";
var text06 = "Intensidade relativa:";
var text07 = "Figura de interfer&ecirc;ncia";
var text08 = "Distribui&ccedil;&atilde;o de intensidade";

var author = "W. Fendt 2003,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
