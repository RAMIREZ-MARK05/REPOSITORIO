// Interferenz zweier Kreis- oder Kugelwellen, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = ["Pausa", "Continuar"];           
var text02 = "C&acirc;mara lenta";
var text03 = "Dist&acirc;ncia entre";
var text04 = "as fontes:";
var text05 = "Comprimento de onda:";

var author = "W. Fendt 1999";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";

// Texte in Unicode-Schreibweise:

var text06 = "Diferen\u00E7a de percurso:";
var text07 = "Interfer\u00EAncia construtiva (amplitude m\u00E1xima)";
var text08 = "Interfer\u00EAncia destrutiva (amplitude m\u00EDnima)";

// Symbole:

var symbolPhaseDifference = "\u0394";                      // Symbol f�r Phasendifferenz (Delta)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (lambda)
