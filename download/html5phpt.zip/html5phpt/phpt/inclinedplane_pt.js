// Kr�fte an der schiefen Ebene, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];
var text03 = "C&acirc;mara lenta";
var text04 = "Dinam&oacute;metro";
var text05 = "Vectores for&ccedil;a";
var text06 = "&Acirc;ngulo de inclina&ccedil;&atilde;o:";
var text07 = "Peso:";
var text08 = "Componente paralela:";
var text09 = "Reac&ccedil;&atilde;o normal:";
var text10 = "Coeficiente de atrito:";
var text11 = "For&ccedil;a de atrito:";
var text12 = "For&ccedil;a de trac&ccedil;&atilde;o:";

var author = "W. Fendt 1999,&nbsp; Casa das Ci&ecirc;ncias 2009";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                             
var newton = "N";                                
