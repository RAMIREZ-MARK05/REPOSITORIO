// Zerfallsreihen, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "S&eacute;rie de decaimento:";
var text03 = "Decaimento seguinte";

var author = "W. Fendt 1998"; 
var translator = "Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:

var text02 = ["S\u00E9rie do t\u00F3rio", 
              "S\u00E9rie do nept\u00FAnio", 
              "S\u00E9rie do ur\u00E2nio-radio", 
              "S\u00E9rie do ur\u00E2nio-act\u00EDnio"];          





