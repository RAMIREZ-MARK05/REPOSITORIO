// Kepler-Fernrohr, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Dist&acirc;ncias focais:"; 
var text02 = "Objectiva:";
var text03 = "Ocular:";
var text04 = "&Acirc;ngulo de vis&atilde;o:";
var text05 = "Amplia&ccedil;&atilde;o:";

var author = "W. Fendt 2000";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite
