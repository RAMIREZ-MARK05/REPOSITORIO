// Gleichgewicht dreier Kr�fte, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "For&ccedil;as:";
var text02 = "Esquerda:";
var text03 = "Direita:";
var text04 = "Em baixo:";
var text05 = "Paralelograma das for&ccedil;as";
var text06 = "&Acirc;ngulos:";
var text07 = "Esquerda:";
var text08 = "Direita:";

var author = "W. Fendt 2000";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                       
var newton = "N";                           
