// Gekoppelte Pendel, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";                           
var text02 = ["Start", "Pausa", "Continuar"];                
var text03 = "C&acirc;mara lenta";
var text04 = "Posi&ccedil;&otilde;es iniciais:";

var author = "W. Fendt 1998";
var translator = "Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise:

var text05 = "P\u00EAndulo 1";                             // Erstes Pendel (links)
var text06 = "P\u00EAndulo 2";                             // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
