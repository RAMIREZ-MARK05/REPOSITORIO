// Kettenkarussell, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Carrossel";
var text02 = "Carrossel com for&ccedil;as";
var text03 = "Esquema";
var text04 = "Valores";
var text05 = ["Pausa", "Continuar"];
var text06 = "C&acirc;mara lenta";
var text07 = "Per&iacute;odo:";
var text08 = ["Dist&acirc;ncia das suspens&otilde;es", "ao eixo de rota&ccedil;&atilde;o:"]; 
var text09 = "Comprimento dos cabos:";
var text10 = "Massa:";

var author = "W. Fendt 1999,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:

var text11 = "Frequ\u00EAncia:";
var text12 = "Velocidade angular:";
var text13 = "Raio:";
var text14 = "Velocidade:";
var text15 = "\u00C2ngulo:";
var text16 = "Peso:";
var text17 = "For\u00E7a centr\u00EDpeta:";
var text18 = "Tens\u00E3o no cabo:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




