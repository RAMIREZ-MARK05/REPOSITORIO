// Loopingbahn, portugiesische Texte
// Letzte �nderung 12.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];
var text03 = "C&acirc;mara lenta (5 &times;)";
var text04 = "C&acirc;mara lenta (50 &times;)";
var text05 = "Raio:";
var text06 = "Altura inicial:";
var text07 = "Acelera&ccedil;&atilde;o da gravidade:";
var text08 = "Massa:";
var text09 = "Velocidade";
var text10 = "Peso, for&ccedil;a de contato";
var text11 = "For&ccedil;a tangencial, for&ccedil;a centr&iacute;peta";
var text12 = "For&ccedil;a total";

var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Texte in Unicode-Schreibweise:

var text13 = "Velocidade:";
var text14 = "Peso:";
var text15 = "For\u00E7a de contato:";
var text16 = "For\u00E7a tangencial:";
var text17 = "For\u00E7a centr\u00EDpeta:";
var text18 = "For\u00E7a total:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var second = "s";                               
var meter = "m";                                 
var meterPerSecond = "m/s";                        
var meterPerSecond2 = "m/s\u00b2";         
var kilogram = "kg";
var newton = "N";    


