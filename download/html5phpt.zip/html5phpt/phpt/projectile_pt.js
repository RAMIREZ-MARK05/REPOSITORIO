// Schiefer Wurf, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";                    
var text02 = ["Start", "Pausa", "Continuar"];          
var text03 = "C&acirc;mara lenta";
var text04 = "Altura inicial:";
var text05 = "Velocidade inicial:";
var text06 = "&Acirc;ngulo:";
var text07 = "Massa:"; 
var text08 = "Acelera&ccedil;&atilde;o de queda:";
var text09 = "Posi&ccedil;&atilde;o";
var text10 = "Velocidade";
var text11 = "Acelera&ccedil;&atilde;o";
var text12 = "For&ccedil;a";
var text13 = "Energia";

var author = "W. Fendt 2000,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                               
var meterPerSecond = "m/s";                 
var meterPerSecond2 = "m/s&sup2;";          
var kilogram = "kg";                            
var degree = "&deg;";                         

// Texte in Unicode-Schreibweise:

var text14 = "(em m)";                            
var text15 = "Posi\u00E7\u00E3o:";
var text16 = "(horizontal)";
var text17 = "(vertical)";
var text18 = "Alcance horizontal:";
var text19 = "Altura m\u00E1xima:";
var text20 = "Dura\u00E7\u00E3o:";
var text21 = "Componentes do vector velocidade:";
var text22 = "M\u00F3dulo da velocidade:";
var text23 = "\u00C2ngulo:";
var text24 = "Acelera\u00E7\u00E3o:";
var text25 = "For\u00E7a:";
var text26 = "Energia cin\u00E9tica:";
var text27 = "Energia potencial:";
var text28 = "Energia total:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                           
var secondUnicode = "s";                          
var meterPerSecondUnicode = "m/s";                   
var meterPerSecond2Unicode = "m/s\u00b2";              
var newtonUnicode = "N";                          
var jouleUnicode = "J";                           
var degreeUnicode = "\u00b0";                  



