// Wheatstonesche Br�ckenschaltung, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Nova medi&ccedil;&atilde;o";
var text02 = "Resist&ecirc;ncia padr&atilde;o:";
var text03 = "Resist&ecirc;ncia deslizante:";
var text04 = "Posi&ccedil;&atilde;o do contacto deslizante:";
var text05 = "Tens&atilde;o da fonte de corrente:";
var text06 = "Resist&ecirc;ncia interna do aparelho de medi&ccedil;&atilde;o:";
var text07 = "Calcular a resist&ecirc;ncia";
var text08 = "Indicar a tens&atilde;o";
var text09 = "Indicar a corrente";
var author = "W. Fendt 2006,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Texte in Unicode-Schreibweise:

var text10 = ["Deslocar o contacto deslizante,",
  	          "at\u00E9 que a intensidade da corrente seja 0!"];
var text11 = "Pode agora ser calculado o valor da resist\u00EAncia.";         

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var milliampere = "mA";
var ohm = "\u03A9";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00D7";                              
