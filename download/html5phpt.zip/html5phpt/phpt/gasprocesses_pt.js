// Spezielle Prozesse eines idealen Gases, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 10.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Transforma&ccedil;&atilde;o isob&aacute;rica";
var text02 = "Transforma&ccedil;&atilde;o isoc&oacute;rica";
var text03 = "Transforma&ccedil;&atilde;o isot&eacute;rmica";
var text04 = "Estado inicial:";
var text05 = "Press&atilde;o:";
var text06 = "Volume:";
var text07 = "Temperatura:";
var text08 = "Estado final:";
var text09 = "Estado inicial";
var text10 = "Start";

var author = "W. Fendt 1999, Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Trabalho";
var text12 = "Calor";
var text13 = "A energia interna do g\u00E1s";
var text14 = "aumenta.";
var text15 = "A energia interna do g\u00E1s";
var text16 = "permanence inalterada.";
var text17 = "A energia interna do g\u00E1s";
var text18 = "diminui.";
var text19 = "Press\u00E3o muito pequena!";
var text20 = "Press\u00E3o muito grande!";
var text21 = "Volume muito pequeno!";
var text22 = "Volume muito grande!";
var text23 = "Temperature muito pequena!";
var text24 = "Temperature muito grande!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


