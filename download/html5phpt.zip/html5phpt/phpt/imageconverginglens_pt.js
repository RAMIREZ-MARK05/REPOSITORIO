// Bilderzeugung Sammellinse, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = "Dist&acirc;ncia Focal:";
var text02 = "Dist&acirc;ncia ao Objecto:";
var text03 = "Altura do Objecto:";
var text04 = "Dist&acirc;ncia da Imagem:";
var text05 = "Altura da Imagem:";    
var text06 = "Tipo de Imagem:"
var text07 = ["real", "virtual"];
var text08 = ["invertida", "direita"];
var text09 = ["menor que o objecto", "igual ao objecto", "maior que o objecto", "infinitamente grande"];
var text10 = "Raios principais";
var text11 = "Feixe de raios luminosos";
var text12 = "Real&ccedil;ar:";

var author = "W. Fendt 2008,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var centimeter = "cm";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text13 = ["objecto", 
              "dist\u00E2ncia ao objecto", 
              "altura do objecto",
              "lente", 
              "plano da lente", 
              "eixo \u00F3ptico",
              "focos", 
              "dist\u00E2ncia focal", 
              "imagem", 
              "dist\u00E2ncia da imagem", 
              "altura da imagem",
              "ecr\u00E3"];
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "o";
var symbolGG = "O"; 
var symbolB = "i";
var symbolBB = "I";


