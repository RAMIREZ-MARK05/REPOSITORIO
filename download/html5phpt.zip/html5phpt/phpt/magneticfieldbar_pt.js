// Magnetfeld eines Stabmagneten, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Apagar as linhas de campo";
var text02 = "Inverter o &iacute;man";

var author = "W. Fendt 2001";
var translator = "Casa das Ci&ecirc;ncias 2009";
