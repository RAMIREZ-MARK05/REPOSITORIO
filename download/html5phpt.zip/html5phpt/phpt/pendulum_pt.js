// Fadenpendel, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];
var text03 = "C&acirc;mara lenta";
var text04 = "Comprimento do p&ecirc;ndulo:";
var text05x = "Acelera&ccedil;&atilde;o";
var text05 = "da gravidade:";
var text06 = "Massa:";
var text07 = "Amplitude:";
var text08 = "Elonga&ccedil;&atilde;o";
var text09 = "Velocidade";
var text10 = "Acelera&ccedil;&atilde;o";
var text11 = "For&ccedil;a";
var text12 = "Energia";

var author = "W. Fendt 1998,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var meter = "m";                                
var meterPerSecond2 = "m/s&sup2;";              
var kilogram = "kg";                             
var degree = "&deg;";               

// Texte in Unicode-Schreibweise:

var text13 = "M\u00E1ximo";
var text14 = "Elonga\u00E7\u00E3o";
var text15 = "Velocidade"; 
var text16 = "Acelera\u00E7\u00E3o (componente tangencial)";
var text17 = "For\u00E7a (componente tangencial)";
var text18 = "Energia potencial";
var text19 = "Energia cin\u00E9tica";
var text20 = "Energia total";
var text21 = "(em s)";
var text22 = "(em m)";
var text23 = "(em m/s)";
var text24 = "(em m/s\u00b2)";
var text25 = "(em N)";
var text26 = "(em J)";
var text27 = "Per\u00EDodo de oscila\u00E7\u00E3o";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolTangential = "tang";                             // Symbol f�r tangential
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                 
var meterUnicode = "m";                          
var meterPerSecond = "m/s";                            
var meterPerSecond2Unicode = "m/s\u00b2";           
var newton = "N";                                 
var joule = "J";                             


