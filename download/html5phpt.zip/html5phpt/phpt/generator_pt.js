// Generator, portugiesische Texte (Casa das Ciencias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Sem comutador";
var text02 = "Com comutador";
var text03 = "Sentido inverso";
var text04 = ["Start", "Pausa", "Continuar"];
var text05 = "Sentido da rota&ccedil;&atilde;o";
var text06 = "Campo magn&eacute;tico";
var text07 = "Corrente induzida";

var author = "W. Fendt 1998";  
var translator = "Casa das Ci&ecirc;ncias 2009";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";                        // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "V";
var symbolResistor = "R";
