// Ersatzkraft mehrerer Kr�fte, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "N&uacute;mero de for&ccedil;as individuais:";
var text02 = "Determinar a for&ccedil;a resultante";
var text03 = "Apagar a constru&ccedil;&atilde;o";

var author = "W. Fendt 1998";
var translator = "Casa das Ci&ecirc;ncias 2009";
