// Einfache Wechselstromkreise, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Resist&ecirc;ncia";
var text02 = "Condensador";
var text03 = "Bobina";
var text04 = "Reset";
var text05 = ["Start", "Pausa", "Continuar"];          
var text06 = "C&acirc;mara lenta";
var text07 = "Frequ&ecirc;ncia:";
var text08 = "Tens&atilde;o m&aacute;x.:";
var text09 = "Resist&ecirc;ncia:";                            
var text10 = "Capacidade:";                          
var text11 = "Indut&acirc;ncia:"; 
var text12 = "Corrente m&aacute;x.:"; 

var author = "W. Fendt 1998,&nbsp; Casa das Ci&ecirc;ncias 2009";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";            
var volt = "V";               
var ampere = "A";                   
var milliampere = "mA";                  
var microampere = "&mu;A";   
var ohm = "&Omega;";            
var microfarad = "&mu;F";             
var henry = "H";             

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
