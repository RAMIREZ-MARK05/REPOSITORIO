// Magnetfeld eines geraden stromdurchflossenen Leiters, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Inverter o sentido da corrente";

var author = "W. Fendt 2000";
var translator = "Casa das Ci&ecirc;ncias 2009";
