// Elektromagnetischer Schwingkreis, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pausa", "Continuar"];
var text03 = "C&acirc;mara lenta (10 &times;)";
var text04 = "C&acirc;mara lenta (100 &times;)";
var text05 = "Capacidade:";
var text06 = "Indut&acirc;ncia:";
var text07 = "Resist&ecirc;ncia:";
var text08 = "Tens&atilde;o m&aacute;x.:";
var text09 = "Tens&atilde;o, Corrente";
var text10 = "Energia";

var author = "W. Fendt 1999,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";
var henry = "H";      
var ohm = "&Omega;";        
var volt = "V";                

// Texte in Unicode-Schreibweise:

var text11 = "Per\u00EDodo da oscila\u00E7\u00E3o:";
var text12 = "Energia do campo el\u00E9ctrico:";
var text13 = "Energia do campo magn\u00E9tico:";
var text14 = "Energia interna:";
var text15 = "Oscila\u00E7\u00E3o n\u00E3o amortecida";
var text16 = "Oscila\u00E7\u00E3o amortecida";
var text17 = "Amortecimento cr\u00EDtico";
var text18 = "Amortecimento super-cr\u00EDtico";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";        
var voltUnicode = "V";  
var ampere = "A";             
var joule = "J";          
