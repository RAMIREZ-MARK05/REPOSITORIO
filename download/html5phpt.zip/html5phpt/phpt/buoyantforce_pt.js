// Messung der Auftriebskraft, portugiesische Texte (Casa das Ci�ncias)
// Letzte �nderung 23.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Superf&iacute;cie da base do corpo:"; 
var text02 = "Altura do corpo:";
var text03 = "Densidade do corpo:";
var text04 = "Densidade do l&iacute;quido:";   
var text05 = "Altura submersa:";
var text06 = "Volume deslocado:"; 
var text07 = "Impuls&atilde;o:";
var text08 = "Peso do corpo:";
var text09 = "For&ccedil;a medida:";
var text10 = "Gama de medi&ccedil;&atilde;o:";

var author = "W. Fendt 1998,&nbsp; Casa das Ci&ecirc;ncias 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Excedida a gama de medi\u00E7\u00E3o!";
