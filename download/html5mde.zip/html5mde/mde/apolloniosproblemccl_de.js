// Apollonios-Problem CCL, deutsche Texte
// Letzte �nderung 19.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Auswahl der L&ouml;sungen (rot):";
var text02 = ["(Die H&auml;kchen stehen bei den beiden",
              "gegebenen Kreisen f&uuml;r ausschlie&szlig;ende", 
              "Ber&uuml;hrung, bei der Gerade f&uuml;r eine", 
              "der beiden Halbebenen.)"];
var text03 = ["L&ouml;sungstyp 1:",
              "L&ouml;sungstyp 2:",
              "L&ouml;sungstyp 3:",
              "L&ouml;sungstyp 4:",
              "L&ouml;sungstyp 5:",
              "L&ouml;sungstyp 6:",
              "L&ouml;sungstyp 7:",
              "L&ouml;sungstyp 8:"];   
var text04 = "Zahl der L&ouml;sungen:"; 
          
var author = "W. Fendt 2008"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var nameCircle1 = "k_1";
var nameCircle2 = "k_2";
var nameLine1 = "g";

