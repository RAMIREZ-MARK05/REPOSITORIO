// Regelm��ige Vielecke (2 Apps), deutsche Texte
// Letzte �nderung 02.12.2022

// Texte in HTML-Schreibweise:

var text11 = "Zahl der Ecken:";
var text12 = "Umkreis";
var text13 = "Inkreis";
var text14 = "Bestimmungsdreiecke";
var text15 = "Diagonalen";

var text21 = "Schl&auml;fli-Symbol:";

var author = "W. Fendt 2018";
var translator = "";





