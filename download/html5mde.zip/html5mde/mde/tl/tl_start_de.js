// Dreiecks-Labor, Startseite, deutsche Texte
// Letzte �nderung 21.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Neustart";
var text02 = "N&auml;chster Schritt";
var author = "W. Fendt 2004"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Die Apps dieser Serie lassen", 
               "sich alle auf die gleiche Weise",
               "bedienen.",
               "Weiter geht es mit einem Maus-",
               "klick (linke Taste!) auf den Schalt-",
               "knopf \u0022N\u00E4chster Schritt\u0022."], 
              ["Die Ecken des links gezeichneten",
               "Dreiecks (rot) lassen sich durch",
               "Ziehen mit gedr\u00FCckter linker Maus-",
               "taste verschieben."],
              ["Der untere Schaltknopf ist jetzt",
               "deaktiviert. Durch einen Mausklick",
               "auf den oberen Schaltknopf l\u00E4sst",
               "sich die App neu starten."]
              ];






