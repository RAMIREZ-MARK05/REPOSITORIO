// Gerade Strophoide, deutsche Texte
// Letzte �nderung 09.11.2020

// Texte in HTML-Schreibweise:

var text01 = "Zur&uuml;ck";
var text02 = ["Start", "Pause", "Weiter"];  

var author = "W. Fendt 2020";    

                




