// Zwillingskreise des Archimedes, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Hilfslinien zur Radiusberechnung:";
var text02 = "links";
var text03 = "rechts";

var author = "W. Fendt 2000";
