// Strahlensatz, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "V-Figur";
var text02 = "X-Figur";
var text03 = "Streckenverh&auml;ltnis:";

var author = "W. Fendt 2000";
var translator = "";

// Symbole in Unicode-Schreibweise:

var symbolDivision = ":";

var symbolZ = "Z";
var symbolA1 = "A";
var symbolB1 = "B";
var symbolA2 = "A'";
var symbolB2 = "B'";



