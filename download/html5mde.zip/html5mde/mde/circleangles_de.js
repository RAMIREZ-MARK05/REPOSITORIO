// Winkel am Kreis, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Winkelgr&ouml;&szlig;e:";
var text02 = "Mittelpunktswinkel:";
var text03 = "Umfangswinkel:";
var text04 = "Sehnen-Tangenten-Winkel:";

var author = "W. Fendt 1997";
var translator = "";
