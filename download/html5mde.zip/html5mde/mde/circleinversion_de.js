// Kreisspiegelung, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Neue Zeichnung";
var text03 = "Hinzuf&uuml;gen";
var text04 = "L&ouml;schen";
var text05 = "Bild";

var author = "W. Fendt 2017";
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["Punkt", "Gerade", "Halbgerade", "Strecke", "Kreis", "Dreieck", "Viereck"];

