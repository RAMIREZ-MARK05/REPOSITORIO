// Kr�mmungskreise von Funktionsgraphen, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Funktionsgleichung:";
var text02 = "f(x) =";
var text03 = "Linker Rand:";
var text04 = "Rechter Rand:";
var text05 = "Unterer Rand:";
var text06 = "Oberer Rand:";
var text07 = "Zeichnen";

var author = "W. Fendt 2017";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text08 = "Funktionsterm unverst\u00E4ndlich!";
var text09 = "Fehler bei Ableitung!";

var symbolX = "x";
var symbolY = "y";
