// Schriftliches Rechnen, deutsche Texte
// Letzte �nderung 10.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Rechenart:";
var text02 = "Addition";
var text03 = "Addition (mehrere Summanden)";
var text04 = "Subtraktion";
var text05 = "Multiplikation";
var text06 = "Division (ohne Rest)";
var text07 = "Division (mit Rest)";
var text08 = "Schwierigkeitsgrad:";
var text09 = "N&auml;chste Aufgabe";

var author = "W. Fendt 1998";

// Texte in Unicode-Schreibweise:

var text11 = "Keine Rechenart ausgew\u00e4hlt!";           // Warnmeldung f�r type == 0
var text12 = ["1 Aufgabe",                        
              "x Aufgaben"];         
var text13 = "davon";
var text14 = ["x v\u00f6llig richtig"];                 
var text15 = ["x Fehler"];                           