// Besondere Linien und Kreise im Dreieck, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Mittelsenkrechte";
var text02 = "Umkreis";
var text03 = "Winkelhalbierende";
var text04 = "Inkreis";
var text05 = "Ankreise";
var text06 = "Mittelparallelen";
var text07 = "Seitenhalbierende";
var text08 = "H&ouml;hen";
var text09 = "Eulersche Gerade";
var text10 = "Feuerbachscher Kreis";

var author = "W. Fendt 1998";
var translator = "";
