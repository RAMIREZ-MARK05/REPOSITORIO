// Rechnen mit Restklassen, deutsche Texte
// Letzte �nderung 20.07.2022

// Texte in HTML-Schreibweise:

var text01 = "Restklassen modulo";
var text02 = "Addition";
var text03 = "Subtraktion";
var text04 = "Multiplikation";
var text05 = "Division";
var text06 = "Inverses bez&uuml;glich Addition";
var text07 = "Inverses bez&uuml;glich Multiplikation";
var text11 = "1. Summand:";
var text12 = "2. Summand:";
var text13 = "Summe:";
var text21 = "Minuend:";
var text22 = "Subtrahend:";
var text23 = "Differenz:";
var text31 = "1. Faktor:";
var text32 = "2. Faktor:";
var text33 = "Produkt:";
var text41 = "Dividend:";
var text42 = "Divisor:";
var text43 = "Quotient:";
var text51 = "Gegebenes Element:";
var text52 = "Inverses Element:";
var text61 = "Gegebenes Element:";
var text62 = "Inverses Element:";
var undef = "n. def.";

var author = "W. Fendt  2022";

// Texte in Unicode-Schreibweise:

var symbolAdd = "+";
var symbolSub = "\u2212";
var symbolMul = "\u00B7";
var symbolDiv = ":";
var symbolNeg = "\u2212x";



