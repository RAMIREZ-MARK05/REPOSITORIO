// Geradengleichung, deutsche Texte
// Letzte �nderung 27.10.2015

// Texte in HTML-Schreibweise:

var text01 = "Punkt A:";
var text02 = "Punkt B:";

//var decimalSeparator = ",";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text03 = "Gerade AB nicht definiert!";

var symbolPoint1 = "A";
var symbolPoint2 = "B";
var symbolX = "x_1";
var symbolY = "x_2";
var symbolZ = "x_3";
var symbolPositionVector = "X";
var symbolParameter = "\u03BB";
