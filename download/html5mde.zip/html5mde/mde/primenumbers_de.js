// Primzahlentabelle, deutsche Texte
// Letzte �nderung 05.09.2015

var textError = "Fehlerhafte Eingabe!";                    // Text f�r Fehlermeldung
var textPrime = "ist eine Primzahl.";                      // Text f�r Primzahl
var symbolMult = "&middot;";                               // Multiplikationszeichen (HTML)
