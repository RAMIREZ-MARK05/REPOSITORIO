// T�rme von Hanoi, deutsche Texte
// Letzte �nderung 26.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Zahl der Scheiben:";
var text02 = "Zur&uuml;ck";
var text03 = "Eigene L&ouml;sung";
var text04 = "Automatische L&ouml;sung";
var text05 = ["Start", "Pause", "Weiter"];

// Texte in Unicode-Schreibweise:

var text06 = "Zug";
var text07 = "Gl\u00FCckwunsch!";
var text08 = "Das Problem ist gel\u00F6st.";

var author = "W. Fendt 2022";
var translator = "";

