// Einfache geometrische Abbildungen, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text02 = "Neue Zeichnung";
var text04 = "Hinzuf&uuml;gen";
var text05 = "L&ouml;schen";
var text06 = "Bild";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text01 = ["Achsenspiegelung", "Punktspiegelung", "Verschiebung", "Drehung"];
var text03 = ["Punkt", "Gerade", "Halbgerade", "Strecke", "Kreis", "Dreieck", "Viereck"];

