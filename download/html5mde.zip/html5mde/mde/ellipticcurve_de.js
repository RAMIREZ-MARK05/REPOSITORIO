// Elliptische Kurve, deutsche Texte
// Letzte �nderung 17.11.2020

// Texte in HTML-Schreibweise:

var text01 = "Koeffizient a:";
var text02 = "Koeffizient b:";

var author = "W. Fendt 2020";
var translator = "";

// Symbole:

var decimalSeparator = ",";
var symbolX = "x";
var symbolY = "y";
var symbolSummand1 = "P";
var symbolSummand2 = "Q";
var symbolSum = "P+Q";
