// Primyphos, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Zerlege in zwei Faktoren:";

var author = "W. Fendt 1998";

var symbolMultiply = "&middot;";

// Texte in Unicode-Schreibweise:

var text02 = ["Herzlichen Gl\u00FCckwunsch!", 
              "Das war Spitze!", 
              "Hervorragend!", 
              "Nicht \u00FCbel!", 
              "Eine reife Leistung!", 
              "Beeindruckend!",
              "Fantastisch!"];
              
var text03 = ["Wenn du das Spiel neu starten willst:",
              "Ein Mausklick gen\u00FCgt!"];

var symbolMultiplyUnicode = "\u00B7";
