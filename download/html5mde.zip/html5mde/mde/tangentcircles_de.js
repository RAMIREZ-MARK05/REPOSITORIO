// Ber�hrkreise, deutsche Texte
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Gegeben:";
var text02 = "Zwei Punkte";
var text03 = "Punkt und Gerade";
var text04 = "Punkt und Kreis";
var text05 = "Zwei Geraden";
var text06 = "Gerade und Kreis";
var text07 = "Zwei Kreise";

var author = "W. Fendt 2017";
var translator = "";

