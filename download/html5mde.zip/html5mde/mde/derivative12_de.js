// 1. und 2. Ableitungsfunktion, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Funktionsgleichung:";
var text02 = "f(x) =";
var text03 = "1. Ableitung";
var text04 = "2. Ableitung";
var text05 = "Linker Rand:";
var text06 = "Rechter Rand:";
var text07 = "Unterer Rand:";
var text08 = "Oberer Rand:";
var text09 = "Zeichnen";

var author = "W. Fendt 1999";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text10 = "Funktionsterm unverst\u00E4ndlich!";
var text11 = "Fehler bei Ableitung!";

var symbolX = "x";
var symbolY = "y";
