// 15-Puzzle, deutsche Texte
// Letzte �nderung 22.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Ausgangsstellung";
var text02 = "Zuf&auml;llige Stellung";
var text03 = "Z&uuml;ge:";
var text04 = ["Gratulation!", "Du hast das R&auml;tsel gel&ouml;st."];

var author = "W. Fendt 2023";
var translator = "";



