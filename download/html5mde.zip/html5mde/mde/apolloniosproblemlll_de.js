// Apollonios-Problem LLL, deutsche Texte
// Letzte �nderung 19.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Auswahl der L&ouml;sungen (rot):";
var text02 = ["(Die H&auml;kchen stehen jeweils f&uuml;r",
              "eine Halbebene in Bezug auf eine",
              "der gegebenen Geraden.)"];
var text03 = ["L&ouml;sungstyp 1:",
              "L&ouml;sungstyp 2:",
              "L&ouml;sungstyp 3:",
              "L&ouml;sungstyp 4:",
              "L&ouml;sungstyp 5:",
              "L&ouml;sungstyp 6:",
              "L&ouml;sungstyp 7:",
              "L&ouml;sungstyp 8:"];   
var text04 = "Zahl der L&ouml;sungen:";   
        
var author = "W. Fendt 2008"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var nameLine1 = "g_1";
var nameLine2 = "g_2";
var nameLine3 = "g_3";

