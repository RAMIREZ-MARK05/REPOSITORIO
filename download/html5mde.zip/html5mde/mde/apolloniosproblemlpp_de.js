// Apollonios-Problem LPP, deutsche Texte
// Letzte �nderung 19.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Auswahl der L&ouml;sungen (rot):";
var text02 = ["(Die H&auml;kchen stehen f&uuml;r eine der",
              "Halbebenen in Bezug auf die ge-", 
              "gebene Gerade.)"];
var text03 = ["L&ouml;sungstyp 1:",
              "L&ouml;sungstyp 2:"];   
var text04 = "Zahl der L&ouml;sungen:";  
         
var author = "W. Fendt 2008"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var nameLine1 = "g";
var namePoint1 = "P_1";
var namePoint2 = "P_2";

