// Rechnen mit komplexen Zahlen, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Rechenart:";
var text02 = "Addition";
var text03 = "Subtraktion";
var text04 = "Multiplikation";
var text05 = "Division";
var text06 = "Koordinatensystem:";
var text07 = "Kartesische Koordinaten";
var text08 = "Polarkoordinaten";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1998";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "nicht definiert!";

var symbolOperation = ["+", "\u2212", "\u00B7", ":"];      // Rechenzeichen
