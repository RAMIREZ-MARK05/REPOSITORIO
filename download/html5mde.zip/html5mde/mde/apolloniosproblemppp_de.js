// Apollonios-Problem PPP, deutsche Texte
// Letzte �nderung 19.10.2017

// Texte in HTML-Schreibweise:

var text02 = ["Gesucht ist ein Kreis, der durch", 
              "drei gegebene Punkte geht, also", 
              "der Umkreis des entsprechenden",
              "Dreiecks."];
var text04 = "Zahl der L&ouml;sungen:"; 
          
var author = "W. Fendt 2008"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var namePoint1 = "P_1";
var namePoint2 = "P_2";
var namePoint3 = "P_3";

