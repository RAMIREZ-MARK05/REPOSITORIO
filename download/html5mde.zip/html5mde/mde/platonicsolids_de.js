// Platonische K�rper, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Tetraeder";
var text02 = "Hexaeder (W&uuml;rfel)";
var text03 = "Oktaeder";
var text04 = "Dodekaeder";
var text05 = "Ikosaeder";
var text06 = "Lage &auml;ndern";
var text07 = "Umkugel";
var text08 = "Kantenkugel";
var text09 = "Inkugel";

var author = "W. Fendt 1998";
