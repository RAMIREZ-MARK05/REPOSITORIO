// Epizykloiden und Hypozykloiden, deutsche Texte
// Letzte �nderung 24.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Epizykloide";
var text02 = "Hypozykloide";
var text03 = "Verh&auml;ltnis der Radien:";
var text04 = "Zur&uuml;ck";
var text05 = ["Start", "Pause", "Weiter"];  

var author = "W. Fendt 2017";    

// Texte in Unicode-Schreibweise:

var text06 = "Spezialfall Kardioide (Herzkurve)";  
var text07 = "Spezialfall Nephroide (Nierenkurve)";
var text08 = "Spezialfall Kreisdurchmesser (Cardanische Kreise)";
var text09 = "Spezialfall Deltoide";
var text10 = "Spezialfall Astroide";                   




