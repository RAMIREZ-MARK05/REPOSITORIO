// Umrechnung von Einheiten, deutsche Texte
// Letzte �nderung 10.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Neu anfangen";
var text02 = "Start";
var text03 = "L&auml;nge";
var text04 = "Fl&auml;che";
var text05 = "Volumen";
var text06 = "Masse";
var text07 = "Zeit";
var text08 = "Schwierigkeitsgrad:";
var text09 = ["1 Aufgabe", 
              "x Aufgaben"];    
var text10 = ["x Treffer"];    
     
var author = "W. Fendt 2001";                                        // Autor (und �bersetzer)

var decimalSeparator = ",";                                          // Dezimaltrennzeichen (Komma/Punkt)

