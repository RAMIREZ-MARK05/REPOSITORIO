// Abakus, deutsche Texte
// Letzte �nderung 01.08.2023

// Texte in HTML-Schreibweise:

var text01 = "Zahl der Stellen:";
var text02 = "Dezimalschreibweise:";
var text03 = "R&ouml;mische Zahlenschreibweise:";

var author = "W. Fendt 2023";
var translator = "";




