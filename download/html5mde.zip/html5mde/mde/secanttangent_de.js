// Sekanten- und Tangentensteigung, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Fester Punkt:";
var text02 = "Variabler Punkt:";
var text03 = "Sekantensteigung:";
var text04 = "Tangentensteigung:";

var author = "W. Fendt 1998";
var translator = "";

var decimalSeparator = ",";                      // Dezimaltrennzeichen (Komma/Punkt)
var textUndefValue = "nicht definiert";          // Text f�r "nicht definiert"
