// Kreiszahl Pi, deutsche Texte
// Letzte �nderung 02.02.2021

// Texte in HTML-Schreibweise:

var text01 = "Zahl der Ecken:";
var text02 = "Viereck";
var text03 = "Sechseck";
var text04 = "Eckenzahl verdoppeln";
var text05 = "Seitenl&auml;nge";
var text06 = "Umfang";
var text07 = "Fl&auml;cheninhalt";

var author = "W. Fendt 2002";
var translator = "";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";

var text11 = "Seitenl\u00E4nge (einbeschriebenes Vieleck):";
var text12 = "Seitenl\u00E4nge (umbeschriebenes Vieleck):";
var text13 = "Umfang (einbeschriebenes Vieleck):";
var text14 = "Umfang (umbeschriebenes Vieleck):";
var text15 = "Fl\u00E4cheninhalt (einbeschriebenes Vieleck):";
var text16 = "Fl\u00E4cheninhalt (umbeschriebenes Vieleck):";



