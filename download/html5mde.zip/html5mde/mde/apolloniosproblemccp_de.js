// Apollonios-Problem CCP, deutsche Texte
// Letzte �nderung 19.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Auswahl der L&ouml;sungen (rot):";
var text02 = ["(Die gegebenen Kreise (schwarz), die", 
              "ausschlie&szlig;end ber&uuml;hrt werden sollen,", 
              "sind durch H&auml;kchen gekennzeichnet.)"];
var text03 = ["L&ouml;sungstyp 1:",
              "L&ouml;sungstyp 2:",
              "L&ouml;sungstyp 3:",
              "L&ouml;sungstyp 4:"];   
var text04 = "Zahl der L&ouml;sungen:";           
var author = "W. Fendt 2008"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var nameCircle1 = "k_1";
var nameCircle2 = "k_2";
var namePoint1 = "P";

