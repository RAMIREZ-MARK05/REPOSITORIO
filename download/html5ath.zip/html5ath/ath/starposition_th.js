// Position eines Gestirns, englische Texte und Defaultwerte
// Letzte �nderung 20.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Geogr. longitude:";
var text03 = "Geogr. latitude:";
var text05 = "Date:";
var text06 = "Time:";
var text07 = "h (UT)";
var text08 = "Right ascension:";
var text09 = "Declination:";
var text10 = "Reset";
var text11 = ["Start", "Pause", "Resume"];
var text12 = "Emphasize:";

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var dateSeparator = "/";
var timeSeparator = ":";
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var text02 = ["(eastern longitude)", "(western longitude)"];
var text04 = ["(northern latitude)", "(southern latitude)"];
var text13 = ["", "point of observation", "horizon",
              "north point", "west point", "south point", "east point", 
              "zenith", "nadir", "meridian", "altitude circle", 
              "celestial north pole", "celestial south pole", "celestial axis", "celestial equator",
              "vernal equinox", "hour circle", "sidereal time",
              "hour angle", "star", "course of star",
              "right ascension", "declination", "azimuth", "altitude", "nautical triangle"];
var text14 = "Time:";
var text15 = "Sidereal time:";
var text16 = "Azimuth:";
var text17 = "Hour angle:";
var text18 = "Altitude:";

// Symbole und Einheiten:

var symbolObserver = "O";                                  // Beobachtungsort
var symbolNorth = "N";                                     // Nordpunkt
var symbolWest = "W";                                      // Westpunkt
var symbolSouth = "S";                                     // S�dpunkt
var symbolEast = "E";                                      // Ostpunkt
var symbolZenith = "Ze";                                   // Zenit
var symbolNadir = "Na";                                    // Nadir
var symbolNorthPole = "NP";                                // Himmelsnordpol
var symbolSouthPole = "SP";                                // Himmelss�dpol
var symbolVernalEquinox = "V";                             // Fr�hlingspunkt
var symbolStar = "St";                                     // Stern
var symbolHour = "h";                                      // Stunde

// Defaultwerte:

var defaultLongitude = 0*DEG;                              // Geographische L�nge (London)
var defaultLatitude = 50*DEG;                              // Geographische Breite (London)
var defaultDay = 1;                                        // Tag
var defaultMonth = 1;                                      // Monat
var defaultYear = 2000;                                    // Jahr
var defaultTimeZone = 0;                                   // Zeitzone relativ zu UT (h)
