// Zwillingskreise des Archimedes, spanische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "L&iacute;neas auxiliares:";
var text02 = "a la izquierda";
var text03 = "a la derecha";

var author = "W. Fendt 2000";
