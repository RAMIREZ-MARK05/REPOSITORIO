// Ber�hrkreise, spanische Texte
// Letzte �nderung 27.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Elementos dados:";
var text02 = "Dos puntos";
var text03 = "Punto y recta";
var text04 = "Punto y circunferencia";
var text05 = "Dos rectas";
var text06 = "Recta y circunferencia";
var text07 = "Dos circunferencias";

var author = "W. Fendt 2017";

