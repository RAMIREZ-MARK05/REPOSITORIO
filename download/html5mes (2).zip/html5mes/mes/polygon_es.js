// Regelm��ige Vielecke, spanische Texte
// Letzte �nderung 27.04.2018

// Texte in HTML-Schreibweise:

var text11 = "N&uacute;mero de v&eacute;rtices:";
var text12 = "Circunferencia circunscrita";
var text13 = "Circunferencia inscrita";
var text14 = "Tri&aacute;ngulos";
var text15 = "Diagonales";

var text21 = "S&iacute;mbolo de Schl&auml;fli:";

var author = "W. Fendt 2018";
var translator1 = "";
var translator2 = "";





