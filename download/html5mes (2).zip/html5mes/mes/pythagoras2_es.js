// Satz des Pythagoras, spanische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var author = "W. Fendt 2001";
var translator = "";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
