// Komponenten eines Vektors, spanische Texte (Nicol�s Rosillo)
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise (eventuell mit '<sub>...</sub>' f�r Index):

var text01 = "Coordenadas:";
var text02 = "x =";
var text03 = "y =";
var text04 = "z =";

var author = "W. Fendt 1998";
var translator = "N. Rosillo 2002";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise (eventuell mit Index, zum Beispiel "x_1"):

var symbolX = "x";
var symbolY = "y";
var symbolZ = "z";
