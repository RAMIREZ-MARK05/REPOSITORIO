// Einfache geometrische Abbildungen, spanische Texte
// Letzte �nderung 27.02.2020

// Texte in HTML-Schreibweise:

var text02 = "Nuevo dibujo";
var text04 = "Agregar";
var text05 = "Borrar";
var text06 = "Imagen";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text01 = ["reflexi\u00F3n axial", "reflexi\u00F3n central", "traslaci\u00F3n", "rotaci\u00F3n"];
var text03 = ["punto", "recta", "semirrecta", "segmento", "circunferencia", "tri\u00E1ngulo", "cuadril\u00E1tero"];

