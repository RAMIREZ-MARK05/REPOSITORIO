// Kugeldreieck, spanische Texte (Nicol�s Rosillo)
// Letzte �nderung 05.04.2018

// Texte in HTML-Schreibweise:

var text01 = "Lados:";
var text02 = "a = ";
var text03 = "b = ";
var text04 = "c = ";
var text05 = "Suma Lados: ";
var text06 = "&Aacute;ngulos:";
var text07 = "&alpha; = ";
var text08 = "&beta; = ";
var text09 = "&gamma; = ";
var text10 = "Suma &Aacute;ngulos: ";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1999";
var translator = "N. Rosillo 2002";

// Texte in Unicode-Schreibweise:

var symbolA = "A";
var symbolB = "B";
var symbolC = "C";


