// Geradengleichung, spanische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Punto A:";
var text02 = "Punto B:";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text03 = "\u00A1Recta AB no definida!";

var symbolPoint1 = "A";
var symbolPoint2 = "B";
var symbolX = "x";
var symbolY = "y";
var symbolZ = "z";
var symbolPositionVector = "X";
var symbolParameter = "\u03BB";
