// Primzahlentabelle, spanische Texte
// Letzte �nderung 19.01.2016

var textError = "\u00A1Error!";                            // Text f�r Fehlermeldung
var textPrime = "es un n\u00FAmero primo.";                // Text f�r Primzahl
var symbolMult = "&middot;";                               // Multiplikationszeichen (HTML)
