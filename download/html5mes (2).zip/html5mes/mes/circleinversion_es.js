// Kreisspiegelung, spanische Texte
// Letzte �nderung 27.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Nuevo dibujo";
var text03 = "Agregar";
var text04 = "Borrar";
var text05 = "Imagen";

var author = "W. Fendt 2017";
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["punto", "recta", "semirrecta", "segmento", "circunferencia", "tri\u00E1ngulo", "cuadril\u00E1tero"];

