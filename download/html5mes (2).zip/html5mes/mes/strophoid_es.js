// Gerade Strophoide, spanische Texte
// Letzte �nderung 09.11.2020

// Texte in HTML-Schreibweise:

var text01 = "Restablecer";
var text02 = ["Iniciar", "Pausa", "Reanudar"];  

var author = "W. Fendt 2020";    

                




