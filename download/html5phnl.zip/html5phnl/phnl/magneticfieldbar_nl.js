// Magnetfeld eines Stabmagneten, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Wis alle veldlijnen";
var text02 = "Draai magneet om";

var author = "W. Fendt 2001";
var translator = "H. Russeler 2006";
