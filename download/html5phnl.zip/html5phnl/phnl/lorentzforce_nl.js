// Leiterschaukel-Versuch zur Lorentzkraft, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Aan / Uit";
var text02 = "Ompolen stroom";
var text03 = "Magneet draaien";
var text04 = "Stroomrichting";
var text05 = "Magnetisch veld";
var text06 = "Lorentz-kracht";

var author = "W. Fendt 1998";
var translator = "T. Koops 2000";
