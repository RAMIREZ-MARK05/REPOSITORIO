// Zerfallsgesetz der Radioaktivit�t, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauze", "Doorgaan"];    
var text03 = "Diagram";  

var author = "W. Fendt 1998";
var translator = "T. Koops 2000";

// Texte in Unicode-Schreibweise:

var text04 = "Tijd:";                                      
var text05 = "Nog niet vervallen:";
var text06 = "Vervallen:";
var text07 = ["kernen", "kern", "kernen", "kernen"];       // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
