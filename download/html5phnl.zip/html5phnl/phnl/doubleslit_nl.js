// Interferenz von Licht am Doppelspalt, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Golflengte:";
var text02 = "Afstand tussen de spleten:";
var text03 = "Hoek:";
var text04 = "Maxima:";
var text05 = "Minima:";
var text06 = "Relatieve intensiteit:";
var text07 = "Interferentiepatroon";
var text08 = "Intensiteitprofiel";

var author = "W. Fendt 2003,&nbsp; H. Russeler 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
