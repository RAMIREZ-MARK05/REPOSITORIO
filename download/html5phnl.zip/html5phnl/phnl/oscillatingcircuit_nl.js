// Elektromagnetischer Schwingkreis, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauze", "Doorgaan"];
var text03 = "Vertraagd (10 &times;)";
var text04 = "Vertraagd (100 &times;)";
var text05 = "Capaciteit:";
var text06 = "Inductie:";
var text07 = "Weerstand:";
var text08 = "Max. spanning:";
var text09 = "Spanning, Stroom";
var text10 = "Energie";

var author = "W. Fendt 1999,&nbsp; T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                           
var henry = "H";                                   
var ohm = "&Omega;";                                
var volt = "V";                                       

// Texte in Unicode-Schreibweise:

var text11 = "Trillingstijd:";
var text12 = "Energie van het elektrisch veld:";
var text13 = "Energie van het magnetisch veld:";
var text14 = "Inwendige energie:";
var text15 = "Ongedempte oscillatie";
var text16 = "Gedempte oscillatie";
var text17 = "Kritische demping";
var text18 = "Overkritische demping";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                   
var voltUnicode = "V";                                
var ampere = "A";                                       
var joule = "J";                             
