// Potentiometerschaltung, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Spanning van de voedingsbron:";
var text02 = "Schuifweerstand:";
var text03 = "Plaats van het sleepcontact:";
var text04 = "Weerstand van het apparaat:";
var text05 = "Spanning weergeven";
var text06 = "Stroomsterkte weergeven";
var author = "W. Fendt 2006";
var translator = "H. Russeler 2006";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "V";                                  // Symbol f�r Spannung
var symbolVoltage2 = "A";                                  // Index f�r Verbraucher
                      
