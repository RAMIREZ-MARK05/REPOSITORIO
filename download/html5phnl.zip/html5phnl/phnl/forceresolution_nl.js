// Zerlegung einer Kraft in zwei Komponenten, niederl�ndische Version (Henk Russeler)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Grootte van de gegeven";                       
var text02 = "kracht:";
var text03 = "Grootte van de hoeken:";
var text04 = "1ste hoek:";
var text05 = "2de hoek:";
var text06 = "Grootte van de componenten:";
var text07 = "1ste component:";
var text08 = "2de component:";
var text09 = "Vind de componenten";
var text10 = "Wis de constructie";

var author = "W. Fendt 2003";
var translator = "H. Russeler 2006";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                              
var newton = "N";                                

// Texte in Unicode-Schreibweise:

var text11 = "1ste component";                             // Text f�r erste Komponente
var text12 = "2de component";                              // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                        