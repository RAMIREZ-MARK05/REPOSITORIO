// Messung der Auftriebskraft, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Grondoppervlak van het blok:"; 
var text02 = "Hoogte van het blok:";
var text03 = "Dichtheid van het blok:";
var text04 = "Dichtheid van de vloeistof:";   
var text05 = "Indoopdiepte:";
var text06 = "Verplaatst volume:"; 
var text07 = "Opwaartse kracht:";
var text08 = "Gewicht van het blok:";
var text09 = "Gemeten kracht:";
var text10 = "Meetbereik:";

var author = "W. Fendt 1998,&nbsp; T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Maximum overschreden!";
