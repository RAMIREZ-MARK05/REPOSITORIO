// Ohmsches Gesetz, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Max. spanning:";
var text02 = "Max. stroom:";
var text03 = "Verhoog weerstand";
var text04 = "Verlaag weerstand";
var text05 = "Verhoog spanning";
var text06 = "Verlaag spanning";

var author = "W. Fendt 1997";
var translator = "T. Koops 2000";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Maximum overschreden!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
