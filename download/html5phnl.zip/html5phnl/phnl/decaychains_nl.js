// Zerfallsreihen, niederl�ndische Texte (Teun Koops, WWW-Recherche)
// Letzte �nderung 10.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Vervalreeks:";
var text03 = "Volgend verval";

var author = "W. Fendt 1998"; 
var translator = "T. Koops 2000";

// Texte in Unicode-Schreibweise:

var text02 = ["Thoriumreeks", "Neptuniumreeks", "Uraniumreeks", "Actiniumreeks"];          





