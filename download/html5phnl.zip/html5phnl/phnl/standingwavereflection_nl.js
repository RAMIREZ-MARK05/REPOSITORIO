// Stehende Welle, Erkl�rung durch Reflexion, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Terugkaatsing";
var text02 = "bij een vast uiteinde";
var text03 = "bij een los uiteinde";
var text04 = "Reset";
var text05 = ["Start", "Pauze", "Doorgaan"];
var text06 = "Vertraagd";
var text07 = "Animatie";
var text08 = "Per stap";
var text09 = "Invallende golf";
var text10 = "Teruggekaatste golf";
var text11 = "Resulterende staande golf";

var author = "W. Fendt 2003"; 
var translator = "H. Russeler 2006";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "N";
var symbolAntiNode = "A";

