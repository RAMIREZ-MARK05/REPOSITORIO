// Gekoppelte Pendel, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";                           
var text02 = ["Start", "Pauze", "Doorgaan"];                
var text03 = "Vertraagd";
var text04 = "Beginpositie:";

var author = "W. Fendt 1998";
var translator = "T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                        

// Texte in Unicode-Schreibweise:

var text05 = "Slinger 1";                                  // Erstes Pendel (links)
var text06 = "Slinger 2";                                  // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
