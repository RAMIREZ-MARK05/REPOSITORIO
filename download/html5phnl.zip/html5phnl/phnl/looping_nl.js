// Loopingbahn, niederl�ndische Texte (Roland Van Kerschaver)
// Letzte �nderung 05.05.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauze", "Doorgaan"];
var text03 = "Vertraagd (5 &times;)";
var text04 = "Vertraagd (50 &times;)";
var text05 = "Straal:";
var text06 = "Aanvangshoogte:";
// Falls n�tig, Variable text06x f�r zus�tzliche Zeile!
var text07 = "Valversnelling:";
var text08 = "Massa:";
var text09 = "Snelheid";
var text10 = "Zwaartekracht en normaalkracht";
var text11 = "Tangenti&euml;le en centripetale kracht";
var text12 = "Resultante";

var author = "W. Fendt 2020";                              // Autor
var translator = "R. V. Kerschaver 2020";                  // �bersetzer

// Texte in Unicode-Schreibweise:

var text13 = "Snelheid:";
var text14 = "Zwaartekracht:";
var text15 = "Normaalkracht:";
var text16 = "Tangenti\u00EBle kracht:";
var text17 = "Centripetale kracht:";
var text18 = "Resultante:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var second = "s";                               
var meter = "m";                                 
var meterPerSecond = "m/s";                        
var meterPerSecond2 = "m/s\u00b2";         
var kilogram = "kg";
var newton = "N";    


