// Magnetfeld eines geraden stromdurchflossenen Leiters, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Ompolen";

var author = "W. Fendt 2000";
var translator = "T. Koops 2000";
