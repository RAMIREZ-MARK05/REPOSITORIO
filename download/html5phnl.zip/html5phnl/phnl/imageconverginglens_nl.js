// Bilderzeugung Sammellinse, niederl�ndische Texte (Wikipedia und andere WWW-Quellen)
// Letzte �nderung 27.04.2020

// Texte in HTML-Schreibweise:
    
var text01 = "Brandpuntsafstand:";
var text02 = "Voorwerpsafstand:";
var text03 = "Voorwerpshoogte:";
var text04 = "Beeldafstand:";
var text05 = "Beeldhoogte:";    
var text06 = "Aard van het beeld:"
var text07 = ["re&euml;el", "virtueel"];
var text08 = ["omgekeerd", "rechtop"];
var text09 = ["verkleind", "even groot", "vergroot", "onbegrensd groot"]; // ???
var text10 = "Bijzondere lichtstralen";
var text11 = "Lichtbundel";
var text12 = "Markeren:";

var author = "W. Fendt 2008";

// Symbole und Einheiten:

var centimeter = "cm";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text13 = ["voorwerp", 
              "voorwerpsafstand", 
              "voorwerpshoogte",
              "lens", 
              "hoofdvlak", // ???
              "optische as",
              "brandpunten", 
              "brandpuntsafstand", 
              "beeld", 
              "beeldafstand", 
              "beeldhoogte",
              "scherm"];
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "v";
var symbolGG = "V"; 
var symbolB = "b";
var symbolBB = "B";


