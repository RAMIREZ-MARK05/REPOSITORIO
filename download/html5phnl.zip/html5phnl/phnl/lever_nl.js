// Hebelgesetz, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in Unicode-Schreibweise:

var text01 = "Moment linksdraaiend:";
var text02 = "Moment rechtsdraaiend:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "M_1";                              // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "M_2";                             // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

var newton = "N";
var meter = "m";

var author = "W. Fendt 1997,  T. Koops 2000";              // Autor (und �bersetzer)
