// Kr�fte an der schiefen Ebene, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauze", "Doorgaan"];
var text03 = "Vertraagd";
var text04 = "Veerunster";
var text05 = "Krachtvectoren";
var text06 = "Hellingshoek:";
var text07 = "Gewicht:";
var text08 = "Component // helling:";
var text09 = "Normaalkracht:";
var text10 = "Wrijvingsco&euml;ffici&euml;nt:";
var text11 = "Wrijvingskracht:";
var text12 = "Trekkracht:";

var author = "W. Fendt 1999,&nbsp; T. Koops 2000";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                          
var newton = "N";                             
