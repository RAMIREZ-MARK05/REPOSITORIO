// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "2 katrollen";
var text02 = "4 katrollen";
var text03 = "6 katrollen";
var text04 = "Gewicht:";
var text05 = "Gewicht van de losse katrol(len):";
var text06 = "Benodigde kracht:";
var text07 = "Veerunster";
var text08 = "Krachtvectoren";

var author = "W. Fendt 1998";
var translator = "T. Koops 2000";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                  
