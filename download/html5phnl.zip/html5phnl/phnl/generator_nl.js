// Generator, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Zonder commutator";
var text02 = "Met Kommutator";
var text03 = "Omkering draairichting";
var text04 = ["Start", "Pauze", "Doorgaan"];
var text05 = "Bewegingsrichting";
var text06 = "Magneetveld";
var text07 = "Inductie stroom";

var author = "W. Fendt 1998";  
var translator = "T. Koops 2000";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "omw/min";                        // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
