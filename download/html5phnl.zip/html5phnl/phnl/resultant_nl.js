// Ersatzkraft mehrerer Kr�fte, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Aantal krachten:";
var text02 = "Bepaal de resultante";
var text03 = "Wis de tekening";

var author = "W. Fendt 1998";
var translator = "T. Koops 2000";
