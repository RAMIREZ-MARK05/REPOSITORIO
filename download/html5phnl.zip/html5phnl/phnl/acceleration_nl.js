// Bewegung mit konstanter Beschleunigung, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauze", "Doorgaan"];
var text03 = "Vertraagd";
var text04 = "Begin positie:";
var text05 = "Begin snelheid:";
var text06 = "Versnelling:";
var text07 = "Snelheidsvector";
var text08 = "Versnellingsvector";

var author = "W. Fendt 2000";
var translator = "H. Russeler 2006";

// Texte in Unicode-Schreibweise:

var text09 = "(in s)";                                     // Einheitenangabe f�r Zeit-Achse
var text10 = "(in m)";                                     // Einheitenangabe f�r Weg-Achse
var text11 = "(in m/s)";                                   // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(in m/s\u00b2)";                             // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                     
var meter = "m";                                      
var meterPerSecond = "m/s";                         
var meterPerSecond2 = "m/s\u00b2";                 
