// Druckdose (hydrostatischer Druck), niederl�ndische Texte (Teun Koops)
// Letzte �nderung 03.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Vloeistof:";
var text03 = "Dichtheid:";
var text04 = "Diepte:";
var text05 = "Vloeistofdruk:";

var author = "W. Fendt 1999";                              // Autor
var translator = "T. Koops 2000";                          // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["onbekend", "water", "ethanol", "benzeen", "tetrachloormethaan", "kwik"]; 
