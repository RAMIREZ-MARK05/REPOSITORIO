// Elastischer und unelastischer Sto�, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Elastische botsing";
var text02 = "Onelastische botsing";
var text03 = "Reset";
var text04 = "Start";
var text05 = "Vertraagd";
var text06 = "Karretje 1:";
var text07 = "Karretje 2:";
var text08 = "Massa:";
var text09 = "Snelheid:";
var text10 = "Snelheid";
var text11 = "Impuls";
var text12 = "Kinetische energie";

var author = "W. Fendt 1998,&nbsp; T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                                   
var meterPerSecond = "m/s";                             

// Texte in Unicode-Schreibweise:

var text13 = "Karretje 1:";
var text14 = "Karretje 2:";
var text15 = "Snelheden voor de botsing:";
var text16 = "Snelheden na de botsing:";
var text17 = "Impulsen voor de botsing:";
var text18 = "Impulsen na de botsing:";
var text19 = "Kinetische energie voor de botsing:";
var text20 = "Kinetische energie na de botsing:";
var text21 = "Totale impuls:";
var text22 = "Totale kinetische energie:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                 
var kilogramMeterPerSecond = "kg m/s";               
var joule = "J";                                      
