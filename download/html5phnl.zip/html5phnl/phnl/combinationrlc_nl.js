// Kombinationen von Widerst�nden, Spulen und Kondensatoren, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 21.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Wisselspanningsbron:";
var text02 = "Spanning:";
var text03 = "Frequentie:";
var text04 = "Onderdeel:";
var text05 = ["Weerstand", "Spoel", "Condensator"];
var text06 = ["Weerstand:", "Inductie:", "Capaciteit:"];
var text07 = "Vervangen";
var text08 = "Voeg toe (serie)";
var text09 = "Voeg toe (parallel)";
var text10 = "Wis";
var text11 = "Meter:";
var text12 = "Spanning";
var text13 = "Stroomsterkte";

var author = "W. Fendt 2004";
var translator = "H. Russeler 2006";

// Texte in Unicode-Schreibweise:

var text14 = "Spanning:";
var text15 = "Stroomsterkte:";
var text16 = "Complexe impedantie:";
var text17 = "Impedantie:";
var text18 = "Fasehoek:";
var text19 = "heel klein";                                 // Stromst�rke Voltmeter
var text20 = "heel klein";                                 // Spannung Amperemeter
var text21 = "heel klein";                                 // Impedanz/Widerstand Amperemeter
var text22 = "heel groot";                                 // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)