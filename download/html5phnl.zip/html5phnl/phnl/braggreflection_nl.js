// Bragg-Reflexion, niederl�ndische Texte
// Letzte �nderung 17.03.2021

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauze", "Doorgaan"];
var text03 = "Vertraagd";
var text04 = "Afstand tussen de vlakken:";
var text05 = "Golflengte:";
var text06 = "Hoek:";
var text07 = "Aantal vlakken:";
var text08 = "Padverschil:";

var author = "W. Fendt 2021";
var translator = "";

// Text in Unicode-Schreibweise:

var text09 = "Bragg-conditie vervuld!";

// Einheiten und Symbole:

var decimalSeparator = ",";
var picometer = "pm";
var degree = "\u00B0";
var symbolDeltaS = "\u0394s";
var symbolLambda = "\u03BB";