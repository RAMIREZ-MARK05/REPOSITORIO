// Kombinationen von Widerst�nden, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 27.04.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Spanning van de batterij:";
var text03 = "Weerstand:";
var text04 = "Weerstand toevoegen (Serieschakeling)";
var text05 = "Weerstand toevoegen (Parallelschakeling)";
var text06 = "Meters:";
var text07 = "Spanning";
var text08 = "Amp&egrave;re";

var author = "W. Fendt 2002";
var translator = "H. Russeler 2006";

// Texte in Unicode-Schreibweise:

var text09 = "Spanning:";
var text10 = "Amp\u00E8re:";
var text11 = "Weerstand:";
var text12 = "Vervangingsweerstand:";
var text13 = "heel klein";
var text14 = "heel groot";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

