// Einfache Wechselstromkreise, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Weerstand";
var text02 = "Condensator";
var text03 = "Spoel";
var text04 = "Reset";
var text05 = ["Start", "Pauze", "Doorgaan"];          
var text06 = "Vertraagd";
var text07 = "Frequentie:";
var text08 = "Max. spanning:";
var text09 = "Weerstand:";                            
var text10 = "Capaciteit:";                          
var text11 = "Impedantie:"; 
var text12 = "Max. stroom:"; 

var author = "W. Fendt 1998,&nbsp; T. Koops 2000";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                  
var volt = "V";                                     
var ampere = "A";                                   
var milliampere = "mA";                                
var microampere = "&mu;A";                         
var ohm = "&Omega;";                              
var microfarad = "&mu;F";                       
var henry = "H";                               

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
