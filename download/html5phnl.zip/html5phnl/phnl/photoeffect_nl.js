// Photoelektrischer Effekt, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Kathode materiaal:";
var text02 = ["cesium", "natrium"];
var text03 = "Spectraal lijn (Hg):";
var text04 = "Stopspanning:";
var text05 = "Frequentie:";
var text06 = ["Energie van een", "foton:"];
var text07 = "Uittree-arbeid:";
var text08 = ["Maximale kinetische energie", "van een elektron:"];
var text09 = "Wis metingen";

var author = "W. Fendt 2000,&nbsp; T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                
var terahertz = "THz";                          
var electronvolt = "eV";                            

// Texte in Unicode-Schreibweise:

var text10 = ["geel", "groen", "violet", "ultraviolet", "ultraviolet"];
var text11 = "(in THz)";
var text12 = "(in V)";
var text13 = [
             ["De energie van een foton is onvoldoende voor de", "emissie van een elektron."],
             ["Verhoog de stopspanning zo ver dat er geen", "elektronen de anode bereiken!"], 
             ["De stopspanning is zo hoog dat de elektronen", "terugkeren naar de kathode."],
             ["Ga door met een nieuwe meting voor een andere", "spectraal lijnen!"],
             ["Ga door met een nieuwe serie metingen voor", "een ander kathode materiaal!"],
             ["De metingen zijn klaar.", ""]
             ];

var symbolCathode = "K";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
