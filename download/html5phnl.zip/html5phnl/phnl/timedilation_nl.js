// Beispiel zur Zeitdilatation, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Verlaag de snelheid";
var text02 = "Verhoog de snelheid";
var text03 = "Reset";
var text04 = ["Start", "Pauze", "Doorgaan"];

var author = "W. Fendt 1997,&nbsp; T. Koops 2000";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text05 = "Afstand:";
var text06 = "5 lichturen";
var text07 = "Snelheid:";
var text08 = "Vliegtijd in het aarde-systeem:";
var text09 = "uren";
var text10 = "Vliegtijd in het ruimteschip-systeem:";