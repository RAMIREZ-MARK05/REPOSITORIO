// Beispiel zum Doppler-Effekt, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.17.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Pauze", "Doorgaan"]; 

var author = "W. Fendt 1998";
var translator = "T. Koops 2000";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                        
  ["Zo lang de ambulance de",
  "persoon nadert, komen de",
  "golffronten met kortere",
  "tussenpozen aan."],
  ["Nu verwijdert de ambulance",
  "zich van de persoon.",
  "De golffronten komen nu met",
  "langere tussenpozen aan."]];
  

