// Newtons Wiege, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Start";
var text03 = "Aantal kogels:";

var author = "W. Fendt 1997";
var translator = "H. Russeler 2007";
