// Wheatstonesche Br�ckenschaltung, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Nieuwe berekening";
var text02 = "Vergelijkingsweerstand:";
var text03 = "Schuifweerstand:";
var text04 = "Plaats van het sleepcontact:";
var text05 = "Spanning van de voedingsbron:";
var text06 = "Weerstand van de meter:";
var text07 = "Bereken de weerstand";
var text08 = "Spanningen aangeven";
var text09 = "Stroomsterktes aangeven";
var author = "W. Fendt 2006,&nbsp; H. Russeler 2006";

// Texte in Unicode-Schreibweise:

var text10 = ["Verplaats het sleepcontact zo,",
  	          "dat de stroomsterkte nul is!"];
var text11 = "Nu kan de weerstand berekend worden.";         

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var milliampere = "mA";
var ohm = "\u03A9";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00D7";                              
