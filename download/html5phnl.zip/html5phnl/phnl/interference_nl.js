// Interferenz zweier Kreis- oder Kugelwellen, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = ["Pauze", "Doorgaan"];                
var text02 = "Vertraagd";
var text03 = "Afstand tussen de";
var text04 = "twee bronnen:";
var text05 = "Golflengte:";

var author = "W. Fendt 1999";
var translator = "T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                             

// Texte in Unicode-Schreibweise:

var text06 = "Weglengteverschil:";
var text07 = "Versterking (maximale amplitude)";
var text08 = "Verzwakking (minimale amplitude)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (Lambda)
