// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Opnieuw";
var text02 = "Volgende stap";
var text03 = ["Pauze", "Doorgaan"];                  
var text04 = "Brekingsindex stof 1:";
var text05 = "Brekingsindex stof 2:";
var text06 = "Hoek van inval:";

var author = "W. Fendt 1998";
var translator = "T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                  

// Texte in Unicode-Schreibweise:

var text07 = [
  ["Een vlak golffront loopt",                             // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "diagonaal tegen het grens-",
   "vlak van twee stoffen.",
   "De golf heeft in elke stof",
   "een andere  snelheid."],
   
  ["Een vlak golffront loopt lood-",                       // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "recht tegen het grensvlak",
   "van twee stoffen.",
   "De golf heeft in elke stof",
   "een andere snelheid."],
   
  ["Bij aankomst van het golffront",                       // i == 2 (step == 1, n1 > n2)
   "gedragen punten op het",
   "grensvlak zich volgens het",
   "principe  van Huygens. Elk",
   "punt kan worden beschouwd",
   "als een cirkelvormige lichtbron.",
   "In stof 2 breiden deze elemen-",
   "taire golven zich sneller uit",
   "omdat de brekingsindex",
   "kleiner is."],
   
  ["Bij de aankomst van een golf-",                        // i == 3 (step == 1, n1 < n2)
   "front gedragen punten op het",
   "grensvlak zich naar het principe",
   "van Huygens. Elk punt kan",
   "worden beschouwd als een",
   "cirkelvormige lichtbron.",
   "In stof 2 breiden deze elemen-",
   "taire golven zich trager uit",
   "omdat de brekingsindex",
   "groter is."],
   
  ["Een superpositie van alle",                            // i == 4 (step == 2, total == false, esp1 > 0)
   "elementaire golven resulteert",
   "in een nieuwe vlakke golf.",
   "Merk op dat de voortplantings-",
   "richting van de vlakke",
   "golf verandert als deze",
   "van stof 1 in stof 2 komt."], 
   
  ["Een superpositie van alle",                            // i == 5 (step == 2, total == false, esp1 == 0)
   "elementaire golven resulteert",
   "in een nieuw vlak golffront."],
   
  ["Een superpositie van alle elemen-",                    // i == 6 (step == 2, total == true)
   "taire golven resulteert in een",
   "nieuwe vlakke golf in stof 1",
   "(weerkaatste golf).",
   "De golf dringt niet door in",
   "stof 2 (totale interne",
   "weerkaatsing)."],
   
  ["De voortplantingsrichting",                            // i == 7 (step == 3)
   "van de golven wordt hier",
   "getekend.",
   "Het is de lijn loodrecht op",
   "het golffront."],
   
  ["Een golffront komt zelden",                            // i == 8 (step == 4)
   "alleen!!"],

  ["Als de brekingsindex van beide",                       // i == 9 (n1 == n2)
  "stoffen gelijk is, gebeurt er",
  "niets speciaals."]];
          
var text08 = "Hoek van inval:"; 
var text09 = "Reflectiehoek:";
var text10 = "Brekingshoek:"; 
var text11 = "Stof 1";
var text12 = "Stof 2";      
var text13 = ["Grenshoek voor", "totale spiegeling:"];

// Einheiten:

var degreeUnicode = "\u00b0";                           
