// Zweites Kepler-Gesetz, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "Lange halve as:";
var text03 = "Excentriciteit:";
var text04 = ["Pauze", "Doorgaan"];
var text05 = "Vertraagd";
var text06 = ["Afstand", "vanaf de zon:"];
var text07 = "Snelheid:";
var text08 = "Momentane waarde:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Sectoren";
var text12 = "Snelheidsvector";

var author = "W. Fendt 2000,&nbsp; T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AE";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Mercurius", "Venus", "Aarde", "Mars", "Jupiter", "Saturnus", "Uranus", "Neptunus",
              "Pluto", "Komeet van Halley", ""];

// Symbole und Einheiten: 

var auUnicode = "AE";
var symbolPeriod = "T";

