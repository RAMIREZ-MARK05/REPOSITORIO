// Schiefer Wurf, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";                    
var text02 = ["Start", "Pauze", "Doorgaan"];          
var text03 = "Vertraagd";
var text04 = "Starthoogte:";
var text05 = "Beginsnelheid:";
var text06 = "Hoek:";
var text07 = "Massa:"; 
var text08 = "Valversnelling (g):";
var text09 = "Co&ouml;rdinaten";
var text10 = "Snelheid";
var text11 = "Valversnelling";
var text12 = "Kracht";
var text13 = "Energie";

var author = "W. Fendt 2000,&nbsp; T. Koops 2000";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                 
var meterPerSecond = "m/s";                       
var meterPerSecond2 = "m/s&sup2;";               
var kilogram = "kg";                             
var degree = "&deg;";                           

// Texte in Unicode-Schreibweise:

var text14 = "(in m)";                                     // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Co\u00F6rdinaten:";
var text16 = "(horizontaal)";
var text17 = "(verticaal)";
var text18 = "Werpafstand:";
var text19 = "Maximale hoogte:";
var text20 = "Tijd:";
var text21 = "Snelheidscomponenten:";
var text22 = "Totale snelheid:";
var text23 = "Hoek:";
var text24 = "Valversnelling:";
var text25 = "Kracht:";
var text26 = "Kinetische energie:";
var text27 = "Potenti\u00EBle energie:";
var text28 = "Totale energie:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                            
var secondUnicode = "s";                             
var meterPerSecondUnicode = "m/s";                   
var meterPerSecond2Unicode = "m/s\u00b2";               
var newtonUnicode = "N";                           
var jouleUnicode = "J";                               
var degreeUnicode = "\u00b0";                         



