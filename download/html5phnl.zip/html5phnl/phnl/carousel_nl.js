// Kettenkarussell, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Draaimolen";
var text02 = "Draaimolen met krachten";
var text03 = "Schets";
var text04 = "Numerieke waarden";
var text05 = ["Pauze", "Doorgaan"];
var text06 = "Vertraagd";
var text07 = "Omlooptijd:";
var text08 = ["Afstand tussen de ophangpunten", "en de rotatie-as:"]; 
var text09 = "Lengte van de koorden:";
var text10 = "Massa:";

var author = "W. Fendt 1999,&nbsp; T. Koops 2000";

// Texte in Unicode-Schreibweise:

var text11 = "Frequentie:";
var text12 = "Hoeksnelheid:";
var text13 = "Straal:";
var text14 = "Snelheid:";
var text15 = "Hoek:";
var text16 = "Gewicht:";
var text17 = "Middelpuntzoekende kracht:";
var text18 = "Trekkracht in het koord:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




