// Schwebungen, niederl�ndische Texte (Henk Russeler)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauze", "Doorgaan"];
var text03 = "Vertraagd";
var text04 = "Frequenties:";
var text05 = "1ste golf:";
var text06 = "2de golf:";

var author = "W. Fendt 2001"; 
var translator = "H. Russeler 2006";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



