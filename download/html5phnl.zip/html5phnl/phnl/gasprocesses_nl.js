// Spezielle Prozesse eines idealen Gases, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 17.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Isobaar proces";
var text02 = "Isochoor proces";
var text03 = "Isotherm proces";
var text04 = "Beginsituatie:";
var text05 = "Druk:";
var text06 = "Volume:";
var text07 = "Temperatuur:";
var text08 = "Eindsituatie:";
var text09 = "Beginsituatie";
var text10 = "Start";

var author = "W. Fendt 1999,&nbsp; T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Arbeid";
var text12 = "Warmte";
var text13 = "De interne energie van het gas";
var text14 = "neemt toe.";
var text15 = "De interne energie van het gas";
var text16 = "blijft gelijk.";
var text17 = "De interne energie van het gas";
var text18 = "neemt af.";
var text19 = "Druk te klein!";
var text20 = "Druk te groot!";
var text21 = "Volume te klein!";
var text22 = "Volume te groot!";
var text23 = "Temperatuur te klein!";
var text24 = "Temperatuur te groot!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


