// Reflexion und Brechung von Licht, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = "Brekingsindex stof 1:";
var text02 = "Brekingsindex stof 2:";
var text03 = "Hoek van inval:";
var text04 = "Hoek van terugkaatsing:";
var text05 = "Brekingshoek:";    
var text06 = ["Grenshoek van de", "totale reflectie:"];

var author = "W. Fendt 1997,&nbsp; T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                              

// Texte in Unicode-Schreibweise:

var text07 = [["vacu\u00FCm", "1"], ["lucht", "1.0003"],   // Stoffe und Brechungsindizes
    ["water", "1.33"], ["alcohol [ethanol]", "1.36"],
    ["kwartsglas", "1.46"], ["benzeen", "1.49"], 
    ["kroonglas N-K5", "1.52"], ["steenzout", "1.54"], 
    ["flintglas LF5", "1.58"], ["kroonglas N-SK4", "1.61"],
    ["flintglas SF6", "1.81"], ["diamant", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                        
