// Stehende L�ngswellen, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Vorm van de buis:";
var text02 = "beide zijden open";
var text03 = "&eacute;&eacute;n kant open";
var text04 = "beide kanten gesloten";
var text05 = "Trillingstoestand:";
var text06 = ["grondtoon", "1e boventoon",                 // Bezeichnungen der Eigenschwingungen 
              "2e boventoon", "3e boventoon", 
              "4e boventoon", "5e boventoon"];
var text07 = "Lager";
var text08 = "Hoger";
var text09 = "Lengte van de buis:";
var text10 = "Golflengte:";
var text11 = "Frequentie:";

var author = "W. Fendt 1998,&nbsp; T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                 
var hertz = "Hz";                                  

// Texte in Unicode-Schreibweise:

var text12 = "Uitwijking van de deeltjes";                 // �berschrift des ersten Diagramms
var text13 = "Drukwisseling";                              // �berschrift des zweiten Diagramms (?)

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "K";                                      // Symbol f�r Knoten
var symbolAntinode = "B";                                  // Symbol f�r Bauch

