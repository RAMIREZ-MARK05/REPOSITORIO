// Kepler-Fernrohr, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Brandpuntsafstanden:"; 
var text02 = "Objectief:";
var text03 = "Oculair:";
var text04 = "Hoeken:";
var text05 = "Vergroting:";

var author = "W. Fendt 2000";
var translator = "T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite
