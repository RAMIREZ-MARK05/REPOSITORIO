// Gleichgewicht dreier Kr�fte, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Krachten:";
var text02 = "Links:";
var text03 = "Rechts:";
var text04 = "Onder:";
var text05 = "Parallellogram van krachten";
var text06 = "Hoeken:";
var text07 = "Links:";
var text08 = "Rechts:";

var author = "W. Fendt 2000";
var translator = "T. Koops 2000";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                             
var newton = "N";                                  
