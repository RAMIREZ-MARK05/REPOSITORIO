// Gleichstrom-Elektromotor, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Reset";
var text02 = ["Start", "Pauze", "Doorgaan"];             
var text03 = "Omkeren draairichting";
var text04 = "Stroomrichting";
var text05 = "Magnetisch veld";
var text06 = "Lorentz-kracht";

var author = "W. Fendt 1997";               
var translator = "T. Koops 2000";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "omw/min";                        // Umdrehungen pro Minute
