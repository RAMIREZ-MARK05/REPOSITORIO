// Erstes Kepler-Gesetz, niederl�ndische Texte (Teun Koops)
// Letzte �nderung 20.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "Lange halve as:";
var text03 = "Excentriciteit:";
var text04 = "Korte halve as:";
var text05 = ["Pauze", "Doorgaan"];
var text06 = "Vertraagd";
var text07 = "Afstand vanaf de zon:";
var text08 = "Actuele waarde:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Baanvlak";
var text12 = "Assen";
var text13 = "Verbindingslijnen";

var author = "W. Fendt 2000,&nbsp; T. Koops 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AE";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Mercurius", "Venus", "Aarde", "Mars", "Jupiter", "Saturnus", "Uranus", "Neptunus",
              "Pluto", "Komeet  Halley", ""];

var text14 = "Zon";
var text15 = "Planeet";
var text16 = "Komeet";
var text17 = "Perihelium";
var text18 = "Aphelium";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "AE";

