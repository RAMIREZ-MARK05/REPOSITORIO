// Himmelspole, niederländische Texte (Roland van Kerschaver)
// Letzte Änderung 23.02.2020

// Texte in Unicode-Schreibweise:

var text01 = "Evenaar";
var	text02 = "Noordpool";
var text03 = "Zuidpool";
var text04 = "Aardas";
var text05 = "Horizontaal vlak";
var text06 = "Hemelbol";
var	text07 = "Zenith";
var text08 = "Noordelijke hemelpool";
var	text09 = "Zuidelijke hemelpool";
var text10 = "Noord";
var text11 = "Zuid";

var author = "W. Fendt 1998,  R. van Kerschaver 2019";
