// Position eines Gestirns, niederländische Texte (Roland van Kerschaver), Defaultwerte
// Letzte Änderung 16.05.2019

// Texte in HTML-Schreibweise:

var text01 = "Geogr. lengte:";
var text03 = "Geogr. breedte:";
var text05 = "Datum:";
var text06 = "Tijd:";
var text07 = "h (MET)";
var text08 = "Rechte stijging:";
var text09 = "Declinatie:";
var text10 = "Reset";
var text11 = ["Start", "Pauze", "Opnieuw"];
var text12 = "Samenvatting:";

var author = "W. Fendt 1999,  R. van Kerschaver 2019";

// Symbole und Einheiten:

var dateSeparator = "/";
var timeSeparator = ":";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var text02 = ["(oosterlengte)", "(westerlengte)"];
var text04 = ["(noorderbreedte)", "(zuiderbreedte)"];
var text13 = ["", "waarnemingspunt", "horizont",
              "noordpunt", "westpunt", "zuidpunt", "oostpunt", 
              "zenith", "nadir", "meridiaan", "hoogtecircel", 
              "hemelnoordpool", "hemelzuidpool", "hemelas", "hemelevenaar",
              "lentepunt", "uurcircel", "sterrentijd",
              "uurhoek", "ster", "loop van ster",
              "rechte klimming", "declinatie", "azimuth", "hoogte", "nautische driehoek"];
var text14 = "Tijd:";
var text15 = "Sterrentijd:";
var text16 = "Azimuth:";
var text17 = "Uurhoek:";
var text18 = "Hoogte:";

// Symbole und Einheiten:

var symbolObserver = "Wa";                                 // Beobachtungsort
var symbolNorth = "N";                                     // Nordpunkt
var symbolWest = "W";                                      // Westpunkt
var symbolSouth = "Z";                                     // Südpunkt
var symbolEast = "O";                                      // Ostpunkt
var symbolZenith = "Ze";                                   // Zenit
var symbolNadir = "Na";                                    // Nadir
var symbolNorthPole = "NP";                                // Himmelsnordpol
var symbolSouthPole = "ZP";                                // Himmelssüdpol
var symbolVernalEquinox = "L";                             // Frühlingspunkt
var symbolStar = "St";                                     // Stern
var symbolHour = "h";                                      // Stunde

// Defaultwerte:

var defaultLongitude = 0*DEG;                              // Geographische Länge (London)
var defaultLatitude = 50*DEG;                              // Geographische Breite (London)
var defaultDay = 1;                                        // Tag
var defaultMonth = 1;                                      // Monat
var defaultYear = 2000;                                    // Jahr
var defaultTimeZone = 1;                                   // Zeitzone relativ zu UT (h)
