// Kr�fte an der schiefen Ebene, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Zur&uuml;ck";
var text02 = ["Start", "Pause", "Weiter"];
var text03 = "Zeitlupe";
var text04 = "Federwaage";
var text05 = "Kraftvektoren";
var text06 = "Neigungswinkel:";
var text07 = "Gewichtskraft:";
var text08 = "Hangabtriebskraft:";
var text09 = "Normalkraft:";
var text10 = "Reibungszahl:";
var text11 = "Reibungskraft:";
var text12 = "Zugkraft:";

var author = "W. Fendt 1999";                              // Autor (und �bersetzer)

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad
var newton = "N";                                          // Newton
