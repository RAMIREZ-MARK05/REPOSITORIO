// Loopingbahn, deutsche Texte
// Letzte �nderung 12.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Zur&uuml;ck";
var text02 = ["Start", "Pause", "Weiter"];
var text03 = "Zeitlupe (5 &times;)";
var text04 = "Zeitlupe (50 &times;)";
var text05 = "Radius:";
var text06 = "Ausgangsh&ouml;he:";
// Falls n�tig, Variable text06x f�r zus�tzliche Zeile!
var text07 = "Fallbeschleunigung:";
var text08 = "Masse:";
var text09 = "Geschwindigkeit";
var text10 = "Gewichtskraft, Kontaktkraft";
var text11 = "Tangentialkraft, Radialkraft";
var text12 = "Gesamtkraft";

var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Texte in Unicode-Schreibweise:

var text13 = "Geschwindigkeit:";
var text14 = "Gewichtskraft:";
var text15 = "Kontaktkraft:";
var text16 = "Tangentialkraft:";
var text17 = "Radialkraft:";
var text18 = "Gesamtkraft:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var second = "s";                               
var meter = "m";                                 
var meterPerSecond = "m/s";                        
var meterPerSecond2 = "m/s\u00b2";         
var kilogram = "kg";
var newton = "N";    


