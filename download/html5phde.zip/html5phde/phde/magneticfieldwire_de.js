// Magnetfeld eines geraden stromdurchflossenen Leiters, deutsche Texte
// Letzte �nderung 18.10.2018

// Texte in HTML-Schreibweise:

var text01 = "Umpolen";

var author = "W. Fendt 2000";
var translator = "";
