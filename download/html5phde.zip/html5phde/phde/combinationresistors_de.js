// Kombinationen von Widerst�nden, deutsche Texte
// Letzte �nderung 18.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Spannung der Batterie:";
var text03 = "Widerstand:";
var text04 = "Hinzuf&uuml;gen (in Serie)";
var text05 = "Hinzuf&uuml;gen (parallel)";
var text06 = "Messger&auml;te:";
var text07 = "Spannung";
var text08 = "Stromst&auml;rke";

var author = "W. Fendt 2002";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "Spannung:";
var text10 = "Stromst\u00E4rke:";
var text11 = "Widerstand:";
var text12 = "Ersatzwiderstand:";
var text13 = "sehr klein";
var text14 = "sehr gro\u00DF";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

