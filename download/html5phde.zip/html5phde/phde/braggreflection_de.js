// Bragg-Reflexion, deutsche Texte
// Letzte �nderung 17.03.2021

// Texte in HTML-Schreibweise:

var text01 = "Zur&uuml;ck";
var text02 = ["Start", "Pause", "Weiter"];
var text03 = "Zeitlupe";
var text04 = "Abstand der Netzebenen:";
var text05 = "Wellenl&auml;nge:";
var text06 = "Glanzwinkel:";
var text07 = "Zahl der Netzebenen:";
var text08 = "Gangunterschied:";

var author = "W. Fendt 2021";
var translator = "";

// Text in Unicode-Schreibweise:

var text09 = "Bragg-Bedingung erf\u00FCllt!";

// Einheiten und Symbole:

var decimalSeparator = ",";
var picometer = "pm";
var degree = "\u00B0";
var symbolDeltaS = "\u0394s";
var symbolLambda = "\u03BB";