// Bilderzeugung Sammellinse, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:
    
var text01 = "Brennweite:";
var text02 = "Gegenstandsweite:";
var text03 = "Gegenstandsgr&ouml;&szlig;e:";
var text04 = "Bildweite:";
var text05 = "Bildgr&ouml;&szlig;e:";    
var text06 = "Art des Bildes:"
var text07 = ["reell", "virtuell"];
var text08 = ["umgekehrt", "aufrecht"];
var text09 = ["verkleinert", "gleich gro&szlig;", "vergr&ouml;&szlig;ert", "unendlich gro&szlig;"];
var text10 = "Spezielle Lichtstrahlen";
var text11 = "Lichtb&uuml;ndel";
var text12 = "Hervorheben:";

var author = "W. Fendt 2008";                              // Autor (und �bersetzer)

// Symbole und Einheiten:

var centimeter = "cm";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text13 = ["Gegenstand", 
              "Gegenstandsweite", 
              "Gegenstandsgr\u00F6\u00DFe",
              "Linse", 
              "Linsenebene", 
              "optische Achse",
              "Brennpunkte", 
              "Brennweite", 
              "Bild", 
              "Bildweite", 
              "Bildgr\u00F6\u00DFe",
              "Mattscheibe"];
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "g";
var symbolGG = "G"; 
var symbolB = "b";
var symbolBB = "B";


