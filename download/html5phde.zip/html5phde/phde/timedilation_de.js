// Beispiel zur Zeitdilatation, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Geschwindigkeit verkleinern";
var text02 = "Geschwindigkeit vergr&ouml;&szlig;ern";
var text03 = "Zur&uuml;ck";
var text04 = ["Start", "Pause", "Weiter"];

var author = "W. Fendt 1997";                              // Autor (und �bersetzer)

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text05 = "Flugstrecke:";
var text06 = "5 Lichtstunden";
var text07 = "Geschwindigkeit:";
var text08 = "Flugzeit im Erd-System:";
var text09 = "Stunden";
var text10 = "Flugzeit im Raketen-System:";