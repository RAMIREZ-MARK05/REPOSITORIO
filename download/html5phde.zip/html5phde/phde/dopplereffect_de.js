// Beispiel zum Doppler-Effekt, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Zur&uuml;ck";
var text02 = ["Pause", "Weiter"]; 

var author = "W. Fendt 1998";
var translator = "";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                        
  ["Dadurch, dass sich der Notarzt-",
  "wagen der Person n\u00E4hert,",
  "kommen die Wellenfronten",
  "in k\u00FCrzeren Zeitabst\u00E4nden an."],
  ["Wenn sich das Fahrzeug",
  "von der Person entfernt,",
  "sind die zeitlichen Abst\u00E4nde",
  "zwischen den eintreffenden",
  "Wellenfronten verl\u00E4ngert."]];
  

