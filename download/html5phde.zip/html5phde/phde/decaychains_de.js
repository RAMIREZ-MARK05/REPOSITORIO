// Zerfallsreihen, deutsche Texte
// Letzte �nderung 26.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Zerfallsreihe:";
var text03 = "N&auml;chster Zerfall";

var author = "W. Fendt 1998"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["Thorium-Reihe", "Neptunium-Reihe", "Uran-Radium-Reihe", "Uran-Actinium-Reihe"];          





