// Rutherford-Streuung, deutsche Texte
// Letzte �nderung 16.05.2020

// Texte in HTML-Schreibweise:

var text01 = "Teilchenbahnen l&ouml;schen";                    
var text02 = "Start";          
var text03 = "Streuender Atomkern:";
var text04 = "Kernladungszahl:";
var text05 = "Alphateilchen:";
var text06 = "Geschwindigkeit:";
var text07 = "Sto&szlig;parameter:";
var text08 = "Streuwinkel:";
var text09 = "Minimaler Abstand:";
var text10 = "Asymptoten, Sto&szlig;parameter";
var text11 = "Asymptoten, Streuwinkel";


var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var femtometer = "fm";
var kilometerPerSecond = "km/s";
var degree = "\u00B0";




