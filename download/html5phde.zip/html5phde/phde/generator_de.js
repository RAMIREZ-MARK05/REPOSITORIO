// Generator, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise;

var text01 = "Ohne Kommutator";
var text02 = "Mit Kommutator";
var text03 = "Umgekehrte Richtung";
var text04 = ["Start", "Pause", "Weiter"];
var text05 = "Bewegungsrichtung";
var text06 = "Magnetfeld";
var text07 = "Induzierter Strom";

var author = "W. Fendt 1998";  
var translator = "";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "U/min";                          // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
