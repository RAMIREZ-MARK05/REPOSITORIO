// Spezielle Prozesse eines idealen Gases, deutsche Texte
// Letzte �nderung 10.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Isobare Zustands&auml;nderung";
var text02 = "Isochore Zustands&auml;nderung";
var text03 = "Isotherme Zustands&auml;nderung";
var text04 = "Anfangszustand:";
var text05 = "Druck:";
var text06 = "Volumen:";
var text07 = "Temperatur:";
var text08 = "Endzustand:";
var text09 = "Anfangszustand";
var text10 = "Start";

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Arbeit";
var text12 = "W\u00E4rme";
var text13 = "Die innere Energie des Gases";
var text14 = "vergr\u00F6\u00DFert sich.";
var text15 = "Die innere Energie des Gases";
var text16 = "bleibt unver\u00E4ndert.";
var text17 = "Die innere Energie des Gases";
var text18 = "verkleinert sich.";
var text19 = "Druck zu klein!";
var text20 = "Druck zu gro\u00DF!";
var text21 = "Volumen zu klein!";
var text22 = "Volumen zu gro\u00DF!";
var text23 = "Temperatur zu klein!";
var text24 = "Temperatur zu gro\u00DF!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


