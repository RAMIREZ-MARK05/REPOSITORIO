// Kepler-Fernrohr, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Brennweiten:"; 
var text02 = "Objektiv:";
var text03 = "Okular:";
var text04 = "Sehwinkel:";
var text05 = "Vergr&ouml;&szlig;erung:";

var author = "W. Fendt 2000";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite
