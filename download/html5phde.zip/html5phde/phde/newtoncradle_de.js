// Newtons Wiege, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Zur&uuml;ck";
var text02 = "Start";
var text03 = "Zahl der ausgelenkten Kugeln:";

var author = "W. Fendt 1997";
var translator = "";
