// Fahrbahnversuch zum 2. Newtonschen Gesetz, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Messreihe l&ouml;schen";
var text02 = ["Start", "Ergebnis registrieren"];
var text03 = "Diagramm";
var text04 = "Masse des Wagens:";
var text05 = "Masse des W&auml;gest&uuml;cks:";
var text06 = "Reibungszahl:";
var text07 = "Messwerte:";

var author = "W. Fendt 1997";                              // Autor (und �bersetzer)

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "LS";
var text09 = "(in s)";
var text10 = "(in m)";
var text11 = "Reibung zu gro\u00DF!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


