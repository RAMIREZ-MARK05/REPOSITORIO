// Stehende Welle, Erkl�rung durch Reflexion, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Reflexion";
var text02 = "am festen Ende";
var text03 = "am losen Ende";
var text04 = "Zur&uuml;ck";
var text05 = ["Start", "Pause", "Weiter"];
var text06 = "Zeitlupe";
var text07 = "Animation";
var text08 = "Einzelschritte";
var text09 = "Einfallende Welle";
var text10 = "Reflektierte Welle";
var text11 = "Resultierende stehende Welle";

var author = "W. Fendt 2003"; 
var translator = "";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "K";
var symbolAntiNode = "B";

