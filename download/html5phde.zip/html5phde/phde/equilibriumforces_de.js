// Gleichgewicht dreier Kr�fte, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Kr&auml;fte:";
var text02 = "Links:";
var text03 = "Rechts:";
var text04 = "Unten:";
var text05 = "Kr&auml;fteparallelogramm";
var text06 = "Winkel:";
var text07 = "Links:";
var text08 = "Rechts:";

var author = "W. Fendt 2000";
var translator = "";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var degree = "\u00b0";                                     // Symbol f�r Grad
var newton = "N";                                          // Abk�rzung f�r Newton
