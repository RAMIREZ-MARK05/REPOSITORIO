// Gravitation, deutsche Texte
// Letzte �nderung 01.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Zur&uuml;ck";                    
var text02 = ["Start", "Pause", "Weiter"];
var text03 = "Zeitlupe";
var text04 = "Abstand:";
var text05 = "Masse 1:";
var text06 = "Geschwindigkeit 1:";
var text07 = "Masse 2:";
var text08 = "Geschwindigkeit 2:";

var text09 = "Kreisbahn";
var text10 = "Parabelbahn";

var author = "W. Fendt 2020";                              // Autor (und �bersetzer)

// Texte in Unicode-Schreibweise:

var textSelect = ["",
              "Bahndaten",
              "Position",
              "Abstand",
              "Geschwindigkeit",
              "Beschleunigung",
              "Kraft",
              "Energie",
              "Drehmimpuls",
              "Umlaufdauer"];
              
var text11 = "Bahntyp:";
var text12 = ["Gerade",
              "Ellipse", 
              "Kreis (Ellipse)", 
              "Ellipse", 
              "Parabel", 
              "Hyperbel"];
var text13 = ["Gro\u00DFe Halbachsen:",
              "Radien:",
              "Gro\u00DFe Halbachsen:",
              "Halbparameter:",
              "Reelle Halbachsen:"];
var text14 = "Numerische Exzentrizit\u00E4t:";

var text21 = "Positionswinkel:";
var text22 = "Koordinaten:";

var text31 = "Abstand:";

var text41 = "Geschwindigkeitsbetr\u00E4ge:";
var text42 = "Geschwindigkeitskomponenten:";

var text51 = "Beschleunigungsbetr\u00E4ge:";
var text52 = "Beschleunigungskomponenten:";

var text61 = "Kraftbetr\u00E4ge:";
var text62 = "Kraftkomponenten:";

var text71 = "Gesamtenergie:";
var text72 = "Potentielle Energie:";
var text73 = "Kinetische Energie:";

var text81 = "Gesamtdrehimpuls:";
var text82 = "Einzelne Drehimpulse:";

var text91 = "Umlaufdauer:";

var text101 = "Zeit:";
var text102 = "Minimaler Wert:";
var text103 = "Maximaler Wert:";
var text104 = "Minimale Werte:";
var text105 = "Maximale Werte:";

var undef = "nicht definiert";
var inf = "unendlich";
var body1 = "K\u00F6rper 1";
var body2 = "K\u00F6rper 2";

// Symbole und Einheiten (Unicode-Schreibweise):

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var power10 = "\u00B7 10";                                 // Mal 10 hoch
var kilogram = "kg";
var second = "s";
var minute = "min";
var hour = "h";
var day = "d";
var year = "a";
var meter = "m";
var meterPerSecond = "m/s";
var meterPerSecond2 = "m/s\u00B2";
var newton = "N";
var joule = "J";
var kilogramMeter2PerSecond = "kg m\u00B2 / s";
var degree = "\u00B0";

var symbolAE1 = "a_E1";                                    // Gro�e Halbachse (Ellipse) f�r K�rper 1
var symbolAE2 = "a_E2";                                    // Gro�e Halbachse (Ellipse) f�r K�rper 2
var symbolAH1 = "a_H1";                                    // Reelle Halbachse (Hyperbel) f�r K�rper 1
var symbolAH2 = "a_H2";                                    // Reelle Halbachse (Hyperbel) f�r K�rper 2
var symbolR1 = "r_1";                                      // Radius (Kreis) f�r K�rper 1
var symbolR2 = "r_2";                                      // Radius (Kreis) f�r K�rper 2
var symbolHP1 = "p_1";                                     // Halbparameter (Parabel) f�r K�rper 1
var symbolHP2 = "p_2";                                     // Halbparameter (Parabel) f�r K�rper 2
var symbolEpsilon = "\u03B5";
var symbolTime = "t";                                      // Aktuelle Zeit
var symbolPhi1 = "\u03C6_1";
var symbolPhi2 = "\u03C6_2";

var symbolX1 = "x_1";
var symbolY1 = "y_1";
var symbolX2 = "x_2";
var symbolY2 = "y_2";

var symbolD = "d";                                         // Abstand
var symbolDMin = "d_min";                                  // Minimaler Abstand
var symbolDMax = "d_max";                                  // Maximaler Abstand

var symbolV1 = "v_1";                                      // Geschwindigkeit von K�rper 1
var symbolV2 = "v_2";                                      // Geschwindigkeit von K�rper 2
var symbolV1Min = "v_1 min";
var symbolV2Min = "v_2 min";
var symbolV1Max = "v_1 max";
var symbolV2Max = "v_2 max";
var symbolV1x = "v_1x";
var symbolV1y = "v_1y";
var symbolV2x = "v_2x";
var symbolV2y = "v_2y";

var symbolA1 = "a_1";                                      // Beschleunigung von K�rper 1
var symbolA2 = "a_2";                                      // Beschleunigung von K�rper 2
var symbolA1Min = "a_1 min";                               // Minimale Beschleunigung von K�rper 1
var symbolA2Min = "a_2 min";                               // Minimale Beschleunigung von K�rper 2 
var symbolA1Max = "a_1 max";                               // Maximale Beschleunigung von K�rper 1
var symbolA2Max = "a_2 max";                               // Maximale Beschleunigung von K�rper 1 
var symbolA1Tang = "a_1 tang";                             // Tangentiale Beschleunigung von K�rper 1
var symbolA1Rad = "a_1 rad";                               // Radiale Beschleunigung von K�rper 1
var symbolA2Tang = "a_2 tang";                             // Tangentiale Beschleunigung von K�rper 2
var symbolA2Rad = "a_2 rad";                               // Radiale Beschleunigung von K�rper 2

var symbolF1 = "F_1";
var symbolF2 = "F_2";
var symbolFMin = "F_min";
var symbolFMax = "F_max";
var symbolF1Tang = "F_1 tang";
var symbolF1Rad = "F_1 rad";
var symbolF2Tang = "F_2 tang";
var symbolF2Rad = "F_2 rad";

var symbolEnergy = "E";
var symbolEnergyPot = "E_pot";
var symbolEnergy1Kin = "E_1 kin";
var symbolEnergy2Kin = "E_2 kin";

var symbolAngMom = "L";
var symbolAngMom1 = "L_1";
var symbolAngMom2 = "L_2";

var symbolPeriod = "T";






