// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "2 Rollen";
var text02 = "4 Rollen";
var text03 = "6 Rollen";
var text04 = "Gewicht der Last:";
var text05 = "Gewicht der losen Flasche:";
var text06 = "Ben&ouml;tigte Kraft:";
var text07 = "Federwaage";
var text08 = "Kraftvektoren";

var author = "W. Fendt 1998";
var translator = "";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                          // Abk�rzung f�r Newton
