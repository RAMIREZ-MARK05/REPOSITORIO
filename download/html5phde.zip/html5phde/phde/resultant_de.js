// Ersatzkraft mehrerer Kr�fte, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Zahl der Einzelkr&auml;fte:";
var text02 = "Gesamtkraft ermitteln";
var text03 = "Konstruktion l&ouml;schen";

var author = "W. Fendt 1998";
var translator = "";
