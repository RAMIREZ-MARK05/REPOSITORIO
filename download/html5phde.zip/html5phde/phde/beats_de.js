// Schwebungen, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Zur&uuml;ck";
var text02 = ["Start", "Pause", "Weiter"];
var text03 = "Zeitlupe";
var text04 = "Frequenzen:";
var text05 = "1. Welle:";
var text06 = "2. Welle:";

var author = "W. Fendt 2001"; 
var translator = "";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



