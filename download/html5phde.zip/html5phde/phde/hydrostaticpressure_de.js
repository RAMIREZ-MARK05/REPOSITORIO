// Druckdose (hydrostatischer Druck), deutsche Texte
// Letzte �nderung 31.01.2019

// Texte in HTML-Schreibweise:

var text01 = "Fl&uuml;ssigkeit:";
var text03 = "Dichte:";
var text04 = "Tiefe:";
var text05 = "Schweredruck:";

var author = "W. Fendt 1999";                              // Autor
var translator = "";                                       // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["Unbekannt", "Wasser", "Ethanol", "Benzol", "Tetrachlorkohlenstoff", "Quecksilber"]; 
