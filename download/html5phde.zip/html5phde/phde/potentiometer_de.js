// Potentiometerschaltung, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Spannung der Stromquelle:";
var text02 = "Schiebewiderstand:";
var text03 = "Position des Schleifkontakts:";
var text04 = "Verbraucherwiderstand:";
var text05 = "Spannung angeben";
var text06 = "Stromst&auml;rke angeben";
var author = "W. Fendt 2006";
var translator = "";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "U";                                  // Symbol f�r Spannung
var symbolVoltage2 = "V";                                  // Index f�r Verbraucher
                      
