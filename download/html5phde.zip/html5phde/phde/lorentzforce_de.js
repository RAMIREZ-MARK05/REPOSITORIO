// Leiterschaukel-Versuch zur Lorentzkraft, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Ein / Aus";
var text02 = "Umpolen";
var text03 = "Magnet umdrehen";
var text04 = "Stromrichtung";
var text05 = "Magnetfeld";
var text06 = "Lorentzkraft";

var author = "W. Fendt 1998";
var translator = "";
