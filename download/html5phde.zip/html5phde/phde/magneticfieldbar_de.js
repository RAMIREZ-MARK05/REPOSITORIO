// Magnetfeld eines Stabmagneten, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Feldlinien l&ouml;schen";
var text02 = "Magnet umdrehen";

var author = "W. Fendt 2001";
var translator = "";
