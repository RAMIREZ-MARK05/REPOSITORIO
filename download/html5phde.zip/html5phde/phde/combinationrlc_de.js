// Kombinationen von Widerst�nden, Spulen und Kondensatoren, deutsche Texte
// Letzte �nderung 21.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Spannungsquelle:";
var text02 = "Spannung:";
var text03 = "Frequenz:";
var text04 = "Bauteil:";
var text05 = ["Widerstand", "Spule", "Kondensator"];
var text06 = ["Widerstand:", "Induktivit&auml;t:", "Kapazit&auml;t:"];
var text07 = "Ersetzen";
var text08 = "Hinzuf&uuml;gen (in Serie)";
var text09 = "Hinzuf&uuml;gen (parallel)";
var text10 = "Entfernen";
var text11 = "Messger&auml;te:";
var text12 = "Spannung";
var text13 = "Stromst&auml;rke";

var author = "W. Fendt 2004";
var translator = "";

// Texte in Unicode-Schreibweise:

var text14 = "Spannung:";
var text15 = "Stromst\u00E4rke:";
var text16 = "Impedanz:";
var text17 = "Impedanz (Betrag):";
var text18 = "Phasenverschiebung:";
var text19 = "sehr klein";                                 // Stromst�rke Voltmeter
var text20 = "sehr klein";                                 // Spannung Amperemeter
var text21 = "sehr klein";                                 // Impedanz/Widerstand Amperemeter
var text22 = "sehr gro\u00DF";                             // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)