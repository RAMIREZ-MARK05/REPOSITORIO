// Kettenkarussell, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Karussell";
var text02 = "Karussell mit Kr&auml;ften";
var text03 = "Skizze";
var text04 = "Zahlenwerte";
var text05 = ["Pause", "Weiter"];
var text06 = "Zeitlupe";
var text07 = "Umlaufzeit:";
var text08 = ["Abstand der Aufh&auml;ngungen", "von der Drehachse:"]; 
var text09 = "Fadenl&auml;nge:";
var text10 = "Masse:";

var author = "W. Fendt 1999";                              // Autor (und �bersetzer)

// Texte in Unicode-Schreibweise:

var text11 = "Frequenz:";
var text12 = "Winkelgeschwindigkeit:";
var text13 = "Radius:";
var text14 = "Geschwindigkeit:";
var text15 = "Winkel:";
var text16 = "Gewichtskraft:";
var text17 = "Zentripetalkraft:";
var text18 = "Belastung des Fadens:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




