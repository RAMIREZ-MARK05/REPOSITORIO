// Gleichstrom-Elektromotor, deutsche Texte
// Letzte �nderung 18.10.2017

// Texte in HTML-Schreibweise;

var text01 = "Zur&uuml;ck";
var text02 = ["Start", "Pause", "Weiter"];             
var text03 = "Umpolen";
var text04 = "Stromrichtung";
var text05 = "Magnetfeld";
var text06 = "Lorentzkraft";

var author = "W. Fendt 1997";               
var translator = "";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "U/min";                          // Umdrehungen pro Minute
