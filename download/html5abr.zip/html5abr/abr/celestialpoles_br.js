// Himmelspole, portugiesische (Brasilien) Texte (UFRGS)
// Letzte �nderung 22.11.2017

// Texte in Unicode-Schreibweise:

var text01 = "Equador";
var	text02 = "Polo Norte";
var text03 = "Polo Sul";
var text04 = "Eixo da Terra";
var text05 = "Plano do Horizonte";
var text06 = "Esfera Celeste";
var	text07 = "Z\u00EAnite";
var text08 = "Polo Norte Celeste";
var	text09 = "Polo Sul Celeste";
var text10 = "Norte";
var text11 = "Sul";

var author = "W. Fendt 1998, UFRGS";
