// Position eines Gestirns, brasilianisch-portugiesische Texte und Defaultwerte
// Letzte �nderung 23.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Longitude geogr.:";
var text03 = "Latitude geogr.:";
var text05 = "Dia:";
var text06 = "Tempo:";
var text07 = "h (TU)";
var text08 = "Ascens\u00E3o reta:";
var text09 = "Declina\u00E7\u00E3o:";
var text10 = "Reset";
var text11 = ["Rota\u00E7\u00E3o", "Pausa", "Rota\u00E7\u00E3o"];
var text12 = "Real\u00E7ar:";

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var dateSeparator = ".";
var timeSeparator = ":";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var text02 = ["(E)", "(W)"];
var text04 = ["(N)", "(S)"];
var text13 = ["", "observador", "horizonte",
              "ponto norte", "ponto oeste", "ponto sul", "ponto leste", 
              "z\u00EAnite", "nadir", "meridiano", "vertical do astro", 
              "polo norte celeste", "polo sul celeste", "eixo do mundo", "equador celeste",
              "ponto vernal", "c\u00EDrculo hor\u00E1rio", "tempo sideral",
              "\u00E2ngulo hor\u00E1rio", "astro", "trajet\u00F3ria do astro",
              "ascens\u00E3o reta", "declina\u00E7\u00E3o", "azimute", "altura", "tri\u00E2ngulo de posi\u00E7\u00E3o"];
var text14 = "Tempo:";
var text15 = "Tempo sideral:";
var text16 = "Azimute:";
var text17 = "\u00C2ngulo hor\u00E1rio:";
var text18 = "Altura:";

// Symbole und Einheiten:

var symbolObserver = "O";                                  // Beobachtungsort
var symbolNorth = "N";                                     // Nordpunkt
var symbolWest = "W";                                      // Westpunkt
var symbolSouth = "S";                                     // S�dpunkt
var symbolEast = "E";                                      // Ostpunkt
var symbolZenith = "Z";                                    // Zenit
var symbolNadir = "Na";                                    // Nadir
var symbolNorthPole = "PNC";                               // Himmelsnordpol
var symbolSouthPole = "PSC";                               // Himmelss�dpol
var symbolVernalEquinox = "V";                             // Fr�hlingspunkt
var symbolStar = "A";                                      // Stern
var symbolHour = "h";                                      // Stunde

// Defaultwerte:

var defaultLongitude = 10*DEG;                             // Geographische L�nge
var defaultLatitude = 50*DEG;                              // Geographische Breite
var defaultDay = 1;                                        // Tag
var defaultMonth = 1;                                      // Monat
var defaultYear = 2000;                                    // Jahr
var defaultTimeZone = 0;                                   // Zeitzone relativ zu UT (h)
