// Winkel am Kreis, spanische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Amplitud del &aacute;ngulo:";
var text02 = "&Aacute;ngulo central:";
var text03 = "&Aacute;ngulo inscrito:";
var text04 = "&Aacute;ngulo semi-inscrito:";

var author = "W. Fendt 1997";
var translator = "";
