// Kreiszahl Pi, spanische Texte
// Letzte �nderung 08.02.2022

// Texte in HTML-Schreibweise:

var text01 = "N&uacute;mero de v&eacute;rtices:";
var text02 = "Cuadril&aacute;tero";
var text03 = "Hex&aacute;gono";
var text04 = "Doblar el n&uacute;mero de v&eacute;rtices";
var text05 = "Longitud del lado";
var text06 = "Per&iacute;metro";
var text07 = "&Aacute;rea";

var author = "W. Fendt 2002";
var translator = "";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";

var text11 = "Longitud del lado (pol\u00EDgono inscrito):";
var text12 = "Longitud del lado (pol\u00EDgono circunscrito):";
var text13 = "Per\u00EDmetro (pol\u00EDgono inscrito):";
var text14 = "Per\u00EDmetro (pol\u00EDgono circunscrito):";
var text15 = "\u00C1rea (pol\u00EDgono inscrito):";
var text16 = "\u00C1rea (pol\u00EDgono circunscrito):";



