// Rechnen mit Restklassen, spanische Texte
// Letzte �nderung 14.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Congruencia m&oacute;dulo";
var text02 = "Adici&oacute;n";
var text03 = "Sustracci&oacute;n";
var text04 = "Multiplicaci&oacute;n";
var text05 = "Divisi&oacute;n";
var text06 = "Inverso aditivo";
var text07 = "Inverso multiplicativo";
var text11 = "Primer sumando:"; 
var text12 = "Segundo sumando:";
var text13 = "Suma:";
var text21 = "Minuendo:";
var text22 = "Sustraendo:";
var text23 = "Diferencia:";
var text31 = "Primer factor:";
var text32 = "Segundo factor:";
var text33 = "Producto:";
var text41 = "Dividendo:";
var text42 = "Divisor:";
var text43 = "Cociente:";
var text51 = "Elemento dado:";
var text52 = "Inverso aditivo:";
var text61 = "Elemento dado:";
var text62 = "Inverso multiplicativo:";
var undef = "no def."; 

var author = "W. Fendt  2022";

// Texte in Unicode-Schreibweise:

var symbolAdd = "+";
var symbolSub = "\u2212";
var symbolMul = "\u00B7";
var symbolDiv = "\u00F7";
var symbolNeg = "\u2212x";



