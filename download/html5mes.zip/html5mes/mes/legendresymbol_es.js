// Online-Rechner Legendre-Symbol, spanische Texte
// Letzte �nderung 25.07.2023

// Texte in HTML-Schreibweise:

var text01 = "1. n&uacute;mero:";
var text02 = "2. n&uacute;mero:";
var text03 = "OK";

var author = "W. Fendt 2023";
var translator = "";

// Texte in Unicode-Schreibweise:

var text04 = "S\u00EDmbolo de Legendre (Jacobi, Kronecker):";
var text05 = "S\u00EDmbolo de Jacobi (Kronecker):";
var text06 = "S\u00EDmbolo de Kronecker:";

var text11 = "#1 es un residuo cuadr\u00E1tico m\u00F3dulo #2.";
var text12 = "#1 es un no-residuo cuadr\u00E1tico m\u00F3dulo #2.";
var text13 = "#1 y #2 no son n\u00FAmeros coprimos.";
var text14 = "#1\u00B2 = #2 \u2261 #3 mod #4";
var text15 = "No existe ning\u00FAn n\u00FAmero entero x con x\u00B2 \u2261 #1 mod #2."; 

var symbolGCD = "MCD";
var symbolMul = "\u00B7";
var symbolNeg = "\u2212";

var error = "Fehler";





