// 15-Puzzle, spanische Texte
// Letzte �nderung 25.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Posici&oacute;n inicial";
var text02 = "Posici&oacute;n aleatoria";
var text03 = "Movidas:";
var text04 = ["Enhorabuena.", "Has resuelto el enigma."];

var author = "W. Fendt 2023";
var translator = "";



