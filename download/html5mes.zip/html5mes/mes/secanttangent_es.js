// Sekanten- und Tangentensteigung, spanische Texte (Nicol�s Rosillo)
// Letzte �nderung 05.04.2018

// Texte in HTML-Schreibweise:

var text01 = "Punto fijo:";
var text02 = "Punto variable:";
var text03 = "Pendiente de la recta secante:";
var text04 = "Pendiente de la recta tangente:";

var author = "W. Fendt 1998";
var translator = "N. Rosillo 2002";

var decimalSeparator = ",";                      // Dezimaltrennzeichen (Komma/Punkt)
var textUndefValue = "indef.";                   // Text f�r "nicht definiert"
