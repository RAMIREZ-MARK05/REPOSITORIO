// Umrechnung von Einheiten, spanische Texte
// Letzte �nderung 28.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Restablecer";
var text02 = "Iniciar";
var text03 = "Longitud";
var text04 = "&Aacute;rea";
var text05 = "Volumen";
var text06 = "Masa";
var text07 = "Tiempo";
var text08 = "Nivel de dificultad:";
var text09 = ["1 tarea", 
              "x tareas"];  
var text10 = ["1 correcta", 
              "x correctas"];        
     
var author = "W. Fendt 2001";                              // Autor (und �bersetzer)

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

