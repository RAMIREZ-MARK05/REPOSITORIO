// Online-Rechner Aussagenlogik, spanische Texte
// Letzte �nderung 26.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Borrar s&iacute;mbolo"; // ?
var text02 = "Borrar todo"; // ?
var text03 = "N&uacute;mero de variables:";
var text04 = "Variable:";
var author = "W. Fendt 2021";

// Texte in Unicode-Schreibweise:

var text05 = "Expresi\u00F3n:"; // ?
var text06 = "Comentario:";
var text07 = "Tabla de verdad:";
var text08 = "Forma normal disyuntiva:";
var text09 = "Forma normal conjuntiva:";

var variables = ["x", "y", "z"];                           // Array-Gr��e variabel

var symbolFalse = "F";
var symbolTrue = "V";

var empty = "Expresi\u00F3n vac\u00EDa"; // ?
var variable = "Variable";
var constant = "Constante";
var negation = "Negaci\u00F3n";
var brack = "Par\u00E9ntesis";
var conjunction = "Conjunci\u00F3n (y)";
var disjunction = "Disyunci\u00F3n (o)";
var implication = "Implicaci\u00F3n";
var equivalence = "Equivalencia";

var symbolNegation = "\u00AC";
var symbolConjunction = "\u2227";
var symbolDisjunction = "\u2228";
var symbolImplication = "\u21D2";
var symbolEquivalence = "\u21D4";

// Fehlermeldungen:

var syntaxOK = "\u00A1Sintaxis OK!";
var missNeg = "\u00A1Negaci\u00F3n incompleta!";
var missCon1 = "Conjunci\u00F3n: \u00A1Falta el primer operando!";
var missCon2 = "\u00A1Conjunci\u00F3n incompleta!";
var missDis1 = "Disyunci\u00F3n: \u00A1Falta el primer operando!";
var missDis2 = "\u00A1Disyunci\u00F3n incompleta!";
var missImp1 = "Implicaci\u00F3n: \u00A1Falta el primer operando!";
var missImp2 = "Implicaci\u00F3n incompleta!";
var missEqu1 = "Equivalencia: \u00A1Falta el primer operando!";
var missEqu2 = "\u00A1Equivalencia incompleta!";
var openBracket = "\u00A1Par\u00E9ntesis no terminado!";
var emptyBracket = "\u00A1Par\u00E9ntesis vac\u00EDo!"; // ?
var closingBracket = "\u00A1Par\u00E9ntesis de cierre sin sentido!"; // ?
var missingBracket = "\u00A1Falta el par\u00E9ntesis!";

var unknownError = "\u00A1Incomprensible!";




