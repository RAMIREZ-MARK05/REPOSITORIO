// Satz des Pythagoras, spanische Texte
// Letzte �nderung 29.07.2023

// Texte in HTML-Schreibweise:

var author = "W. Fendt 2001";
var translator = "";

// Texte in Unicode-Schreibweise:

var a2 = "a\u00B2";
var b2 = "b\u00B2";
var c2 = "c\u00B2";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
