// Platonische K�rper, spanische Texte (Nicol�s Rosillo)
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Tetraedro";
var text02 = "Hexaedro (cubo)";
var text03 = "Octaedro";
var text04 = "Dodecaedro";
var text05 = "Icosaedro";
var text06 = "Cambiar eje de rotaci&oacute;n";
var text07 = "Esfera circunscrita";
var text08 = "Esfera tangente a las aristas";
var text09 = "Esfera inscrita";

var author = "W. Fendt 1998,&nbsp; N. Rosillo 2002";
