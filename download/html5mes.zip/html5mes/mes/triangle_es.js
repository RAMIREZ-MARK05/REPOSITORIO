// Besondere Linien und Kreise im Dreieck, spanische Texte (Nicol�s Rosillo)
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Mediatrices";
var text02 = "Circunc&iacute;rculo";
var text03 = "Bisectrices";
var text04 = "Inc&iacute;rculo";
var text05 = "Exinc&iacute;rculos";
var text06 = "Paralelas medias";
var text07 = "Medianas";
var text08 = "Alturas";
var text09 = "Recta de Euler";
var text10 = "Circunferencia de Feuerbach";

var author = "W. Fendt 1998";
var translator = "N. Rosillo 2002";
