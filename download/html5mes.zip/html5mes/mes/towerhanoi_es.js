// T�rme von Hanoi, spanische Texte
// Letzte �nderung 26.07.2023

// Texte in HTML-Schreibweise:

var text01 = "N&uacute;mero de discos:";
var text02 = "Inicio";
var text03 = "Soluci&oacute;n propia";
var text04 = "Soluci&oacute;n autom&aacute;tica";
var text05 = ["Comenzar", "Pausa", "Reanudar"];

// Texte in Unicode-Schreibweise:

var text06 = "Movimiento";
var text07 = "Enhorabuena.";
var text08 = "El problema est\u00E1 resuelto.";

var author = "W. Fendt 2022";
var translator = "";

