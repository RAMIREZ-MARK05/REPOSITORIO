// Epizykloiden und Hypozykloiden, spanische Texte
// Letzte �nderung 01.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Epicicloide";
var text02 = "Hipocicloide";
var text03 = "Raz&oacute;n de los radios:";
var text04 = "Restablecer";
var text05 = ["Iniciar", "Pausa", "Reanudar"];  

var author = "W. Fendt 2017";    

// Texte in Unicode-Schreibweise:

var text06 = "Caso especial: Cardioide";  
var text07 = "Caso especial: Nefroide";
var text08 = "Caso especial: Di\u00E1metro del c\u00EDrculo";
var text09 = "Caso especial: Deltoide";
var text10 = "Caso especial: Astroide";                   




