// Elliptische Kurve, spanische Texte
// Letzte �nderung 05.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Coeficiente a:";
var text02 = "Coeficiente b:";

var author = "W. Fendt 2020";
var translator = "";

// Symbole:

var decimalSeparator = ",";
var symbolX = "x";
var symbolY = "y";
var symbolSummand1 = "P";
var symbolSummand2 = "Q";
var symbolSum = "P+Q";
