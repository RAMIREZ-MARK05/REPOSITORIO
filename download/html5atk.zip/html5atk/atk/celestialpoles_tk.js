// Himmelspole, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 21.11.2017

// Texte in Unicode-Schreibweise:

var text01 = "Ekwator";
var	text02 = "Demirgazyk pol\u00FDus";
var text03 = "G\u00FCnorta pol\u00FDus";
var text04 = "\u00DDerin oky";
var text05 = "Gorizontal tekizlik";
var text06 = "Asman sferasy";
var	text07 = "Zenit";
var text08 = "Demirgazyk asman pol\u00FDusy";
var	text09 = "G\u00FCnorta asman pol\u00FDusy";
var text10 = "Demirgazyk";
var text11 = "G\u00FCnorta";

var author = "W. Fendt 1998, PICT Turkmenistan";

// � ... \u00FC, � ... \u00DC
// � ... \u00FD, � ... \u00DD 
