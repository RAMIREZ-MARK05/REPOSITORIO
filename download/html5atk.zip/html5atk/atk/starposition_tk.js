// Position eines Gestirns, turkmenische Texte und Defaultwerte
// Letzte �nderung 21.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Geogr. uzaklyk ginisligi:";
var text03 = "Geogr. belentlik:";
var text05 = "Sene:";
var text06 = "Wagt:";
var text07 = "sagat (UT)";
var text08 = "G\u00F6ni galys:";
var text09 = "Gysarma:";
var text10 = "Yza ga\u00FDt";
var text11 = ["A\u00FDla", "Arakesme", "A\u00FDla"];
var text12 = "\u00DCns ber:";

var author = "W. Fendt 1999, PICT Turkmenistan";

// Symbole und Einheiten:

var dateSeparator = ".";
var timeSeparator = ":";
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var text02 = ["(G\u00FCndogar uzaklyk ginisligi)", "(G\u00FCnbatar uzaklyk ginisligi)"];
var text04 = ["(Demirgazyk belentligi)", "(G\u00FCnorta belentligi)"];
var text13 = ["", "g\u00F6zeg\u00E7ilik nokady", "gorizont",
              "demirgazyk nokat", "g\u00FCnbatar nokat", "g\u00FCnorta nokat", "g\u00FCndogar nokat", 
              "zenit", "nadir", "meridian", "belentlik t\u00F6weregi", 
              "asman demirgazyk pol\u00FDusy", "asman g\u00FCnorta pol\u00FDusy", "asman oky", "asman ekwatory",
              "\u00FDaz gije-g\u00FCndizin barabarlygy", "asman meridiany", "\u00FDyldyz wagty",
              "sagatlyk bur\u00E7y", "\u00FDyldyz", "\u00FDyldyzlaryn \u00FDoly",
              "g\u00F6ni galys", "gysarma", "azimut", "belentlik", "deniz\u00E7ilik \u00FC\u00E7bur\u00E7lugy"];
var text14 = "Wagt:";
var text15 = "\u00DDyldyz wagty:";
var text16 = "Azimut:";
var text17 = "Sagatlyk bur\u00E7y:";
var text18 = "Belentlik:";

// Symbole und Einheiten:

var symbolObserver = "O";                                  // Beobachtungsort
var symbolNorth = "N";                                     // Nordpunkt
var symbolWest = "W";                                      // Westpunkt
var symbolSouth = "S";                                     // S�dpunkt
var symbolEast = "E";                                      // Ostpunkt
var symbolZenith = "Ze";                                   // Zenit
var symbolNadir = "Na";                                    // Nadir
var symbolNorthPole = "NP";                                // Himmelsnordpol
var symbolSouthPole = "SP";                                // Himmelss�dpol
var symbolVernalEquinox = "V";                             // Fr�hlingspunkt
var symbolStar = "St";                                     // Stern
var symbolHour = "h";                                      // Stunde

// Defaultwerte:

var defaultLongitude = 0*DEG;                              // Geographische L�nge (London)
var defaultLatitude = 50*DEG;                              // Geographische Breite (London)
var defaultDay = 1;                                        // Tag
var defaultMonth = 1;                                      // Monat
var defaultYear = 2000;                                    // Jahr
var defaultTimeZone = 0;                                   // Zeitzone relativ zu UT (h)

// � ... \u00E7
// � ... \u00F6
// � ... \u00FC, � ... \u00DC
// � ... \u00FD, � ... \u00DD 
