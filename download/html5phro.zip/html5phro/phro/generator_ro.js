// Generator, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 23.01.2018

// Texte in HTML-Schreibweise;

var text01 = "Fara comutator";
var text02 = "Cu commutator";
var text03 = "Schimbarea sensului";
var text04 = ["Start", "Pauza", "Continuare"];
var text05 = "Directia de miscare";
var text06 = "Campul magnetic";
var text07 = "Curentul indus";

var author = "W. Fendt 1998";  
var translator = "O. Huhn 2003";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";                        // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
