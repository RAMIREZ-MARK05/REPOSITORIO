// Gleichgewicht dreier Kr�fte, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Forte:";
var text02 = "Stanga:";
var text03 = "Dreapta:";
var text04 = "Jos:";
var text05 = "Paralelogramul fortelor";
var text06 = "Unghiuri:";
var text07 = "Stanga:";
var text08 = "Dreapta:";

var author = "W. Fendt 2000";
var translator = "O. Huhn 2003";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                                     // Symbol f�r Grad
var newton = "N";                                          // Abk�rzung f�r Newton
