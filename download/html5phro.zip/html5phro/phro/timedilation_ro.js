// Beispiel zur Zeitdilatation, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 25.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Micsorarea vitezei";
var text02 = "Cresterea vitezei";
var text03 = "Inapoi";
var text04 = ["Start", "Pauza", "Continuare"];

var author = "W. Fendt 1997,&nbsp; O. Huhn 2003";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "Distanta de zbor:";
var text06 = "5 ore lumina";
var text07 = "Viteza:";
var text08 = "Timpul de zbor in sistemul pamant:";
var text09 = "ore";
var text10 = "Timpul de zbor in sistemul racheta:";