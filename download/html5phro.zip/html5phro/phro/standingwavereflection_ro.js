// Stehende Welle, Erkl�rung durch Reflexion, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 22.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reflectia";
var text02 = "la un capat fix";
var text03 = "la un capat liber";
var text04 = "Reset";
var text05 = ["Start", "Pauza", "Continuare"];
var text06 = "Miscare incetinita";
var text07 = "Animatie";
var text08 = "Pas cu pas";
var text09 = "Unda incidenta";
var text10 = "Unda reflectata";
var text11 = "Unda stationara rezultanta";

var author = "W. Fendt 2003"; 
var translator = "O. Huhn 2003";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "N";
var symbolAntiNode = "V";

