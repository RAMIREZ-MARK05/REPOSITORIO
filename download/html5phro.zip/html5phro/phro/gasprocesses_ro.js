// Spezielle Prozesse eines idealen Gases, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 18.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Proces izobar";
var text02 = "Proces izocor";
var text03 = "Proces izoterm";
var text04 = "Starea initiala:";
var text05 = "Presiunea:";
var text06 = "Volumul:";
var text07 = "Temperatura:";
var text08 = "Starea finala:";
var text09 = "Starea initiala";
var text10 = "Start";

var author = "W. Fendt 1999,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Lucrul mecanic";
var text12 = "Caldura";
var text13 = "Energia interna";
var text14 = "creste.";
var text15 = "Energia interna";
var text16 = "este constant.";
var text17 = "Energia interna";
var text18 = "scade.";
var text19 = "Presiunea prea mic!";
var text20 = "Presiunea prea mare!";
var text21 = "Volumul prea mic!";
var text22 = "Volumul prea mare!";
var text23 = "Temperatura prea mic!";
var text24 = "Temperatura prea mare!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


