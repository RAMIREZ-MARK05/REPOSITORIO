// Zweites Kepler-Gesetz, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 21.01.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Semiaxa mare:";
var text03 = "Excentricitatea num.:";
var text04 = ["Pauza", "Continuare"];
var text05 = "Miscare incetinita";
var text06 = ["Distanta", "de la Soare:"];
var text07 = "Viteza:";
var text08 = "Valoarea actuala:";
var text09 = "Minimul:";
var text10 = "Maximul:";
var text11 = "Sectoare";
var text12 = "Vectorul viteza";

var author = "W. Fendt 2000,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "UA";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Mercur", "Venus", "Pamant", "Martie", "Jupiter", "Saturn", "Uranus", "Neptun",
              "Pluto", "Cometa Halley", ""];

// Symbole und Einheiten: 

var auUnicode = "UA";
var symbolPeriod = "T";

