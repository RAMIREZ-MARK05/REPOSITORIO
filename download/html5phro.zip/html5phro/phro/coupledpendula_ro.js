// Gekoppelte Pendel, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 22.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";                           
var text02 = ["Start", "Pauza", "Continuare"];                
var text03 = "Miscare incetinita";
var text04 = "Pozitii initiale:";

var author = "W. Fendt 1998";
var translator = "O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                   

// Texte in Unicode-Schreibweise:

var text05 = "Pendulul 1";                                 // Erstes Pendel (links)
var text06 = "Pendulul 2";                                 // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
