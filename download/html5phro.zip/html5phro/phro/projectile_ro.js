// Schiefer Wurf, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";                    
var text02 = ["Start", "Pauza", "Continuare"];          
var text03 = "Miscare incetinita";
var text04 = "Inaltimea initiala:";
var text05 = "Viteza initiala:";
var text06 = "Unghiul:";
var text07 = "Masa:"; 
var text08 = "Acceleratia gravitationala:";
var text09 = "Coordonatele";
var text10 = "Viteza";
var text11 = "Acceleratia";
var text12 = "Forta";
var text13 = "Energia";

var author = "W. Fendt 2000,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                           // Abk�rzung f�r Meter
var meterPerSecond = "m/s";                                // Abk�rzung f�r Meter pro Sekunde
var meterPerSecond2 = "m/s&sup2;";                         // Abk�rzung f�r Meter pro Sekunde hoch 2
var kilogram = "kg";                                       // Abk�rzung f�r Kilogramm
var degree = "&deg;";                                      // Abk�rzung f�r Grad

// Texte in Unicode-Schreibweise:

var text14 = "(in m)";                                     // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Coordonatele:";
var text16 = "(orizontal)";
var text17 = "(vertical)"; 
var text18 = "Distanta orizont.:";
var text19 = "Inaltimea max.:";
var text20 = "Timpul:"; 
var text21 = "Componentele vitezei:";
var text22 = "Modulul vitezei:";
var text23 = "Unghiul:";
var text24 = "Acceleratia:";
var text25 = "Forta:";
var text26 = "Energia cinetica:";
var text27 = "Energia potentiala:";
var text28 = "Energia totala:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                                    // Abk�rzung f�r Meter
var secondUnicode = "s";                                   // Abk�rzung f�r Sekunde
var meterPerSecondUnicode = "m/s";                         // Abk�rzung f�r Meter pro Sekunde
var meterPerSecond2Unicode = "m/s\u00b2";                  // Abk�rzung f�r Meter pro Sekunde hoch 2
var newtonUnicode = "N";                                   // Abk�rzung f�r Newton
var jouleUnicode = "J";                                    // Abk�rzung f�r Joule
var degreeUnicode = "\u00b0";                              // Abk�rzung f�r Grad



