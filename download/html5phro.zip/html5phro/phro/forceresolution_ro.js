// Zerlegung einer Kraft in zwei Komponenten, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Modulul fortei";                       
var text02 = "date:";
var text03 = "Valoarea unghiurilor:";
var text04 = "unghiul 1:";
var text05 = "unghiul 2:";
var text06 = "Modulul componentelor:";
var text07 = "componenta 1:";
var text08 = "componenta 2:";
var text09 = "Gasirea componentelor";
var text10 = "Stergerea constructiei";

var author = "W. Fendt 2003";
var translator = "O. Huhn 2003";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Winkelgrad
var newton = "N";                                          // Einheit Newton (Kraft), HTML-Schreibweise

// Texte in Unicode-Schreibweise:

var text11 = "componenta 1";                               // Text f�r erste Komponente
var text12 = "componenta 2";                               // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                                   // Einheit Newton (Kraft), Unicode-Schreibweise