// Beispiel zum Doppler-Effekt, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 22.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Start nou";
var text02 = ["Pauza", "Continuare"]; 

var author = "W. Fendt 1998";
var translator = "O. Huhn 2003";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                             // Erl�uterungstext
     ["Daca ambulanta se apropie", 
      "de persoana, intervalul de timp",
      "dintre fronturile de unda", 
      "se scurteaza."],
     ["Daca vehiculul se indeparteaza", 
      "de persoana, intervalul de timp",
      "dintre fronturile de unda", 
      "se lungeste."]];

 

  

