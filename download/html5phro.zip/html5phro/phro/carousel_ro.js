// Kettenkarussell, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Carusel";
var text02 = "Carusel cu forte";
var text03 = "Schita";
var text04 = "Valori numerice";
var text05 = ["Pauza", "Continuare"];
var text06 = "Miscare incetinita";
var text07 = "Perioada:";
var text08 = ["Distanta de la punctul de suspensie", "pana la axa de rotatie:"]; 
var text09 = "Lungimea firului:";
var text10 = "Masa:";

var author = "W. Fendt 1999,&nbsp; O. Huhn 2003";

// Texte in Unicode-Schreibweise:

var text11 = "Frecventa:";
var text12 = "Viteza unghiulara:";
var text13 = "Raza:";
var text14 = "Viteza:";
var text15 = "Unghiul:";
var text16 = "Greutatea:";
var text17 = "Forta centripeta:";
var text18 = "Tensiunea din fir:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




