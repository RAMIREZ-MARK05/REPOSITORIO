// Resonanz, rum�ische Texte (Otmar Huhn)
// Letzte �nderung 22.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Continuare"];
var text03 = "Miscare incetinita";
var text04 = "Rezonator:";
var text05 = "Constanta elastica:";
var text06 = "Masa:";
var text07 = "Atenuarea:";
var text08 = "Excitator:";
var text09 = "Frecventa:"; // ???
var text10 = "Diagrama elongatiei";
var text11 = "Diagrama amplitudinii";
var text12 = "Diagrama diferentei de faza";

var author = "W. Fendt 1998,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                                
var newtonPerMeter = "N/m";                         
var perSecond = "1/s";                                 
var radPerSecond = "rad/s";                            

// Texte in Unicode-Schreibweise:

var text13 = "Catastrofa!";
var text14 = "(Simularea nu mai este realista!)";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                                   
var radPerSecondUnicode = "rad/s";                      


