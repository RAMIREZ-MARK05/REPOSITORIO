// Kombinationen von Widerst�nden, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 19.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Tensiunea bateriei:";
var text03 = "Rezistenta:";
var text04 = "Adauga rezistenta (in serie)";
var text05 = "Adauga rezistenta (in paralel)";
var text06 = "Instrumente:";
var text07 = "Tensiune";
var text08 = "Intensitate";

var author = "W. Fendt 2002";
var translator = "O. Huhn 2003";

// Texte in Unicode-Schreibweise:

var text09 = "Tensiune:";
var text10 = "Intensitate:";
var text11 = "Rezistenta:";
var text12 = "Rezistenta echivalenta:";
var text13 = "foarte mic";
var text14 = "foarte mare";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

