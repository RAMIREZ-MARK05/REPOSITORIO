// Erstes Kepler-Gesetz, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 21.01.2018

// Texte in HTML-Schreibweise:
    
var text01 = ["Mercur", "Venus", "Pamant", "Martie", "Jupiter", "Saturn", "Uranus", "Neptun",
              "Pluto", "Cometa Halley", ""];
var text02 = "Semiaxa mare:";
var text03 = "Excentricitatea num.:";
var text04 = "Semiaxa mica:";
var text05 = ["Pauza", "Continuare"];
var text06 = "Miscare incetinita";
var text07 = "Distanta de la Soare:";
var text08 = "Valoarea actuala:";
var text09 = "Minimul:";
var text10 = "Maximul:";
var text11 = "Traiectoria eliptica";
var text12 = "Axele";
var text13 = "Liniile de legatura";

var author = "W. Fendt 2000,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "UA";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text14 = "Soare";
var text15 = "Planeta";
var text16 = "Cometul";
var text17 = "Perihel";
var text18 = "Aphel";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "UA";

