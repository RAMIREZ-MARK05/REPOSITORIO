// Federpendel, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 22.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Continuare"];  
var text03 = "Miscare incetinita";
var text04 = "Constanta de elasticitate:";
var text05 = "Masa:";
var text06x = "Acceleratia";                               // Zus�tzliche Zeile!
var text06 = "gravitationala:";
var text07 = "Amplitudinea:";
var text08 = "Elongatia";
var text09 = "Viteza";
var text10 = "Acceleratia";
var text11 = "Forta";
var text12 = "Energia";

var author = "W. Fendt 1998,&nbsp; O. Huhn 2003";   
             

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var newtonPerMeter = "N/m";                              
var kilogram = "kg";                                
var meterPerSecond2 = "m/s&sup2;";                
var meter = "m";                                   

// Texte in Unicode-Schreibweise:

var text13 = "Maximum";
var text14 = "Elongatia";
var text15 = "Viteza";
var text16 = "Acceleratia";
var text17 = "Forta";
var text18 = "Energia potentiala";
var text19 = "Energia cinetica";
var text20 = "Energia totala";
var text21 = "(in s)";
var text22 = "(in m)";
var text23 = "(in m/s)";
var text24 = "(in m/s\u00b2)";
var text25 = "(in N)";
var text26 = "(in J)";
var text27 = "Perioda de oscilatie";

// Symbole und Einheiten: 

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                     
var meterUnicode = "m";                              
var meterPerSecond = "m/s";                           
var meterPerSecond2Unicode = "m/s\u00b2";            
var newton = "N";                                    
var joule = "J";                                   

