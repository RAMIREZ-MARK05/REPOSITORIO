// Zerfallsgesetz der Radioaktivit�t, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 26.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Continuare"];    
var text03 = "Diagrama";  

var author = "W. Fendt 1998";
var translator = "O. Huhn 2003";

// Texte in Unicode-Schreibweise:

var text04 = "Timpul:";                                      
var text05 = "Nedezintegrat:";
var text06 = "Dezintegrat:";
var text07 = ["nuclee", "nucleu", "nuclee", "nuclee"];    // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
