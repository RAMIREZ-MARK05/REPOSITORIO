// Newtons Wiege, rum�nische Texte (fehlt noch!)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Start";
var text03 = "Number of swinging balls:"; // ???

var author = "W. Fendt 1997";
var translator = "";
