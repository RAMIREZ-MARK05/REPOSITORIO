// Messung der Auftriebskraft, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 21.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Aria bazei paralelipipedului:"; 
var text02 = "Inaltimea paralelipipedului:";
var text03 = "Densitatea paralelipipedului:";
var text04 = "Densitatea lichidului:";   
var text05 = "Adincimea de scufundare:";
var text06 = "Volumul dizlocat:"; 
var text07 = "Forta ascensionala:";
var text08 = "Forta de greutate:";
var text09 = "Forta masurata:";
var text10 = "Domeniul de masura:";

var author = "W. Fendt 1998&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Depasire domeniu de masura";
