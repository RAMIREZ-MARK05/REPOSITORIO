// Einfache Wechselstromkreise, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 23.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Rezistor";
var text02 = "Condensator";
var text03 = "Bobina";
var text04 = "Reset";
var text05 = ["Start", "Pauza", "Continuare"];          
var text06 = "Miscare incetinita";
var text07 = "Frecventa:";
var text08 = "Tensiunea max.:";
var text09 = "Rezistenta:";                            
var text10 = "Capacitatea:";                          
var text11 = "Inductanta:"; 
var text12 = "Intensitatea max.:"; 

var author = "W. Fendt 1998,&nbsp; O. Huhn 2003";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                     
var volt = "V";                                       
var ampere = "A";                                     
var milliampere = "mA";                                
var microampere = "&mu;A";                             
var ohm = "&Omega;";                                   
var microfarad = "&mu;F";                              
var henry = "H";                                       

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
