// Magnetfeld eines Stabmagneten, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 23.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Stergerea liniilor de camp";
var text02 = "Intoarcerea magnetului";

var author = "W. Fendt 2001";
var translator = "O. Huhn 2003";
