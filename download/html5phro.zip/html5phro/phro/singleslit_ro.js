// Beugung von Licht am Einfachspalt, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 24.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Lungimea de unda:";
var text02 = "Latimea fantei:";
var text03 = "Unghiul:";
var text04 = "Maxime:";
var text05 = "Minime:";
var text06 = "Intensitatea relativa:";
var text07 = "Figura de difractie";
var text08 = "Distributia intensitatii";

var author = "W. Fendt 2003&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
