// Elektromagnetischer Schwingkreis, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 23.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Continuare"];
var text03 = "Miscare incetinita (10 &times;)";
var text04 = "Miscare incetinita (100 &times;)";
var text05 = "Capacitatea:";
var text06 = "Inductanta:";
var text07 = "Rezistenta:";
var text08 = "Tensiunea max.:";
var text09 = "Tensiunea, intensitatea";
var text10 = "Energia";

var author = "W. Fendt 1999,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                             
var henry = "H";                                      
var ohm = "&Omega;";                                  
var volt = "V";                                        

// Texte in Unicode-Schreibweise:

var text11 = "Perioada:";
var text12 = "Energia campului electric:";
var text13 = "Energia campului magnetic:";
var text14 = "Energia interna:";
var text15 = "Oscilatie neamortizata";
var text16 = "Oscilatie amortizata";
var text17 = "Regim aperiodic";
var text18 = "Atenuare supracritica";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                      
var voltUnicode = "V";                                 
var ampere = "A";                                      
var joule = "J";                                       
