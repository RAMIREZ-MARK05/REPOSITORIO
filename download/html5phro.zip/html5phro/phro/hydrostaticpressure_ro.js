// Druckdose (hydrostatischer Druck), rum�nische Texte (Otmar Huhn)
// Letzte �nderung 05.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Lichid:";
var text03 = "Densitatea:";
var text04 = "Adancime:";
var text05 = "Presiunea hidrostatica:";

var author = "W. Fendt 1999";                              // Autor
var translator = "O. Huhn 2003";                           // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["necunoscut", "apa", "etanol", "benzen", "tetraclorura de carbon", "mercur"]; 
