// Kepler-Fernrohr, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 24.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Distante focale:"; 
var text02 = "Obiectiv:";
var text03 = "Ocular:";
var text04 = "Unghiul:";
var text05 = "Marirea:";

var author = "W. Fendt 2000";
var translator = "O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite

