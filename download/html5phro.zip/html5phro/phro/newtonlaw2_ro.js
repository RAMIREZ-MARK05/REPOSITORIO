// Fahrbahnversuch zum 2. Newtonschen Gesetz, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Stergerea rezultatelor";
var text02 = ["Start", "Inregistrarea datelor"];
var text03 = "Diagrama";
var text04 = "Masa caruciorului:";
var text05 = "Masa greutatilor:";
var text06 = "Coeficientul de frecare:";
var text07 = "Date:";

var author = "W. Fendt 1997,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "LS";
var text09 = "(in s)";
var text10 = "(in m)";
var text11 = "Frecarea e prea mare!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


