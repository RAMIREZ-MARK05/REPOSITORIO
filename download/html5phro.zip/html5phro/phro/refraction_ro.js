// Reflexion und Brechung von Licht, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 24.01.2018

// Texte in HTML-Schreibweise:
    
var text01 = "Indice de refractie 1:";
var text02 = "Indice de refractie 2:";
var text03 = "Unghiul de incidenta:";
var text04 = "Unghiul de reflectie:";
var text05 = "Unghiul de refractie:";    
var text06 = ["Unghiul minim de", "reflectie totala:"];

var author = "W. Fendt 1997&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                   

// Texte in Unicode-Schreibweise:

var text07 = [["vid", "1"], ["aer", "1.0003"],             // Stoffe und Brechungsindizes
    ["apa", "1.33"], ["etanol", "1.36"],
    ["sticla de cuart", "1.46"], ["benzol", "1.49"], 
    ["sticla crown N-K5", "1.52"], ["sare", "1.54"], 
    ["sticla flint LF5", "1.58"], ["sticla crown N-SK4", "1.61"],
    ["sticla flint SF6", "1.81"], ["diamant", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                          
