// Ersatzkraft mehrerer Kr�fte, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Numarul fortelor:";
var text02 = "Constructia rezultantei";
var text03 = "Stergerea constructiei";

var author = "W. Fendt 1998";
var translator = "O. Huhn 2003";
