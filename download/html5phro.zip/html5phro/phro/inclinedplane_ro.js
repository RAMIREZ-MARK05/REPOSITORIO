// Kr�fte an der schiefen Ebene, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Continuare"];
var text03 = "Miscare incetinita";
var text04 = "Dinamometru";
var text05 = "Vectorii forta";
var text06 = "Unghiul de inclinare:";
var text07 = "Greutatea:";
var text08 = "Componenta paralela:";
var text09 = "Componenta  normala:";
var text10 = "Coeficientul de frecare:";
var text11 = "Forta de frecare:";
var text12 = "Forta de tractiune:";

var author = "W. Fendt 1999,&nbsp; O. Huhn 2003";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad
var newton = "N";                                          // Newton
