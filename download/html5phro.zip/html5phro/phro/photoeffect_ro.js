// Photoelektrischer Effekt, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 25.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Materialul catodului:";
var text02 = ["Cesiu", "Sodiu"];
var text03 = "Linia spectrala (Hg):";
var text04 = "Tensiunea inversa:";
var text05 = "Frecventa:";
var text06 = ["Energia", "fotonului:"];
var text07 = "L. mec. de extractie:";
var text08 = ["Energia cinetica maxima", "a unui electron:"];
var text09 = "Stergerea datelor masurate";

var author = "W. Fendt 2000,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                     
var terahertz = "THz";                              
var electronvolt = "eV";                            

// Texte in Unicode-Schreibweise:

var text10 = ["galben", "verde", "violet", "ultraviolet", "ultraviolet"];
var text11 = "(in THz)";
var text12 = "(in V)";
var text13 = [
             ["Energia fotonului este insuficienta", "pentru extragerea electronului."],
             ["Mareste tensiunea inversa pana cand", "nici un electron nu mai ajunge la anod!"],
             ["Tensiunea inversa este asa de mare", "incat electronii se intorc la catod."],
             ["Continua masuratorile pentru o", "alta linie spectrala!"],
             ["Continua cu o noua serie de masuratori", "cu un alt material al catodului!"],
             ["Masuratorile s-au terminat."]
             ];

var symbolCathode = "K";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
