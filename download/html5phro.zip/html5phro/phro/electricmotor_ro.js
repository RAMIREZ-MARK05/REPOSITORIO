// Gleichstrom-Elektromotor, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 23.01.2018

// Texte in HTML-Schreibweise;

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Continuare"];             
var text03 = "Schimbarea directiei";
var text04 = "Sensul curentului";
var text05 = "Campul magnetic";
var text06 = "Forta Lorentz";

var author = "W. Fendt 1997";             
var translator = "O. Huhn 2003";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";                        // Umdrehungen pro Minute
