// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), rum�nische Texte (Otmar Huhn)
// Letzte �nderung 24.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Start nou";
var text02 = "Pasul urmator";
var text03 = ["Pauza", "Continuare"];                  
var text04 = "Indice de refractie 1:";
var text05 = "Indice de refractie 2:";
var text06 = "Unghiul de incidenta:";

var author = "W. Fendt 1998";
var translator = "O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                               

// Texte in Unicode-Schreibweise:

var text07 = [

  ["Un front de unda plana se",                            // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "indreapta oblic spre suprafata",
   "de separare a doua medii care",
   "au viteze de faza diferite."],
   
  ["Un front de unda plana se",                            // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "indreapta perpendicular spre",
   "suprafata de separare a doua",
   "medii care au viteze de faza",
   "diferite."],
 
  ["La intalnirea suprafetei de",                          // i == 2 (step == 1, n1 > n2) 
   "separare punctele acesteia emit",
   "conform principiului lui Huygens",
   "unde sferice (numite unde",
   "elementare).",
   "In al doilea mediu aceste unde",
   "elementare se propaga cu viteza",
   "mai mare, deoarece indicele de",
   "refractie este mai mic."],

  ["La intalnirea suprafetei de",                          // i == 3 (step == 1, n1 < n2)
   "separare punctele acesteia emit",
   "conform principiului lui  Huygens",
   "unde sferice (numite unde",
   "elementare).",
   "In al doilea mediu aceste unde",
   "elementare se propaga cu viteza",
   "mai mica, deoarece indicele de",
   "refractie este mai mare."],
   
  ["Prin suprapunerea undelor",                            // i == 4 (step == 2, total == false, esp1 > 0) 
   "elementare iau nastere",
   "noi fronturi de unda plane.",
   "In mediul 1 apare o unda",
   "reflectata, iar in mediul 2",
   "o unda refractata."],   

  ["Prin suprapunerea undelor",                            // i == 5 (step == 2, total == false, esp1 == 0)
   "elementare iau nastere",
   "noi fronturi de unda plane.",
   "In mediul 1 apare o unda",
   "reflectata, iar in mediul 2",
   "o unda refractata."],  

  ["Prin suprapunerea undelor",                            // i == 6 (step == 2, total == true)
   "undelor elementare iau nastere",
   "in mediul 1 un nou front",
   "de unda plana (unda reflectata).",
   "In mediul 2 nu ia nastere",
   "nici un front de unda",
   "(reflexia totala)."], 
   
  ["Suplimentar s-a desenat acum",                         // i == 7 (step == 3)
   "directia de propagare a undelor.",
   "Ea este perpendiculare",
   "pe frontul de unda."],
   
  ["Un front de unda",                                     // i == 8 (step == 4)
   "rar apare singur."],

  ["Daca indicii de refractie",                            // i == 9 (n1 == n2)
   "coincid nu se intampla",
   "nimic deosebit."]];
          
var text08 = "Unghiul de incidenta:"; 
var text09 = "Unghiul de reflexie:";
var text10 = "Unghiul de refractie:"; 
var text11 = "Mediul 1";
var text12 = "Mediul 2";      
var text13 = ["Unghiul limita de", "reflexie totala:"];

// Einheiten:

var degreeUnicode = "\u00b0";                           
