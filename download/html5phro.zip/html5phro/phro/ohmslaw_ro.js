// Ohmsches Gesetz, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 23.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Tensiunea max.:";
var text02 = "Intensitatea max.:";
var text03 = "Cresterea lui R";
var text04 = "Micsorarea lui R";
var text05 = "Cresterea lui U";
var text06 = "Micsorarea lui U";

var author = "W. Fendt 1997";
var translator = "O. Huhn 2003";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Depasirea domeniului de masurare!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
