// Interferenz zweier Kreis- oder Kugelwellen, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 22.01.2018

// Texte in HTML-Schreibweise:

var text01 = ["Pauza", "Continuare"];                      // Schaltknopf (Pause/Weiter)
var text02 = "Miscare incetinita";
var text03 = "Distanta dintre centrele";
var text04 = "undelor:";
var text05 = "Lungimea de unda:";

var author = "W. Fendt 1999";
var translator = "O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                                  

// Texte in Unicode-Schreibweise:

var text06 = "Diferenta de drum:";
var text07 = "Interferenta constructiva (Amplitudinea maxima)";
var text08 = "Interferenta destructiva (Amplitudinea minima)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (Lambda)
