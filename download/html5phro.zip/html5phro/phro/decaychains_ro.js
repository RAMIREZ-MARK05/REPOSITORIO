// Zerfallsreihen, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 26.1.2018

// Texte in HTML-Schreibweise:

var text01 = "Seria:";
var text03 = "Urmatoarea dezintegrare";

var author = "W. Fendt 1998"; 
var translator = "O. Huhn 2003";

// Texte in Unicode-Schreibweise:

var text02 = ["Seria Thoriu", "Seria Neptuniu", "Seria Uraniu-Radiu", "Seria Uraniu-Actiniu"];          





