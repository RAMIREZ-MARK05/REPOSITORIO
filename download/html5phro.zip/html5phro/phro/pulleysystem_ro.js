// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "2 scripete";
var text02 = "4 scripete";
var text03 = "6 scripete";
var text04 = "Greutatea:";
var text05 = "Greutatea scripetelor mobile:";
var text06 = "Forta necesara:";
var text07 = "Dinamometru";
var text08 = "Vectorii forta";

var author = "W. Fendt 1998";
var translator = "O. Huhn 2003";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division (&divide; ?)
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                          // Abk�rzung f�r Newton
