// Stehende L�ngswellen, rum�nische Texte (Otmar Huhn, unvollst�ndig!)
// Letzte �nderung 22.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Forma tubulara:";
var text02 = "deschis la ambele capete";
var text03 = "deschis la un capat";
var text04 = "inchis la ambele capete";
var text05 = "Mod de oscilatie:";
var text06 = ["fundamental",  "Prima armonica",            // Bezeichnungen der Eigenschwingungen 
              "Armonica a 2-a", "Armonica a 3-a", 
              "Armonica a 4-a", "Armonica a 5-a"];
var text07 = "Mai jos";
var text08 = "Mai inalt";
var text09 = "Lungimea tubului:";
var text10 = "Lungimea de unda:";
var text11 = "Frecventa:";

var author = "W. Fendt 1998,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                    
var hertz = "Hz";                                     

// Texte in Unicode-Schreibweise:

var text12 = "Displacement of particles"; // ???           // �berschrift des ersten Diagramms
var text13 = "Divergence from average pressure"; // ???    // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "N";                                      // Symbol f�r Knoten
var symbolAntinode = "V";                                  // Symbol f�r Bauch

