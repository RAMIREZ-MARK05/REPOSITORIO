// Leiterschaukel-Versuch zur Lorentzkraft, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 23.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Pornit / Oprit";
var text02 = "Inversarea polaritatii";
var text03 = "Intoarcerea magnetului";
var text04 = "Sensul curentului";
var text05 = "Campul magnetic";
var text06 = "Forta Lorentz";

var author = "W. Fendt 1998";
var translator = "O. Huhn 2003";
