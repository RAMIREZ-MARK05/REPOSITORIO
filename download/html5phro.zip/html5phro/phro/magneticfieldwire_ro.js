// Magnetfeld eines geraden stromdurchflossenen Leiters, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 23.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Inversarea polaritatii";

var author = "W. Fendt 2000";
var translator = "O. Huhn 2003";
