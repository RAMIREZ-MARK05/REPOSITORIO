// Elastischer und unelastischer Sto�, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Ciocnire elastica";
var text02 = "Ciocnire inelastica";
var text03 = "Reset";
var text04 = "Start";
var text05 = "Miscare incetinita";
var text06 = "Caruciorul 1:";
var text07 = "Caruciorul 2:";
var text08 = "Masa:";
var text09 = "Viteza:";
var text10 = "Viteza";
var text11 = "Impulsul";
var text12 = "Energia cinetica";

var author = "W. Fendt 1998,&nbsp; O. Huhn 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                                // Abk�rzung f�r Meter pro Sekunde

// Texte in Unicode-Schreibweise:

var text13 = "Caruciorul 1:";
var text14 = "Caruciorul 2:";
var text15 = "Vitezele inainte de ciocnire:";
var text16 = "Vitezele dupa ciocnire:";
var text17 = "Impulsurile inainte de ciocnire:";
var text18 = "Impulsurile dupa ciocnire:";
var text19 = "Energia cinetica inainte de ciocnire:";
var text20 = "Energia cinetica dupa ciocnire:";
var text21 = "Impulsul total:";
var text22 = "Energia cinetica totala:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                         // Abk�rzung f�r Meter pro Sekunde
var kilogramMeterPerSecond = "kg m/s";                     // Abk�rzung f�r Kilogramm mal Meter pro Sekunde
var joule = "J";                                           // Abk�rzung f�r Joule
