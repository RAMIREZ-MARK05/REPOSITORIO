// Bohrsches Atommodell, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 26.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Modelul corpuscular";
var text02 = "Modelul ondulatoriu";
var text03 = "Numarul cuantic principal:";


var author = "W. Fendt 1999"; 
var translator = "O. Huhn 2003";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



