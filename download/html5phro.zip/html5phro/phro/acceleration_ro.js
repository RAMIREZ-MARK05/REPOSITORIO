// Bewegung mit konstanter Beschleunigung, rum�nische Texte (Otmar Huhn)
// Letzte �nderung 20.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Continua"];
var text03 = "Miscare incetinita";
var text04 = "Pozitia initiala:";
var text05 = "Viteza initiala:";
var text06 = "Acceleratia:";
var text07 = "Vectorul viteza";
var text08 = "Vectorul acceleratie";

var author = "W. Fendt 2000";
var translator = "O. Huhn 2003";

// Texte in Unicode-Schreibweise:

var text09 = "(in s)";                                     // Einheitenangabe f�r Zeit-Achse
var text10 = "(in m)";                                     // Einheitenangabe f�r Weg-Achse
var text11 = "(in m/s)";                                   // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(in m/s\u00b2)";                             // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                          // Abk�rzung f�r Sekunde
var meter = "m";                                           // Abk�rzung f�r Meter
var meterPerSecond = "m/s";                                // Abk�rzung f�r Meter pro Sekunde
var meterPerSecond2 = "m/s\u00b2";                         // Abk�rzung f�r Meter pro Sekunde hoch 2
