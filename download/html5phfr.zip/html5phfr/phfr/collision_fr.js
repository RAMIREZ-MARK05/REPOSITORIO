// Elastischer und unelastischer Sto�, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Choc &eacute;lastique";
var text02 = "Choc in&eacute;lastique";
var text03 = "Remise &agrave; z&eacute;ro";
var text04 = "D&eacute;but";
var text05 = "Mouvement lent";
var text06 = "Wagon 1:";
var text07 = "Wagon 2:";
var text08 = "Masse:";
var text09 = "Vitesse:";
var text10 = "Vitesse";
var text11 = "Quantit&eacute; de mouvement";
var text12 = "Energie cin&eacute;tique";

var author = "W. Fendt 1998,&nbsp; Y. Weiss 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                        

// Texte in Unicode-Schreibweise:

var text13 = "Wagon 1:";
var text14 = "Wagon 2:";
var text15 = "Vitesses avant le choc:";
var text16 = "Vitesses apr\u00e8s le choc:";
var text17 = "Quantit\u00e9s de mouvement avant le choc:";
var text18 = "Quantit\u00e9s de mouvement apr\u00e8s le choc:";
var text19 = "Energie cin\u00e9tique avant le choc:";
var text20 = "Energie cin\u00e9tique apr\u00e8s le choc:";
var text21 = "Quantit\u00e9 de mouvement totale:";
var text22 = "Energie cin\u00e9tique totale:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                 
var kilogramMeterPerSecond = "kg m/s";            
var joule = "J";                                      
