// Zweites Kepler-Gesetz, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "Demi grand axe:";
var text03 = "Excentricit&eacute;:";
var text04 = ["Pause", "Recommence"];
var text05 = "Ralenti";
var text06 = ["Distance", "au Soleil:"];
var text07 = "Vitesse:";
var text08 = "Actuellement:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Secteurs";
var text12 = "Vecteur vitesse";

var author = "W. Fendt 2000,&nbsp; Y. Weiss 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "UA";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Mercure", "Venus", "Terre", "Mars", "Jupiter", "Saturne", "Uranus", "Neptune",
              "Pluton", "Com\u00E8te de Halley", ""];

// Symbole und Einheiten: 

var auUnicode = "UA";
var symbolPeriod = "T";

