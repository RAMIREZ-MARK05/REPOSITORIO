// Kr�fte an der schiefen Ebene, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;part", "Pause", "Recommence"];
var text03 = "Mouvement lent";
var text04 = "Dynamom&egrave;tre";
var text05 = "Vecteurs forces";
var text06 = "Angle d'inclinaison:";
var text07 = "Poids:";
var text08 = "Composante parall&egrave;le:";
var text09 = "Composante normale:";
var text10 = "Coefficient de frottement:";
var text11 = "Force de frottement:";
var text12 = "Force motrice:";

var author = "W. Fendt 1999,&nbsp; Y. Weiss 1999";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad
var newton = "N";                                          // Newton
