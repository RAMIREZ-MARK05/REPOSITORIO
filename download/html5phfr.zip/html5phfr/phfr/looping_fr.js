// Loopingbahn, franz�sische Texte
// Letzte �nderung 10.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;but", "Pause", "Recommence"];
var text03 = "Mouvement lent (5 &times;)";
var text04 = "Mouvement lent (50 &times;)";
var text05 = "Rayon:";
var text06 = "Hauteur initiale:";
var text07 = "Acc&eacute;l&eacute;ration de la pesanteur:";
var text08 = "Masse:";
var text09 = "Vitesse";
var text10 = "Poids, force de contact";
var text11 = "Force tangentielle, force centrip&egrave;te";
var text12 = "Force totale";

var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Texte in Unicode-Schreibweise:

var text13 = "Vitesse:";
var text14 = "Poids:";
var text15 = "Force de contact:";
var text16 = "Force tangentielle:";
var text17 = "Force centrip\u00E8te:";
var text18 = "Force totale:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var second = "s";                               
var meter = "m";                                 
var meterPerSecond = "m/s";                        
var meterPerSecond2 = "m/s\u00b2";         
var kilogram = "kg";
var newton = "N";    


