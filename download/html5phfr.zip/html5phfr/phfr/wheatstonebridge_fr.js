// Wheatstonesche Br�ckenschaltung, franz�sische Texte
// Letzte �nderung 10.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Nouvelle mesure";
var text02 = "R&eacute;sistance de comparaison:";
var text03 = "R&eacute;sistance du rh&eacute;ostate:";
var text04 = "Position du contact glissant:";
var text05 = "Source de tension:";
var text06 = "R&eacute;sistance d'amp&egrave;rem&egrave;tre:";
var text07 = "Calculer la r&eacute;sistance";
var text08 = "Indiquer la tension &eacute;lectrique";
var text09 = "Indiquer l'intensit&eacute; du courant";
var author = "W. Fendt 2006";

// Texte in Unicode-Schreibweise:

var text10 = ["D\u00E9placez le contact glissant jusqu'\u00E0 ce",
  	          "que le courant soit nul!"];
var text11 = "La r\u00E9sistance peut maintenant \u00EAtre calcul\u00E9e.";         

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var milliampere = "mA";
var ohm = "\u03A9";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00D7";                              
