// Bewegung mit konstanter Beschleunigung, franz�sische Texte
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;but", "Pause", "Recommence"];
var text03 = "Mouvement lent";
var text04 = "Position  initiale:";
var text05 = "Vitesse initiale:";
var text06 = "Acc&eacute;l&eacute;ration:";
var text07 = "Vecteur vitesse";
var text08 = "Vecteur acc&eacute;l&eacute;ration";

var author = "W. Fendt 2000";
var translator = "Y. Weiss 2000";

// Texte in Unicode-Schreibweise:

var text09 = "(en s)";                                     // Einheitenangabe f�r Zeit-Achse
var text10 = "(en m)";                                     // Einheitenangabe f�r Weg-Achse
var text11 = "(en m/s)";                                   // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(en m/s\u00b2)";                             // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                          // Abk�rzung f�r Sekunde
var meter = "m";                                           // Abk�rzung f�r Meter
var meterPerSecond = "m/s";                                // Abk�rzung f�r Meter pro Sekunde
var meterPerSecond2 = "m/s\u00b2";                         // Abk�rzung f�r Meter pro Sekunde hoch 2
