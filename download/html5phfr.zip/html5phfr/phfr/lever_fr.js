// Hebelgesetz, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in Unicode-Schreibweise:

var text01 = "Sens de rotation gauche:";
var text02 = "Sens de rotation droite:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "M_1";                              // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "M_2";                             // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

var newton = "N";
var meter = "m";

var author = "W. Fendt 1997,  Y. Weiss 1998";              // Autor (und �bersetzer)
