// Gekoppelte Pendel, franz�sische Texte
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";                           
var text02 = ["D&eacute;marrer", "Pause", "Recommence"];                
var text03 = "Mouvement lent";
var text04 = "Positions initiales:";

var author = "W. Fendt 1998";
var translator = "Y. Weiss 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                  

// Texte in Unicode-Schreibweise:

var text05 = "Pendule 1";                                  // Erstes Pendel (links)
var text06 = "Pendule 2";                                  // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
