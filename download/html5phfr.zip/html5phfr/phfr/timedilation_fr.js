// Beispiel zur Zeitdilatation, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Diminution vitesse";
var text02 = "Augmentation vitesse";
var text03 = "Remise &agrave; z&eacute;ro";
var text04 = ["D&eacute;part", "Pause", "Recommence"];

var author = "W. Fendt 1997,&nbsp; Y. Weiss 1998";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text05 = "Distance:";
var text06 = "5 heures-lumi\u00E8re";
var text07 = "Vitesse:";
var text08 = "Temps de vol (syst\u00E8me Terre):";
var text09 = "heures";
var text10 = "Temps de vol (syst\u00E8me vaisseau):";