// Kombinationen von Widerst�nden, franz�sische Texte
// Letzte �nderung 04.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = "Tension de la batterie:";
var text03 = "R&eacute;sistance:";
var text04 = "Ajouter r&eacute;sistance (en s&eacute;rie)";
var text05 = "Ajouter r&eacute;sistance (en parall&egrave;le)";
var text06 = "Appareils de mesure:";
var text07 = "Tension";
var text08 = "Intensit&eacute;";

var author = "W. Fendt 2002";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "Tension:";
var text10 = "Intensit\u00E9:";
var text11 = "R\u00E9sistance:";
var text12 = "R\u00E9sistance \u00E9quivalente:";
var text13 = "tr\u00E8s petite";
var text14 = "tr\u00E8s grande";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

