// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "2 poulies";
var text02 = "4 poulies";
var text03 = "6 poulies";
var text04 = "Poids:";
var text05 = "Poids des poulies suspendues:";
var text06 = "Force &agrave; appliquer:";
var text07 = "Dynamom&egrave;tre";
var text08 = "Vecteurs de force";

var author = "W. Fendt 1998";
var translator = "Y. Weiss 1998";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                          // Abk�rzung f�r Newton
