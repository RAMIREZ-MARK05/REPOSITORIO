// Fadenpendel, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;part", "Arr&ecirc;t", "Recommence"];
var text03 = "Mouvement lent";
var text04 = "Longueur:";
var text05x = "Acc&eacute;l&eacute;ration";                // Zus�tzliche Zeile!
var text05 = "de la pesanteur:";
var text06 = "Masse:";
var text07 = "Amplitude:";
var text08 = "Elongation";
var text09 = "Vitesse";
var text10 = "Acc&eacute;l&eacute;ration";
var text11 = "Force";
var text12 = "Energie";

var author = "W. Fendt 1998,&nbsp; Y. Weiss 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var meter = "m";                                  
var meterPerSecond2 = "m/s&sup2;";                   
var kilogram = "kg";                                 
var degree = "&deg;";                           

// Texte in Unicode-Schreibweise:

var text13 = "Maximum";
var text14 = "Elongation";
var text15 = "Vitesse"; 
var text16 = "Acc\u00e9l\u00e9ration (composante tangentielle)";
var text17 = "Force (composante tangentielle)";
var text18 = "Energie potentielle";
var text19 = "Energie cin\u00e9tique";
var text20 = "Energie totale";
var text21 = "(en s)";
var text22 = "(en m)";
var text23 = "(en m/s)";
var text24 = "(en m/s\u00b2)";
var text25 = "(en N)";
var text26 = "(en J)";
var text27 = "P\u00e9riode des oscillations";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolTangential = "tang";                             // Symbol f�r tangential
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                    
var meterUnicode = "m";                               
var meterPerSecond = "m/s";                            
var meterPerSecond2Unicode = "m/s\u00b2";             
var newton = "N";                                    
var joule = "J";                                   


