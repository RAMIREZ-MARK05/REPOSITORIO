// Potentiometerschaltung, franz�sische Texte
// Letzte �nderung 10.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Source de tension:";
var text02 = "R&eacute;sistance du rh&eacute;ostate:";
var text03 = "Position du contact glissant:";
var text04 = "R&eacute;sistance du r&eacute;cepteur:";
var text05 = "Indiquer la tension &eacute;lectrique";
var text06 = "Indiquer l'intensit&eacute; du courant";
var author = "W. Fendt 2006";
var translator = "";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "U";                                  // Symbol f�r Spannung
var symbolVoltage2 = "r";                                  // Index f�r Verbraucher
                      
