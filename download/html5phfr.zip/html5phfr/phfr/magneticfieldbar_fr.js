// Magnetfeld eines Stabmagneten, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Effacer les lignes de champ";
var text02 = "Inverser les p&ocirc;les";

var author = "W. Fendt 2001";
var translator = "Y. Weiss 2001";
