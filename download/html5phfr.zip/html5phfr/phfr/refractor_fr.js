// Kepler-Fernrohr, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Distances focales:"; 
var text02 = "Objectif:";
var text03 = "Oculaire:";
var text04 = "Angles:";
var text05 = "Grossissement:";

var author = "W. Fendt 2000";
var translator = "Y. Weiss 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite
