// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Red&eacute;marrer";
var text02 = "Etape suivante";
var text03 = ["Pause", "Recommence"];                  
var text04 = "1. Indice de r&eacute;fraction:";
var text05 = "2. Indice de r&eacute;fraction:";
var text06 = "Angle d'incidence:";

var author = "W. Fendt 1998";
var translator = "Y. Weiss 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                             

// Texte in Unicode-Schreibweise:

var text07 = [                                             // i == 0 (step == 0, n1 != n2, eps1 > 0)

  ["Un front d'ondes planes arrive",
   "en diagonal sur la fronti\u00e8re",
   "de s\u00e9paration de deux milieux.",
   "Les ondes ont une vitesse",
   "diff\u00e9rente dans chaque milieu."],
   
  ["Un front d'ondes planes arrive",                       // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "perpendiculairement sur la",
   "fronti\u00e8re de separation de",
   "deux milieux.",
   "Les ondes ont une vitesse",
   "diff\u00e9rente dans chaque milieu."],
   
  ["A l'arriv\u00e9e du front d'ondes",                    // i == 2 (step == 1, n1 > n2)
   "les points le long de la",
   "fronti\u00e8re doivent v\u00e9rifier le",
   "principe de Huygens. Chaque",
   "point joue le r\u00f4le d'une",
   "source d'ondes sph\u00e9riques.",
   "Dans le milieu 2 ces ondes",
   "\u00e9l\u00e9mentaires se d\u00e9placent",
   "d'autant plus rapidement que",
   "l'indice de r\u00e9fraction est",
   "petit."],
   
  ["A l'arriv\u00e9e du front d'ondes",                    // i == 3 (step == 1, n1 < n2)
   "les points le long de la",
   "fronti\u00e8re doivent v\u00e9rifier le",
   "principe de Huygens. Chaque",
   "point joue le r\u00f4le d'une",
   "source d'ondes sph\u00e9riques.",
   "Dans le milieu 2 ces ondes",
   "\u00e9l\u00e9mentaires se d\u00e9placent",
   "d'autant plus lentement que",
   "l'indice de r\u00e9fraction est",
   "grand."],

  ["De la superposition de toutes",                        // i == 4 (step == 2, total == false, esp1 > 0)
   "ces ondes \u00e9l\u00e9mentaires",
   "r\u00e9sulte une nouvelle onde",
   "plane."],  
   
  ["De la superposition de toutes",                        // i == 5 (step == 2, total == false, esp1 == 0)
   "ces ondes \u00e9l\u00e9mentaires",
   "r\u00e9sulte une nouvelle onde",
   "plane."],

  ["De la superposition de toutes",                        // i == 6 (step == 2, total == true)
   "ces ondes \u00e9l\u00e9mentaires",
   "r\u00e9sulte une nouvelle onde",
   "plane dans le milieu 1 (onde",
   "r\u00e9fl\u00e9chie).",
   "L'onde n'est pas trasmise",
   "au milieu 2 (r\u00e9flexion totale)."],
     
  ["La direction de la propagation",                       // i == 7 (step == 3)
   "des ondes est maintenant",
   "trac\u00e9e. C'est la ligne perpen-",
   "diculaire au front d'ondes."],  
   
  ["Un front d'ondes arrive",                              // i == 8 (step == 4)
   "rarement seul!"],   

  ["Si les deux milieux ont le",                           // i == 9 (n1 == n2)
   "m\u00eame indice de r\u00e9fraction",
   "rien de sp\u00e9cial n'appara\u00eet."]];
        
var text08 = "Angle d'incidence:"; 
var text09 = "Angle de r\u00e9flexion:";
var text10 = "Angle de r\u00e9fraction:"; 
var text11 = "Milieu 1";
var text12 = "Milieu 2";      
var text13 = ["Angle limite pour une", "r\u00e9flexion totale:"];

// Einheiten:

var degreeUnicode = "\u00b0";                              // Grad
