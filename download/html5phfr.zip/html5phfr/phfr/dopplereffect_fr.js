// Beispiel zum Doppler-Effekt, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Red&eacute;marrer";
var text02 = ["Pause", "Recommence"]; 

var author = "W. Fendt 1998";
var translator = "Y. Weiss 1998";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                        
  ["Aussi longtemps que",
   "l'ambulance se rapproche",
   "de la personne les intervalles",
   "entre les fronts d'ondes",
   "se raccourcissent."],
  ["Maintenant le v\u00E9hicule",
   "s'\u00E9loigne de la personne.",
   "Les intervalles entre les",
   "fronts d'ondes sont alors",
   "plus longs."]];
  

