// Elektromagnetischer Schwingkreis, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;but", "Pause", "Continuer"];
var text03 = "Ralenti (10 &times;)";
var text04 = "Ralenti (100 &times;)";
var text05 = "Capacit&eacute;:";
var text06 = "Inductance:";
var text07 = "R&eacute;sistance:";
var text08 = "Tension max.:";
var text09 = "Tension, Intensit&eacute;";
var text10 = "Energie";

var author = "W. Fendt 1999,&nbsp; Y. Weiss 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                          
var henry = "H";                               
var ohm = "&Omega;";                             
var volt = "V";                                  

// Texte in Unicode-Schreibweise:

var text11 = "P\u00E9riode des oscillations:";
var text12 = "Energie \u00E9lectrique:";
var text13 = "Energie magn\u00E9tique:";
var text14 = "Energie interne:";
var text15 = "Oscillations non amorties";
var text16 = "Oscillations amorties";
var text17 = "R\u00E9gime ap\u00E9riodique";
var text18 = "R\u00E9gime non oscillatoire";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "V";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                  
var voltUnicode = "V";                            
var ampere = "A";                             
var joule = "J";                                
