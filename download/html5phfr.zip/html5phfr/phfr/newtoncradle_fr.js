// Newtons Wiege, franz�sische Texte
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = "D&eacute;but";
var text03 = "Nombre de billes:";

var author = "W. Fendt 1997";
var translator = "";
