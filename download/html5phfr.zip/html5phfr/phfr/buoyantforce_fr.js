// Messung der Auftriebskraft, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Surface de base du corps:"; 
var text02 = "Hauteur du corps:";
var text03 = "Densit&eacute; du corps:";
var text04 = "Densit&eacute; du liquide:";   
var text05 = "Hauteur immerg&eacute;e:";
var text06 = "Volume d&eacute;plac&eacute;:"; 
var text07 = "Pous&eacute;e d'Archim&egrave;de:";
var text08 = "Poids du corps:";
var text09 = "Force mesur&eacute;e:";
var text10 = "Tension maximum:";

var author = "W. Fendt 1998,&nbsp; Y. Weiss 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Maximum atteint!";
