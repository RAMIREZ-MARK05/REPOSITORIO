// Schiefer Wurf, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";                    
var text02 = ["D&eacute;but", "Pause", "Reprendre"];          
var text03 = "Mouvement lent";
var text04 = "Hauteur initiale:";
var text05 = "Vitesse initiale:";
var text06 = "Angle d'inclinaison:";
var text07 = "Masse:"; 
var text08 = "Acc&eacute;l&eacute;ration de la pesanteur:";
var text09 = "Coordonn&eacute;es";
var text10 = "Vitesse";
var text11 = "Acc&eacute;l&eacute;ration";
var text12 = "Force";
var text13 = "Energie";

var author = "W. Fendt 2000,&nbsp; Y. Weiss 2000";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                       
var meterPerSecond = "m/s";                        
var meterPerSecond2 = "m/s&sup2;";                    
var kilogram = "kg";                               
var degree = "&deg;";                                   

// Texte in Unicode-Schreibweise:

var text14 = "(en m)";                                     // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Coordonn\u00e9es:";
var text16 = "(horizontale)";
var text17 = "(verticale)";
var text18 = "Port\u00e9e:";
var text19 = "Hauteur maximale:";
var text20 = "Temps:";
var text21 = "Composantes de la vitesse:";
var text22 = "Norme de la vitesse:";
var text23 = "Angle d'inclinaison:";
var text24 = "Acc\u00e9l\u00e9ration:";
var text25 = "Force:";
var text26 = "Energie cin\u00e9tique:";
var text27 = "Energie potentielle:";
var text28 = "Energie totale:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                                  
var secondUnicode = "s";                               
var meterPerSecondUnicode = "m/s";                        
var meterPerSecond2Unicode = "m/s\u00b2";               
var newtonUnicode = "N";                                
var jouleUnicode = "J";                                
var degreeUnicode = "\u00b0";                        



