// Erstes Kepler-Gesetz, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "Demi grand axe:";
var text03 = "Excentricit&eacute;:";
var text04 = "Demi petit axe:";
var text05 = ["Pause", "Recommence"];
var text06 = "Rallenti";
var text07 = "Distance au Soleil:";
var text08 = "Actuellement:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Orbite elliptique";
var text12 = "Axes";
var text13 = "Lignes vers foyers";

var author = "W. Fendt 2000,&nbsp; Y. Weiss 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "UA";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Mercure", "Venus", "Terre", "Mars", "Jupiter", "Saturne", "Uranus", "Neptune",
              "Pluton", "Com\u00E8te de Halley", ""];

var text14 = "Soleil";
var text15 = "Plan\u00E8te";
var text16 = "Com\u00E8te";
var text17 = "P\u00E9rih\u00E9lie";
var text18 = "Aph\u00E9lie";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "UA";

