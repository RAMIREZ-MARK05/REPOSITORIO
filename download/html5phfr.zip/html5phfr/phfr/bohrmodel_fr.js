// Bohrsches Atommodell, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Mod&egrave;le particule";
var text02 = "Mod&egrave;le onde";
var text03 = "Nombre quantique principal:";


var author = "W. Fendt 1999"; 
var translator = "Y. Weiss 1999";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



