// Bilderzeugung Sammellinse, franz�sische Texte
// Letzte �nderung 10.03.2020

// Texte in HTML-Schreibweise:
    
var text01 = "Distance focale:";
var text02 = "Distance de l'objet:"; 
var text03 = "Grandeur de l'objet:";
var text04 = "Distance de l'image:";
var text05 = "Grandeur de l'image:"; 
var text06 = "Type d'image:"
var text07 = ["r&eacute;elle", "virtuelle"];
var text08 = ["invers&eacute;e", "droite"]; 
var text09 = ["plus petite", "de m&ecirc;me grandeur", "plus grande", "infiniment grande"];
var text10 = "Rayons particuliers";
var text11 = "Faisceau de rayons";
var text12 = "Souligner:";

var author = "W. Fendt 2008";

// Symbole und Einheiten:

var centimeter = "cm";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text13 = ["objet", 
              "distance de l'objet",
              "grandeur de l'object",
              "lentille", 
              "plan de la lentille", 
              "axe optique",
              "foyers", 
              "distance focale", 
              "image", 
              "distance de l'image",
              "grandeur de l'image",
              "\u00E9cran"];
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "o";
var symbolGG = "O"; 
var symbolB = "i";
var symbolBB = "I";


