// Photoelektrischer Effekt, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Mat&eacute;riau de la cathode:";
var text02 = ["cesium", "sodium"];
var text03 = "Raie spectrale (Hg):";
var text04 = "Tension d'arr&ecirc;t:";
var text05 = "Fr&eacute;quence:";
var text06 = ["Energie d'un", "photon:"];
var text07 = "Travail d'extraction:";
var text08 = ["Energie cin&eacute;tique maximum", "d'un &eacute;lectron:"];
var text09 = "Nettoyer les mesures";

var author = "W. Fendt 2000,&nbsp; Y. Weiss 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                   
var terahertz = "THz";                             
var electronvolt = "eV";                          

// Texte in Unicode-Schreibweise:

var text10 = ["jaune", "vert", "violet", "ultraviolet", "ultraviolet"];
var text11 = "(en THz)";
var text12 = "(en V)";
var text13 = [
             ["L'\u00E9nergie d'un photon n'est pas suffisante", "pour l'\u00E9mission d'un \u00E9lectron."],
             ["Augmenter un peu plus la tension d'arr\u00EAt pour que", "moins d'\u00E9lectrons n'atteignent l'anode!"], 
             ["La tension d'arr\u00EAt est si grande que les \u00E9lectrons", "retournent sur la cathode."],
             ["En avant pour une nouvelle mesure avec une autre", "longueur d'onde!"],
             ["En avant pour une nouvelle s\u00E9rie de mesures avec", "un autre mat\u00E9riau pour la cathode!"],
             ["Les mesures sont termin\u00E9es.", ""]
             ];

var symbolCathode = "C";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
