// Ohmsches Gesetz, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Tension max:";
var text02 = "Intensit&eacute; max:";
var text03 = "Augmentation de R";
var text04 = "R&eacute;duction de R";
var text05 = "Augmentation de U";
var text06 = "R&eacute;duction de U";

var author = "W. Fendt 1997";
var translator = "Y. Weiss 1998";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Maximum atteint!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
