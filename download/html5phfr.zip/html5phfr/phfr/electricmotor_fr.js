// Gleichstrom-Elektromotor, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;part", "Pause", "Recommence"];             
var text03 = "Changement de direction";
var text04 = "Sens du courant";
var text05 = "Champ magn&eacute;tique";
var text06 = "Force de Laplace";

var author = "W. Fendt 1997";               
var translator = "Y. Weiss 1998";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";                        // Umdrehungen pro Minute
