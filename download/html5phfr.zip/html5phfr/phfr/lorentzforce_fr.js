// Leiterschaukel-Versuch zur Lorentzkraft, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "On / Off";
var text02 = "Inversion du courant";
var text03 = "Inversion du champ";
var text04 = "Sens du courant";
var text05 = "Champ magn&eacute;tique";
var text06 = "Force de Laplace";

var author = "W. Fendt 1998";
var translator = "Y. Weiss 1998";
