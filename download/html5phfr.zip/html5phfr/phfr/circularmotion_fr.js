// Kreisbewegung mit konstanter Winkelgeschwindigkeit, franz�sische Texte
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;but", "Pause", "Reprendre"];
var text03 = "Mouvement lent";
var text04 = "Rayon:";
var text05 = "P&eacute;riode:";
var text06 = "Masse:";
var text07 = "Position";
var text08 = "Vitesse";
var text09 = "Acc&eacute;l&eacute;ration";
var text10 = "Force";

var author = "W. Fendt 2007";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                      
var second = "s";                                    
var kilogram = "kg";                                

// Texte in Unicode-Schreibweise:

var text11 = "Position:";
var text12 = "Vitesse:";
var text13 = "Vitesse angulaire:";
var text14 = "Acc\u00e9l\u00e9ration centrip\u00e8te:";
var text15 = "Force centrip\u00e8te:";
var text16 = "(en s)";
var text17 = "(en m)";
var text18 = "(en m/s)";
var text19 = "(en m/s\u00b2)";
var text20 = "(en N)";
var text21 = "(composante x)";
var text22 = "(composante y)";
var text23 = "(module)";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03c9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "m";                              
var meterPerSecond = "m/s";                          
var meterPerSecond2 = "m/s\u00b2";                      
var newton = "N";                                      
var radPerSecond = "rad/s";                             




