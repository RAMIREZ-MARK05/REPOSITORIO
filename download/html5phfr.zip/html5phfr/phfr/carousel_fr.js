// Kettenkarussell, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Man&egrave;ge";
var text02 = "Man&egrave;ge, forces";
var text03 = "R&eacute;sum&eacute;";
var text04 = "Valeurs num&eacute;riques";
var text05 = ["Pause", "Reprise"];
var text06 = "Mouvement lent";
var text07 = "P&eacute;riode:";
var text08 = ["Distance entre suspensions", "et axe de rotation:"]; 
var text09 = "Longueur des cordes:";
var text10 = "Masse:";

var author = "W. Fendt 1999,&nbsp; Y. Weiss 2000";

// Texte in Unicode-Schreibweise:

var text11 = "Fr\u00E9quence:";
var text12 = "Vitesse angulaire:";
var text13 = "Rayon:";
var text14 = "Vitesse:";
var text15 = "Angle:";
var text16 = "Poids:";
var text17 = "Force centrip\u00E8te:";
var text18 = "Tension sur la corde:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




