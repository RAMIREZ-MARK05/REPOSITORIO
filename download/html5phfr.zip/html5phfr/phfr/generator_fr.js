// Generator, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Sans commutateur";
var text02 = "Avec commutateur";
var text03 = "Changement de sens";
var text04 = ["Start", "Pause", "Recommence"];
var text05 = "Sens du mouvement";
var text06 = "Champ magn&eacute;tique";
var text07 = "Courant induit";

var author = "W. Fendt 1998";  
var translator = "Y. Weiss 1998";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "tours/min";                      // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "V";
var symbolResistor = "R";
