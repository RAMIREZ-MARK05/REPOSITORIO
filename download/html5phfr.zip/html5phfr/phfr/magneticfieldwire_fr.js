// Magnetfeld eines geraden stromdurchflossenen Leiters, franz�sische Texte
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Inversion du courant";

var author = "W. Fendt 2000";
var translator = "Y. Weiss 2000";
