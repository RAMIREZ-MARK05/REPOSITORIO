// Spezielle Prozesse eines idealen Gases, franz�sische Texte (Yves Weiss)
// Letzte �nderung 10.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Transformation isobare";
var text02 = "Transformation isochore";
var text03 = "Transformation isotherme";
var text04 = "&Eacute;tat initial:";
var text05 = "Pression:";
var text06 = "Volume:";
var text07 = "Temp&eacute;rature:";
var text08 = "&Eacute;tat final:";
var text09 = "&Eacute;tat initial";
var text10 = "D&eacute;part";

var author = "W. Fendt 1999,&nbsp; Y. Weiss 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Travail";
var text12 = "Chaleur";
var text13 = "L'\u00E9nergie interne du gaz";
var text14 = "augmente.";
var text15 = "L'\u00E9nergie interne du gaz";
var text16 = "est constante.";
var text17 = "L'\u00E9nergie interne du gaz";
var text18 = "diminue.";
var text19 = "Pression trop petite!";
var text20 = "Pression trop grande!";
var text21 = "Volume trop petit!";
var text22 = "Volume trop grande!";
var text23 = "Temp\u00E9rature trop petite!";
var text24 = "Temp\u00E9rature trop grande!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


