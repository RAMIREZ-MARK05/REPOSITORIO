// Gleichgewicht dreier Kr�fte, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Forces:";
var text02 = "Gauche:";
var text03 = "Droite:";
var text04 = "Centre:";
var text05 = "Parall&eacute;logramme des forces";
var text06 = "Angles:";
var text07 = "Gauche:";
var text08 = "Droite:";

var author = "W. Fendt 2000";
var translator = "Y. Weiss 2000";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var degree = "\u00b0";                                     // Symbol f�r Grad
var newton = "N";                                          // Abk�rzung f�r Newton
