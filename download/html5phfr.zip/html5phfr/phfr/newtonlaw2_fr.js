// Fahrbahnversuch zum 2. Newtonschen Gesetz, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;part", "Enregistrement"];
var text03 = "Diagramme";
var text04 = "Masse du wagon:";
var text05 = "Masse suspendue:";
var text06 = "Coefficient du frottement:";
var text07 = "Data:";

var author = "W. Fendt 1997,&nbsp; Y. Weiss 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "LS";
var text09 = "(en s)";
var text10 = "(en m)";
var text11 = "Trop grand frottement!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


