// Rutherford-Streuung, franz�sische Texte
// Letzte �nderung 01.11.2020

// Texte in HTML-Schreibweise:

var text01 = "Effacer les trajectories";                  
var text02 = "D&eacute;but";
var text03 = "Noyau de diffusion:"; // ???
var text04 = "Num&eacute;ro atomique:";
var text05 = "Particule alpha:";
var text06 = "Vitesse:";
var text07 = "Param&egrave;tre de choc:";
var text08 = "Angle de d&eacute;viation:";
var text09 = "Distance minimale:";
var text10 = "Asymptotes, param&egrave;tre de choc";
var text11 = "Asymptotes, angle de d&eacute;viation";


var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var femtometer = "fm";
var kilometerPerSecond = "km/s";
var degree = "\u00B0";




