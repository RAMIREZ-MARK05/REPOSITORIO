// Interferenz von Licht am Doppelspalt, franz�sische Texte (WWW-Recherche)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Longueur d'onde:";
var text02 = "Distance entre les fentes:";
var text03 = "Angle:";
var text04 = "Maxima:";
var text05 = "Minima:";
var text06 = "Intensit&eacute; relative:";
var text07 = "Figure d'interf&eacute;rence";
var text08 = "Profil d'intensit&eacute;";

var author = "W. Fendt 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
