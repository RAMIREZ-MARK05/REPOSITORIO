// Stehende Welle, Erkl�rung durch Reflexion, franz�sische Texte
// Letzte �nderung 03.03.2020

// Texte in HTML-Schreibweise:

var text01 = "R&eacute;flexion";
var text02 = "sur une extr&eacute;mit&eacute; fixe";
var text03 = "sur une extr&eacute;mit&eacute; libre";
var text04 = "Remise &agrave; z&eacute;ro";
var text05 = ["D&eacute;part", "Pause", "Recommence"];
var text06 = "Mouvement lent";
var text07 = "Animation";
var text08 = "&Eacute;tapes uniques";
var text09 = "Onde incidente";
var text10 = "Onde r&eacute;flechi&eacute;";
var text11 = "Onde r&eacute;sultante";

var author = "W. Fendt 2003"; 
var translator = "";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "N";
var symbolAntiNode = "V";

