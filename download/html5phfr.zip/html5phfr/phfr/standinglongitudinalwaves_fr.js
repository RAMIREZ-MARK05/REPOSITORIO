// Stehende L�ngswellen, franz�sische Texte
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Forme du tube:";
var text02 = "deux c&ocirc;t&eacute;s ouverts";
var text03 = "un c&ocirc;t&eacute; ouvert";
var text04 = "deux c&ocirc;t&eacute;s ferm&eacute;s";
var text05 = "Harmonique:";
var text06 = ["oscillation de base", "1er mode d'oscillation",  // Bezeichnungen der Eigenschwingungen 
              "2e mode d'oscillation", "3e mode d'oscillation", 
              "4e mode d'oscillation", "5e mode d'oscillation"];
var text07 = "Inf&eacute;rieur";
var text08 = "Sup&eacute;rieur";
var text09 = "Longueur du tube:";
var text10 = "Longueur d'onde:";
var text11 = "Fr&eacute;quence:";

var author = "W. Fendt 1998,&nbsp; Y. Weiss 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                    
var hertz = "Hz";                               

// Texte in Unicode-Schreibweise:

var text12 = "D\u00e9placement des particules";            // �berschrift des ersten Diagramms
var text13 = "Variation de pression";                      // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "N";                                      // Symbol f�r Knoten
var symbolAntinode = "V";                                  // Symbol f�r Bauch

