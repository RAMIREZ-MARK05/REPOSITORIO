// Ersatzkraft mehrerer Kr�fte, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Nombre de forces:";
var text02 = "Construction de la r&eacute;sultante";
var text03 = "Effacer la construction";

var author = "W. Fendt 1998";
var translator = "Y. Weiss 2000";
