// Einfache Wechselstromkreise, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = "R&eacute;sistance";
var text02 = "Condensateur";
var text03 = "Bobine";
var text04 = "Remise &agrave; z&eacute;ro";
var text05 = ["D&eacute;part", "Pause", "Reprise"];          
var text06 = "Mouvement lent";
var text07 = "Fr&eacute;quence:";
var text08 = "Tension max:";
var text09 = "R&eacute;sistance:";                            
var text10 = "Capacit&eacute;:";                          
var text11 = "Inductance:"; 
var text12 = "Intensit&eacute; max:"; 

var author = "W. Fendt 1998,&nbsp; Y. Weiss 1998";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                         
var volt = "V";                                   
var ampere = "A";                                
var milliampere = "mA";                           
var microampere = "&mu;A";                       
var ohm = "&Omega;";                           
var microfarad = "&mu;F";                          
var henry = "H";                                  

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "V";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
