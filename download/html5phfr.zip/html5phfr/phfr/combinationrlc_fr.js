// Kombinationen von Widerst�nden, Spulen und Kondensatoren, franz�sische Texte
// Letzte �nderung 22.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Source de tension alternative:";
var text02 = "Tension:";
var text03 = "Fr&eacute;quence:";
var text04 = "Composante:";
var text06 = ["R&eacute;sistance:", "Inductance:", "Capacit&eacute;:"];
var text07 = "Remplacer";
var text08 = "Ajouter (en s&eacute;rie)";
var text09 = "Ajouter (en parall&egrave;le)";
var text10 = "Enlever";
var text11 = "Appareils de mesure:";
var text12 = "Tension";
var text13 = "Intensit&eacute;";

var author = "W. Fendt 2004";
var translator = "";

// Texte in Unicode-Schreibweise:

var text05 = ["R\u00E9sistance", "Bobine", "Condensateur"];
var text14 = "Tension:";
var text15 = "Intensit\u00E9:";
var text16 = "Imp\u00E9dance:";
var text17 = "Imp\u00E9dance (module):";
var text18 = "Angle de phase:";
var text19 = "tr\u00E8s petite";                           // Stromst�rke Voltmeter
var text20 = "tr\u00E8s petite";                           // Spannung Amperemeter
var text21 = "tr\u00E8s petite";                           // Impedanz/Widerstand Amperemeter
var text22 = "tr\u00E8s grande";                           // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)