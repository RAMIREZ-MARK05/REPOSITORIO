// Reflexion und Brechung von Licht, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = "1. indice de r&eacute;fraction:";
var text02 = "2. indice de r&eacute;fraction:";
var text03 = "Angle d'incidence:";
var text04 = "Angle de r&eacute;flexion:";
var text05 = "Angle de r&eacute;fraction:";    
var text06 = ["Angle limite pour une", "r&eacute;flexion totale:"];

var author = "W. Fendt 1997,&nbsp; Y. Weiss 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                        

// Texte in Unicode-Schreibweise:

var text07 = [["vide", "1"], ["air", "1.0003"],            // Stoffe und Brechungsindizes
    ["eau", "1.33"], ["\u00e9thanol", "1.36"],
    ["verre de quartz", "1.46"], ["benz\u00e8ne", "1.49"], 
    ["verre crown N-K5", "1.52"], ["sel gemme", "1.54"], 
    ["verre flint LF5", "1.58"], ["verre crown N-SK4", "1.61"],
    ["verre flint SF6", "1.81"], ["diamant", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                       
