// Zerfallsreihen, franz�sische Texte (Yves Weiss)
// Letzte �nderung 07.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Cha&icirc;ne de d&eacute;sint&eacute;gration:";
var text03 = "D&eacute;sint&eacute;gration suivante";

var author = "W. Fendt 1998"; 
var translator = "Y. Weiss 1998";

// Texte in Unicode-Schreibweise:

var text02 = ["Famille du Thorium", "Famille du Neptunium", "Famille de l'Uranium-Radium", "Famille de l'Uranium-Actinium"];          





