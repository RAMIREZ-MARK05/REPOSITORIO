// Interferenz zweier Kreis- oder Kugelwellen, franz�sische Texte (Yves Weiss)
// Letzte �nderung 14.12.2017

// Texte in HTML-Schreibweise:

var text01 = ["Pause", "Recommence"];                      // Schaltknopf (Pause/Weiter)
var text02 = "Ralenti";
var text03 = "Distance aux deux";
var text04 = "sources:";
var text05 = "Longueur d'onde:";

var author = "W. Fendt 1999";
var translator = "Y. Weiss 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                                     // Zentimeter

// Texte in Unicode-Schreibweise:

var text06 = "Diff\u00e9rence de marche:";
var text07 = "Interf\u00e9rences constructives (amplitude maximale)";
var text08 = "Interf\u00e9rences destructives (amplitude minimale)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (Lambda)
