// Schwebungen, franz�sische Texte
// Letzte �nderung 15.03.2021

// Texte in HTML-Schreibweise:

var text01 = "Remise &agrave; z&eacute;ro";
var text02 = ["D&eacute;part", "Arr&ecirc;t", "Reprise"];
var text03 = "Mouvement lent";
var text04 = "Distance interr&eacute;ticulaire:";
var text05 = "Longueur d'onde:";
var text06 = "Angle de Bragg:";
var text07 = "Nombre de plans:";
var text08 = "Diff&eacute;rence de chemin:";

var author = "W. Fendt 2021";
var translator = "";

// Text in Unicode-Schreibweise:

var text09 = "Condition de Bragg satisfaite!";

// Einheiten und Symbole:

var decimalSeparator = ",";
var picometer = "pm";
var degree = "\u00B0";
var symbolDeltaS = "\u0394s";
var symbolLambda = "\u03BB";