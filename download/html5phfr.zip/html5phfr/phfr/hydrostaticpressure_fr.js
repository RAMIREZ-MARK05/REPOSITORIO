// Druckdose (hydrostatischer Druck), franz�sische Texte (Yves Weiss)
// Letzte �nderung 03.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Liquide:";
var text03 = "Densit&eacute;:";
var text04 = "Profondeur:";
var text05 = "Pression hydrostatique:";

var author = "W. Fendt 1999";                              // Autor
var translator = "Y. Weiss 1999";                          // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["inconnu", "eau", "\u00E9thanol", "benz\u00E8ne", "t\u00E9trachlorom\u00E9thane", "mercure"]; 
