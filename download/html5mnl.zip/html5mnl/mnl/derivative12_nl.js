// 1. und 2. Ableitungsfunktion, niederl�ndische Texte (PeterJaap de Bruin)
// Letzte �nderung 23.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Functievergelijking:";
var text02 = "f(x) =";
var text03 = "1e afgeleide";
var text04 = "2e afgeleide";
var text05 = "Linkerrand:";
var text06 = "Rechterrand:";
var text07 = "Onderrand:";
var text08 = "Bovenrand:";
var text09 = "Tekenen";

var author = "W. Fendt 1999,&nbsp; P.J. de Bruin 2003";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text10 = "Foutive vergelijking!";
var text11 = "Fout bij het afleiden!";

var symbolX = "x";
var symbolY = "y";
