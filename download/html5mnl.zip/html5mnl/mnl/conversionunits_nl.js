// Umrechnung von Einheiten, niederl�ndische Texte (PeterJaap de Bruin)
// Letzte �nderung 10.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Opnieuw starten";
var text02 = "Start";
var text03 = "Lengte";
var text04 = "Oppervlakte";
var text05 = "Volume";
var text06 = "Massa";
var text07 = "Tijd";
var text08 = "Moeilijkheid:";
var text09 = ["1 opgave", 
              "x opgaven"];         
var text10 = ["1 hit", 
              "x hits"];           
     
var author = "W. Fendt 2001,&nbsp; P.J. de Bruin 2003";              // Autor (und �bersetzer)

var decimalSeparator = ",";                                          // Dezimaltrennzeichen (Komma/Punkt)

