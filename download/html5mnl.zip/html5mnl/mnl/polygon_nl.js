// Regelm��ige Vielecke, niederl�ndische Texte
// Letzte �nderung 24.02.2020

// Texte in HTML-Schreibweise:

var text11 = "Aantal hoekpunten:";
var text12 = "Omgeschreven cirkel";
var text13 = "Ingeschreven cirkel";
var text14 = "Driehoeken";
var text15 = "Diagonalen";

var text21 = "Schl&auml;fli-symbool:";

var author = "W. Fendt 2018";
var translator1 = "";
var translator2 = "";





