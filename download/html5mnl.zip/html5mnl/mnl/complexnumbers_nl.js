// Rechnen mit komplexen Zahlen, niederl�ndische Texte (PeterJaap de Bruin)
// Letzte �nderung 25.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Rekensoort:";
var text02 = "Optellen";
var text03 = "Aftrekken";
var text04 = "Vermenigvuldigen";
var text05 = "Delen";
var text06 = "Co&ouml;rdinatenstelsel:";
var text07 = "Cartesische Co&ouml;rdinaten";
var text08 = "Poolco&ouml;rdinaten";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1998";
var translator = "P.J. de Bruin 2003";

// Texte in Unicode-Schreibweise:

var text09 = "niet gedefinieerd!";

var symbolOperation = ["+", "\u2212", "\u00B7", ":"];      // Rechenzeichen
