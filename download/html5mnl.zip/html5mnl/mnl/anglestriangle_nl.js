// Innenwinkelsumme eines Dreiecks, niederl�ndische Texte (WWW-Recherche)
// Letzte �nderung 30.05.2018

// Texte in HTML-Schreibweise:

var text01 = "Hoeken:"; // ???
var text02 = "Decimalen:";

var author = "W. Fendt 1998";
var translator = "";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Winkelgrad

// Texte in Unicode-Schreibweise:

var angle1 = ["\u03B1",                                    // Alpha 
              "\u03B2",                                    // Beta
              "\u03B3"];                                   // Gamma
              
var angle2 = ["\u03B1'",                                   // Alpha Strich 
              "\u03B2'"];                                  // Beta Strich
              
var vertex = ["A", "B", "C"];                              // Ecken

        
              

