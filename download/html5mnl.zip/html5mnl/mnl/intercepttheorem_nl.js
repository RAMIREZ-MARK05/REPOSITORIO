// Strahlensatz, niederl�ndische Texte
// Letzte �nderung 24.2.2020

// Texte in HTML-Schreibweise:

var text01 = "V figuur";
var text02 = "X figuur";
var text03 = "Verhouding:";

var author = "W. Fendt 2000";
var translator = "";

// Symbole in Unicode-Schreibweise:

var symbolDivision = ":";

var symbolZ = "Z";
var symbolA1 = "A";
var symbolB1 = "B";
var symbolA2 = "A'";
var symbolB2 = "B'";



