// Kugeldreieck, niederl�ndische Texte (PeterJaap de Bruin)
// Letzte �nderung 25.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Zijden:";
var text02 = "a = ";
var text03 = "b = ";
var text04 = "c = ";
var text05 = "Som van de zijden:&nbsp;&nbsp;";
var text06 = "Hoeken:";
var text07 = "&alpha; = ";
var text08 = "&beta; = ";
var text09 = "&gamma; = ";
var text10 = "Som van de hoeken:&nbsp;&nbsp;";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1999";
var translator = "P.J. de Bruin 2003";

// Texte in Unicode-Schreibweise:

var symbolA = "A";
var symbolB = "B";
var symbolC = "C";


