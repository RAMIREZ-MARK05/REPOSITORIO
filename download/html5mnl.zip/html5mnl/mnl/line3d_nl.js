// Geradengleichung, niederl�ndische Texte (PeterJaap de Bruin)
// Letzte �nderung 25.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Punt A:";
var text02 = "Punt B:";

//var decimalSeparator = ",";

var author = "W. Fendt 1999";
var translator = "P.J. de Bruin 2003";

// Texte in Unicode-Schreibweise:

var text03 = "Lijn AB niet gedefinieerd!";

var symbolPoint1 = "A";
var symbolPoint2 = "B";
var symbolX = "x_1";
var symbolY = "x_2";
var symbolZ = "x_3";
var symbolPositionVector = "X";
var symbolParameter = "\u03BB";
