// Gerade Strophoide, niederl�ndische Texte
// Letzte �nderung 06.01.20

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauze", "Doorgaan"];  

var author = "W. Fendt 2020";    

                




