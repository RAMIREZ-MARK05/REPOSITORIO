// Kr�mmungskreise von Funktionsgraphen, niederl�ndische Texte
// Letzte �nderung 24.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Functievergelijking:";
var text02 = "f(x) =";
var text03 = "Linkerrand:";
var text04 = "Rechterrand:";
var text05 = "Onderrand:";
var text06 = "Bovenrand:";
var text07 = "Tekenen";

var author = "W. Fendt 2017";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text08 = "Foutive vergelijking!";
var text09 = "Fout bij het afleiden!";

var symbolX = "x";
var symbolY = "y";

