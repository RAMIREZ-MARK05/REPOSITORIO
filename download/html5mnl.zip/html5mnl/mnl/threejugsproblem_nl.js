// Milchkannenr�tsel, niederl�ndische Texte (unvollst�ndig)
// Letzte �nderung 02.12.2017

var unit0 = "liters";                                      // Volumeneinheit, Anzahl 0
var unit1 = "liter";                                       // Volumeneinheit, Anzahl 1
var unit2 = "liters";                                      // Volumeneinheit, Anzahl 2
var unit3 = "liters";                                      // Volumeneinheit, Anzahl mindestens 3
var text1 = "Herzlichen Gl\u00fcckwunsch!";                // Text f�r Gratulation
var text2 = "Wenn du das Spiel neu starten willst:";       // Text f�r Neustart, 1. Zeile
var text3 = "Ein Mausklick gen\u00fcgt!";                  // Text f�r Neustart, 2. Zeile
