// Epizykloiden und Hypozykloiden, niederl�ndische Texte
// Letzte �nderung 24.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Epicyclo&iuml;de";
var text02 = "Hypocyclo&iuml;de";
var text03 = "Verhouding van de stralen:";
var text04 = "Reset";
var text05 = ["Start", "Pauze", "Doorgaan"];  

var author = "W. Fendt 2017";    

// Texte in Unicode-Schreibweise:

var text06 = "Bijzonder geval: Cardio\u00EFde";  
var text07 = "Bijzonder geval: Nefro\u00EFde";
var text08 = "Bijzonder geval: Cirkeldiameter (Cardano cirkels)";
var text09 = "Bijzonder geval: Delto\u00EFde";
var text10 = "Bijzonder geval: Astro\u00EFde";                   




