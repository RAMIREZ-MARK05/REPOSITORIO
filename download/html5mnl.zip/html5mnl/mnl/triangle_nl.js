// Besondere Linien und Kreise im Dreieck, niederl�ndische Texte (Gerard Koolstra)
// Letzte �nderung 25.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Middelloodlijnen";
var text02 = "Omgeschreven cirkel";
var text03 = "Deellijnen (bissectrices)";
var text04 = "Ingeschreven cirkel";
var text05 = "Aanliggende cirkels";
var text06 = "Middenparallellen";
var text07 = "Zwaartelijnen";
var text08 = "Hoogtelijnen";
var text09 = "Lijn van Euler";
var text10 = "Cirkel van Feuerbach";

var author = "W. Fendt 1998";
var translator = "G. Koolstra 2004";
