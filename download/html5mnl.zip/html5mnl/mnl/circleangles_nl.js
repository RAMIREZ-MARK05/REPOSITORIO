// Winkel am Kreis, niederl�ndische Texte
// Letzte �nderung 24.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Grootte van de hoeken:";
var text02 = "Middelpuntshoek:";
var text03 = "Omtrekshoek:";
var text04 = "Hoek tussen koord en raaklijn:";

var author = "W. Fendt 1997";
var translator = "";
