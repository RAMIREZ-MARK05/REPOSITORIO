// Einfache geometrische Abbildungen, niederl�ndische Texte
// Letzte �nderung 23.02.2020

// Texte in HTML-Schreibweise:

var text02 = "Nieuwe schets";
var text04 = "Toevoegen";
var text05 = "Verwijderen";
var text06 = "Beeld";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text01 = ["lijnspiegeling", "puntspiegeling", "translatie", "rotatie"];
var text03 = ["punt", "rechte", "halfrechte", "lijnstuk", "cirkel", "driehoek", "vierhoek"];

