// Platonische K�rper, niederl�ndische Texte (PeterJaap de Bruin)
// Letzte �nderung 25.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Tetra&euml;der";
var text02 = "Hexa&euml;der";
var text03 = "Octa&euml;der";
var text04 = "Dodeca&euml;der";
var text05 = "Icosa&euml;der";
var text06 = "Rotatie veranderen";
var text07 = "Omgeschreven bol";
var text08 = "Bol rakend aan de ribben";
var text09 = "Ingeschreven bol";

var author = "W. Fendt 1998,&nbsp; P.J. de Bruin 2003";
