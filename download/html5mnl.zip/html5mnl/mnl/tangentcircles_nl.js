// Ber�hrkreise, niederl�ndische Texte
// Letzte �nderung 24.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Gegeven:";
var text02 = "Twee punten";
var text03 = "Punt en lijn";
var text04 = "Punt en cirkel";
var text05 = "Twee lijnen";
var text06 = "Lijn en cirkel";
var text07 = "Twee cirkels";

var author = "W. Fendt 2017";

