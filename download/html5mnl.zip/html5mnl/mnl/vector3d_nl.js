// Komponenten eines Vektors, niederl�ndische Texte (PeterJaap de Bruin)
// Letzte �nderung 25.11.2017

// Texte in HTML-Schreibweise (eventuell mit '<sub>...</sub>' f�r Index):

var text01 = "Co&ouml;rdinaten:";
var text02 = "x =";
var text03 = "y =";
var text04 = "z =";

var author = "W. Fendt 1998";
var translator = "P.J. de Bruin 2003";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise (eventuell mit Index, zum Beispiel "x_1"):

var symbolX = "x";
var symbolY = "y";
var symbolZ = "z";
