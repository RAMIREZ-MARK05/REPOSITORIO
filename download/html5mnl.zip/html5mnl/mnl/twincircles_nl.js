// Zwillingskreise des Archimedes, niederl�ndische Texte
// Letzte �nderung 24.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Hulplijnen:";
var text02 = "Links";
var text03 = "Rechts";

var author = "W. Fendt 2000";
