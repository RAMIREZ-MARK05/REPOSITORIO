// Primyphos, niederl�ndische Texte (DeepL, dict.cc)
// Letzte �nderung 24.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Verdeel in twee factoren:";

var author = "W. Fendt 1998";

var symbolMultiply = "&times;";

// Texte in Unicode-Schreibweise:

var text02 = ["Gefeliciteerd!", 
              "Dat was geweldig!", 
              "Uitstekend!", 
              "Niet slecht!", 
              "Een volwaardige prestatie!", 
              "Indrukwekkend!",
              "Fantastisch!"];
              
var text03 = ["Als u het spel opnieuw wilt starten:",
              "Een muisklik is genoeg!"];

var symbolMultiplyUnicode = "\u00D7";
