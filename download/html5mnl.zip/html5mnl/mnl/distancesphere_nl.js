// Abstand zweier Punkte auf einer Kugeloberfl�che, niederl�ndische Texte
// Letzte �nderung 16.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Radius:";
var text02 = "Punt A:";
var text03 = "Punt B:";
var text04 = "Afstand:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 2021";
var translator = "";

// Texte in Unicode-Schreibweise:

var text11 = ["lengte (O)", "lengte (W)"];
var text12 = ["breedte (N)", "breedte (Z)"];

var symbolA = "A";
var symbolB = "B";
var symbolN = "N";
var symbolS = "S";

var degree = "\u00B0"
var kilometer = "km";


