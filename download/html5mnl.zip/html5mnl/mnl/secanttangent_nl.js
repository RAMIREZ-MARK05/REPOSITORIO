// Sekanten- und Tangentensteigung, niederl�ndische Texte
// Letzte �nderung 25.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Gefixeerde punt:"; // ???
var text02 = "Variabele punt:"; // ???
var text03 = "Helling van de snijlijn:";
var text04 = "Helling van de raaklijn:";

var author = "W. Fendt 1998";
var translator = "";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var textUndefValue = "ongedef.";                           // Text f�r "nicht definiert"
