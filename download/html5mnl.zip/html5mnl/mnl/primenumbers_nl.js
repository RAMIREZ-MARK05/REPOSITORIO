// Primzahlentabelle, niederl�ndische Texte
// Letzte �nderung 23.02.2020

var textError = "Fout!";                                   // Text f�r Fehlermeldung
var textPrime = "is een priemgetal.";                      // Text f�r Primzahl
var symbolMult = "&times;";                                // Multiplikationszeichen (HTML)
