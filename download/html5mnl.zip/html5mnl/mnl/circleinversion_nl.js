// Kreisspiegelung, niederl�ndische Texte
// Letzte �nderung 23.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Nieuwe schets";
var text03 = "Toevoegen";
var text04 = "Verwijderen";
var text05 = "Beeld";

var author = "W. Fendt 2017";
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["punt", "rechte", "halfrechte", "lijnstuk", "cirkel", "driehoek", "vierhoek"];

