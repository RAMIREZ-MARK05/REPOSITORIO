// Elliptische Kurve, niederl�ndische Texte
// Letzte �nderung 06.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Co\u00EBffici\u00EBnt a:";
var text02 = "Co\u00EBffici\u00EBnt b:";

var author = "W. Fendt 2020";
var translator = "";

// Symbole:

var decimalSeparator = ",";
var symbolX = "x";
var symbolY = "y";
var symbolSummand1 = "P";
var symbolSummand2 = "Q";
var symbolSum = "P+Q";
