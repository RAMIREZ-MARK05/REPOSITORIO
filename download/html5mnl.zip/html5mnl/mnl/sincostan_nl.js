// Winkelfunktionen am Einheitskreis, niederl�ndische Texte
// Letzte �nderung 25.11.2017

// Texte in HTML-Schreibweise:

var text01 = "sinus";
var text02 = "cosinus";
var text03 = "tangens";

var author = "W. Fendt 1997";
var translator = "P.J. de Bruin 2003";

var decimalSeparator = ",";                      // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var symbolSine = "sin";                          // Symbol f�r Sinus
var symbolCosine = "cos";                        // Symbol f�r Cosinus
var symbolTangent = "tan";                       // Symbol f�r Tangens
var undef = "ongedefinieerd!";                   // F�r Definitionsl�cken der Tangensfunktion
