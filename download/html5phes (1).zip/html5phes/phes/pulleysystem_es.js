// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, spanische Texte (Juan Munoz)
// Letzte �nderung 12.12.2017

// Texte in HTML-Schreibweise:

var text01 = "2 Poleas";
var text02 = "4 Poleas";
var text03 = "6 Poleas";
var text04 = "Peso:";
var text05 = "Peso de la(s) Polea(s) Suelta(s):";
var text06 = "Fuerza Necesaria:";
var text07 = "Dinam&oacute;metro";
var text08 = "Vectores de Fuerza";

var author = "W. Fendt 1998";
var translator = "J. Mu&ntilde;oz 1999";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = "&divide;";                           // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                          // Abk�rzung f�r Newton
