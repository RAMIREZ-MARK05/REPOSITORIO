// Gleichgewicht dreier Kr�fte, spanische Texte (Jos� Miguel Zamarro)
// Letzte �nderung 12.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Fuerzas:";
var text02 = "Izquierda:";
var text03 = "Derecha:";
var text04 = "Abajo:";
var text05 = "Paralelogramo de fuerzas";
var text06 = "&Aacute;ngulos:";
var text07 = "Izquierda:";
var text08 = "Derecha:";

var author = "W. Fendt 2000";
var translator = "J. M. Zamarro 2001";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                                     // Symbol f�r Grad
var newton = "N";                                          // Abk�rzung f�r Newton
