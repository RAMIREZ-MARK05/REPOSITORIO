// Beispiel zum Doppler-Effekt, italienische Texte (Carlo Sansotta)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Ricomincia";
var text02 = ["Pausa", "Riprendi"]; 

var author = "W. Fendt 1998";
var translator = "C. Sansotta 1998";

// Texte in Unicode-Schreibweise:                  

var text03 = [ 
  ["Poich\u00E8 l'ambulanza (sorgente)",
   "si muove, man mano che si",
   "avvicina alla persona",
   "(osservatore) la distanza tra",
   "due fronti d'onda successivi",
   "\u00E8 pi\u00F9 breve davanti all'",
   "ambulanza. I fronti d'onda",
   "raggiungono l'osservatore",
   "con una frequenza maggiore",
   "rispetto alla sorgente."],
  ["Ora il veicolo si allontana",
   "dalla persona. I fronti d'onda",
   "raggiungono la persona in",
   "intervalli di tempo pi\u00F9 lunghi.",
   "I fronti d'onda raggiungono",
   "l'osservatore con una",
   "frequenza minore rispetto",
   "alla sorgente."]];
  

