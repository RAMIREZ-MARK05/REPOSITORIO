// Zweites Kepler-Gesetz, italienische Texte (Luciano Pirri)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "Semiasse maggiore:";
var text03 = "Eccentricit&agrave;:";
var text04 = ["Pausa", "Riprendi"];
var text05 = "Moto rallentato";
var text06 = ["Distanza", "dal Sole:"];
var text07 = "Velocit&agrave;";
var text08 = "istantanea:";
var text09 = "minima:";
var text10 = "massima:";
var text11 = "Settori";
var text12 = "Vettore velocit&agrave;";

var author = "W. Fendt 2000,&nbsp; L. Pirri 2001";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "UA";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Mercurio", "Venere", "Terra", "Marte", "Giove", "Saturno", "Urano", "Nettuno",
              "Plutone", "Cometa di Halley", ""];

// Symbole und Einheiten: 

var auUnicode = "UA";
var symbolPeriod = "T";

