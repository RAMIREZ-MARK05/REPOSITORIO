// Magnetfeld eines geraden stromdurchflossenen Leiters, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Cambia verso corrente";

var author = "W. Fendt 2000";
var translator = "";
