// Wheatstonesche Br�ckenschaltung, italienische Texte
// Letzte �nderung 11.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Nuova misurazione";
var text02 = "Resistenza di comparazione:";
var text03 = "Resistenza del reostato:";
var text04 = "Posizione del contatto strisciante:";
var text05 = "Generatore di tensione:"; 
var text06 = "Resistenza dell'amperometro:";
var text07 = "Calcolare la resistenza";
var text08 = "Indicare la tensione";
var text09 = "Indicare l'amperaggio";
var author = "W. Fendt 2006";

// Texte in Unicode-Schreibweise:

var text10 = ["Spostare il contatto strisciante finch\u00E9",
  	          "l'intensit\u00E0 della corrente \u00E8 pari a zero!"];
var text11 = "Ora \u00E8 possibile calcolare la resistenza.";       

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var milliampere = "mA";
var ohm = "\u03A9";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00D7";                              
