// Bilderzeugung Sammellinse, italienische Texte
// Letzte �nderung 12.03.2020

// Texte in HTML-Schreibweise:
    
var text01 = "Distanza focale:";
var text02 = "Distanza dell'oggetto:";
var text03 = "Altezza dell'oggetto:";
var text04 = "Distanza dell'immagine:";
var text05 = "Altezza dell'immagine:";    
var text06 = "Tipo dell'immagine:";
var text07 = ["reale", "virtuale"];
var text08 = ["capovolta", "diritta"];
var text09 = ["rimpicciolita", "della stessa dimensione", "ingrandita", "infinitamente ingrandita"];
var text10 = "Raggi principali";
var text11 = "Fascio di raggi";
var text12 = "Evidenziare:";

var author = "W. Fendt 2008";

// Symbole und Einheiten:

var centimeter = "cm";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text13 = ["oggetto", 
              "distanza dell'oggetto", 
              "altezza dell'oggetto",
              "lente", 
              "piano lente",
              "asse ottico",
              "fuochi",
              "distanza focale", 
              "immagine", 
              "distanza dell'immagine", 
              "altezza dell'immagine",
              "schermo"];
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "o";
var symbolGG = "O"; 
var symbolB = "i";
var symbolBB = "I";


