// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, italienische Texte (Luciano Pirri)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "2 pulegge";
var text02 = "4 pulegge";
var text03 = "6 pulegge";
var text04 = "Peso:";
var text05 = "Peso bozzello pulegge:";
var text06 = "Forza motrice:";
var text07 = "Dinamometro";
var text08 = "Vettori forza";

var author = "W. Fendt 1998";
var translator = "L. Pirri 2001";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                 
