// Elastischer und unelastischer Sto�, italienische Texte (Carlo Sansotta)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Urto elastico";
var text02 = "Urto anelastico";
var text03 = "Reset";
var text04 = "Avanti";
var text05 = "Moto rallentato";
var text06 = "Vagone 1:";
var text07 = "Vagone 2:";
var text08 = "Massa:";
var text09 = "Velocit&agrave;:";
var text10 = "Velocit&agrave;";
var text11 = "Momento";
var text12 = "Energia cinetica";

var author = "W. Fendt 1998,&nbsp; C. Sansotta 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                         

// Texte in Unicode-Schreibweise:

var text13 = "Vagone 1:";
var text14 = "Vagone 2:";
var text15 = "Velocit\u00E0 prima dell'urto:";
var text16 = "Velocit\u00E0 dopo l'urto:";
var text17 = "Momenti prima dell'urto:";
var text18 = "Momenti dopo l'urto:";
var text19 = "Energia cinetica prima dell'urto:";
var text20 = "Energia cinetica dopo l'urto:";
var text21 = "Momento totale:";
var text22 = "Energia cinetica totale:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                  
var kilogramMeterPerSecond = "kg m/s";               
var joule = "J";                                           
