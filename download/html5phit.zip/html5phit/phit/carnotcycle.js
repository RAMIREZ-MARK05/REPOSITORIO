// Carnot-Prozess
// 18.08.2023 - 31.08.2023

// ****************************************************************************
// * Autor: Walter Fendt (www.walter-fendt.de)                                *
// * Dieses Programm darf - auch in ver�nderter Form - f�r nicht-kommerzielle *
// * Zwecke verwendet und weitergegeben werden, solange dieser Hinweis nicht  *
// * entfernt wird.                                                           *
// **************************************************************************** 

// Sprachabh�ngige Texte sind in einer eigenen Datei (zum Beispiel carnotcycle_de.js) abgespeichert.

// Farben:

var colorBackground = "#ffff00";                           // Hintergrundfarbe
var colorPiston = "#0000ff";                               // Farbe f�r Kolben
var colorGas = "#00ff00";                                  // Farbe f�r Gas
var colorCylinder = "#ffc800";                             // Farbe f�r Zylinderwand
var colorWork = "#8080ff";                                 // Farbe f�r Arbeit
var colorHeat = "#ffa0a0";                                 // Farbe f�r W�rme
var colorPoint = "#ff00ff";                                // Farbe f�r Punkt in einem Diagramm

// Sonstige Konstanten:

var FONT = "normal normal bold 12px sans-serif";           // Zeichensatz
var R_MOL = 8.31446261815324;                              // Gaskonstante in J/(mol*K)
var FACTOR_ENERGY = 0.01;                                  // Faktor f�r Energie-Pfeile
var MIN_T = 100, MAX_T = 10*MIN_T;                         // Minimale und maximale Temperatur (Kelvin)
var MIN_V = 1, MAX_V = 10*MIN_V;                           // Minimales und maximales Volumen (Kubikdezimeter)

// Attribute:

var canvas, ctx;                                           // Zeichenfl�che, Grafikkontext
var width, height;                                         // Abmessungen der Zeichenfl�che (Pixel)
var ipN;                                                   // Eingabefeld Stoffmenge
var ipKappa;                                               // Eingabefeld Adiabatenexponent
var ipMinT, ipMaxT;                                        // Eingabefelder Temperatur
var ipMinV, ipMaxV;                                        // Eingabefelder Volumen
var ipMinP, ipMaxP;                                        // Ausgabefelder Druck
var bu1, bu2;                                              // Schaltkn�pfe
var rb1, rb2, rb3;                                         // Radiobuttons

var n;                                                     // Stoffmenge (0,1 bis 1 Mol)
var kappa;                                                 // Adiabatenexponent (1,3 bis 1,7)
var t1;                                                    // Starttemperatur (maximale Temperatur, 100 bis 1000 Kelvin)
var v1;                                                    // Startvolumen (minimales Volumen, 0,001 bis 0,01 Kubikmeter) 
var p1;                                                    // Startdruck (maximaler Druck, Pascal) 
var v2;                                                    // Volumen nach isothermer Expansion (Kubikmeter)
var p2;                                                    // Druck nach isothermer Expansion (Pascal)
var t3;                                                    // Temperatur nach adiabatischer Expansion (minimale Temperatur, 100 bis 1000 Kelvin)  
var v3;                                                    // Volumen nach adiabatischer Expansion (maximales Volumen, 0,001 bis 0,01 Kubikmeter)
var p3;                                                    // Druck nach adiabatischer Expansion (minimaler Druck, Pascal)
var v4;                                                    // Volumen nach isothermer Kompression (Kubikmeter)
var p4;                                                    // Druck nach isothermer Kompression (Pascal)                                                  
var w12, w23, w34, w41;                                    // Abgegebene Arbeit w�hrend eines Teilprozesses (Joule)
var w;                                                     // Abgegebene Arbeit w�hrend eines Kreisprozesses (Joule)
var vpt;                                                   // Aktueller Zustand (Verbund mit den Attributen v, p, t, sr)
var on;                                                    // Flag f�r Bewegung
var time0;                                                 // Bezugszeitpunkt
var t;                                                     // Zeitvariable (s)
var timer;                                                 // Timer f�r Animation

// Element der Schaltfl�che (aus HTML-Datei):
// id ..... ID im HTML-Befehl
// text ... Text (optional)

function getElement (id, text) {
  var e = document.getElementById(id);                     // Element
  if (text) e.innerHTML = text;                            // Text festlegen, falls definiert
  return e;                                                // R�ckgabewert
  } 

// Start:

function start () {
  canvas = getElement("cv");                               // Zeichenfl�che
  width = canvas.width; height = canvas.height;            // Abmessungen (Pixel)
  ctx = canvas.getContext("2d");                           // Grafikkontext  
  getElement("lb1",text01);                                // Erkl�render Text (Stoffmenge)
  ipN = getElement("ip1");                                 // Eingabefeld (Stoffmenge)
  focus(ipN);                                              // Fokus f�r erstes Eingabefeld
  getElement("u1",mol);                                    // Einheit (Stoffmenge)
  getElement("lb2",text02);                                // Erkl�render Text (Adiabatenexponent)
  ipKappa = getElement("ip2");                             // Eingabefeld (Adiabatenexponent)
  getElement("lb3",text03);                                // Erkl�render Text (minimale Temperatur)
  ipMinT = getElement("ip3");                              // Eingabefeld (minimale Temperatur)
  getElement("u3",kelvin);                                 // Einheit (minimale Temperatur)
  getElement("lb4",text04);                                // Erkl�render Text (maximale Temperatur)
  ipMaxT = getElement("ip4");                              // Eingabefeld (maximale Temperatur)
  getElement("u4",kelvin);                                 // Einheit (maximale Temperatur)
  getElement("lb5",text05);                                // Erkl�render Text (minimales Volumen)
  ipMinV = getElement("ip5");                              // Eingabefeld (minimales Volumen)
  getElement("u5",decimeter3);                             // Einheit (minimales Volumen)
  getElement("lb6",text06);                                // Erkl�render Text (maximales Volumen)
  ipMaxV = getElement("ip6");                              // Eingabefeld (maximales Volumen)
  getElement("u6",decimeter3);                             // Einheit (maximales Volumen)
  getElement("lb7",text07);                                // Erkl�render Text (minimaler Druck)
  ipMinP = getElement("ip7");                              // Eingabefeld (minimaler Druck)
  ipMinP.readOnly = true;                                  // Eingabefeld deaktiviert
  getElement("u7",kiloPascal);                             // Einheit (minimaler Druck)
  getElement("lb8",text08);                                // Erkl�render Text (maximaler Druck)
  ipMaxP = getElement("ip8");                              // Eingabefeld (maximaler Druck)
  ipMaxP.readOnly = true;                                  // Eingabefeld deaktiviert
  getElement("u8",kiloPascal);                             // Einheit (maximaler Druck)
  bu1 = getElement("bu1",text09);                          // Schaltknopf (Reset)
  bu2 = getElement("bu2",text10[0]);                       // Schaltknopf (Start/Pause/Weiter)
  bu2.state = 0;                                           // Zustand Schaltknopf
  rb1 = getElement("rb9");                                 // Radiobutton (Versuchsaufbau, kleine Diagramme)
  rb1.checked = true;                                      // Radiobutton zun�chst ausgew�hlt
  getElement("lb9",text11);                                // Zugeh�riger Text
  rb2 = getElement("rb10");                                // Radiobutton (gro�es p-V-Diagramm)
  getElement("lb10",text12);                               // Zugeh�riger Text
  rb3 = getElement("rb11");                                // Radiobutton (gro�es T-S-Diagramm)
  getElement("lb11",text13);                               // Zugeh�riger Text
  getElement("author",author);                             // Autor (und �bersetzer)
  
  n = 0.5;                                                 // Stoffmenge (Mol)
  kappa = 7/5;                                             // Adiabatenexponent (zweiatomige Molek�le, Idealfall)
  // Zustand 1 (Start): 500 Kelvin, 2 Kubikdezimeter
  // Zustand 3 (nach adiabatischer Expansion): 400 Kelvin, 8 Kubikdezimeter
  t1 = 500; v1 = 0.002;                                    // Startzustand (SI-Einheiten)
  t3 = 400; v3 = 0.008;                                    // Zustand nach adiabatischer Expansion (SI-Einheiten)
  calculation();                                           // Zeitunabh�ngige Berechnungen 
  updateInput();                                           // Eingabefelder aktualisieren (Defaultwerte)  
  on = false;                                              // Animation zun�chst abgeschaltet
  t = 0;                                                   // Startwert Zeitvariable
  paint();                                                 // Neu zeichnen
    
  ipN.onkeydown = reactionEnter;                           // Reaktion auf Enter-Taste (Eingabe Stoffmenge)
  ipKappa.onkeydown = reactionEnter;                       // Reaktion auf Enter-Taste (Eingabe Adiabatenexponent)
  ipMinT.onkeydown = reactionEnter;                        // Reaktion auf Enter-Taste (Eingabe minimale Temperatur)
  ipMaxT.onkeydown = reactionEnter;                        // Reaktion auf Enter-Taste (Eingabe maximale Temperatur)
  ipMinV.onkeydown = reactionEnter;                        // Reaktion auf Enter-Taste (Eingabe minimales Volumen)
  ipMaxV.onkeydown = reactionEnter;                        // Reaktion auf Enter-Taste (Eingabe maximales Volumen)
  ipN.onblur = reaction;                                   // Reaktion auf Verlust des Fokus (Eingabe Stoffmenge)
  ipKappa.onblur = reaction;                               // Reaktion auf Verlust des Fokus (Eingabe Adiabatenexponent)
  ipMinT.onblur = reaction;                                // Reaktion auf Verlust des Fokus (Eingabe minimale Temperatur)
  ipMaxT.onblur = reaction;                                // Reaktion auf Verlust des Fokus (Eingabe maximale Temperatur)
  ipMinV.onblur = reaction;                                // Reaktion auf Verlust des Fokus (Eingabe minimales Volumen)
  ipMaxV.onblur = reaction;                                // Reaktion auf Verlust des Fokus (Eingabe maximales Volumen)  
  bu1.onclick = reactionButton1;                           // Reaktion auf oberen Schaltknopf (Reset)
  bu2.onclick = reactionButton2;                           // Reaktion auf unteren Schaltknopf (Start/Pause/Weiter)
  rb9.onclick = paint;                                     // Reaktion auf ersten Radiobutton (Gesamtansicht)
  rb10.onclick = paint;                                    // Reaktion auf zweiten Radiobutton (gro�es p-V-Diagramm)
  rb11.onclick = paint;                                    // Reaktion auf dritten Radiobutton (gro�es T-S-Diagramm)
  
  } // Ende der Methode start 
  

   
// Hilfsroutine f�r Aktionen:
// Seiteneffekt n, kappa, t1, t3, v1, v3, p1, p3, v2, p2, v4, p4, w12, w23, w34, w41, w, t, time0, vpt
// Wirkung auf Ein- und Ausgabefelder

function reaction () {
  input();                                                 // Eingabe
  calculation();                                           // Zeitunabh�ngige Berechnungen
  updatePressure();                                        // Ausgabefelder f�r Druck aktualisieren
  if (!on) paint();                                        // Falls Animation abgeschaltet, neu zeichnen
  }
  
// Hilfsroutine: Aktivierung/Deaktivierung der Eingabefelder
// a ... Flag f�r Aktivierung

function enable (a) {
  ipN.readOnly = !a;                                       // Stoffmenge
  ipKappa.readOnly = !a;                                   // Adiabatenexponent
  ipMinT.readOnly = !a;                                    // Minimale Temperatur
  ipMaxT.readOnly = !a;                                    // Maximale Temperatur
  ipMinV.readOnly = !a;                                    // Minimales Volumen
  ipMaxV.readOnly = !a;                                    // Maximales Volumen
  }
       
// Reaktion auf oberen Schaltknopf (Reset):
// Seiteneffekt bu2, on, t, time0, n, kappa, t1, t3, v1, v3, p1, p3, v2, p2, v4, p4, w12, w23, w34, w41, w, vpt
   
function reactionButton1 () {
  bu2.state = 0;                                           // Schaltknopf Start/Pause/Weiter im Anfangszustand
  bu2.innerHTML = text10[0];                               // Zugeh�riger Schaltknopftext
  on = false;                                              // Animation abgeschaltet
  t = 0;                                                   // Zeitvariable zur�cksetzen
  time0 = new Date();                                      // Bezugszeitpunkt
  enable(true);                                            // Eingabefelder aktivieren
  reaction();                                              // Hilfsroutine aufrufen
  focus(ipN);                                              // Fokus f�r erstes Eingabefeld
  }
  
// Umschalten des unteren Schaltknopfs (Start/Pause/Weiter):
// Seiteneffekt bu2
  
function switchButton2 () {
  var st = bu2.state;                                      // Bisheriger Zustand des Schaltknopfs
  if (st == 0) {                                           // Falls bisher Anfangszustand ...
    st = 1;                                                // Neuer Zustand
    enable(false);                                         // Eingabefelder deaktivieren
    }
  else st = 3-st;                                          // Wechsel zwischen Animation und Unterbrechung
  bu2.state = st;                                          // Zustand des Schaltknopfs
  bu2.innerHTML = text10[st];                              // Zugeh�riger Schaltknopftext
  }
  
// Reaktion auf unteren Schaltknopf (Start/Pause/Weiter):
// Seiteneffekt on, timer, time0, n, kappa, t1, t3, v1, v3, p1, p3, v2, p2, v4, p4, w12, w23, w34, w41, w, t, vpt
  
function reactionButton2 () {
  switchButton2();                                         // Umschalten
  if (bu2.state == 1) startAnimation();                    // Entweder Animation starten bzw. fortsetzen ...
  else stopAnimation();                                    // ... oder stoppen
  reaction();                                              // Hilfsroutine aufrufen
  }
  
// Reaktion auf Enter-Taste:
// Seiteneffekt n, kappa, t1, t3, v1, v3, p1, p3, v2, p2, v4, p4, w12, w23, w34, w41, w, t, time0, vpt

function reactionEnter (e) {
  var enter = (e.key == "Enter" || e.code == "Enter");     // Flag f�r Enter-Taste
  if (enter) reaction();                                   // Falls Enter-Taste, Eingabe, Berechnungen, Ausgabe, neu zeichnen
  }
  
// Fokus f�r Eingabefeld, Cursor am Ende:
// ip ... Eingabefeld
  
function focus (ip) {
  ip.focus();                                              // Fokus f�r Eingabefeld
  var n = ip.value.length;                                 // L�nge der Zeichenkette
  ip.setSelectionRange(n,n);                               // Cursor setzen (am Ende)
  }
    
// Animation starten oder fortsetzen:
// Seiteneffekt on, timer, time0

function startAnimation () {
  on = true;                                               // Animation angeschaltet
  timer = setInterval(paint,40);                           // Timer mit Intervall 0,040 s aktivieren
  time0 = new Date();                                      // Neuer Bezugszeitpunkt 
  }
  
// Animation stoppen:
// Seiteneffekt on, timer

function stopAnimation () {
  on = false;                                              // Animation abgeschaltet
  clearInterval(timer);                                    // Timer deaktivieren
  }

//-------------------------------------------------------------------------------------------------
  
// Zeitunabh�ngige Berechnungen (auf Grundlage von n, kappa, t1, v1, t3, v3):
// Seiteneffekt p1, p3, v2, p2, v4, p4, w12, w23, w34, w41, w

function calculation () {
  p1 = n*R_MOL*t1/v1;                                      // Startdruck (maximaler Druck, Pascal)
  p3 = n*R_MOL*t3/v3;                                      // Druck nach adiabatischer Expansion (minimaler Druck, Pascal)
  var rad = p3*Math.pow(v3,kappa)/(p1*v1);                 // Radikand
  v2 = Math.pow(rad,1/(kappa-1));                          // Volumen nach isothermer Kompression (Kubikmeter)
  p2 = p1*v1/v2;                                           // Druck nach isothermer Kompression (Pascal)
  rad = p1*Math.pow(v1,kappa)/(p3*v3);                     // Radikand
  v4 = Math.pow(rad,1/(kappa-1));                          // Volumen nach isothermer Expansion (Kubikmeter)
  p4 = p3*v3/v4;                                           // Druck nach isothermer Expansion (Pascal)
  w12 = n*R_MOL*t1*Math.log(v2/v1);                        // Arbeit bei isothermer Expansion (positiv)
  w23 = n*R_MOL*(t1-t3)/(kappa-1);                         // Arbeit bei adiabatischer Expansion (positiv)
  w34 = n*R_MOL*t3*Math.log(v4/v3);                        // Arbeit bei isothermer Kompression (negativ)
  w41 = n*R_MOL*(t3-t1)/(kappa-1);                         // Arbeit bei adiabatischer Kompression (negativ)
  w = w12+w23+w34+w41;                                     // Arbeit w�hrend des gesamten Zyklus
  }
  
// Umwandlung einer Zahl in eine Zeichenkette:
// n ..... Gegebene Zahl
// d ..... Zahl der Stellen
// fix ... Flag f�r Nachkommastellen (im Gegensatz zu g�ltigen Ziffern)

function ToString (n, d, fix) {
  var s = (fix ? n.toFixed(d) : n.toPrecision(d));         // Zeichenkette mit Dezimalpunkt
  return s.replace(".",decimalSeparator);                  // Eventuell Punkt durch Komma ersetzen
  }
  
// Aktualisierung der Eingabefelder f�r die Temperatur (abh�ngig von t1 und t3):

function updateTemperature () {
  ipMinT.value = ToString(t3,1,true);                      // Eingabefeld f�r minimale Temperatur
  ipMaxT.value = ToString(t1,1,true);                      // Eingabefeld f�r maximale Temperatur
  }
  
// Aktualisierung der Eingabefelder f�r das Volumen (abh�ngig von v1 und v3):

function updateVolume () {
  ipMinV.value = ToString(1000*v1,3,true);                 // Eingabefeld f�r minimales Volumen
  ipMaxV.value = ToString(1000*v3,3,true);                 // Eingabefeld f�r maximales Volumen
  }
  
// Aktualisierung der Ausgabefelder f�r den Druck (abh�ngig von p1 und p3):

function updatePressure () {
  ipMinP.value = ToString(p3/1000,0,true);                 // Eingabefeld f�r minimalen Druck
  ipMaxP.value = ToString(p1/1000,0,true);                 // Eingabefeld f�r maximalen Druck
  }
  
// Aktualisierung der Ein- und Ausgabefelder:

function updateInput () {
  ipN.value = ToString(n,3,true);                          // Stoffmenge
  ipKappa.value = ToString(kappa,2,true);                  // Adiabatenexponent
  updateTemperature();                                     // Minimale und maximale Temperatur (Eingabefelder)
  updateVolume();                                          // Minimales und maximales Volumen (Eingabefelder)
  updatePressure();                                        // Minimaler und maximaler Druck (Ausgabefelder)
  }
  
// Eingabe einer Zahl
// ef .... Eingabefeld
// d ..... Zahl der Stellen
// fix ... Flag f�r Nachkommastellen (im Gegensatz zu g�ltigen Ziffern)
// min ... Minimum des erlaubten Bereichs
// max ... Maximum des erlaubten Bereichs
// R�ckgabewert: Zahl oder NaN
  
function inputNumber (ef, d, fix, min, max) {
  var s = ef.value;                                        // Zeichenkette im Eingabefeld
  s = s.replace(",",".");                                  // Eventuell Komma in Punkt umwandeln
  var n = Number(s);                                       // Umwandlung in Zahl, falls m�glich
  if (isNaN(n)) n = 0;                                     // Sinnlose Eingaben als 0 interpretieren 
  if (n < min) n = min;                                    // Falls Zahl zu klein, korrigieren
  if (n > max) n = max;                                    // Falls Zahl zu gro�, korrigieren
  ef.value = ToString(n,d,fix);                            // Eingabefeld eventuell korrigieren
  return n;                                                // R�ckgabewert
  }
  
// Hilfsroutine: Korrektur der Volumenwerte bei gegebenen Temperaturwerten
// Seiteneffekt v1, v3; eine �nderung erfolgt nur, falls sie unbedingt n�tig ist.

function corrVolume () {
  var min_qV = Math.max(Math.pow(t3/t1,1/(1-kappa)),1);    // Minimum f�r qV = v3/v1
  if (v3/v1 >= min_qV) return;                             // Falls Minimum nicht unterschritten, abbrechen
  alert(errorV);                                           // Fehlermeldung
  var qV = Math.sqrt(min_qV*10);                           // qV neu (geometrisches Mittel von min_qV und 10)
  var vm = MIN_V*0.001*Math.sqrt(10);                      // Geometrisches Mittel der Intervallgrenzen
  var sqrt = Math.sqrt(qV);                                // Wurzel aus qV als Hilfsgr��e
  v1 = vm/sqrt; v3 = vm*sqrt;                              // Neue Volumenwerte
  updateVolume();                                          // Eingabefelder aktualisieren
  }
  
// Gesamte Eingabe:
// Seiteneffekt n, kappa, t1, t3, v1, v3
// Wirkung auf Eingabefelder ipMinT, ipMaxT, ipMinV, ipMaxV
// Folgende Bedingungen sind zu ber�cksichtigen:
// 100 K <= t3 < t1 <= 1000 K
// 1 dm^3 <= v1 < v3 <= 10 dm^3
// qT^(1/(1-kappa)) < 10, wobei qT = t3/t1 < 1
// qV^(kappa-1) * qT > 1, wobei qT = t3/t1 < 1 und qV = v3/v1 > 1

function input () {
  var ae = document.activeElement;                         // Aktives Element
  n = inputNumber(ipN,3,true,0.1,1);                       // Stoffmenge (Mol)
  kappa = inputNumber(ipKappa,2,true,1.3,1.7);             // Adiabatenexponent
  t1 = inputNumber(ipMaxT,1,true,MIN_T,MAX_T);             // Maximale Temperatur (Zustand 1 und 2)
  t3 = inputNumber(ipMinT,1,true,MIN_T,MAX_T);             // Minimale Temperatur (Zustand 3 und 4)
  if (t3 > t1) {                                           // Falls Vertauschung bei der Temperatur n�tig ...
    var h = t1; t1 = t3; t3 = h;                           // Vertauschung durchf�hren 
    updateTemperature();                                   // Eingabefelder aktualisieren
    }
  var qT = t3/t1;                                          // Temperaturverh�ltnis (0,1 bis 1)
  var min_qT = Math.max(Math.pow(10,1-kappa),0.1);         // Minimum f�r qT
  if (ae == ipMinT || ae == ipMaxT) {                      // Falls Temperatureingabe ...
    if (qT < min_qT) {                                     // Falls Fehler bei der Temperatureingabe ...
      alert(errorT);                                       // Fehlermeldung
      qT = Math.sqrt(min_qT);                              // qT neu (geometrisches Mittel von min_qT und 1)
      if (ae == ipMinT) t3 = t1*qT;                        // Entweder t3 ...
      if (ae == ipMaxT) t1 = t3/qT;                        // ... oder t1 ab�ndern
      updateTemperature();                                 // Eingabefelder aktualisieren
      } // Ende if (qT)
    corrVolume();                                          // Falls n�tig, Volumenwerte korrigieren
    } // Ende if (ae)     
  v1 = inputNumber(ipMinV,3,true,MIN_V,MAX_V)/1000;        // Minimales Volumen (Zustand 1)
  v3 = inputNumber(ipMaxV,3,true,MIN_V,MAX_V)/1000;        // Maximales Volumen (Zustand 3)  
  if (v3 < v1) {                                           // Falls Vertauschung beim Volumen n�tig ...
    h = v1; v1 = v3; v3 = h;                               // Vertauschung durchf�hren
    updateVolume();                                        // Eingabefelder aktualisieren
    }
  corrVolume();                                            // Falls n�tig, Volumenwerte korrigieren    
  var qV = v3/v1;                                          // Volumenverh�ltnis (1 bis 10)
  var min_qV = Math.max(Math.pow(qT,1/(1-kappa)),1);       // Minimum f�r qV
  if (qV < min_qV && (ae == ipMinV || ae == ipMaxV)) {     // Falls Fehler bei der Volumeneingabe ...
    alert(errorV);                                         // Fehlermeldung
    var qV = Math.sqrt(min_qV*10);                         // qV neu (geometrisches Mittel von min_qV und 10)
    var vm = MIN_V*0.001*Math.sqrt(10);                    // Geometrisches Mittel der Intervallgrenzen
    var sqrt = Math.sqrt(qV);                              // Wurzel aus qV als Hilfsgr��e                                 
    if (ae == ipMinV) {                                    // Falls Fehler bei der Eingabe von v1 ...
      if (v3/qV >= 0.001) v1 = v3/qV;                      // Entweder nur v1 ...
      else {v1 = vm/sqrt; v3 = vm*sqrt;}                   // ... oder v1 und v3 ab�ndern
      }
    if (ae == ipMaxV) {                                    // Falls Fehler bei der Eingabe von v3 ...
      if (v1*qV <= 0.01) v3 = v1*qV;                       // Entweder nur v3 ...
      else {v1 = vm/sqrt; v3 = vm*sqrt;}                   // ... oder v1 und v3 ab�ndern
      }
    updateVolume();                                        // Eingabefelder aktualisieren
    } // Ende if (qV)
  if (ae == ipN) focus(ipKappa);                           // Fokus f�r n�chstes Eingabefeld
  if (ae == ipKappa) focus(ipMinT);                        // Fokus f�r n�chstes Eingabefeld
  if (ae == ipMinT) focus(ipMaxT);                         // Fokus f�r n�chstes Eingabefeld
  if (ae == ipMaxT) focus(ipMinV);                         // Fokus f�r n�chstes Eingabefeld
  if (ae == ipMinV) focus(ipMaxV);                         // Fokus f�r n�chstes Eingabefeld
  if (ae == ipMaxV) ipMaxV.blur();                         // Fokus abgeben
  }
  
// Zustand in Abh�ngigkeit von der Zeit:
// t ... Zeit (s)
// R�ckgabewert: Verbund mit den Attributen v (Volumen in Kubikmetern), p (Druck in Pascal), t (absolute Temperatur in Kelvin)
// und sr (relative Entropie, 0 bis 1)
// F�r die 1. und 3. Phase wird angenommen, dass die W�rmezufuhr bzw. W�rmeabgabe gleichm��ig erfolgt.
// F�r die 2. und 4. Phase wird angenommen, dass sich die Temperatur gleichm��ig �ndert.
  
function stateTime (t) {
  var d12 = n*R_MOL*t1;                                    // Nenner f�r 1. Phase
  var d34 = n*R_MOL*t3;                                    // Nenner f�r 3. Phase
  var exp = 1/(kappa-1);                                   // Exponent f�r 2. und 4. Phase
  t = t%20;                                                // Vielfaches von 20 s subtrahieren
  if (t <= 5) {                                            // Falls 1. Phase (5 s lang) ...
    var q = t*w12/5;                                       // Bisher zugef�hrte W�rme (Joule)
    var vol = v1*Math.exp(q/d12);                          // Volumen (Kubikmeter)
    var pr = p1*v1/vol;                                    // Druck (Pascal)
    var temp = t1;                                         // Temperatur (Kelvin)
    var sRel = t/5;                                        // Relative Entropie
    }
  else if (t <= 10) {                                      // Falls 2. Phase (5 s lang) ...
    temp = t1+(t-5)*(t3-t1)/5;                             // Temperatur (Kelvin)
    vol = v2*Math.pow(t1/temp,exp);                        // Volumen (Kubikmeter)
    pr = p2*v2*temp/(vol*t1);                              // Druck (Pascal)
    sRel = 1;                                              // Relative Entropie (maximal)
    }
  else if (t <= 15) {                                      // Falls 3. Phase (5 s lang) ...
    q = (t-10)*w34/5;                                      // Bisher zugef�hrte W�rme (Joule, negativ)
    vol = v3*Math.exp(q/d34);                              // Volumen (Kubikmeter)
    pr = p3*v3/vol;                                        // Druck (Pascal)
    temp = t3;                                             // Temperatur (Kelvin)
    sRel = (15-t)/5;                                       // Relative Entropie
    }
  else {                                                   // Falls 4. Phase (5 s lang) ...
    temp = t3+(t-15)*(t1-t3)/5;                            // Temperatur (Kelvin)
    vol = v4*Math.pow(t3/temp,exp);                        // Volumen (Kubikmeter)
    pr = p4*v4*temp/(vol*t3);                              // Druck (Pascal)
    sRel = 0;                                              // Relative Entropie (minimal)
    }
  return {v: vol, p: pr, t: temp, sr: sRel};               // Verbund als R�ckgabewert 
  }
  
// Nummer des aktuellen Teilprozesses:
// t ... Zeit (s)
// R�ckgabewert: 1 f�r isotherme Expansion, 2 f�r adiabatische Expansion, 3 f�r isotherme Kompression, 
// 4 f�r adiabatische Kompression, 0 f�r Startzustand und Wechsel zwischen Teilprozessen
  
function numberProcess (t) {
  t = t%20;                                                // Vielfaches von 20 s subtrahieren
  if (t%5 == 0) return 0;                                  // R�ckgabewert f�r Diagramm-Eckpunkt
  else if (t < 5) return 1;                                // R�ckgabewert f�r isotherme Expansion
  else if (t < 10) return 2;                               // R�ckgabewert f�r adiabatische Expansion
  else if (t < 15) return 3;                               // R�ckgabewert f�r isotherme Kompression
  else return 4;                                           // R�ckgabewert f�r adiabatische Kompression
  }
  
// Beschreibung der aktuellen Zustands�nderung:
// t ... Zeit (s)

function textProcess (t) {
  switch (numberProcess(t)) {                              // Je nach Nummer des Teilprozesses ...
    case 0: return (t == 0 ? text20 : "");                 // Startzustand bzw. Wechsel zwischen Teilprozessen
    case 1: return text21;                                 // Isotherme Expansion
    case 2: return text22;                                 // Isentrope Expansion
    case 3: return text23;                                 // Isotherme Kompression
    case 4: return text24;                                 // Isentrope Kompression
    }
  }
   
//-------------------------------------------------------------------------------------------------

// Neuer Grafikpfad mit Standardwerten:
// w ... Liniendicke (optional, Defaultwert 1)

function newPath (w) {
  ctx.beginPath();                                         // Neuer Grafikpfad
  ctx.strokeStyle = "#000000";                             // Linienfarbe schwarz
  ctx.lineWidth = (w ? w : 1);                             // Liniendicke
  }
  
// Linie zeichnen:
// x1, y1 ... Anfangspunkt
// x2, y2 ... Endpunkt
// w ........ Liniendicke (optional, Defaultwert 1)
// c ........ Farbe (optional, Defaultwert schwarz)

function line (x1, y1, x2, y2, w, c) {
  newPath(w);                                              // Neuer Grafikpfad (Standardwerte)
  if (c) ctx.strokeStyle = c;                              // Linienfarbe festlegen, falls angegeben
  ctx.moveTo(x1,y1); ctx.lineTo(x2,y2);                    // Linie vorbereiten
  ctx.stroke();                                            // Linie zeichnen
  }
  
// Rechteck mit schwarzem Rand:
// (x,y) ... Koordinaten der Ecke links oben (Pixel)
// w ....... Breite (Pixel)
// h ....... H�he (Pixel)
// c ....... F�llfarbe (optional, Defaultwert bisherige F�llfarbe)

function rectangle (x, y, w, h, c) {
  if (c) ctx.fillStyle = c;                                // F�llfarbe
  newPath();                                               // Neuer Grafikpfad
  ctx.fillRect(x,y,w,h);                                   // Rechteck ausf�llen
  ctx.strokeRect(x,y,w,h);                                 // Rand zeichnen
  }

// Kreisscheibe mit schwarzem Rand:
// (x,y) ... Mittelpunktskoordinaten (Pixel)
// r ....... Radius (Pixel)
// c ....... F�llfarbe (optional; falls undefiniert, keine F�llung)

function circle (x, y, r, c) {
  if (c) ctx.fillStyle = c;                                // F�llfarbe
  newPath();                                               // Neuer Grafikpfad
  ctx.arc(x,y,r,0,2*Math.PI,true);                         // Kreis vorbereiten
  if (c) ctx.fill();                                       // Kreis ausf�llen, falls gew�nscht
  ctx.stroke();                                            // Rand zeichnen
  }
  
// Pfeil zeichnen:
// x1, y1 ... Anfangspunkt
// x2, y2 ... Endpunkt
// w ........ Liniendicke (optional, Defaultwert 1)
// Zu beachten: Die Farbe wird durch ctx.strokeStyle bestimmt.

function arrow (x1, y1, x2, y2, w) {
  if (!w) w = 1;                                           // Falls Liniendicke nicht definiert, Defaultwert                          
  var dx = x2-x1, dy = y2-y1;                              // Vektorkoordinaten
  var length = Math.sqrt(dx*dx+dy*dy);                     // L�nge
  if (length == 0) return;                                 // Abbruch, falls L�nge 0
  dx /= length; dy /= length;                              // Einheitsvektor
  var s = 2.5*w+7.5;                                       // L�nge der Pfeilspitze 
  var xSp = x2-s*dx, ySp = y2-s*dy;                        // Hilfspunkt f�r Pfeilspitze         
  var h = 0.5*w+3.5;                                       // Halbe Breite der Pfeilspitze
  var xSp1 = xSp-h*dy, ySp1 = ySp+h*dx;                    // Ecke der Pfeilspitze
  var xSp2 = xSp+h*dy, ySp2 = ySp-h*dx;                    // Ecke der Pfeilspitze
  xSp = x2-0.6*s*dx; ySp = y2-0.6*s*dy;                    // Einspringende Ecke der Pfeilspitze
  ctx.beginPath();                                         // Neuer Pfad
  ctx.lineWidth = w;                                       // Liniendicke
  ctx.moveTo(x1,y1);                                       // Anfangspunkt
  if (length < 5) ctx.lineTo(x2,y2);                       // Falls kurzer Pfeil, weiter zum Endpunkt, ...
  else ctx.lineTo(xSp,ySp);                                // ... sonst weiter zur einspringenden Ecke
  ctx.stroke();                                            // Linie zeichnen
  if (length < 5) return;                                  // Falls kurzer Pfeil, keine Spitze
  ctx.beginPath();                                         // Neuer Pfad f�r Pfeilspitze
  ctx.fillStyle = ctx.strokeStyle;                         // F�llfarbe wie Linienfarbe
  ctx.moveTo(xSp,ySp);                                     // Anfangspunkt (einspringende Ecke)
  ctx.lineTo(xSp1,ySp1);                                   // Weiter zum Punkt auf einer Seite
  ctx.lineTo(x2,y2);                                       // Weiter zur Spitze
  ctx.lineTo(xSp2,ySp2);                                   // Weiter zum Punkt auf der anderen Seite
  ctx.closePath();                                         // Zur�ck zum Anfangspunkt
  ctx.fill();                                              // Pfeilspitze zeichnen 
  }
   
// Zylinder mit Kolben und Gasf�llung:
  
function cylinder () {
  var x0 = 170, y0 = 120;                                  // Bezugspunkt oben Mitte (Pixel)
  var d = 10;                                              // Wanddicke (Pixel)
  var r = 40;                                              // Radius innen (Pixel)
  var x1 = x0-r-d;                                         // Waagrechte Bildschirmkoordinate links au�en
  var x2 = x0-r;                                           // Waagrechte Bildschirmkoordinate links innen
  var x3 = x0+r;                                           // Waagrechte Bildschirmkoordinate rechts innen
  var x4 = x0+r+d;                                         // Waagrechte Bildschirmkoordinate rechts au�en
  var h = 90;                                              // H�he innen (Pixel)
  var y1 = y0+d;                                           // Senkrechte Bildschirmkoordinate oben innen
  var y2 = y0+d+h;                                         // Senkrechte Bildschirmkoordinate unten 
  newPath();                                               // Neuer Grafikpfad
  ctx.moveTo(x1,y0);                                       // Anfangspunkt links oben
  ctx.lineTo(x1,y2);                                       // Weiter nach unten
  ctx.lineTo(x2,y2);                                       // Weiter nach rechts
  ctx.lineTo(x2,y1);                                       // Weiter nach oben
  ctx.lineTo(x3,y1);                                       // Weiter nach rechts
  ctx.lineTo(x3,y2);                                       // Weiter nach unten
  ctx.lineTo(x4,y2);                                       // Weiter nach rechts
  ctx.lineTo(x4,y0);                                       // Weiter nach oben
  ctx.lineTo(x1,y0);                                       // Zur�ck nach links zum Anfangspunkt
  ctx.fillStyle = colorCylinder;                           // F�llfarbe
  ctx.fill(); ctx.stroke();                                // Gef�llte Fl�che und Rand f�r Zylinder  
  var pixV = h*1000/MAX_V;                                 // Umrechnungsfaktor (Pixel pro Kubikmeter)
  var dy = vpt.v*pixV;                                     // H�he Gasf�llung (Pixel)
  rectangle(x2,y1,2*r,dy,colorGas);                        // Gef�lltes Rechteck und Rand f�r Gas
  var y3 = y0+d+dy;                                        // Senkrechte Bildschirmkoordinate f�r Oberseite des Kolbens
  var y4 = y3+d;                                           // Senkrechte Bildschirmkoordinate f�r Unterseite des Kolbens
  var y5 = y4+30;                                          // Senkrechte Bildschirmkoordinate f�r Fortsatz
  var x5 = x0-5, x6 = x0+5;                                // Waagrechte Bildschirmkoordinaten f�r Fortsatz
  newPath();                                               // Neuer Grafikpfad f�r Kolben
  ctx.moveTo(x2,y3);                                       // Anfangspunkt links oben
  ctx.lineTo(x2,y4);                                       // Weiter nach unten
  ctx.lineTo(x5,y4);                                       // Weiter nach rechts
  ctx.lineTo(x5,y5);                                       // Weiter nach unten
  ctx.lineTo(x6,y5);                                       // Weiter nach rechts
  ctx.lineTo(x6,y4);                                       // Weiter nach oben
  ctx.lineTo(x3,y4);                                       // Weiter nach rechts
  ctx.lineTo(x3,y3);                                       // Weiter nach oben
  ctx.lineTo(x2,y3);                                       // Zur�ck nach links zum Anfangspunkt
  ctx.fillStyle = colorPiston;                             // F�llfarbe
  ctx.fill(); ctx.stroke();                                // Gef�llte Fl�che und Rand f�r Kolben
  }
  
// Druckmessger�t:

function manometer () {
  var x0 = 145, y0 = 95;                                   // Mittelpunkt (Pixel)
  var w0 = 1.25*Math.PI;                                   // Positionswinkel Nullmarkierung (Bogenma�)
  var pix1 = 1.5*Math.PI/10;                               // Winkelabstand der Ticks (Bogenma�)
  var max = 100;                                           // Maximum Druck (Pascal), Startwert
  var f = 5;                                               // Faktor f�r verl�ngerte Ticks, Startwert
  while (p1 > max) {                                       // Solange Messbereich zu klein ...
    max *= 2; f = 5; if (p1 <= max) break;                 // Gr��erer Messbereich
    max *= 2.5; f = 2; if (p1 <= max) break;               // Gr��erer Messbereich
    max *= 2; f = 5;                                       // Gr��erer Messbereich
    }
  // Skala bis 100 Pa, 200 Pa, 500 Pa, 1000 Pa usw.   
  circle(x0,y0,25,"#000000");                              // Au�enrand Skala
  circle(x0,y0,20,"#ffffff");                              // Innenrand Skala
  rectangle(x0-2,y0+25,4,10,"#000000");                    // Gaszuleitung
  for (var i=0; i<=10; i++) {                              // F�r alle Indizes ...
    var phi = w0-i*pix1;                                   // Positionswinkel (Bogenma�)
    var cos = Math.cos(phi), sin = Math.sin(phi);          // Trigonometrische Werte
    var r = (i%f == 0 ? 13 : 16);                          // Innenradius f�r Tick
    var x1 = x0+r*cos, y1 = y0-r*sin;                      // Anfangspunkt Tick (innen)
    var x2 = x0+20*cos, y2 = y0-20*sin;                    // Endpunkt Tick (au�en)
    line(x1,y1,x2,y2,2);                                   // Dicke Linie f�r Tick
    }  
  var pix2 = 1.5*Math.PI/max;                              // Umrechnungsfaktor (Radiant pro Pascal)
  var phi = w0-vpt.p*pix2;                                 // Positionswinkel Zeiger (Bogenma�)
  var x1 = x0+12*Math.cos(phi);                            // Waagrechte Bildschirmkoordinate Zeigerendpunkt (Pixel) 
  var y1 = y0-12*Math.sin(phi);                            // Senkrechte Bildschirmkoordinate Zeigerendpunkt (Pixel)
  line(x0,y0,x1,y1,2);                                     // Dicke Linie f�r Zeiger
  }

// Hilfsroutine f�r Thermometer: Schmales, senkrecht stehendes Rechteck mit abgerundeten Ecken
// x .... Waagrechte Koordinate (Pixel)
// y0 ... Senkrechte Koordinate des h�chsten Punkts (Pixel)
// y1 ... Senkrechte Koordinate des tiefsten Punkts (Pixel)
// c .... F�llfarbe

function roundRect (x, y0, y1, c) {
  newPath();                                               // Neuer Grafikpfad (Standardwerte)
  ctx.moveTo(x+2,y1-2);                                    // Anfangspunkt (rechts unten)
  ctx.lineTo(x+2,y0+2);                                    // Weiter nach oben
  ctx.arc(x,y0+2,2,0,Math.PI,true);                        // Oberer Halbkreisbogen
  ctx.lineTo(x-2,y1-2);                                    // Weiter nach unten
  ctx.arc(x,y1-2,2,Math.PI,2*Math.PI,true);                // Unterer Halbkreisbogen
  ctx.fillStyle = c;                                       // F�llfarbe
  ctx.fill(); ctx.stroke();                                // Gef�llte Fl�che und Rand
  }
  
// Thermometer:
  
function thermometer () {
  var x0 = 200, y0 = 120;                                  // Bezugspunkt auf der Oberseite des Zylinders (Pixel)
  var yNP = y0-10;                                         // Senkrechte Bildschirmkoordinate f�r absoluten Nullpunkt
  var pix = 6;                                             // Abstand benachbarter Ticks (Pixel)
  var max = 10*pix;                                        // Maximale H�he (Pixel)                                    
  var f = 2;                                               // Faktor f�r verl�ngerte Ticks, Startwert
  var pixT = 1.2;                                          // Umrechnungsfaktor (Pixel pro Kelvin), Startwert
  while (t1*pixT > max) {                                  // Solange Messbereich zu klein ...
    pixT /= 2; f = 5; if (t1*pixT <= max) break;           // Kleinerer Umrechnungsfaktor
    pixT /= 2; f = 5; if (t1*pixT <= max) break;           // Kleinerer Umrechnungsfaktor
    pixT /= 2.5; f = 2;                                    // Kleinerer Umrechnungsfaktor
    }
  // Skala bis 50 K, bis 100 K, bis 200 K, bis 500 K usw.
  rectangle(x0-20,y0-100,40,100,"#ffffff");                // Rechteck f�r Skala
  for (var i=0; i<=10; i++) {                              // F�r alle Indizes ...
    var y = yNP-i*pix;                                     // Senkrechte Koordinate (Pixel)
    var w = (i%f==0 ? 15 : 10);                            // Strichl�nge (Pixel)
    line(x0-w,y,x0-3,y);                                   // Strich links
    line(x0+3,y,x0+w,y);                                   // Strich rechts
    }
  roundRect(x0,y0-90,y0+15,"#ffffff");                     // Glasr�hrchen
  y = yNP-vpt.t*pixT;                                      // Oberes Ende der Fl�ssigkeitss�ule
  roundRect(x0,y,y0+15,"#808080");                         // Thermometerfl�ssigkeit   
  }
  
// Ausgabe des Volumens (Kubikdezimeter, 3 Nachkommastellen):
// v ....... Volumen (Kubikmeter)
// (x,y) ... Position (Pixel)
// sy ...... Symbol f�r Volumen (optional); falls definiert, Symbol und Gleichheitszeichen am Anfang
  
function writeVolume (v, x, y, sy) {
  var s = (sy ? sy+" = " : "");                            // Anfang der Zeichenkette
  s += ToString(1000*v,3,true)+" "+decimeter3;             // Zeichenkette erg�nzen
  ctx.fillText(s,x,y);                                     // Zeichenkette ausgeben
  }

// Ausgabe des Drucks (Kilopascal, 0 Nachkommastellen):
// p ....... Druck (Pascal)
// (x,y) ... Position (Pixel)
// sy ...... Symbol f�r Druck (optional); falls definiert, Symbol und Gleichheitszeichen am Anfang
  
function writePressure (p, x, y, sy) {
  var s = (sy ? sy+" = " : "");                            // Anfang der Zeichenkette
  s += ToString(p/1000,0,true)+" "+kiloPascal;             // Zeichenkette erg�nzen
  ctx.fillText(s,x,y);                                     // Zeichenkette ausgeben
  }

// Ausgabe der Temperatur (Kelvin, 1 Nachkommastelle):
// t ....... Temperatur (Kelvin)
// (x,y) ... Position (Pixel)
// Symbol f�r Temperatur (optional); falls definiert, Symbol und Gleichheitszeichen am Anfang
  
function writeTemperature (t, x, y, sy) {
  var s = (sy ? sy+" = " : "");                            // Anfang der Zeichenkette
  s += ToString(t,1,true)+" "+kelvin;                      // Zeichenkette erg�nzen
  ctx.fillText(s,x,y);                                     // Zeichenkette ausgeben
  }

// Ausgabe der Energie (Joule, 1 Nachkommastelle):
// e ....... Energie (Joule)
// (x,y) ... Position (Pixel)
// sy ...... Symbol f�r Energie (optional); falls definiert, Symbol und Gleichheitszeichen am Anfang
  
function writeEnergy (e, x, y, sy) {
  var s = (sy ? sy+" = " : "");                            // Anfang der Zeichenkette
  s += ToString(e,1,true)+" "+joule;                       // Zeichenkette erg�nzen
  ctx.fillText(s,x,y);                                     // Zeichenkette ausgeben
  }

// Ausgabe der Entropie (Joule/Kelvin, 2 Nachkommastellen):
// e ....... Entropie (Joule/Kelvin)
// (x,y) ... Position (Pixel)
// sy ...... Symbol f�r Entropie (optional); falls definiert, Symbol und Gleichheitszeichen am Anfang
  
function writeEntropy (e, x, y, sy) {
  var s = (sy ? sy+" = " : "");                            // Anfang der Zeichenkette
  s += ToString(e,2,true)+" "+joulePerKelvin;              // Zeichenkette erg�nzen
  ctx.fillText(s,x,y);                                     // Zeichenkette ausgeben
  }
  
// Pfeil f�r Arbeit (senkrecht nach unten oder oben), mit Beschriftung:
// w ... Abgegebene Arbeit (mit Vorzeichen, Joule)

function polygonWork (w) {
  if (w == 0) return;                                      // Falls Arbeit gleich 0, abbrechen
  var x0 = 170, y0 = 280;                                  // Bezugspunkt (Pixel)
  var sign = 1;                                            // Vorzeichenfaktor (+1 f�r abgegebene Arbeit) 
  if (w < 0) {sign = -1; w = -w;}                          // Korrektur, falls Arbeit zugef�hrt
  var h = w*FACTOR_ENERGY;                                 // Halbe Breite des Pfeils (Pixel) 
  if (h > 40) h = 40;                                      // Zu breiten Pfeil verhindern
  var xL = x0-h, xR = x0+h, xLL = xL-20, xRR = xR+20;      // Waagrechte Bildschirmkoordinaten (Pixel)
  var y1 = y0-sign*30, y2 = y0+sign*10, y3 = y0+sign*30;   // Senkrechte Bildschirmkoordinaten (Pixel)
  newPath();                                               // Neuer Grafikpfad
  ctx.moveTo(x0,y3);                                       // Pfeilspitze als Anfangspunkt
  ctx.lineTo(xLL,y2);                                      // Schr�g nach links au�en
  ctx.lineTo(xL,y2);                                       // Waagrecht nach rechts
  ctx.lineTo(xL,y1);                                       // Senkrecht von der Pfeilspitze weg
  ctx.lineTo(xR,y1);                                       // Waagrecht nach rechts
  ctx.lineTo(xR,y2);                                       // Senkrecht in Richtung Pfeilspitze
  ctx.lineTo(xRR,y2);                                      // Waagrecht nach rechts au�en
  ctx.lineTo(x0,y3);                                       // Schr�g zur�ck zur Pfeilspitze
  ctx.fillStyle = colorWork;                               // F�llfarbe
  ctx.fill(); ctx.stroke();                                // Gef�llte Fl�che und Rand
  ctx.fillStyle = "#000000";                               // Schriftfarbe
  ctx.textAlign = "left";                                  // Textausrichtung
  ctx.fillText(text25,x0+50,y0-16);                        // Erkl�render Text (Arbeit)
  writeEnergy(w*sign,x0+50,y0+4);                          // Abgegebene Arbeit (mit Vorzeichen)
  }

// Pfeil f�r W�rme (waagrecht nach rechts oder links), mit Beschriftung:
// q ... Zugef�hrte W�rme (mit Vorzeichen, Joule)
  
function polygonHeat (q) {
  if (q == 0) return;                                      // Falls W�rme gleich 0, abbrechen
  var x0 = 70, y0 = 140;                                   // Bezugspunkt (Pixel)
  var sign = 1;                                            // Vorzeichenfaktor (+1 f�r zugef�hrte W�rme)
  if (q < 0) {sign = -1; q = -q;}                          // Korrektur, falls W�rme abgegeben
  var h = q*FACTOR_ENERGY;                                 // Halbe Breite des Pfeils (Pixel)
  if (h > 40) h = 40;                                      // Zu breiten Pfeil verhindern
  var yT = y0-h, yB = y0+h, yTT = yT-20, yBB = yB+20;      // Senkrechte Bildschirmkoordinaten (Pixel)
  var x1 = x0-sign*30, x2 = x0+sign*10, x3 = x0+sign*30;   // Waagrechte Bildschirmkoordinaten (Pixel)
  newPath();                                               // Neuer Grafikpfad
  ctx.moveTo(x3,y0);                                       // Pfeilspitze als Anfangspunkt
  ctx.lineTo(x2,yTT);                                      // Schr�g nach ganz oben
  ctx.lineTo(x2,yT);                                       // Senkrecht nach unten
  ctx.lineTo(x1,yT);                                       // Waagrecht von der Pfeilspitze weg
  ctx.lineTo(x1,yB);                                       // Senkrecht nach unten
  ctx.lineTo(x2,yB);                                       // Waagrecht in Richtung Pfeilspitze
  ctx.lineTo(x2,yBB);                                      // Senkrecht nach ganz unten
  ctx.lineTo(x3,y0);                                       // Schr�g zur�ck zur Pfeilspitze
  ctx.fillStyle = colorHeat;                               // F�llfarbe
  ctx.fill(); ctx.stroke();                                // Gef�llte Fl�che und Rand
  ctx.fillStyle = "#000000";                               // Schriftfarbe
  ctx.textAlign = "left";                                  // Textausrichtung
  ctx.fillText(text26,x0-20,y0+h+35);                      // Erkl�render Text (W�rme)
  writeEnergy(q*sign,x0-20,y0+h+55);                       // Aufgenommene W�rme (mit Vorzeichen)
  }
  
// Pfeile f�r Energietransport:

function transportEnergy () {
  var x = 30, y = 355;                                     // Bildschirmkoordinaten f�r Kommentar
  switch (numberProcess(t)) {
    case 1:                                                // 1. Phase (isotherme Expansion)
      polygonWork(w12); polygonHeat(w12);                  // Pfeile f�r Arbeit und W�rme
      ctx.fillText(text28,x,y);                            // Kommentar (innere Energie konstant)
      break;
    case 2:                                                // 2. Phase (adiabatische Expansion)
      polygonWork(w23);                                    // Pfeil f�r Arbeit
      ctx.fillText(text27,x,y);                            // Kommentar (innere Energie verkleinert sich)
      break;
    case 3:                                                // 3. Phase (isotherme Kompression)
      polygonWork(w34); polygonHeat(w34);                  // Pfeile f�r Arbeit und W�rme
      ctx.fillText(text28,x,y);                            // Kommentar (innere Energie konstant) 
      break;
    case 4:                                                // 4. Phase (adiabatische Kompression) 
      polygonWork(w41);                                    // Pfeil f�r Arbeit
      ctx.fillText(text29,x,y);                            // Kommentar (innere Energie vergr��ert sich)
      break;
    }
  }

// Hilfsroutine: Angaben zu einer Achse
// pix ...... Umrechnungsfaktor (Pixel pro SI-Einheit)
// minPix ... Minimaler Abstand benachbarter Ticks
// R�ckgabewert: Verbund mit den Attributen dTick (Abstand benachbarter Ticks in Pixeln) und fTick 
// (Faktor f�r die Beschriftung von Ticks)
  
function infoAxis (pix, minPix) {
  var d = 0.000001;                                        // Startwert f�r Abstand der Ticks (SI-Einheit)
  var f = 5;                                               // Startwert f�r Faktor
  while (pix*d < minPix) {                                 // Solange Abstand der Ticks zu klein ...
    d *= 2; if (pix*d >= minPix) break;                    // Abstand vergr��ern; falls gro� genug, while-Schleife verlassen
    d *= 2.5; f = 2; if (pix*d >= minPix) break;           // Abstand vergr��ern; falls gro� genug, while-Schleife verlassen
    d *= 2; f = 5;                                         // Abstand vergr��ern; falls gro� genug, while-Schleife verlassen 
    }
  return {dTick: d, fTick: f};                             // R�ckgabewert (Verbund)
  }
   
// Waagrechte Achse mit Zubeh�r:
// (u0,v0) ... Ursprung (Pixel)
// len ....... L�nge der Achse (Pixel, ab Ursprung)
// sy ........ Symbol der Gr��e
// pix ....... Umrechnungsfaktor (Pixel pro SI-Einheit)
// minPix .... Minimaler Abstand benachbarter Ticks (Pixel)
// b ......... Flag f�r Beschriftung von Ticks
// conv ...... Faktor f�r die Umrechnung der SI-Einheit in die verwendete Einheit
// n ......... Anzahl der Nachkommastellen (beschriftete Ticks)
// unit ...... Verwendete Einheit (muss nicht SI sein)

function horAxis (u0, v0, len, sy, pix, minPix, b, conv, n, unit) {
  arrow(u0-10,v0,u0+len,v0);                               // Achse zeichnen
  ctx.textAlign = "left";                                  // Textausrichtung
  ctx.fillText(sy,u0+len-8,v0+15);                         // Symbol f�r Gr��e
  var info = infoAxis(pix,minPix);                         // Daten zur Achse
  var dt = info.dTick;                                     // Abstand benachbarter Ticks (SI-Einheit)
  var f = info.fTick;                                      // Faktor f�r beschriftete Ticks
  var iMax = Math.floor(len/(dt*pix));                     // Maximaler Index
  ctx.textAlign = "center";                                // Textausrichtung
  for (var i=1; i<=iMax; i++) {                            // F�r alle Indizes ...
    var u = u0+i*dt*pix;                                   // Waagrechte Bildschirmkoordinate (Pixel)
    if (u > u0+len-20) break;                              // Falls zu weit rechts, abbrechen
    line(u,v0-3,u,v0+3);                                   // Tick zeichnen
    if (!b || i%f != 0) continue;                          // Falls keine Beschriftung, weiter zum n�chsten Index
    var s = ToString(conv*i*dt,n,true)+" "+unit;           // Zeichenkette f�r Beschriftung
    ctx.fillText(s,u,v0+15);                               // Beschriftung
    }
  }
  
// Senkrechte Achse mit Zubeh�r:
// (u0,v0) ... Ursprung (Pixel)
// len ....... L�nge der Achse (Pixel, ab Ursprung)
// sy ........ Symbol der Gr��e
// pix ....... Umrechnungsfaktor (Pixel pro SI-Einheit)
// minPix .... Minimaler Abstand benachbarter Ticks (Pixel)
// b ......... Flag f�r Beschriftung von Ticks
// conv ...... Faktor f�r die Umrechnung der SI-Einheit in die verwendete Einheit
// n ......... Anzahl der Nachkommastellen (beschriftete Ticks)
// unit ...... Verwendete Einheit (muss nicht SI sein)

function vertAxis (u0, v0, len, sy, pix, minPix, b, conv, n, unit) {
  arrow(u0,v0+10,u0,v0-len);                               // Achse zeichnen
  ctx.textAlign = "right";                                 // Textausrichtung
  ctx.fillText(sy,u0-5,v0-len+10);                         // Symbol f�r Gr��e
  var info = infoAxis(pix,minPix);                         // Daten zur Achse
  var dt = info.dTick;                                     // Abstand benachbarter Ticks (SI-Einheit)
  var f = info.fTick;                                      // Faktor f�r beschriftete Ticks                     
  var iMax = Math.floor(len/(dt*pix));                     // Maximaler Index
  for (var i=1; i<=iMax; i++) {                            // F�r alle Indizes ...
    var v = v0-i*dt*pix;                                   // Senkrechte Bildschirmkoordinate (Pixel)
    if (v < v0-len+20) break;                              // Falls zu weit oben, abbrechen
    line(u0-3,v,u0+3,v);                                   // Tick zeichnen
    if (!b || i%f != 0) continue;                          // Falls keine Beschriftung, weiter zum n�chsten Index
    var s = ToString(conv*i*dt,n,true)+" "+unit;           // Zeichenkette f�r Beschriftung
    ctx.fillText(s,u0-5,v+4);                              // Beschriftung
    }
  }
  
// Punkt im p-V-Diagramm f�r Zustand:
// (u0,v0) ... Ursprung (Pixel)
// pixV ...... Umrechnungsfaktor (Pixel pro Kubikmeter)
// pixP ...... Umrechnungsfaktor (Pixel pro Pascal)
// v ......... Volumen (Kubikmeter)
// p ......... Druck (Pascal)
// c ......... Farbe (optional, Defaultwert schwarz)
  
function pointVP (u0, v0, pixV, pixP, v, p, c) {
  c = (c ? c : "#000000");                                 // Farbe
  var x = u0+pixV*v, y = v0-pixP*p;                        // Bildschirmkoordinaten (Pixel)
  circle(x,y,2.5,c);                                       // Punkt zeichnen
  }
  
// Hinzuf�gen einer Isotherme zum Grafikpfad (p-V-Diagramm):
// Der aktuelle Punkt des Grafikpfads sollte schon gesetzt sein.
// (u0,v0) ... Bildschirmkoordinaten des Ursprungs (Pixel)
// vStart .... Startvolumen (Kubikmeter)
// pStart .... Startdruck (Pascal)
// vEnd ...... Endvolumen (Kubikmeter)
  
function addIsothermal (u0, v0, pixV, pixP, vStart, pStart, vEnd) {
  var n = 100;                                             // Zahl der Abschnitte
  var dx = (vEnd-vStart)/n;                                // Koordinatendifferenz f�r einen Abschnitt
  for (var i=1; i<=n; i++) {                               // F�r alle Indizes ...    
    var x = vStart+i*dx;                                   // Aktuelles Volumen (Kubikmeter)
    var y = pStart*vStart/x;                               // Aktueller Druck (Pascal)
    var vPix = u0+x*pixV;                                  // Waagrechte Bildschirmkoordinate (Pixel)    
    var pPix = v0-y*pixP;                                  // Senkrechte Bildschirmkoordinate (Pixel)
    ctx.lineTo(vPix,pPix);                                 // Strecke zum Polygonzug hinzuf�gen 
    }
  }
  
// Hinzuf�gen einer Isentrope zum Grafikpfad (p-V-Diagramm):
// Der aktuelle Punkt des Grafikpfads sollte schon gesetzt sein.
// (u0,v0) ... Bildschirmkoordinaten des Ursprungs (Pixel)
// vStart .... Startvolumen (Kubikmeter)
// pStart .... Startdruck (Pascal)
// pEnd ...... Enddruck (Pascal)
  
function addIsentropic (u0, v0, pixV, pixP, vStart, pStart, pEnd) {
  var n = 100;                                             // Zahl der Abschnitte
  var dy = (pEnd-pStart)/n;                                // Koordinatendifferenz f�r einen Abschnitt
  for (var i=1; i<=n; i++) {                               // F�r alle Indizes ...    
    var y = pStart+i*dy;                                   // Aktueller Druck (Pascal)
    var x = vStart*Math.pow(pStart/y,1/kappa);             // Aktuelles Volumen (Kubikmeter)
    var vPix = u0+x*pixV;                                  // Waagrechte Bildschirmkoordinate (Pixel)
    var pPix = v0-y*pixP;                                  // Senkrechte Bildschirmkoordinate (Pixel)
    ctx.lineTo(vPix,pPix);                                 // Strecke zum Polygonzug hinzuf�gen 
    }
  }

// p-V-Diagramm:
// big ... Flag f�r gro�es Diagramm
  
function diagramVP (big) {
  var u0 = (big?70:310), v0 = (big?360:120);               // Ursprung (Pixel) 
  var len1 = (big?390:150), len2 = (big?280:100);          // L�ngen der Achsen (Pixel)                         
  var sy1 = symbolV, sy2 = symbolP;                        // Symbole der Gr��en 
  var pix1 = (big?35000:12000), pix2 = (big?250/p1:80/p1); // Umrechnungsfaktoren (Pixel pro SI-Einheit) 
  var minPix = (big?20:10);                                // Minimaler Abstand benachbarter Ticks (Pixel) 
  var b = (big?true:false);                                // Flag f�r beschriftete Ticks 
  var unit1 = decimeter3, unit2 = kiloPascal;              // Einheiten
  var conv1 = 1000, conv2 = 0.001;                         // Faktoren f�r die Umrechnung in die verwendeten Einheiten
  horAxis(u0,v0,len1,sy1,pix1,minPix,b,conv1,0,unit1);     // Waagrechte Achse mit Zubeh�r
  vertAxis(u0,v0,len2,sy2,pix2,minPix,b,conv2,0,unit2);    // Senkrechte Achse mit Zubeh�r
  newPath();                                               // Neuer Grafikpfad
  ctx.moveTo(u0+pix1*v1,v0-pix2*p1);                       // Anfangspunkt (Startzustand)
  addIsothermal(u0,v0,pix1,pix2,v1,p1,v2);                 // Kurve f�r isotherme Expansion
  addIsentropic(u0,v0,pix1,pix2,v2,p2,p3);                 // Kurve f�r adiabatische Expansion
  addIsothermal(u0,v0,pix1,pix2,v3,p3,v4);                 // Kurve f�r isotherme Kompression
  addIsentropic(u0,v0,pix1,pix2,v4,p4,p1);                 // Kurve f�r adiabatische Kompression
  if (t >= 20) {                                           // Falls mindestens ein Zyklus durchlaufen ...
    ctx.fillStyle = colorWork;                             // F�llfarbe
    ctx.fill();                                            // Fl�che ausf�llen
    }
  ctx.stroke();                                            // Rand der Fl�che
  pointVP(u0,v0,pix1,pix2,v1,p1,"#000000");                // Punkt f�r Zustand 1 (Start)
  pointVP(u0,v0,pix1,pix2,v2,p2,"#000000");                // Punkt f�r Zustand 2
  pointVP(u0,v0,pix1,pix2,v3,p3,"#000000");                // Punkt f�r Zustand 3
  pointVP(u0,v0,pix1,pix2,v4,p4,"#000000");                // Punkt f�r Zustand 4
  pointVP(u0,v0,pix1,pix2,vpt.v,vpt.p,colorPoint);         // Punkt f�r aktuellen Zustand
  } 
  
// Punkt im T-S-Diagramm f�r Zustand:
// (u0,v0) ... Ursprung (Pixel)
// s1 ........ Kleinere Entropie (Pixel)
// s2 ........ Gr��ere Entropie (Pixel)
// pixT ...... Umrechnungsfaktor (Pixel pro Kelvin)
// s ......... Relative Entropie (0 bis 1)
// t ......... Temperatur (Kelvin)
// c ......... Farbe (optional, Defaultwert schwarz)
  
function pointST (u0, v0, s1, s2, pixT, s, t, c) {
  c = (c ? c : "#000000");                                 // F�llfarbe
  var u = u0+(1-s)*s1+s*s2, v = v0-pixT*t;                 // Bildschirmkoordinaten (Pixel)
  circle(u,v,2.5,c);                                       // Ausgef�llter Kreis mit Rand
  }

// T-S-Diagramm:
// big ... Flag f�r gro�es Diagramm
  
function diagramST (big) {
  var u0 = (big?70:310), v0 = (big?360:300);               // Ursprung (Pixel)
  var len1 = (big?390:150), len2 = (big?280:100);          // L�ngen der Achsen (Pixel)
  var sy1 = symbolS, sy2 = symbolT;                        // Symbole der Gr��en
  var s1 = (big?100:40), s2 = (big?300:100);               // Entropiewerte (Pixel)
  var pix2 = (big?200/t1:70/t1);                           // Umrechnungsfaktor (Pixel pro Kelvin)
  var minPix = (big?20:10);                                // Minimaler Abstand benachbarter Ticks (Pixel)
  var b = (big?true:false);                                // Flag f�r Beschriftung
  var unit2 = kelvin;                                      // Einheit T-Achse  
  arrow(u0-10,v0,u0+len1,v0);                              // Waagrechte Achse
  line(u0+s1,v0-3,u0+s1,v0+3);                             // Tick f�r niedrigere Entropie
  line(u0+s2,v0-3,u0+s2,v0+3);                             // Tick f�r h�here Entropie
  vertAxis(u0,v0,len2,sy2,pix2,minPix,b,1,0,unit2);        // Senkrechte Achse
  ctx.textAlign = "left";                                  // Textausrichtung
  ctx.fillText(sy1,u0+len1-8,v0+15);                       // Symbol f�r Entropie
  var u1 = u0+s1, u2 = u0+s2;                              // Waagrechte Bildschirmkoordinaten (Pixel)
  var v1 = v0-pix2*t3, v2 = v0-pix2*t1;                    // Senkrechte Bildschirmkoordinaten (Pixel)
  newPath();                                               // Neuer Grafikpfad
  ctx.moveTo(u1,v2);                                       // Startpunkt (links oben)
  ctx.lineTo(u2,v2);                                       // Waagrechte Linie nach rechts
  ctx.lineTo(u2,v1);                                       // Senkrechte Linie nach unten
  ctx.lineTo(u1,v1);                                       // Waagrechte Linie nach links
  ctx.lineTo(u1,v2);                                       // Senkrechte Linie nach oben (Startpunkt)
  if (t >= 20) {                                           // Falls mindestens ein Zyklus durchlaufen ...
    ctx.fillStyle = colorHeat;                             // F�llfarbe 
    ctx.fill();                                            // Rechteck ausf�llen
    }
  ctx.stroke();                                            // Rand des Rechtecks
  pointST(u0,v0,s1,s2,pix2,0,t1);                          // Punkt f�r Zustand 1 (Start)
  pointST(u0,v0,s1,s2,pix2,1,t1);                          // Punkt f�r Zustand 2
  pointST(u0,v0,s1,s2,pix2,1,t3);                          // Punkt f�r Zustand 3
  pointST(u0,v0,s1,s2,pix2,0,t3);                          // Punkt f�r Zustand 4
  pointST(u0,v0,s1,s2,pix2,vpt.sr,vpt.t,colorPoint);       // Punkt f�r aktuellen Zustand
  if (!b) return;                                          // Falls keine Beschriftung, abbrechen
  ctx.textAlign = "center";                                // Textausrichtung
  ctx.fillStyle = "#000000";                               // Schriftfarbe
  writeEntropy(w12/t1,u0+200,v0+15,symbolDeltaS);          // Angabe zum Entropieunterschied
  var w = ctx.measureText(symbolS).width;                  // Breite des Symbols f�r Entropie (Pixel)
  var u = u0+s1-w/2;                                       // Waagrechte Bildschirmkoordinate (Pixel)
  ctx.fillText(symbolS,u,v0+15);                           // Symbol f�r Entropie
  ctx.fillText("1",u+w,v0+20);                             // Index 1
  u = u0+s2-w/2;                                           // Waagrechte Bildschirmkoordinate (Pixel)
  ctx.fillText(symbolS,u,v0+15);                           // Symbol f�r Entropie
  ctx.fillText("2",u+w,v0+20);                             // Index 2
  }
   
// Grafikausgabe: Versuchsaufbau, kleine Diagramme
  
function paint1 () {
  cylinder();                                              // Gasgef�llter Zylinder mit Kolben
  manometer();                                             // Druckmessger�t
  thermometer();                                           // Thermometer
  transportEnergy();                                       // Pfeile f�r Energietransport
  diagramVP(false);                                        // Kleines p-V-Diagramm
  diagramST(false);                                        // Kleines T-S-Diagramm
  ctx.fillStyle = "#000000";                               // Schriftfarbe
  ctx.textAlign = "left";                                  // Textausrichtung
  ctx.fillText(textProcess(t),30,335);                     // Kommentar (Teilprozess)
  writeVolume(vpt.v,230,150);                              // Zahlenwert Volumen
  writePressure(vpt.p,110,60);                             // Zahlenwert Druck
  writeTemperature(vpt.t,230,80);                          // Zahlenwert Temperatur
  if (t < 20) return;                                      // Falls erster Zyklus noch nicht beendet, abbrechen
  ctx.fillText(text30,30,380);                             // Erkl�render Text (aufgenommene W�rme)                            
  writeEnergy(w12,350,380);                                // Zahlenwert (aufgenommene W�rme)       
  ctx.fillText(text31,30,400);                             // Erkl�render Text (abgegebene Arbeit)
  writeEnergy(w,350,400);                                  // Zahlenwert (abgegebene Arbeit)
  ctx.fillText(text32,30,420);                             // Erkl�render Text (Wirkungsgrad)
  ctx.fillText(ToString(w/w12,3,true),350,420);            // Zahlenwert (Wirkungsgrad)
  }
  
// Hilfsroutine: Angaben zum Teilprozess und zum aktuellen Zustand

function information () {
  ctx.fillStyle = "#000000";                               // Schriftfarbe
  ctx.textAlign = "left";                                  // Textausrichtung                                  
  ctx.fillText(textProcess(t),40,50);                      // Beschreibung Teilprozess
  writeVolume(vpt.v,350,50,symbolV);                       // Aktuelles Volumen ausgeben
  writePressure(vpt.p,350,70,symbolP);                     // Aktuellen Druck ausgeben
  writeTemperature(vpt.t,350,90,symbolT);                  // Aktuelle Temperatur ausgeben
  }
  
// Grafikausgabe: Gro�es p-V-Diagramm (mit Angabe der aktuellen Werte)
  
function paint2 () {
  diagramVP(true);                                         // Gro�es p-V-Diagramm
  information();                                           // Angaben zum Teilprozess und zum aktuellen Zustand
  }
  
// Grafikausgabe: Gro�es T-S-Diagramm (mit Angabe der aktuellen Werte)

function paint3 () {
  diagramST(true);                                         // Gro�es T-S-Diagramm
  information();                                           // Angaben zum Teilprozess und zum aktuellen Zustand
  }
             
// Grafikausgabe:
// Seiteneffekt t, time0, vpt
  
function paint () {
  ctx.fillStyle = colorBackground;                         // Hintergrundfarbe
  ctx.fillRect(0,0,width,height);                          // Hintergrund ausf�llen
  if (on) {                                                // Falls Animation l�uft ...
    var time1 = new Date();                                // Aktuelle Zeit
    t += (time1-time0)/1000;                               // Zeitvariable aktualisieren
    time0 = time1;                                         // Bezugszeitpunkt aktualisieren
    }    
  vpt = stateTime(t);                                      // Aktueller Zustand (Verbund mit den Attributen v, p, t, sr)    
  ctx.font = FONT;                                         // Zeichensatz
  if (rb1.checked) paint1();                               // Versuchsanordnung, kleine Diagramme                                    
  if (rb2.checked) paint2();                               // Gro�es p-V-Diagramm
  if (rb3.checked) paint3();                               // Gro�es T-S-Diagramm
  }
  
document.addEventListener("DOMContentLoaded",start,false); // Nach dem Laden der Seite Start-Methode aufrufen




