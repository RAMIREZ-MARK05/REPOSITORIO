// Interferenz von Licht am Doppelspalt, italienische Texte (WWW-Recherche)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Lunghezza d'onda:";
var text02 = "Distanza tra le fenditure:";
var text03 = "Angolo:";
var text04 = "Massimi:";
var text05 = "Minimi:";
var text06 = "Intensit&agrave; relativa:";
var text07 = "Figura di interferenza";
var text08 = "Distribuzione d'intensit&agrave;";

var author = "W. Fendt 2003";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
