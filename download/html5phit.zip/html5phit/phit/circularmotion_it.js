// Kreisbewegung mit konstanter Winkelgeschwindigkeit, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];
var text03 = "Moto rallentato";
var text04 = "Raggio:";
var text05 = "Per&igrave;odo:";
var text06 = "Massa:";
var text07 = "Posizione";
var text08 = "Velocit&agrave;";
var text09 = "Accelerazione";
var text10 = "Forza";

var author = "W. Fendt 2007";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                       
var second = "s";                                    
var kilogram = "kg";                                

// Texte in Unicode-Schreibweise:

var text11 = "Posizione:";
var text12 = "Velocit\u00E0:";
var text13 = "Velocit\u00E0 angolare:";
var text14 = "Accelerazione centripeta:";
var text15 = "Forza centripeta:";
var text16 = "(in s)";
var text17 = "(in m)";
var text18 = "(in m/s)";
var text19 = "(in m/s\u00b2)";
var text20 = "(in N)";
var text21 = "(direzione x)";
var text22 = "(direzione y)";
var text23 = "(modulo)";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03c9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "m";                      
var meterPerSecond = "m/s";                       
var meterPerSecond2 = "m/s\u00b2";                
var newton = "N";                                  
var radPerSecond = "rad/s";                      




