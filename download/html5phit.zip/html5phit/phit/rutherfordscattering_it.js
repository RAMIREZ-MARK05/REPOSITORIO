// Rutherford-Streuung, italienische Texte
// Letzte �nderung 01.11.2020

// Texte in HTML-Schreibweise:

var text01 = "Cancella le tracce"; // ???                    
var text02 = "Avanti";
var text03 = "Nucleo di deflessione:"; // ???
var text04 = "Numero atomico:";
var text05 = "Particella alfa:";
var text06 = "Velocit&agrave;:";
var text07 = "Parametro d'urto:";
var text08 = "Angolo di deflessione:";
var text09 = "Distanza minima:";
var text10 = "Asintoti, parametro d'urto";
var text11 = "Asintoti, angolo di deflessione";


var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var femtometer = "fm";
var kilometerPerSecond = "km/s";
var degree = "\u00B0";




