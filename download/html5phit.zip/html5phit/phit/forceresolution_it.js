// Zerlegung einer Kraft in zwei Komponenten, italienische Texte
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Modulo della";                       
var text02 = "forza:";
var text03 = "Misure degli angoli:";
var text04 = "1o angolo:";
var text05 = "2o angolo:";
var text06 = "Moduli delle componenti:";
var text07 = "1a componente:";
var text08 = "2a componente:";
var text09 = "Determina componenti";
var text10 = "Cancella costruzione";

var author = "W. Fendt 2003";
var translator = "";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var degree = "&deg;";                               
var newton = "N";                              

// Texte in Unicode-Schreibweise:

var text11 = "1a componente";                              // Text f�r erste Komponente
var text12 = "2a componente";                              // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                         