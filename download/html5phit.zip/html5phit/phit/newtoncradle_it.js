// Newtons Wiege, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Avanti";
var text03 = "Numero delle sfere:";

var author = "W. Fendt 1997";
var translator = "";
