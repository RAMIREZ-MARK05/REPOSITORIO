// Zerfallsreihen, italienische Texte
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Catena di decadimento:";
var text03 = "Prossimo decadimento";

var author = "W. Fendt 1998"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["Serie del Torio", "Serie del Nettunio", "Serie dell'Uranio", "Serie dell'Attinio"];          





