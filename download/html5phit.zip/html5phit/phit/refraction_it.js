// Reflexion und Brechung von Licht, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = "1o indice di rifrazione:";
var text02 = "2o indice di rifrazione:";
var text03 = "Angolo d'incidenza:";
var text04 = "Angolo di riflessione:";
var text05 = "Angolo di rifrazione:";    
var text06 = ["Angolo critico", "(riflessione interna totale):"];

var author = "W. Fendt 1997";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                             

// Texte in Unicode-Schreibweise:

var text07 = [["vuoto", "1"], ["aria", "1.0003"],          // Stoffe und Brechungsindizes
    ["acqua", "1.33"], ["etanolo", "1.36"],
    ["quarzo fuso", "1.46"], ["benzene", "1.49"], 
    ["vetro crown N-K5", "1.52"], ["sale", "1.54"], 
    ["vetro flint LF5", "1.58"], ["vetro crown N-SK4", "1.61"],
    ["vetro flint SF6", "1.81"], ["diamante", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                       
