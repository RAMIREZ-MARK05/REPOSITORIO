// Bohrsches Atommodell, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Modello corpuscolare";
var text02 = "Modello ondulatorio";
var text03 = "Numero quantico principale:";


var author = "W. Fendt 1999"; 
var translator = "";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



