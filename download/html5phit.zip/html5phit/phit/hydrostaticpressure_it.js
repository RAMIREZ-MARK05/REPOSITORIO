// Druckdose (hydrostatischer Druck), italienische Texte
// Letzte �nderung 03.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Liquido:";
var text03 = "Densit&agrave;:";
var text04 = "Profondit&agrave;:";
var text05 = "Pressione idrostatica:";

var author = "W. Fendt 1999";                              // Autor
var translator = "";                                       // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["sconosciuto", "acqua", "etanolo", "benzene", "tetracloruro di carbonio", "mercurio"]; 
