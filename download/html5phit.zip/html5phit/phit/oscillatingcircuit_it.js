// Elektromagnetischer Schwingkreis, italienische Texte (WWW-Recherche)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];
var text03 = "Moto rallentato (10 &times;)";
var text04 = "Moto rallentato (100 &times;)";
var text05 = "Capacit&agrave;:";
var text06 = "Induttanza:";
var text07 = "Resistenza:";
var text08 = "Tensione massima:";
var text09 = "Tensione, intensit&agrave;";
var text10 = "Energia";

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                            
var henry = "H";                            
var ohm = "&Omega;";                             
var volt = "V";                                  

// Texte in Unicode-Schreibweise:

var text11 = "Per\u00ECodo di oscillazione:";
var text12 = "Energia elettrica:";
var text13 = "Energia magnetica:";
var text14 = "Energia interna:";
var text15 = "Oscillazione non smorzata";
var text16 = "Oscillazione smorzata";
var text17 = "Smorzamento critico";
var text18 = "Sovrasmorzamento";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "V";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                  
var voltUnicode = "V";                              
var ampere = "A";                                  
var joule = "J";                                      
