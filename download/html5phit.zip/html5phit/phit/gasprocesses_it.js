// Spezielle Prozesse eines idealen Gases, italienische Texte
// Letzte �nderung 10.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Trasformazione isobara";
var text02 = "Trasformazione isocora";
var text03 = "Trasformazione isoterma";
var text04 = "Stato iniziale:";
var text05 = "Pressione:";
var text06 = "Volume:";
var text07 = "Temperatura:";
var text08 = "Stato finale:";
var text09 = "Stato iniziale";
var text10 = "Avanti";

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Lavoro";
var text12 = "Calore";
var text13 = "L'energia interna del gas";
var text14 = "aumenta.";
var text15 = "L'energia interna del gas";
var text16 = "rimane costante.";
var text17 = "L'energia interna del gas";
var text18 = "diminuisce.";
var text19 = "Pressione troppo piccola!";
var text20 = "Pressione troppo grande!";
var text21 = "Volume troppo piccolo!";
var text22 = "Volume troppo grande!";
var text23 = "Temperatura troppo piccola!";
var text24 = "Temperatura troppo grande!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


