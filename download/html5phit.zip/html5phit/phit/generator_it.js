// Generator, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Generatore c.a.";
var text02 = "Generatore c.c.";
var text03 = "Inverti il moto";
var text04 = ["Start", "Pausa", "Riprendi"];
var text05 = "Verso della rotazione";
var text06 = "Campo magnetico";
var text07 = "Corrente indotta";

var author = "W. Fendt 1998";  
var translator = "C. Sansotta 1998";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";                 

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "V";
var symbolResistor = "R";
