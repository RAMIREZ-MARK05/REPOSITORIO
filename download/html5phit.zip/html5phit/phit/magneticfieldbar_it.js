// Magnetfeld eines Stabmagneten, italienische Texte
// Letzte �nderung 06.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Cancellare le linee di campo";
var text02 = "Girare il magnete";

var author = "W. Fendt 2001";
var translator = "";
