// Ohmsches Gesetz, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Voltaggio massimo:";
var text02 = "Amperaggio massimo:";
var text03 = "Aumentare la resistenza";
var text04 = "Diminuire la resistenza";
var text05 = "Aumentare il voltaggio";
var text06 = "Diminuire il voltaggio";

var author = "W. Fendt 1997";
var translator = "";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Oltre il fondoscala!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
