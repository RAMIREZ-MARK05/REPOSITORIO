// Messung der Auftriebskraft, italienische Texte (Carlo Sansotta)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Area di base del corpo:"; 
var text02 = "Altezza del corpo:";
var text03 = "Densit&agrave; del corpo:";
var text04 = "Densit&agrave; del fluido:";   
var text05 = "Profondit&agrave;:";
var text06 = "Volume spostato:"; 
var text07 = "Spinta:";
var text08 = "Peso del corpo:";
var text09 = "Forza al dinamometro:";
var text10 = "Fondoscala:";

var author = "W. Fendt 1998,&nbsp; C. Sansotta 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Oltre il fondoscala!";
