// Beispiel zur Zeitdilatation, italienische Texte
// Letzte �nderung 11.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Diminuire la velocit&agrave;";
var text02 = "Aumentare la velocit&agrave;";
var text03 = "Reset";
var text04 = ["Avanti", "Pausa", "Riprendi"];

var author = "W. Fendt 1997";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "Distanza:";
var text06 = "5 ore luce";
var text07 = "Velocit\u00E0:";
var text08 = "Durata del volo (sistema Terra):";
var text09 = "ore";
var text10 = "Durata del volo (sistema astronave):";