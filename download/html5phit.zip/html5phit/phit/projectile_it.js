// Schiefer Wurf, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";                    
var text02 = ["Avanti", "Pausa", "Riprendi"];          
var text03 = "Moto rallentato";
var text04 = "Altezza iniziale:";
var text05 = "Velocit&agrave; iniziale:";
var text06 = "Angolo di lancio:";
var text07 = "Massa:"; 
var text08 = "Accelerazione gravitazionale:";
var text09 = "Posizione";
var text10 = "Velocit&agrave;";
var text11 = "Accelerazione";
var text12 = "Forza";
var text13 = "Energia";

var author = "W. Fendt 2000";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                  
var meterPerSecond = "m/s";                      
var meterPerSecond2 = "m/s&sup2;";                 
var kilogram = "kg";                             
var degree = "&deg;";                           

// Texte in Unicode-Schreibweise:

var text14 = "(in m)";                                     // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Posizione:";
var text16 = "(orizzontale)";
var text17 = "(verticale)";
var text18 = "Gittata:";
var text19 = "Altezza massima:";
var text20 = "Durata del volo:";
var text21 = "Componenti della velocit\u00E0:";
var text22 = "Modulo della velocit\u00E0:";
var text23 = "Angolo:";
var text24 = "Accelerazione:";
var text25 = "Forza:";
var text26 = "Energia cinetica:";
var text27 = "Energia potenziale:";
var text28 = "Energia totale:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                       
var secondUnicode = "s";                          
var meterPerSecondUnicode = "m/s";                   
var meterPerSecond2Unicode = "m/s\u00b2";             
var newtonUnicode = "N";                        
var jouleUnicode = "J";                           
var degreeUnicode = "\u00b0";                    



