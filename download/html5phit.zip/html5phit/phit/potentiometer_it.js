// Potentiometerschaltung, italienische Texte
// Letzte �nderung 11.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Generatore di tensione:";
var text02 = "Resistenza del reostato:";
var text03 = "Posizione del contatto strisciante:";
var text04 = "Resistenza del carico:";
var text05 = "Indicare la tensione";
var text06 = "Indicare l'amperaggio";
var author = "W. Fendt 2006";
var translator = "";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "V";                                  // Symbol f�r Spannung
var symbolVoltage2 = "c";                                  // Index f�r Verbraucher
                      
