// Gleichstrom-Elektromotor, italienische Texte (Carlo Sansotta)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];             
var text03 = "Cambia verso corrente";
var text04 = "Verso della corrente";
var text05 = "Campo magnetico";
var text06 = "Forza di Lorentz";

var author = "W. Fendt 1997";               
var translator = "C. Sansotta 1998";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";       
