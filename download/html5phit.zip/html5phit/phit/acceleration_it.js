// Bewegung mit konstanter Beschleunigung, italienische Texte
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];
var text03 = "Moto rallentato";
var text04 = "Posizione iniziale:";
var text05 = "Velocit&agrave; iniziale:";
var text06 = "Accelerazione:";
var text07 = "Vettore velocit&agrave;";
var text08 = "Vettore accelerazione";

var author = "W. Fendt 2000";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "(in s)";                                     // Einheitenangabe f�r Zeit-Achse
var text10 = "(in m)";                                     // Einheitenangabe f�r Weg-Achse
var text11 = "(in m/s)";                                   // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(in m/s\u00b2)";                             // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                   
var meter = "m";                                       
var meterPerSecond = "m/s";                        
var meterPerSecond2 = "m/s\u00b2";                  
