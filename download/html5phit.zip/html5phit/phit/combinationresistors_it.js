// Kombinationen von Widerst�nden, italienische Texte
// Letzte �nderung 06.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Tensione della batteria:"; 
var text03 = "Resistenza:";
var text04 = "Aggiungere resistore (in serie)"; 
var text05 = "Aggiungere resistore (in parallelo)"; 
var text06 = "Strumenti:";
var text07 = "Tensione elettrica";
var text08 = "Intensit&agrave; di corrente";

var author = "W. Fendt 2002";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "Tensione elettrica:";
var text10 = "Intensit\u00E0 di corrente:";
var text11 = "Resistenza:";
var text12 = "Resistenza totale:";
var text13 = "molto piccola";
var text14 = "molto grande";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

