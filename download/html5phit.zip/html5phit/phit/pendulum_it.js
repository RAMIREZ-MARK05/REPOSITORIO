// Fadenpendel, italienische Texte (Carlo Sansotta)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];
var text03 = "Moto rallentato";
var text04 = "Lunghezza:";
var text05x = "Accelerazione";
var text05 = "di gravit&agrave;:";
var text06 = "Massa:";
var text07 = "Ampiezza:";
var text08 = "Elongazione";
var text09 = "Velocit&agrave;";
var text10 = "Accelerazione";
var text11 = "Forza";
var text12 = "Energia";

var author = "W. Fendt 1998,&nbsp; C. Sansotta 1998";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var meter = "m";                            
var meterPerSecond2 = "m/s&sup2;";            
var kilogram = "kg";                         
var degree = "&deg;";                       

// Texte in Unicode-Schreibweise:

var text13 = "Massimo";
var text14 = "Elongazione";
var text15 = "Velocit\u00E0"; 
var text16 = "Accelerazione (componente tangenziale)";
var text17 = "Forza (componente tangenziale)";
var text18 = "Energia potenziale";
var text19 = "Energia cinetica";
var text20 = "Energia totale";
var text21 = "(in s)";
var text22 = "(in m)";
var text23 = "(in m/s)";
var text24 = "(in m/s\u00B2)";
var text25 = "(in N)";
var text26 = "(in J)";
var text27 = "Periodo";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolTangential = "tang";                             // Symbol f�r tangential
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                 
var meterUnicode = "m";                             
var meterPerSecond = "m/s";                           
var meterPerSecond2Unicode = "m/s\u00B2";               
var newton = "N";                                   
var joule = "J";                                    


