// Carnot-Prozess, italienische Texte
// Letzte �nderung 03.09.2023

// Texte in HTML-Schreibweise:

var text01 = "Quantit&agrave; di sostanza:";
var text02 = "Indice adiabatico:";
var text03 = "Temperatura minima:";
var text04 = "Temperatura massima:";
var text05 = "Volume minimo:";
var text06 = "Volume massimo:";
var text07 = "Pressione minima:";
var text08 = "Pressione massima:";
var text09 = "Reset";
var text10 = ["Avanti", "Pausa", "Riprendi"];
var text11 = "Configurazione sperimentale, diagrammi"; 
var text12 = "Diagramma p-V";
var text13 = "Diagramma T-S";
var author = "W. Fendt 2023";

// Texte in Unicode-Schreibweise:

var text20 = "Stato iniziale";
var text21 = "1. trasformazione: Espansione isoterma";
var text22 = "2. trasformazione: Espansione adiabatica";
var text23 = "3. trasformazione: Compressione isoterma";
var text24 = "4. trasformazione: Compressione adiabatica";
var text25 = "Lavoro";
var text26 = "Calore";
var text27 = "L'energia interna del gas diminuisce.";
var text28 = "L'energia interna del gas rimane costante.";
var text29 = "L'energia interna del gas aumenta.";
var text30 = "Calore assorbito (ciclo termodinamico):";
var text31 = "Lavoro prodotto (ciclo termodinamico):";
var text32 = "Rendimento:";

var errorT = "Valori di temperatura inadeguati modificati!";
var errorV = "Valori di volume inadeguati modificati!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolP = "p";                                         // Symbol f�r Druck
var symbolV = "V";                                         // Symbol f�r Volumen
var symbolT = "T";                                         // Symbol f�r absolute Temperatur
var symbolS = "S";                                         // Symbol f�r Entropie
var symbolDeltaS = "\u0394S";                              // Symbol f�r Entropieunterschied
var mol = "mol";             
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";
var joule = "J";
var joulePerKelvin = "J/K";


