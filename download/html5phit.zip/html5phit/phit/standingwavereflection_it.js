// Stehende Welle, Erkl�rung durch Reflexion, italienische Texte
// Letzte �nderung 06.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Riflessione";
var text02 = "da estremo fisso";
var text03 = "da estremo libero";
var text04 = "Reset";
var text05 = ["Avanti", "Pausa", "Riprendi"];
var text06 = "Moto rallentato";
var text07 = "Animazione";
var text08 = "Passi singoli";
var text09 = "Onda incidente";
var text10 = "Onda riflessa";
var text11 = "Onda risultante";

var author = "W. Fendt 2003"; 
var translator = "";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "N";
var symbolAntiNode = "V";

