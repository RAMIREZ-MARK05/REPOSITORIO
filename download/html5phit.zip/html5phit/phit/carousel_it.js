// Kettenkarussell, italienische Texte
// Letzte �nderung 05.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Giostra";
var text02 = "Giostra con forze";
var text03 = "Figura";
var text04 = "Valori numerici";
var text05 = ["Pausa", "Riprendi"];
var text06 = "Moto rallentato";
var text07 = "Periodo:";
var text08 = ["Distanza delle sospensioni", "dall'asse di rotazione:"];
var text09 = "Lunghezza dei fili:";
var text10 = "Massa:";

var author = "W. Fendt 1999";

// Texte in Unicode-Schreibweise:

var text11 = "Frequenza:";
var text12 = "Velocit\u00E0 angolare:";
var text13 = "Raggio:";
var text14 = "Velocit\u00E0:";
var text15 = "Angolo:";
var text16 = "Peso:";
var text17 = "Forza centripeta:";
var text18 = "Tensione del filo:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




