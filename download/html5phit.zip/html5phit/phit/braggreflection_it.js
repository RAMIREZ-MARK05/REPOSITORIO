// Schwebungen, italienische Texte
// Letzte �nderung 16.03.2021

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];
var text03 = "Moto rallentato";
var text04 = "Distanza tra i piani:";
var text05 = "Lunghezza d'onda:";
var text06 = "Angolo:";
var text07 = "Numero di piani:";
var text08 = "Differenza di cammino:";

var author = "W. Fendt 2021";
var translator = "";

// Text in Unicode-Schreibweise:

var text09 = "Condizione di Bragg soddisfatta!";

// Einheiten und Symbole:

var decimalSeparator = ",";
var picometer = "pm";
var degree = "\u00B0";
var symbolDeltaS = "\u0394s";
var symbolLambda = "\u03BB";