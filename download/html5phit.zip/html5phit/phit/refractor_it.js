// Kepler-Fernrohr, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Lunghezze focali:"; 
var text02 = "obiettivo:";
var text03 = "oculare:";
var text04 = "Angoli:";
var text05 = "Ingrandimento:";

var author = "W. Fendt 2000";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite
