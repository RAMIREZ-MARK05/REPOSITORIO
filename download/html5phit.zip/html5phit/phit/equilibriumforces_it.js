// Gleichgewicht dreier Kr�fte, italienische Texte
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Forze:";
var text02 = "a sinistra:";
var text03 = "a destra:";
var text04 = "centro:";
var text05 = "Parallelogramma delle forze";
var text06 = "Angoli:";
var text07 = "a sinistra:";
var text08 = "a destra:";

var author = "W. Fendt 2000";
var translator = "";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                               
var newton = "N";                                     
