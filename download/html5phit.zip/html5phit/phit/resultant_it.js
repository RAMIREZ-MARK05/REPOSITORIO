// Ersatzkraft mehrerer Kr�fte, italienische Texte
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Numero dei vettori:";
var text02 = "Costruzione del risultante";
var text03 = "Cancella risultante";

var author = "W. Fendt 1998";
var translator = "C. Sansotta 1998";
