// Resonanz, italienische Texte (Luciano Pirri)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];
var text03 = "Moto rallentato";
var text04 = "Risuonatore:";
var text05 = "Costante della molla:";
var text06 = "Massa:";
var text07 = "Smorzamento:";
var text08 = "Eccitatore:";
var text09 = "Frequenza angolare:";
var text10 = "Diagramma elongazione";
var text11 = "Diagramma ampiezza";
var text12 = "Diagramma differenza di fase";

var author = "W. Fendt 1998,&nbsp; L. Pirri 2001";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                              
var newtonPerMeter = "N/m";                            
var perSecond = "1/s";                             
var radPerSecond = "rad/s";                      

// Texte in Unicode-Schreibweise:

var text13 = "Disastro risonanza!";
var text14 = "(Simulazione non pi\u00F9 realistica!)";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz (omega)
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz (omega_0)
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                            
var radPerSecondUnicode = "rad/s";                  


