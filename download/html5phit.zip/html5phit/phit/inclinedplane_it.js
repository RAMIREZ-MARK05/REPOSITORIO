// Kr�fte an der schiefen Ebene, italienische Texte (Luciano Pirri)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];
var text03 = "Moto rallentato";
var text04 = "Dinamometro";
var text05 = "Vettori forza";
var text06 = "Angolo d'inclinazione:";
var text07 = "Peso:";
var text08 = "Componente parallela:";
var text09 = "Componente normale:";
var text10 = "Coefficiente di attrito:";
var text11 = "Forza di attrito:";
var text12 = "Forza motrice:";

var author = "W. Fendt 1999,&nbsp; L. Pirri 2001";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                           
var newton = "N";                                
