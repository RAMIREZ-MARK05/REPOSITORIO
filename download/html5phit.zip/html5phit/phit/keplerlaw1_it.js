// Erstes Kepler-Gesetz, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "Semiasse maggiore:";
var text03 = "Eccentricit&agrave;:";
var text04 = "Semiasse minore:";
var text05 = ["Pausa", "Riprendi"];
var text06 = "Moto rallentato";
var text07 = "Distanza dal Sole";
var text08 = "istantanea:";
var text09 = "minima:";
var text10 = "massima:";
var text11 = "Orbita ellittica";
var text12 = "Assi";
var text13 = "Linee congiungenti";

var author = "W. Fendt 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "UA";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Mercurio", "Venere", "Terra", "Marte", "Giove", "Saturno", "Urano", "Nettuno",
              "Plutone", "Cometa di Halley", ""];

var text14 = "Sole";
var text15 = "Pianeta";
var text16 = "Cometa";
var text17 = "Perielio";
var text18 = "Afelio";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "UA";

