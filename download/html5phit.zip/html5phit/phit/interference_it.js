// Interferenz zweier Kreis- oder Kugelwellen, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = ["Pausa", "Riprendi"];                        // Schaltknopf (Pause/Weiter)
var text02 = "Moto rallentato";
var text03 = "Distanza tra le";
var text04 = "sorgenti:";
var text05 = "Lunghezza d'onda:";

var author = "W. Fendt 1999";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                                     // Zentimeter

// Texte in Unicode-Schreibweise:

var text06 = "Differenza di cammino:";
var text07 = "Interferenza costruttiva (ampiezza massima)";
var text08 = "Interferenza distruttiva (ampiezza minima)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (Lambda)
