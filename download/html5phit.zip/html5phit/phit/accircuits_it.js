// Einfache Wechselstromkreise, italienische Texte
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Resistore";
var text02 = "Condensatore";
var text03 = "Bobina";
var text04 = "Reset";
var text05 = ["Avanti", "Pausa", "Riprendi"];          
var text06 = "Moto rallentato";
var text07 = "Frequenza:";
var text08 = "Voltaggio massimo:";
var text09 = "Resistenza:";                            
var text10 = "Capacit&agrave;:";                          
var text11 = "Induttanza:"; 
var text12 = "Amperaggio massimo:"; 

var author = "W. Fendt 1998";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                      
var volt = "V";                                       
var ampere = "A";                                  
var milliampere = "mA";                              
var microampere = "&mu;A";                          
var ohm = "&Omega;";                                
var microfarad = "&mu;F";                             
var henry = "H";                                   

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "V";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
