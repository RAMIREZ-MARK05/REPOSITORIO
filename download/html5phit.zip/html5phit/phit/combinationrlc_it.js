// Kombinationen von Widerst�nden, Spulen und Kondensatoren, italienische Texte
// Letzte �nderung 22.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Fonte di tensione alternata:";
var text02 = "Tensione:";
var text03 = "Frequenza:";
var text04 = "Componente:";
var text05 = ["resistore", "bobina", "condensatore"];
var text06 = ["Resistenza:", "Induttanza:", "Capacit&agrave;:"];
var text07 = "Sostituire";
var text08 = "Aggiungere (in serie)";
var text09 = "Aggiungere (in parallelo)";
var text10 = "Togliere";
var text11 = "Strumenti:";
var text12 = "Tensione elettrica";
var text13 = "Intensit&agrave; di corrente";

var author = "W. Fendt 2004";
var translator = "";

// Texte in Unicode-Schreibweise:

var text14 = "Tensione elettrica:";
var text15 = "Intensit\u00E0 di corrente:";
var text16 = "Impedanza:";
var text17 = "Impedanza (modulo):";
var text18 = "Angolo di fase:";
var text19 = "molto piccola";                              // Stromst�rke Voltmeter
var text20 = "molto piccola";                              // Spannung Amperemeter
var text21 = "molto piccola";                              // Impedanz/Widerstand Amperemeter
var text22 = "molto grande";                               // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)