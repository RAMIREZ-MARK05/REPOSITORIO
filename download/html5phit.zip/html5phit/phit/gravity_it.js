// Gravitation, italienische Texte
// Letzte �nderung 03.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Reset";                    
var text02 = ["Avanti", "Pausa", "Riprendi"];
var text03 = "Moto rallentato";
var text04 = "Distanza:";
var text05 = "Massa 1:";
var text06 = "Velocit&agrave; 1:";
var text07 = "Massa 2:";
var text08 = "Velocit&agrave; 2:";

var text09 = "Orbita circolare";
var text10 = "Traiettoria parabolica";

var author = "W. Fendt 2020";                              // Autor (und �bersetzer)

// Texte in Unicode-Schreibweise:

var textSelect = ["",
              "Parametri orbitali",
              "Posizione",
              "Distanza",
              "Velocit\u00E0",
              "Accelerazione",
              "Forza",
              "Energia",
              "Momento angolare",
              "Periodo orbitale"];
              
var text11 = "Tipo di orbita:";
var text12 = ["retta",
              "ellisse", 
              "circonferenza (ellisse)", 
              "ellisse", 
              "parabola", 
              "iperbole"];
var text13 = ["Semiassi maggiori:",
              "Raggi:",
              "Semiassi maggiori:",
              "Semilato retto:",
              "Semiassi trasversi:"];
var text14 = "Eccentricit\u00E0:";

var text21 = "Angoli di posizione:"; // ???
var text22 = "Coordinate:";

var text31 = "Distanza:";

var text41 = "Valori della velocit\u00E0:"; // ???
var text42 = "Componenti della velocit\u00E0:";

var text51 = "Valori dell'accelerazione:"; // ???
var text52 = "Componenti dell'accelerazione:";

var text61 = "Valori della forza:"; // ???
var text62 = "Componenti della forza:";

var text71 = "Energia totale:";
var text72 = "Energia potenziale:";
var text73 = "Energia cinetica:";

var text81 = "Momento angolare totale:";
var text82 = "Momenti angolari singoli:";

var text91 = "Periodo:";

var text101 = "Tempo:";
var text102 = "Minimo:";
var text103 = "Massimo:";
var text104 = "Minimi:";
var text105 = "Massimi:";

var undef = "non definito";
var inf = "infinito";
var body1 = "corpo 1";
var body2 = "corpo 2";

// Symbole und Einheiten (Unicode-Schreibweise):

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var power10 = "\u00B7 10";                                 // Mal 10 hoch
var kilogram = "kg";
var second = "s";
var minute = "min";
var hour = "h";
var day = "d";
var year = "a";
var meter = "m";
var meterPerSecond = "m/s";
var meterPerSecond2 = "m/s\u00B2";
var newton = "N";
var joule = "J";
var kilogramMeter2PerSecond = "kg m\u00B2 / s";
var degree = "\u00B0";

var symbolAE1 = "a_E1";                                    // Gro�e Halbachse (Ellipse) f�r K�rper 1
var symbolAE2 = "a_E2";                                    // Gro�e Halbachse (Ellipse) f�r K�rper 2
var symbolAH1 = "a_H1";                                    // Reelle Halbachse (Hyperbel) f�r K�rper 1
var symbolAH2 = "a_H2";                                    // Reelle Halbachse (Hyperbel) f�r K�rper 2
var symbolR1 = "r_1";                                      // Radius (Kreis) f�r K�rper 1
var symbolR2 = "r_2";                                      // Radius (Kreis) f�r K�rper 2
var symbolHP1 = "p_1";                                     // Halbparameter (Parabel) f�r K�rper 1
var symbolHP2 = "p_2";                                     // Halbparameter (Parabel) f�r K�rper 2
var symbolEpsilon = "\u03B5";                              // Numerische Exzentrizit�t
var symbolTime = "t";                                      // Aktuelle Zeit
var symbolPhi1 = "\u03C6_1";                               // Positionswinkel von K�rper 1
var symbolPhi2 = "\u03C6_2";                               // Positionswinkel von K�rper 2

var symbolX1 = "x_1";                                      // x-Koordinate von K�rper 1
var symbolY1 = "y_1";                                      // y-Koordinate von K�rper 1
var symbolX2 = "x_2";                                      // x-Koordinate von K�rper 2
var symbolY2 = "y_2";                                      // y-Koordinate von K�rper 2

var symbolD = "d";                                         // Abstand
var symbolDMin = "d_min";                                  // Minimaler Abstand
var symbolDMax = "d_max";                                  // Maximaler Abstand

var symbolV1 = "v_1";                                      // Geschwindigkeit von K�rper 1
var symbolV2 = "v_2";                                      // Geschwindigkeit von K�rper 2
var symbolV1Min = "v_1 min";                               // Minimale Geschwindigkeit von K�rper 1 
var symbolV2Min = "v_2 min";                               // Minimale Geschwindigkeit von K�rper 2
var symbolV1Max = "v_1 max";                               // Maximale Geschwindigkeit von K�rper 1
var symbolV2Max = "v_2 max";                               // Maximale Geschwindigkeit von K�rper 2
var symbolV1x = "v_1x";                                    // Geschwindigkeit von K�rper 1 in x-Richtung
var symbolV1y = "v_1y";                                    // Geschwindigkeit von K�rper 1 in y-Richtung
var symbolV2x = "v_2x";                                    // Geschwindigkeit von K�rper 2 in x-Richtung
var symbolV2y = "v_2y";                                    // Geschwindigkeit von K�rper 2 in y-Richtung

var symbolA1 = "a_1";                                      // Beschleunigung von K�rper 1
var symbolA2 = "a_2";                                      // Beschleunigung von K�rper 2
var symbolA1Min = "a_1 min";                               // Minimale Beschleunigung von K�rper 1
var symbolA2Min = "a_2 min";                               // Minimale Beschleunigung von K�rper 2 
var symbolA1Max = "a_1 max";                               // Maximale Beschleunigung von K�rper 1
var symbolA2Max = "a_2 max";                               // Maximale Beschleunigung von K�rper 1 
var symbolA1Tang = "a_1 tang";                             // Tangentiale Beschleunigung von K�rper 1
var symbolA1Rad = "a_1 rad";                               // Radiale Beschleunigung von K�rper 1
var symbolA2Tang = "a_2 tang";                             // Tangentiale Beschleunigung von K�rper 2
var symbolA2Rad = "a_2 rad";                               // Radiale Beschleunigung von K�rper 2

var symbolF1 = "F_1";                                      // Kraft auf K�rper 1
var symbolF2 = "F_2";                                      // Kraft auf K�rper 2
var symbolFMin = "F_min";                                  // Minimale Kraft
var symbolFMax = "F_max";                                  // Maximale Kraft
var symbolF1Tang = "F_1 tang";                             // Tangentiale Kraft auf K�rper 1
var symbolF1Rad = "F_1 rad";                               // Radiale Kraft auf K�rper 1
var symbolF2Tang = "F_2 tang";                             // Tangentiale Kraft auf K�rper 2
var symbolF2Rad = "F_2 rad";                               // Radiale Kraft auf K�rper 2

var symbolEnergy = "E";                                    // Gesamtenergie
var symbolEnergyPot = "E_pot";                             // Potentielle Energie
var symbolEnergy1Kin = "E_1 kin";                          // Kinetische Energie von K�rper 1
var symbolEnergy2Kin = "E_2 kin";                          // Kinetische Energie von K�rper 2

var symbolAngMom = "L";                                    // Gesamtdrehimpuls
var symbolAngMom1 = "L_1";                                 // Drehimpuls von K�rper 1
var symbolAngMom2 = "L_2";                                 // Drehimpuls von K�rper 2

var symbolPeriod = "T";                                    // Umlaufdauer






