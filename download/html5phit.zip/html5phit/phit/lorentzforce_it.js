// Leiterschaukel-Versuch zur Lorentzkraft, italienische Texte
// Letzte �nderung 06.03.2020

// Texte in HTML-Schreibweise:

var text01 = "On / Off";
var text02 = "Invertire la corrente";
var text03 = "Girare il magnete";
var text04 = "Direzione della corrente";
var text05 = "Campo magnetico";
var text06 = "Forza di Lorentz";

var author = "W. Fendt 1998";
var translator = "";
