// Loopingbahn, italienische Texte
// Letzte �nderung 09.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];
var text03 = "Moto rallentato (5 &times;)";
var text04 = "Moto rallentato (50 &times;)";
var text05 = "Raggio:";
var text06 = "Altezza iniziale:";
var text07 = "Accelerazione gravitazionale:";
var text08 = "Massa:";
var text09 = "Velocit&agrave;";
var text10 = "Forza peso, forza di contatto";
var text11 = "Forza tangenziale, forza centripeta";
var text12 = "Forza totale";

var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Texte in Unicode-Schreibweise:

var text13 = "Velocit\u00E0:";
var text14 = "Forza peso:";
var text15 = "Forza di contatto:";
var text16 = "Forza tangenziale:";
var text17 = "Forza centripeta:";
var text18 = "Forza totale:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var second = "s";                               
var meter = "m";                                 
var meterPerSecond = "m/s";                        
var meterPerSecond2 = "m/s\u00b2";         
var kilogram = "kg";
var newton = "N";    


