// Photoelektrischer Effekt, italienische Texte
// Letzte �nderung 13.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Materiale del catodo:";
var text02 = ["cesio", "sodio"];
var text03 = "Linea spettrale (Hg):";
var text04 = "Potenziale d'arresto:";
var text05 = "Frequenza:";
var text06 = ["Energia di un", "fotone:"];
var text07 = "Lavoro di estrazione:";
var text08 = ["Energia cinetica massima", "degli elettroni:"];
var text09 = "Cancellare le misurazioni";

var author = "W. Fendt 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                            // Volt
var terahertz = "THz";                                     // Terahertz
var electronvolt = "eV";                                   // Elektronenvolt

// Texte in Unicode-Schreibweise:

var text10 = ["giallo", "verde", "violetto", "ultravioletto", "ultravioletto"];
var text11 = "(in THz)";
var text12 = "(in V)";
var text13 = [
             ["L'energia di un fotone non \u00E8 sufficiente per", "l'emissione di un elettrone."],
             ["Aumentare il potenziale d'arresto finch\u00E9 non", "arrivano pi\u00F9 elettroni all'anodo."],
             ["Il potenziale d'arresto \u00E8 cos\u00EC alto,", "che gli elettroni ritornano al catodo."],
             ["Eseguire una misurazione con una linea spettrale", "diversa."],
             ["Eseguire una nuova serie di misurazioni", "con un diverso materiale del catodo."],
             ["Le misurazioni sono state completate."]
             ];

var symbolCathode = "C";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
