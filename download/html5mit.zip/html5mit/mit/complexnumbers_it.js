// Rechnen mit komplexen Zahlen, italienische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Operazione:";
var text02 = "addizione";
var text03 = "sottrazione";
var text04 = "moltiplicazione";
var text05 = "divisione";
var text06 = "Sistema di coordinate:";
var text07 = "coordinate cartesiane";
var text08 = "coordinate polari";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1998";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "non esiste!";

var symbolOperation = ["+", "\u2212", "\u00B7", ":"];      // Rechenzeichen
