// Abstand zweier Punkte auf einer Kugeloberfl�che, italienische Texte
// Letzte �nderung 16.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Raggio:";
var text02 = "Punto A:";
var text03 = "Punto B:";
var text04 = "Distanza:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 2021";
var translator = "";

// Texte in Unicode-Schreibweise:

var text11 = ["longitudine (E)", "longitudine (O)"];
var text12 = ["latitudine (N)", "latitudine (S)"];

var symbolA = "A";
var symbolB = "B";
var symbolN = "N";
var symbolS = "S";

var degree = "\u00B0"
var kilometer = "km";


