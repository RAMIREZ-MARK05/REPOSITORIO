// Winkel am Kreis, italienische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Ampiezza dell'angolo:";
var text02 = "Angolo al centro:";
var text03 = "Angolo alla circonferenza:";
var text04 = "Angolo tra tangente e secante:";

var author = "W. Fendt 1997";
var translator = "";
