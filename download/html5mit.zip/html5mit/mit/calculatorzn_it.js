// Rechnen mit Restklassen, italienische Texte
// Letzte �nderung 15.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Congruenza modulo";
var text02 = "Addizione";
var text03 = "Sottrazione";
var text04 = "Moltiplicazione";
var text05 = "Divisione";
var text06 = "Inverso additivo";
var text07 = "Inverso moltiplicativo";
var text11 = "1&ordm; addendo:";
var text12 = "2&ordm; addendo:";
var text13 = "Somma:";
var text21 = "Minuendo:";
var text22 = "Sottraendo:";
var text23 = "Differenza:";
var text31 = "1&ordm; fattore:";
var text32 = "2&ordm; fattore:";
var text33 = "Prodotto:";
var text41 = "Dividendo:";
var text42 = "Divisore:";
var text43 = "Quoziente:";
var text51 = "Elemento dato:";
var text52 = "Inverso additivo:";
var text61 = "Elemento dato:";
var text62 = "Inverso moltiplicativo:";
var undef = "non def.";

var author = "W. Fendt  2022";

// Texte in Unicode-Schreibweise:

var symbolAdd = "+";
var symbolSub = "\u2212";
var symbolMul = "\u00B7";
var symbolDiv = ":";
var symbolNeg = "\u2212x";



