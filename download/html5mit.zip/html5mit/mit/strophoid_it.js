// Gerade Strophoide, italienische Texte
// Letzte �nderung 09.11.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Avanti", "Pausa", "Riprendi"];  

var author = "W. Fendt 2020";    

                




