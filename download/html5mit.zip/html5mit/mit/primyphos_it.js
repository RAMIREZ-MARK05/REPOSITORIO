// Primyphos, italienische Texte
// Letzte �nderung 29.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Scrivi come prodotto:";

var author = "W. Fendt 1998";

var symbolMultiply = "&middot;";

// Texte in Unicode-Schreibweise:

var text02 = ["Congratulazioni!", 
              "\u00C8 stato grandioso!", 
              "Eccellente!", 
              "Non male!", 
              "Un grande risultato!", 
              "Impressionante!",
              "Fantastico!"];
              
var text03 = ["Se vuoi ricominciare il gioco:",
              "Basta un clic del mouse!"];

var symbolMultiplyUnicode = "\u00B7";
