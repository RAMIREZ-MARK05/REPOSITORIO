// Strahlensatz, italienische Texte
// Letzte �nderung 29.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Figura V";
var text02 = "Figura X";
var text03 = "Rapporto:";

var author = "W. Fendt 2000";
var translator = "";

// Symbole in Unicode-Schreibweise:

var symbolDivision = ":";

var symbolZ = "Z";
var symbolA1 = "A";
var symbolB1 = "B";
var symbolA2 = "A'";
var symbolB2 = "B'";



