// Besondere Linien und Kreise im Dreieck, italienische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Assi dei lati";
var text02 = "Circumcerchio";
var text03 = "Bisettrici";
var text04 = "Incerchio";
var text05 = "Excerchi";
var text06 = "Triangolo mediano";
var text07 = "Mediane";
var text08 = "Altezze";
var text09 = "Retta di Eulero";
var text10 = "Cerchio di Feuerbach";

var author = "W. Fendt 1998";
var translator = "";
