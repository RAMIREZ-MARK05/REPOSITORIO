// Primzahlentabelle, italienische Texte
// Letzte �nderung 23.01.2016

var textError = "Errore!";                                 // Text f�r Fehlermeldung
var textPrime = "&egrave; un numero primo.";               // Text f�r Primzahl
var symbolMult = "&times;";                                // Multiplikationszeichen (HTML)
