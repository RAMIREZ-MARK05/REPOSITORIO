// Regelm��ige Vielecke, italienische Texte
// Letzte �nderung 29.02.2020

// Texte in HTML-Schreibweise:

var text11 = "Numero di vertici:";
var text12 = "Circonferenza circoscritta";
var text13 = "Circonferenza inscritta";
var text14 = "Triangoli";
var text15 = "Diagonali";

var text21 = "Simbolo Schl&auml;fli:";

var author = "W. Fendt 2018";
var translator1 = "";
var translator2 = "";





