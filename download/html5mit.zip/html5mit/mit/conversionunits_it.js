// Umrechnung von Einheiten, italienische Texte
// Letzte �nderung 10.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Cominciare di nuovo";
var text02 = "Avanti";
var text03 = "Lunghezza";
var text04 = "Area";
var text05 = "Volume";
var text06 = "Massa";
var text07 = "Tempo";
var text08 = "Grado di difficolt&aacute;:";
var text09 = ["1 esempio", 
              "x esempi"];
var text10 = ["1 corretto", 
              "x corretti"];
     
var author = "W. Fendt 2001";                              // Autor (und �bersetzer)

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

