// Zwillingskreise des Archimedes, italienische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Linee ausiliarie:";
var text02 = "a sinistra";
var text03 = "a destra";

var author = "W. Fendt 2000";
