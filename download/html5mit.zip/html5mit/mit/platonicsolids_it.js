// Platonische K�rper, italienische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Tetraedro";
var text02 = "Esaedro (cubo)";
var text03 = "Ottaedro";
var text04 = "Dodecaedro";
var text05 = "Icosaedro";
var text06 = "Modificare l'asse di rotazione";
var text07 = "Sfera circoscritta";
var text08 = "Sfera tangente agli spigoli";
var text09 = "Sfera inscritta";

var author = "W. Fendt 1998";
