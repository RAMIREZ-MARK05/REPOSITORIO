// Tangenten von Funktionsgraphen, italienische Texte
// Letzte �nderung 28.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Equazione della funzione:";
var text02 = "f(x) =";
var text03 = "Bordo sinistro:";
var text04 = "Bordo destro:";
var text05 = "Bordo inferiore:";
var text06 = "Bordo superiore:";
var text07 = "Disegnare";

var author = "W. Fendt 2017";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text08 = "Equazione non corretta!";
var text09 = "Errore di differenziazione!";

var symbolX = "x";
var symbolY = "y";
