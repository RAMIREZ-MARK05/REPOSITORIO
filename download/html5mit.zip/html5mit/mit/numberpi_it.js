// Kreiszahl Pi, italienische Texte
// Letzte �nderung 03.02.2021

// Texte in HTML-Schreibweise:

var text01 = "Numero di vertici:";
var text02 = "Quadrato";
var text03 = "Esagono";
var text04 = "Raddoppiare il numero di vertici";
var text05 = "Lunghezza di un lato";
var text06 = "Perimetro";
var text07 = "Area";

var author = "W. Fendt 2002";
var translator = "";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";

var text11 = "Lunghezza di un lato (poligono inscritto):";
var text12 = "Lunghezza di un lato (poligono circoscritto):";
var text13 = "Perimetro (poligono inscritto):";
var text14 = "Perimetro (poligono circoscritto):";
var text15 = "Area (poligono inscritto):";
var text16 = "Area (poligono circoscritto):";



