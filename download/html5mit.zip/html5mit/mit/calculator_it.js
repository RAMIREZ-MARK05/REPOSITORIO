// Rechnen mit beliebiger Genauigkeit, italienische Texte
// Letzte �nderung 15.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Cancella";
var text02 = "Cancella tutto";
var text03 = "Frazione:";                                  // text04 siehe unten!
var text05 = "Numero decimale:";                           // text06 siehe unten!
var text07 = "Frazione algebraica:";                       // text08 siehe unten!
var text09 = "Potenza:";                                   // text10 siehe unten!
var author = "W. Fendt 2020";

// Texte in Unicode-Schreibweise:

var text04 = ["", "numeratore", "denominatore"];
var text06 = ["", "antiperiodo", "periodo"];
var text08 = ["", "nuova frazione", "modificare il numeratore", "modificare il denominatore", "terminare il denominatore"];
var text10 = ["", "nuovo esponente", "modificare l'esponente", "terminare l'esponente"];
var text11 = ["Risultato come frazione", "Risultato come numero misto", "Risultato come numero decimale"]; // ???

var text21 = "Stringa:";
var text22 = "Espressione:";
var text23 = "Tipo:";
var text24 = "Commento:";
var text25 = "Risultato:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMinus = "\u2212";                                // Minuszeichen
var symbolMult = "\u00B7";                                 // Multiplikationszeichen
var symbolDiv = ":";                                       // Divisionszeichen

// Termarten:

var empty = "Espressione vuota";
var natNum = "Numero naturale";
var fracNum = "Frazione o numero misto"; // ???
var decNum = "Numero decimale";
var plus = "Pi\u00F9 unitario"; // ???
var minus = "Meno unitario"; // ???
var brack = "Parentesi";
var perc = "Percentuale";
var sum = "Somma";
var diff = "Differenza";
var prod = "Prodotto";
var prod0 = "Prodotto senza simbolo di moltiplicazione";
var quot = "Quoziente";
var fracTerm = "Frazione algebraica";
var pow = "Potenza";

// Fehlermeldungen:

var syntaxOK = "Sintassi corretta!";
var leadingZero = "Zero iniziale!";
var missingSummand = "Manca il secondo addendo!";
var missingSubtrahend = "Manca il sottraendo!";
var missingFactor1 = "Manca il primo fattore!";
var missingFactor2 = "Manca il secondo fattore!";
var missingDividend = "Manca il dividendo!";
var missingDivisor = "Manca il divisore!";
var missingNumerator = "Manca il numeratore!";
var openNumerator = "Numeratore non completo!";
var missingDenominator = "Manca il denominatore!";
var openDenominator = "Denominatore non completo!";
var missingBase = "Manca la base!";
var missingExponent = "Manca l'esponente!";
var openExponent = "Esponente non completo!";
var openPlus = "Pi\u00F9 unitario non completo!"; // ???
var openMinus = "Meno unitario non completo!"; // ???
var openBracket = "Parentesi non chiuse!"; // ???
var emptyBracket = "Parentesi senza contenuto!";
var closingBracket = "Chiusura di parentesi inutile!";
var missingBracket = "Mancano le parentesi!";
var missingInteger = "Manca la parte intera!";
var missingFractionalPart = "Manca l'antiperiodo!";
var missingPeriod = "Manca il periodo!";

var runtimeOK = "Nessun errore di runtime!";
var divisionByZero = "Divisione per zero!";
var notIntegerExponent = "Esponente non intero!";
var tooBigExponent = "Esponente troppo grande!";

var unknownError = "Incomprensibile!";


