// 1. und 2. Ableitungsfunktion, italienische Texte
// Letzte �nderung 28.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Equazione della funzione:";
var text02 = "f(x) =";
var text03 = "Derivata prima";
var text04 = "Derivata seconda";
var text05 = "Bordo sinistro:";
var text06 = "Bordo destro:";
var text07 = "Bordo inferiore:";
var text08 = "Bordo superiore:";
var text09 = "Disegnare";

var author = "W. Fendt 1999";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text10 = "Equazione non corretta!";
var text11 = "Errore di differenziazione!";

var symbolX = "x";
var symbolY = "y";
