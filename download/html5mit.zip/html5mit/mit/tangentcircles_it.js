// Ber�hrkreise, italienische Texte
// Letzte �nderung 28.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Elementi dati:";
var text02 = "Due punti";
var text03 = "Punto e retta";
var text04 = "Punto e circonferenza";
var text05 = "Due rette";
var text06 = "Retta e circonferenza";
var text07 = "Due circonferenze";

var author = "W. Fendt 2017";

