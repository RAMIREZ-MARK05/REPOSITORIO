// Winkel an parallelen Geraden, italienische Texte (WWW-Recherche)
// Letzte �nderung 30.05.2018

// Texte in HTML-Schreibweise:

var text01 = "Angoli corrispondenti";
var text02 = "Angoli alterni";
var text03 = "Angoli coniugati interni";
var text05 = "Decimali:";
var text06 = "Ampiezze degli angoli:";

var author = "W. Fendt 2006";
var translator = "";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text04 = ["1a coppia di angoli", "2a coppia di angoli", "3a coppia di angoli", "4a coppia di angoli"];

var angle1 = ["\u03B1",                                    // Alpha 
              "\u03B2",                                    // Beta
              "\u03B3",                                    // Gamma
              "\u03B4"];                                   // Delta
              
var angle2 = ["\u03B1'",                                   // Alpha Strich 
              "\u03B2'",                                   // Beta Strich
              "\u03B3'",                                   // Gamma Strich
              "\u03B4'"];                                  // Delta Strich
              

