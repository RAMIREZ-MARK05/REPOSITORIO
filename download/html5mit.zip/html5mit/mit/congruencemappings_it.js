// Einfache geometrische Abbildungen, italienische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text02 = "Cominciare di nuovo";
var text04 = "Aggiungere";
var text05 = "Cancellare";
var text06 = "immagine";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text01 = ["riflessione rispetto ad un asse", "riflessione rispetto ad un punto", "traslazione", "rotazione"];
var text03 = ["punto", "retta", "semiretta", "segmento", "cerchio", "triangolo", "quadrilatero"];

