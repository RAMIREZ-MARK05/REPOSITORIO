// Kreisspiegelung, italienische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Cominciare di nuovo";
var text03 = "Aggiungere";
var text04 = "Cancellare";
var text05 = "immagine";

var author = "W. Fendt 2017";
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["punto", "retta", "semiretta", "segmento", "cerchio", "triangolo", "quadrilatero"];

