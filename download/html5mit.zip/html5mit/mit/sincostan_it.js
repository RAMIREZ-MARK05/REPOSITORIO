// Winkelfunktionen am Einheitskreis, italienische Texte
// Letzte �nderung 25.01.2016

// Texte in HTML-Schreibweise:

var text01 = "Seno";
var text02 = "Coseno";
var text03 = "Tangente";

var author = "W. Fendt 1997";
var translator = "";

var decimalSeparator = ",";                      // Dezimaltrennzeichen (Komma)

// Texte in Unicode-Schreibweise:

var symbolSine = "sin";                          // Symbol f�r Sinus
var symbolCosine = "cos";                        // Symbol f�r Cosinus
var symbolTangent = "tan";                       // Symbol f�r Tangens
var undef = "non esiste!";                       // F�r Definitionsl�cken der Tangensfunktion
