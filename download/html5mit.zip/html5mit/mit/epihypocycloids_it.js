// Epizykloiden und Hypozykloiden, italienische Texte
// Letzte �nderung 28.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Epicicloide";
var text02 = "Ipocicloide";
var text03 = "Rapporto dei raggi:";
var text04 = "Reset";
var text05 = ["Avanti", "Pausa", "Riprendi"];  

var author = "W. Fendt 2017";    

// Texte in Unicode-Schreibweise:

var text06 = "Caso particolare: Cardioide";  
var text07 = "Caso particolare: Nefroide";
var text08 = "Caso particolare: Diametro del cerchio";
var text09 = "Caso particolare: Deltoide";
var text10 = "Caso particolare: Astroide";                   




