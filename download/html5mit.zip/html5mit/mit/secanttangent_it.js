// Sekanten- und Tangentensteigung, italienische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Punto fissato:";
var text02 = "Punto variabile:";
var text03 = "Pendenza della retta secante:";
var text04 = "Pendenza della retta tangente:";

var author = "W. Fendt 1998";
var translator = "";

var decimalSeparator = ",";                      // Dezimaltrennzeichen (Komma oder Punkt)
var textUndefValue = "non esiste!";              // Text f�r "nicht definiert"
