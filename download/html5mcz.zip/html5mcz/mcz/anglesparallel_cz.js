// Winkel an parallelen Geraden, tschechische Texte (Miroslav Panos)
// Letzte �nderung 24.05.2018

// Texte in HTML-Schreibweise:

var text01 = "Souhlasn&eacute; &uacute;hly";
var text02 = "St&rcaron;&iacute;dav&eacute; &uacute;hly";
var text03 = "Vedlej&scaron;&iacute; &uacute;hly";
var text05 = "Desetinn&aacute; m&iacute;sta:";
var text06 = "Velikosti &uacute;hl&uring;:";

var author = "W. Fendt 2006";
var translator = "M. Pano&scaron; 2018";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text04 = ["1. dvojice \u00FAhl\u016F", "2. dvojice \u00FAhl\u016F", "3. dvojice \u00FAhl\u016F", "4. dvojice \u00FAhl\u016F"];

var angle1 = ["\u03B1",                                    // Alpha 
              "\u03B2",                                    // Beta
              "\u03B3",                                    // Gamma
              "\u03B4"];                                   // Delta
              
var angle2 = ["\u03B1'",                                   // Alpha Strich 
              "\u03B2'",                                   // Beta Strich
              "\u03B3'",                                   // Gamma Strich
              "\u03B4'"];                                  // Delta Strich
              

