// Sekanten- und Tangentensteigung, tschechische Texte
// Letzte �nderung 30.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Pevn&yacute; bod:";
var text02 = "Prom&ecaron;nn&yacute; bod:";
var text03 = "Sm&ecaron;rnice se&ccaron;ny:";
var text04 = "Sm&ecaron;rnice te&ccaron;ny:";

var author = "W. Fendt 1998";
var translator = "M. Pano&scaron; 2006";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var textUndefValue = "nedefinov&aacute;no!";               // Text f�r "nicht definiert"
