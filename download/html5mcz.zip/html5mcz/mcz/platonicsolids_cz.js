// Platonische K�rper, tschechische Texte
// Letzte �nderung 30.11.2017

// Texte in HTML-Schreibweise:

var text01 = "&Ccaron;ty&rcaron;st&ecaron;n";
var text02 = "&Scaron;estist&ecaron;n (Krychle)";
var text03 = "Osmist&ecaron;n";
var text04 = "Dvan&aacute;ctist&ecaron;n";
var text05 = "Dvacetist&ecaron;n";
var text06 = "Zm&ecaron;nit osu rotace";
var text07 = "Koule opsan&aacute;";
var text08 = "St&rcaron;edn&iacute; sf&eacute;ra";
var text09 = "Koule vepsan&aacute;";

var author = "W. Fendt 1998,&nbsp; M. Pano&scaron; 2006";
