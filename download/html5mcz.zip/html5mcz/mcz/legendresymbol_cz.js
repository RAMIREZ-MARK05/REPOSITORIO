// Online-Rechner Legendre-Symbol, tschechische Texte (Miroslav Panos)
// Letzte �nderung 24.07.2023

// Texte in HTML-Schreibweise:

var text01 = "1. &ccaron;&iacute;slo:";
var text02 = "2. &ccaron;&iacute;slo:";
var text03 = "OK";
var text04 = "Legendre\u016Fv symbol (Jacobiho symbol, Kronecker\u016Fv symbol):";
var text05 = "Jacobiho symbol (Kronecker\u016Fv symbol):";
var text06 = "Kronecker\u016Fv symbol:";

var author = "W. Fendt 2023";
var translator = "M. Pano&scaron; 2023";

// Texte in Unicode-Schreibweise:

var text11 = "#1 je kvadratick\u00FDm zbytkem modulo #2.";
var text12 = "#1 je kvadratick\u00FDm nezbytkem modulo #2.";
var text13 = "#1 a #2 jsou soud\u011Bln\u00E1 \u010D\u00EDsla.";
var text14 = "#1\u00B2 = #2 \u2261 #3 mod #4";
var text15 = "Neexistuje \u017E\u00E1dn\u00E9 cel\u00E9 \u010D\u00EDslo x, aby x\u00B2 \u2261 #1 mod #2."; 

var symbolGCD = "NSD";
var symbolMul = "\u00B7";
var symbolNeg = "\u2212";

var error = "Fehler";





