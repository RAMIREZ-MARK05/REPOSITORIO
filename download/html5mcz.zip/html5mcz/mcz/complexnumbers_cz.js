// Rechnen mit komplexen Zahlen, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 30.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Operace:";
var text02 = "S&ccaron;&iacute;t&aacute;n&iacute;";
var text03 = "Od&ccaron;&iacute;t&aacute;n&iacute;";
var text04 = "N&aacute;soben&iacute;";
var text05 = "D&ecaron;len&iacute;";
var text06 = "Syst&eacute;m sou&rcaron;adnic:";
var text07 = "Kart&eacute;zsk&yacute; syst&eacute;m";
var text08 = "Pol&aacute;rn&iacute; syst&eacute;m";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1998";
var translator = "M. Pano&scaron; 2006";

// Texte in Unicode-Schreibweise:

var text09 = "nedefinov\u00E1no!";

var symbolOperation = ["+", "\u2212", "\u00B7", ":"];      // Rechenzeichen
