// 15-Puzzle, tschechische Texte (Miroslav Panos)
// Letzte �nderung 22.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Uspo&rcaron;&aacute;dan&aacute; podoba";
var text02 = "N&aacute;hodn&aacute; podoba";
var text03 = "Po&ccaron;et tah&uring;:";
var text04 = ["Gratulujeme!", "Vy&rcaron;e&scaron;ili jste h&aacute;danku."];

var author = "W. Fendt 2023";
var translator = "M. Pano&scaron; 2023";



