// Strahlensatz, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 29.11.2017

// Texte in HTML-Schreibweise:

var text01 = "kladn\u00fd koeficient";
var text02 = "z\u00e1porn\u00fd koeficient";
var text03 = "koeficient stejnolehlosti:";

var author = "W. Fendt 2000";
var translator = "M. Pano&scaron; 2006";

// Symbole in Unicode-Schreibweise:

var symbolDivision = ":";

var symbolZ = "Z";
var symbolA1 = "A";
var symbolB1 = "B";
var symbolA2 = "A'";
var symbolB2 = "B'";



