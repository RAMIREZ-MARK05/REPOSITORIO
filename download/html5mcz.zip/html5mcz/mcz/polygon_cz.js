// Regelm��ige Vielecke, tschechische Texte (Miroslav Panos)
// Letzte �nderung 02.12.2022

// Texte in HTML-Schreibweise:

var text11 = "Po&ccaron;et vrchol&uring;:";
var text12 = "Kru&zcaron;nice opsan&aacute;";
var text13 = "Kru&zcaron;nice vepsan&aacute;";
var text14 = "Pravideln&eacute; troj&uacute;heln&iacute;ky";
var text15 = "&Uacute;hlop&rcaron;&iacute;&ccaron;ky";

var text21 = "Schl&auml;fliho symbol:";

var author = "W. Fendt 2018";
var translator = "M. Pano&scaron; 2018";
