// Apollonios-Problem CLP, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Zvolen\u00E9 \u0159e\u0161en\u00ED (\u010Derven\u00E9):";
var text02 = ["(Za\u0161krtnut\u00ED u kru\u017Enice znamen\u00E1", 
              "vn\u011Bj\u0161\u00ED dotyk, u p\u0159\u00EDmky ozna\u010Duje",
              "\u0159e\u0161en\u00ED v jedn\u00E9 polorovin\u011B.)"];
var text03 = ["\u0158e\u0161en\u00ED 1:",
              "\u0158e\u0161en\u00ED 2:",
              "\u0158e\u0161en\u00ED 3:",
              "\u0158e\u0161en\u00ED 4:"];   
var text04 = "Celkov\u00FD po\u010Det \u0159e\u0161en\u00ED:";  
         
var author = "W. Fendt 2008"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var nameCircle1 = "k";
var nameLine1 = "p";
var namePoint1 = "B";
