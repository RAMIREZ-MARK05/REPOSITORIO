// Elliptische Kurve, tschechische Texte
// Letzte �nderung 8.12.2020

// Texte in HTML-Schreibweise:

var text01 = "Koeficient a:";
var text02 = "Koeficient b:";

var author = "W. Fendt 2020";
var translator = "M. Pano&scaron; 2020";

// Symbole:

var decimalSeparator = ",";
var symbolX = "x";
var symbolY = "y";
var symbolSummand1 = "P";
var symbolSummand2 = "Q";
var symbolSum = "P+Q";
