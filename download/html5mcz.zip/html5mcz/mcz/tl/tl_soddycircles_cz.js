// Dreiecks-Labor, Soddy-Kreise, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 07.09.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2017"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC se svou",              // step = 0
               "kru\u017Enic\u00ED vepsanou."], 
              ["Vyzna\u010D\u00EDme body dotyku, kde se",         // step = 1
               "kru\u017Enice vepsan\u00E1 dot\u00FDk\u00E1 stran."],
              ["Vyzna\u010D\u00EDme body dotyku, kde se",         // step = 2
               "kru\u017Enice vepsan\u00E1 dot\u00FDk\u00E1 stran."],
              ["Vyzna\u010D\u00EDme body dotyku, kde se",         // step = 3
               "kru\u017Enice vepsan\u00E1 dot\u00FDk\u00E1 stran."],
              ["Nyn\u00ED kolem vrchol\u016F op\u00ED\u0161eme",           // step = 4
               "kru\u017Enice, kter\u00E9 proch\u00E1zej\u00ED",
               "sousedn\u00EDmi dotykov\u00FDmi body."],
              ["Nyn\u00ED kolem vrchol\u016F op\u00ED\u0161eme",           // step = 5
               "kru\u017Enice, kter\u00E9 proch\u00E1zej\u00ED",
               "sousedn\u00EDmi dotykov\u00FDmi body."],
              ["Nyn\u00ED kolem vrchol\u016F op\u00ED\u0161eme",           // step = 6
               "kru\u017Enice, kter\u00E9 proch\u00E1zej\u00ED",
               "sousedn\u00EDmi dotykov\u00FDmi body."],
              ["Tyto kru\u017Enice se navz\u00E1jem dot\u00FDkaj\u00ED."],      // step = 7
              ["Vnit\u0159n\u00ED Soddyho kru\u017Enice je kru\u017E-",           // step = 8
               "nice, kter\u00E1 se dot\u00FDk\u00E1 v\u0161ech t\u0159\u00ED",
               "kru\u017Enic kolem vrchol\u016F."],
              ["Tak\u00E9 existuje vn\u011Bj\u0161\u00ED Soddyho",          // step = 9
               "kru\u017Enice, kter\u00E1 m\u00E1 s trojic\u00ED kru\u017Enic",
               "kolem vrchol\u016F vn\u011Bj\u0161\u00ED dotyk."]];
