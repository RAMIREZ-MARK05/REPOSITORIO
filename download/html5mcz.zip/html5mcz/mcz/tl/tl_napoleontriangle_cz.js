// Dreiecks-Labor, Napoleon-Dreieck, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 28.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Nad stranami libovoln\u00E9ho",    // step = 0
               "troj\u00FAheln\u00EDku nar\u00FDsujeme t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nad stranami libovoln\u00E9ho",    // step = 1
               "troj\u00FAheln\u00EDku nar\u00FDsujeme t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nad stranami libovoln\u00E9ho",    // step = 2
               "troj\u00FAheln\u00EDku nar\u00FDsujeme t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nad stranami libovoln\u00E9ho",    // step = 3
               "troj\u00FAheln\u00EDku nar\u00FDsujeme t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nyn\u00ED vyzna\u010D\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",           // step = 4
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F."],
              ["Nyn\u00ED vyzna\u010D\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",           // step = 5
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F."],
              ["Nyn\u00ED vyzna\u010D\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",           // step = 6
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F."],
              ["Tyto t\u011B\u017Ei\u0161t\u011B vz\u00E1jemn\u011B spoj\u00EDme."],           // step = 7
              ["Tyto t\u011B\u017Ei\u0161t\u011B vz\u00E1jemn\u011B spoj\u00EDme."],           // step = 8
              ["Tyto t\u011B\u017Ei\u0161t\u011B vz\u00E1jemn\u011B spoj\u00EDme."],           // step = 9
              ["Nov\u011B vznikl\u00FD troj\u00FAheln\u00EDk se",              // step = 10
               "naz\u00FDv\u00E1 Napoleon\u016Fv troj\u00FAheln\u00EDk."],
              ["Ot\u00E1zka:",                                   // step = 11
               "Co je mo\u017En\u00E9 \u0159\u00EDci o typu",
               "Napoleonova troj\u00FAheln\u00EDku?"],
              ["Odpov\u011B\u010F:",                                 // step = 12
               "Napoleon\u016Fv troj\u00FAheln\u00EDk je v\u017Edy",
               "rovnostrann\u00FD troj\u00FAheln\u00EDk."]];
