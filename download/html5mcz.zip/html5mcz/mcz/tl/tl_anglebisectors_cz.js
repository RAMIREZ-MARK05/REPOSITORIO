// Dreiecks-Labor, Winkelhalbierende, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 25.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var incenter = "I";

var text03 = [["Pro zadan\u00FD troj\u00FAheln\u00EDk nar\u00FDsujeme",          // step = 0
               "v\u0161echny t\u0159i osy (vnit\u0159n\u00EDch) \u00FAhl\u016F."], 
              ["Za\u010D\u00EDn\u00E1me osou \u00FAhlu \u03B1."],             // step = 1
              ["Za\u010D\u00EDn\u00E1me osou \u00FAhlu \u03B1.",             // step = 2
               "V\u0161echny body t\u00E9to osy \u00FAhlu jsou",
               "stejn\u011B vzd\u00E1leny od stran [AB]",
               "a [AC]."],  
              ["Stejn\u011B tak body osy \u00FAhlu \u03B2 jsou",            // step = 3
               "stejn\u011B vzd\u00E1leny od stran [AB] a",
               "[BC]."],
              ["D\u00EDky tomu i pr\u016Fse\u010D\u00EDk t\u011Bchto os (I)",           // step = 4
               "m\u00E1 stejnou vzd\u00E1lenost od v\u0161ech t\u0159\u00ED",
               "vrchol\u016F troj\u00FAheln\u00EDku."],
              ["Proto\u017Ee pr\u016Fse\u010D\u00EDk I m\u00E1 stejnou",
               "vzd\u00E1lenost i od stran [AC] a [BC],",           // step = 5
               "je jasn\u00E9, \u017Ee mus\u00ED le\u017Eet i na ose",
               "t\u0159et\u00EDho \u00FAhlu (\u03B3)."], 
              ["V\u0161echny t\u0159i osy \u00FAhl\u016F se prot\u00EDnaj\u00ED",        // step = 6
               "v jednom bod\u011B, kter\u00FD m\u00E1 stejnou",
               "vzd\u00E1lenost od v\u0161ech t\u0159\u00ED stran."],
              ["Ot\u00E1zka:",                                   // step = 7
               "V jak\u00E9m troj\u00FAheln\u00EDku d\u011Bl\u00ED osa \u00FAhlu",
               "protilehlou stranu p\u0159esn\u011B",
               "v polovin\u011B?"],
              ["Odpov\u011B\u010F:",                                 // step = 8
               "Tento p\u0159\u00EDpad nast\u00E1v\u00E1 pro",
               "rovnoramenn\u00FD troj\u00FAheln\u00EDk.",
               "Pro v\u0161echny t\u0159i osy najednou to",
               "plat\u00ED v rovnostrann\u00E9m troj\u00FAheln\u00EDku."]];
