// Dreiecks-Labor, Tangentendreieck, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 22.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var circumcenter = "U";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC se svou",          // step = 0
               "kru\u017Enic\u00ED opsanou."],
              ["V ka\u017Ed\u00E9m vrcholu nar\u00FDsujeme te\u010Dnu",           // step = 1
               "ke kru\u017Enici opsan\u00E9."],
              ["V ka\u017Ed\u00E9m vrcholu nar\u00FDsujeme te\u010Dnu",           // step = 2
               "ke kru\u017Enici opsan\u00E9."],
              ["V ka\u017Ed\u00E9m vrcholu nar\u00FDsujeme te\u010Dnu",           // step = 3
               "ke kru\u017Enici opsan\u00E9."],
              ["V\u00FDsledkem je tzv. te\u010Dnov\u00FD troj-",            // step = 4
               "\u00FAheln\u00EDk p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Ot\u00E1zka:",                                   // step = 5
               "Kter\u00E9 troj\u00FAheln\u00EDky nemaj\u00ED \u017E\u00E1dn\u00FD",
               "te\u010Dnov\u00FD troj\u00FAheln\u00EDk?"],
              ["Odpov\u011B\u010F:",                                 // step = 6
               "U pravo\u00FAhl\u00E9ho troj\u00FAheln\u00EDku",
               "neexistuje te\u010Dnov\u00FD troj\u00FAheln\u00EDk,",
               "proto\u017Ee dv\u011B te\u010Dny ke kru\u017Enici",
               "opsan\u00E9 jsou rovnob\u011B\u017En\u00E9."]];
