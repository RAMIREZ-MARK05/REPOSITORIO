// Dreiecks-Labor, Gergonne-Punkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 22.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var gergonnepoint = "Ge";

var text03 = [["M\u00E1me troj\u00FAheln\u00EDk ABC se svou",              // step = 0
               "kru\u017Enic\u00ED vepsanou."], 
              ["Vyzna\u010Dme na stran\u00E1ch body,",         // step = 1
               "kde se kru\u017Enice vepsan\u00E1 dot\u00FDk\u00E1."],
              ["Vyzna\u010Dme na stran\u00E1ch body,",         // step = 2
               "kde se kru\u017Enice vepsan\u00E1 dot\u00FDk\u00E1."],
              ["Vyzna\u010Dme na stran\u00E1ch body,",         // step = 3
               "kde se kru\u017Enice vepsan\u00E1 dot\u00FDk\u00E1."],
              ["Spoj\u00EDme-li ka\u017Ed\u00FD ze t\u0159\u00ED vrchol\u016F",        // step = 4
               "s protilehl\u00FDm dotykov\u00FDm",
               "bodem, ..."],
              ["Spoj\u00EDme-li ka\u017Ed\u00FD ze t\u0159\u00ED vrchol\u016F",        // step = 5
               "s protilehl\u00FDm dotykov\u00FDm",
               "bodem, ..."],
              ["Spoj\u00EDme-li ka\u017Ed\u00FD ze t\u0159\u00ED vrchol\u016F",        // step = 6
               "s protilehl\u00FDm dotykov\u00FDm",
               "bodem, ..."],
              ["... v\u0161imneme si, \u017Ee se tyto spojnice",       // step = 7
               "prot\u00EDnaj\u00ED v jednom bod\u011B.",
               "Tomuto bodu G \u0159\u00EDk\u00E1me",
               "Gergonne\u016Fv bod troj\u00FAheln\u00EDku."]];






