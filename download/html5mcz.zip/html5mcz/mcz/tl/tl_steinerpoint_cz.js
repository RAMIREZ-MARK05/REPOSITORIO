// Dreiecks-Labor, Steiner-Kreise und Steiner-Punkte, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.09.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2019"; 
var translator = "M. Pano&scaron; 2020";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";  
var vertex2 = "B"; 
var vertex3 = "C"; 
var centroid = "T";               
var image1 = "A'"; 
var image2 = "B'";
var image3 = "C'";   
var steinerpoint = "St";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC i se sv\u00FDm",
               "t\u011B\u017Ei\u0161t\u011Bm T, kter\u00E9 je d\u00E1no jako",
               "pr\u016Fse\u010D\u00EDk t\u011B\u017Enic."],
              ["Nyn\u00ED postupn\u011B vrcholy troj\u00FAheln\u00EDku",
               "zobraz\u00EDme symetricky podle t\u011B\u017Ei\u0161t\u011B",
               "(st\u0159edov\u00E1 soum\u011Brnost)."],
              ["Nyn\u00ED postupn\u011B vrcholy troj\u00FAheln\u00EDku",
               "zobraz\u00EDme symetricky podle t\u011B\u017Ei\u0161t\u011B",
               "(st\u0159edov\u00E1 soum\u011Brnost)."],
              ["Nyn\u00ED postupn\u011B vrcholy troj\u00FAheln\u00EDku",
               "zobraz\u00EDme symetricky podle t\u011B\u017Ei\u0161t\u011B",
               "(st\u0159edov\u00E1 soum\u011Brnost)."],
              ["D\u00E1le nar\u00FDsujeme kru\u017Enici, kter\u00E1",
               "proch\u00E1z\u00ED vrcholem A a dv\u011Bma",
               "symetrick\u00FDmi obrazy k bod\u016Fm",
               "B a C."],
              ["Pak nar\u00FDsujeme kru\u017Enici, kter\u00E1",
               "proch\u00E1z\u00ED vrcholem B a dv\u011Bma",
               "symetrick\u00FDmi obrazy k bod\u016Fm",
               "A a C."],
              ["A nakonec i kru\u017Enici, kter\u00E1",
               "proch\u00E1z\u00ED vrcholem C a dv\u011Bma",
               "symetrick\u00FDmi obrazy k bod\u016Fm",
               "A a B."],
              ["Kdy\u017E se na v\u0161echny tyto kru\u017Enice",
               "pod\u00EDvame najednou,..."],
              ["Kdy\u017E se na v\u0161echny tyto kru\u017Enice",
               "pod\u00EDvame najednou, zjist\u00EDme,",
               "\u017Ee se prot\u00EDnaj\u00ED v jedin\u00E9m bod\u011B."],
               ["Tyto t\u0159i kru\u017Enice a jejich pr\u016Fse\u010D\u00EDk",
                "se jmenuj\u00ED po Jakobu Steinerovi",
                "Mluv\u00EDme o nich jako o Steinerov\u00FDch",
                "kru\u017Enic\u00EDch a o Steinerov\u011B bodu",
                "troj\u00FAheln\u00EDku."]
               ];
               







