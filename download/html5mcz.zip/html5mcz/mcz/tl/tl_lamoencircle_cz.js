// Dreiecks-Labor, Lamoen-Kreis, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 28.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Troj\u00FAheln\u00EDk ABC je sv\u00FDmi t\u011B\u017Enicemi",          // step = 0
               "rozd\u011Blen na \u0161est men\u0161\u00EDch",
               "troj\u00FAheln\u00EDk\u016F."],
              ["Pro ka\u017Ed\u00FD tento d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDk",            // step = 1
               "nar\u00FDsujeme kru\u017Enici opsanou."],
              ["Pro ka\u017Ed\u00FD tento d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDk",            // step = 2
               "nar\u00FDsujeme kru\u017Enici opsanou."],
              ["Pro ka\u017Ed\u00FD tento d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDk",            // step = 3
               "nar\u00FDsujeme kru\u017Enici opsanou."],
              ["Pro ka\u017Ed\u00FD tento d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDk",            // step = 4
               "nar\u00FDsujeme kru\u017Enici opsanou."],
              ["Pro ka\u017Ed\u00FD tento d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDk",            // step = 5
               "nar\u00FDsujeme kru\u017Enici opsanou."],
              ["Pro ka\u017Ed\u00FD tento d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDk",            // step = 6
               "nar\u00FDsujeme kru\u017Enici opsanou."],
              ["Ukazuje se, \u017Ee st\u0159edy v\u0161ech \u0161esti",          // step = 7
               "kru\u017Enic le\u017E\u00ED na kru\u017Enici.",
               "Tato kru\u017Enice je pojmenov\u00E1na",
               "po sv\u00E9m objeviteli Lamoenova",
               "kru\u017Enice."]
               ];






