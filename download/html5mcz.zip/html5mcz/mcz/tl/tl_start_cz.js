// Dreiecks-Labor, Startseite, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 21.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

// Texte in Unicode-Schreibweise:

var text03 = [["Tyto animace jsou v cel\u00E9 s\u00E9rii",
               "ovl\u00E1dan\u00E9 stejn\u00FDm zp\u016Fsobem.",
               "Pokra\u010Dujte kliknut\u00EDm my\u0161i",
               "(lev\u00E9 tla\u010D\u00EDtko!) na tla\u010D\u00EDtko",
               "\u0022Dal\u0161\u00ED krok\u0022."], 
              ["Vrcholy troj\u00FAheln\u00EDku",
               "nakreslen\u00E9ho vlevo (\u010Derven\u00E9)",
               "lze p\u0159esouvat pomoc\u00ED stisknut\u00ED",
               "lev\u00E9ho tla\u010D\u00EDtka my\u0161i.","(zkuste to!)"],
              ["Doln\u00ED tla\u010D\u00EDtko je nyn\u00ED neaktivn\u00ED.",
               "Kliknut\u00EDm na horn\u00ED tla\u010D\u00EDtko",
               "lze animaci restartovat."]
              ];
