// Dreiecks-Labor, Kiepert-Hyperbel, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 25.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2017"; 
var translator = "M. Pano&scaron; 2017";

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var centroid = "S";
var orthocenter = "H";
var spiekerpoint = "Sp";

// Texte in Unicode-Schreibweise:

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC."],            // step = 0
              ["Nad ka\u017Edou ze t\u0159\u00ED stran m\u016F\u017Eeme",       // step = 1
               "zkonstruovat rovnoramenn\u00E9",
               "troj\u00FAheln\u00EDky, kter\u00E9 jsou navz\u00E1jem", 
               "podob\u00E9, tak\u017Ee maj\u00ED stejn\u00E9 vnit\u0159n\u00ED",
               "\u00FAhly."],
              ["Nad ka\u017Edou ze t\u0159\u00ED stran m\u016F\u017Eeme",       // step = 2
               "zkonstruovat rovnoramenn\u00E9",
               "troj\u00FAheln\u00EDky, kter\u00E9 jsou navz\u00E1jem", 
               "podob\u00E9, tak\u017Ee maj\u00ED stejn\u00E9 vnit\u0159n\u00ED",
               "\u00FAhly."],
              ["Nad ka\u017Edou ze t\u0159\u00ED stran m\u016F\u017Eeme",       // step = 3
               "zkonstruovat rovnoramenn\u00E9",
               "troj\u00FAheln\u00EDky, kter\u00E9 jsou navz\u00E1jem", 
               "podob\u00E9, tak\u017Ee maj\u00ED stejn\u00E9 vnit\u0159n\u00ED",
               "\u00FAhly."],
              ["Vrcholy vznikl\u00FDch rovnoramenn\u00FDch",        // step = 4
               "troj\u00FAheln\u00EDk\u016F spoj\u00EDme s protilehl\u00FDmi",
               "vrcholy p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Vrcholy vznikl\u00FDch rovnoramenn\u00FDch",        // step = 5
               "troj\u00FAheln\u00EDk\u016F spoj\u00EDme s protilehl\u00FDmi",
               "vrcholy p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Vrcholy vznikl\u00FDch rovnoramenn\u00FDch",        // step = 6
               "troj\u00FAheln\u00EDk\u016F spoj\u00EDme s protilehl\u00FDmi",
               "vrcholy p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED vyzna\u010D\u00EDme z\u00EDskan\u00FD pr\u016Fse\u010D\u00EDk",          // step = 7
               "t\u011Bchto spojnic."],
              ["Ukazuje se, \u017Ee tento pr\u016Fse\u010D\u00EDk le\u017E\u00ED",          // step = 8
               "na hyperbole, kter\u00E9 se \u0159\u00EDk\u00E1",
               "tzv. Kiepertova hyperbola."],
              ["Na Kiepertov\u011B hyperbole t\u00E9\u017E le\u017E\u00ED",          // step = 9
               "n\u011Bkter\u00E9 zvl\u00E1\u0161tn\u00ED body ..."],
              ["Na Kiepertov\u011B hyperbole t\u00E9\u017E le\u017E\u00ED",          // step = 10
               "n\u011Bkter\u00E9 zvl\u00E1\u0161tn\u00ED body, nap\u0159\u00EDklad",
               "t\u011B\u017Ei\u0161t\u011B, ..."],
              ["Na Kiepertov\u011B hyperbole t\u00E9\u017E le\u017E\u00ED",          // step = 11
               "n\u011Bkter\u00E9 zvl\u00E1\u0161tn\u00ED body, nap\u0159\u00EDklad",
               "t\u011B\u017Ei\u0161t\u011B, pr\u016Fse\u010D\u00EDk v\u00FD\u0161ek ..."],
              ["Na Kiepertov\u011B hyperbole t\u00E9\u017E le\u017E\u00ED",          // step = 12
               "n\u011Bkter\u00E9 zvl\u00E1\u0161tn\u00ED body, nap\u0159\u00EDklad",
               "t\u011B\u017Ei\u0161t\u011B, pr\u016Fse\u010D\u00EDk v\u00FD\u0161ek a ",
               "tzv. Spieker\u016Fv bod."],
              ["Na Kiepertov\u011B hyperbole t\u00E9\u017E le\u017E\u00ED",          // step = 12
               "n\u011Bkter\u00E9 zvl\u00E1\u0161tn\u00ED body, nap\u0159\u00EDklad",
               "t\u011B\u017Ei\u0161t\u011B, pr\u016Fse\u010D\u00EDk v\u00FD\u0161ek a ",
               "tzv. Spieker\u016Fv bod."]];
