// Dreiecks-Labor, Satz vom Dreizack, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.09.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2017"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var incenter = "I";
var circumcenter = "U";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC se svou",          // step = 0
               "kru\u017Enic\u00ED vepsanou a opsanou."],
              ["Pro \u00FAhel \u03B1 nar\u00FDsujeme osu \u00FAhlu,",
               "kter\u00E1 proch\u00E1z\u00ED st\u0159edem kru\u017Enice",
               "vepsan\u00E9."],
              ["Tato osa \u00FAhlu prot\u00EDn\u00E1 kru\u017Enici",        // step = 2
               "opsanou v n\u011Bjak\u00E9m bod\u011B."],
              ["Nyn\u00ED uva\u017Eujme spojnice tohoto",           // step = 3
               "pr\u016Fse\u010D\u00EDku s vrchloly B a C a se",
               "st\u0159edem kru\u017Enice vepsan\u00E9"],
              ["Tyto t\u0159i \u00FAse\u010Dky maj\u00ED stejnou d\u00E9lku,", // step = 4
               "jak dokazuje nakreslen\u00E1 kru\u017Enice",
               "se st\u0159edem v tomto pr\u016Fse\u010D\u00EDku.",
               "(tzv. \u0160vr\u010Dkov\u011B bod\u011B)"],
              ["Tot\u00E9\u017E plat\u00ED pro osu \u00FAhlu \u03B2 ..."],         // step = 5
              ["Tot\u00E9\u017E plat\u00ED pro osu \u00FAhlu \u03B2 ..."],         // step = 6
              ["Tot\u00E9\u017E plat\u00ED pro osu \u00FAhlu \u03B2 ..."],         // step = 7
              ["Tot\u00E9\u017E plat\u00ED pro osu \u00FAhlu \u03B2 ..."],         // step = 8
              ["Tot\u00E9\u017E plat\u00ED pro osy \u00FAhl\u016F \u03B2 a \u03B3."],         // step = 9
              ["Tot\u00E9\u017E plat\u00ED pro osy \u00FAhl\u016F \u03B2 a \u03B3."],         // step = 10
              ["Tot\u00E9\u017E plat\u00ED pro osy \u00FAhl\u016F \u03B2 a \u03B3."],         // step = 11
              ["Tot\u00E9\u017E plat\u00ED pro osy \u00FAhl\u016F \u03B2 a \u03B3."]];         // step = 12
