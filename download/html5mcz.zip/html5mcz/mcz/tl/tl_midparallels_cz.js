// Dreiecks-Labor, Mittelparallelen, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 22.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var midpoint1 = "D";
var midpoint2 = "E";
var midpoint3 = "F";

var text03 = [["V zadan\u00E9m troj\u00FAheln\u00EDku ABC",             // step = 0
               "vyzna\u010D\u00EDme st\u0159edy stran."], 
              ["D je st\u0159ed strany [BC]."],         // step = 1  
              ["D je st\u0159ed strany [BC].",          // step = 2
               "E je st\u0159ed strany [CA]."], 
              ["D je st\u0159ed strany [BC].",          // step = 3
               "E je st\u0159ed strany [CA].",
               "F je st\u0159ed strany [AB]."], 
              ["St\u0159edy stran postupn\u011B spoj\u00EDme",            // step = 4
               "st\u0159edn\u00EDmi p\u0159\u00ED\u010Dkami, co\u017E n\u00E1m",
               "vytvo\u0159\u00ED men\u0161\u00ED troj\u00FAheln\u00EDk."],
              ["St\u0159edy stran postupn\u011B spoj\u00EDme",            // step = 5
               "st\u0159edn\u00EDmi p\u0159\u00ED\u010Dkami, co\u017E n\u00E1m",
               "vytvo\u0159\u00ED men\u0161\u00ED troj\u00FAheln\u00EDk."],
              ["St\u0159edy stran postupn\u011B spoj\u00EDme",            // step = 6
               "st\u0159edn\u00EDmi p\u0159\u00ED\u010Dkami, co\u017E n\u00E1m",
               "vytvo\u0159\u00ED men\u0161\u00ED troj\u00FAheln\u00EDk."],
              ["Nov\u011B vznikl\u00FD troj\u00FAheln\u00EDk se naz\u00FDv\u00E1",               // step = 7
               "p\u0159\u00ED\u010Dkov\u00FD troj\u00FAheln\u00EDk."],
              ["Ot\u00E1zka:",                                   // step = 8
               "Jak\u00E9 jsou vztahy mezi stranami",
               "p\u0159\u00ED\u010Dkov\u00E9ho troj\u00FAheln\u00EDku a troj-",
               "\u00FAheln\u00EDku p\u016Fvodn\u00EDho?"],
              ["Odpov\u011B\u010F:",                                 // step = 9
               "Ka\u017Ed\u00E1 strana vznikl\u00E9ho p\u0159\u00ED\u010Dkov\u00E9ho",
               "troj\u00FAheln\u00EDku je rovnob\u011B\u017En\u00E1",
               "s jednou stranou p\u016Fvodn\u00EDho",
               "troj\u00FAheln\u00EDku a m\u00E1 polovinu d\u00E9lky",
               "t\u00E9to strany."]];
