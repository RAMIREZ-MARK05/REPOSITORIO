// Dreiecks-Labor, isodynamische Punkte, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 27.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC."],            // step = 0
              ["Pro \u00FAhel \u03B1 nar\u00FDsujeme osu \u00FAhlu."],       // step = 1
              ["Nav\u00EDc zobraz\u00EDme osu p\u0159\u00EDslu\u0161n\u00E9ho",          // step = 2
               "vn\u011Bj\u0161\u00EDho \u00FAhlu, kter\u00E1 je kolm\u00E1",
               "na osu \u00FAhlu vnit\u0159n\u00EDho."],
              ["Nyn\u00ED vyzna\u010D\u00EDme pr\u016Fse\u010Dky obou",          // step = 3
               "os s p\u0159\u00EDmkou BC."],
              ["Nar\u00FDsujeme kru\u017Enici, kter\u00E1 m\u00E1",        // step = 4
               "pr\u016Fm\u011Br shodn\u00FD se vzd\u00E1lenost\u00ED",
               "t\u011Bchto pr\u016Fse\u010D\u00EDk\u016F.",
               "Na t\u00E9to kru\u017Enici tak\u00E9 le\u017E\u00ED bod A."],
              ["Obdobn\u011B postupujeme i pro",            // step = 5
               "\u00FAhly \u03B2 a \u03B3."],
              ["Obdobn\u011B postupujeme i pro",            // step = 6
               "\u00FAhly \u03B2 a \u03B3."],
              ["Obdobn\u011B postupujeme i pro",            // step = 7
               "\u00FAhly \u03B2 a \u03B3."],
              ["Obdobn\u011B postupujeme i pro",            // step = 8
               "\u00FAhly \u03B2 a \u03B3."],
              ["Obdobn\u011B postupujeme i pro",            // step = 9
               "\u00FAhly \u03B2 a \u03B3."],
              ["Obdobn\u011B postupujeme i pro",            // step = 10
               "\u00FAhly \u03B2 a \u03B3."],
              ["Obdobn\u011B postupujeme i pro",            // step = 11
               "\u00FAhly \u03B2 a \u03B3."],
              ["Obdobn\u011B postupujeme i pro",            // step = 12
               "\u00FAhly \u03B2 a \u03B3."],
              ["Ukazuje se, \u017Ee st\u0159edy t\u011Bchto",          // step = 13
               "kru\u017Enic le\u017E\u00ED na p\u0159\u00EDmce."],
              ["Vyzna\u010Dme tak\u00E9 dva body, kter\u00E9",       // step = 14
               "jsou spole\u010Dn\u00E9 v\u0161em t\u0159em kru\u017Enic\u00EDm.",
               "Naz\u00FDv\u00E1me je isodymanick\u00E9 body",
               "troj\u00FAheln\u00EDku."]];
