// Dreiecks-Labor, Punkt der gleich langen Parallelen, tschechische Texte
// Letzte �nderung 25.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2019"; 
var translator = "M. Pano&scaron; 2020";

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";       
var point = "P";  

// Texte in Unicode-Schreibweise:

var text03 = [["Jsou d\u00E1ny troj\u00FAheln\u00EDk ABC a",
               "libovoln\u00FD vnit\u0159n\u00ED bod P.",
               ""], 
              ["Bodem P vyzna\u010Dme \u00FAse\u010Dky",
               "rovnob\u011B\u017En\u00E9 se stranami",
               "troj\u00FAheln\u00EDku."], 
              ["Bod P by m\u011Bl b\u00FDt posunut tak,",
               "aby v\u0161echny t\u0159i \u00FAse\u010Dky byly ",
               "stejn\u011B dlouh\u00E9.",
               "(Pro sna\u017E\u0161\u00ED srovn\u00E1n\u00ED \u00FAse\u010Dek",
               "jsou jejich d\u00E9lky vyneseny dole.)",
               "Pohybujte bodem P."],
              ["Takto vypad\u00E1 \u0159e\u0161en\u00ED!"], 
              ["Ale jak takov\u00FD bod P naj\u00EDt?"],
              ["Nejd\u0159\u00EDve nar\u00FDsujeme rovnob\u011B\u017Eky",
               "se stranami proch\u00E1zej\u00EDc\u00ED",
               "prot\u011Bj\u0161\u00EDmi vrcholy.",
               ""],
              ["Nejd\u0159\u00EDve nar\u00FDsujeme rovnob\u011B\u017Eky",
               "se stranami proch\u00E1zej\u00EDc\u00ED",
               "prot\u011Bj\u0161\u00EDmi vrcholy.",
               ""],
              ["Nejd\u0159\u00EDve nar\u00FDsujeme rovnob\u011B\u017Eky",
               "se stranami proch\u00E1zej\u00EDc\u00ED",
               "prot\u011Bj\u0161\u00EDmi vrcholy.",
               ""],
              ["D\u00E1le budeme pot\u0159ebovat t\u0159i",
               "osy \u00FAhlu."],
              ["D\u00E1le budeme pot\u0159ebovat t\u0159i",
               "osy \u00FAhlu."],
              ["D\u00E1le budeme pot\u0159ebovat t\u0159i",
               "osy \u00FAhlu."],
              ["Vrcholy velk\u00E9ho troj\u00FAheln\u00EDku",
               "a pr\u016Fse\u010D\u00EDk osy \u00FAhlu se stranou",
               "troj\u00FAheln\u00EDku prolo\u017E\u00EDme p\u0159\u00EDmkou."],
              ["Vrcholy velk\u00E9ho troj\u00FAheln\u00EDku",
               "a pr\u016Fse\u010D\u00EDk osy \u00FAhlu se stranou",
               "troj\u00FAheln\u00EDku prolo\u017E\u00EDme p\u0159\u00EDmkou."],
              ["Vrcholy velk\u00E9ho troj\u00FAheln\u00EDku",
               "a pr\u016Fse\u010D\u00EDk osy \u00FAhlu se stranou",
               "troj\u00FAheln\u00EDku prolo\u017E\u00EDme p\u0159\u00EDmkou."],
              ["Vznikl\u00E9 p\u0159\u00EDmky se prot\u00EDnaj\u00ED",
               "v jednom bod\u011B."],
              ["Tento bod je \u0159e\u0161en\u00EDm na\u0161eho",
               "probl\u00E9mu."]];





