// Dreiecks-Labor, Fermat-Punkte, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text02 = "Nov&yacute; start";
var text03 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var fermatpoint1 = "F";
var fermatpoint2 = "F'";

// Text f�r das Auswahlfeld:

var text01 = ["1. Fermat\u016Fv bod", "2. Fermat\u016Fv bod"];

// Text f�r den 1. Fermat-Punkt:

var text04 = [["Nad stranami (vn\u011B) libovoln\u00E9ho",	// step = 0
               "troj\u00FAheln\u00EDku lze sestrojit t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nad stranami (vn\u011B) libovoln\u00E9ho",		 // step = 1
               "troj\u00FAheln\u00EDku lze sestrojit t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nad stranami (vn\u011B) libovoln\u00E9ho",		// step = 2
               "troj\u00FAheln\u00EDku lze sestrojit t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nad stranami (vn\u011B) libovoln\u00E9ho",		// step = 3
               "troj\u00FAheln\u00EDku lze sestrojit t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 4
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 5
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 6
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 7
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 8
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 9
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Vyzna\u010Den\u00E9 p\u0159\u00EDmky se prot\u00EDnaj\u00ED",            // step = 10
               "v bod\u011B F.",
               "Ten se naz\u00FDv\u00E1 1. Fermat\u016Fv bod",
               "troj\u00FAheln\u00EDku ABC."],
              ["Ot\u00E1zka:",                                   // step = 11
               "Za jak\u00FDch podm\u00EDnek se",
               "1. Fermat\u016Fv bod F shoduje",
               "s vrcholem dan\u00E9ho troj\u00FAheln\u00EDku",
               "ABC?"],
              ["Odpov\u011B\u010F:",                                 // step = 12
               "Pokud m\u00E1 dan\u00FD troj\u00FAheln\u00EDk ABC",
               "\u00FAhel 120\u00B0, pak se 1. Fermat\u016Fv",
               "bod shoduje s vrcholem \u00FAhlu 120\u00B0."]];
               
// Text f�r den 2. Fermat-Punkt:

var text05 = [["Pod stranami (sm\u011Brem dovnit\u0159)",    // step = 0
               "libovoln\u00E9ho troj\u00FAheln\u00EDku lze",
               "sestrojit t\u0159i rovnostrann\u00E9",
               "troj\u00FAheln\u00EDky."],
              ["Pod stranami (sm\u011Brem dovnit\u0159)",    // step = 1
               "libovoln\u00E9ho troj\u00FAheln\u00EDku lze",
               "sestrojit t\u0159i rovnostrann\u00E9",
               "troj\u00FAheln\u00EDky."],
              ["Pod stranami (sm\u011Brem dovnit\u0159)",    // step = 2
               "libovoln\u00E9ho troj\u00FAheln\u00EDku lze",
               "sestrojit t\u0159i rovnostrann\u00E9",
               "troj\u00FAheln\u00EDky."],
              ["Pod stranami (sm\u011Brem dovnit\u0159)",    // step = 3
               "libovoln\u00E9ho troj\u00FAheln\u00EDku lze",
               "sestrojit t\u0159i rovnostrann\u00E9",
               "troj\u00FAheln\u00EDky."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 4
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 5
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 6
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 7
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 8
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nov\u00E9 vrcholy p\u0159ipsan\u00FDch",             // step = 9
               "rovnostrann\u00FDch troj\u00FAheln\u00EDk\u016F",
               "se propoj\u00ED s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Vyzna\u010Den\u00E9 p\u0159\u00EDmky se prot\u00EDnaj\u00ED",            // step = 10
               "v bod\u011B F'.",
               "Ten se naz\u00FDv\u00E1 2. Fermat\u016Fv bod",
               "troj\u00FAheln\u00EDku ABC."],
              ["Ot\u00E1zka:",                                   // step = 11
               "Za jak\u00FDch podm\u00EDnek se",
               "2. Fermat\u016Fv bod F' shoduje",
               "s vrcholem dan\u00E9ho troj\u00FAheln\u00EDku",
               "ABC?"],
              ["Odpov\u011B\u010F:",                                 // step = 12
               "Pokud m\u00E1 dan\u00FD troj\u00FAheln\u00EDk ABC",
               "\u00FAhel 60\u00B0, pak se 2. Fermat\u016Fv",
               "bod shoduje s vrcholem \u00FAhlu 60\u00B0."]];
