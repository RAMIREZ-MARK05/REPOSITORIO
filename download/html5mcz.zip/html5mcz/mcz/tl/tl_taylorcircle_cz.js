// Dreiecks-Labor, Taylor-Kreis, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var taylorcenter = "T";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC i se sv\u00FDmi",              // step = 0
               "v\u00FD\u0161kami."],
              ["Z ka\u017Ed\u00E9 paty v\u00FD\u0161ky spust\u00EDme dv\u011B",   // step = 1
               "kolmice k sousedn\u00EDm stran\u00E1m ",
               "troj\u00FAheln\u00EDku."],
              ["Z ka\u017Ed\u00E9 paty v\u00FD\u0161ky spust\u00EDme dv\u011B",   // step = 2
               "kolmice k sousedn\u00EDm stran\u00E1m ",
               "troj\u00FAheln\u00EDku."],
              ["Z ka\u017Ed\u00E9 paty v\u00FD\u0161ky spust\u00EDme dv\u011B",   // step = 3
               "kolmice k sousedn\u00EDm stran\u00E1m ",
               "troj\u00FAheln\u00EDku."],
              ["Z ka\u017Ed\u00E9 paty v\u00FD\u0161ky spust\u00EDme dv\u011B",   // step = 4
               "kolmice k sousedn\u00EDm stran\u00E1m ",
               "troj\u00FAheln\u00EDku."],
              ["Z ka\u017Ed\u00E9 paty v\u00FD\u0161ky spust\u00EDme dv\u011B",   // step = 5
               "kolmice k sousedn\u00EDm stran\u00E1m ",
               "troj\u00FAheln\u00EDku."],
              ["Z ka\u017Ed\u00E9 paty v\u00FD\u0161ky spust\u00EDme dv\u011B",   // step = 6
               "kolmice k sousedn\u00EDm stran\u00E1m ",
               "troj\u00FAheln\u00EDku."],
              ["Z ka\u017Ed\u00E9 paty v\u00FD\u0161ky spust\u00EDme dv\u011B",   // step = 7
               "kolmice k sousedn\u00EDm stran\u00E1m ",
               "troj\u00FAheln\u00EDku."],
              ["Z ka\u017Ed\u00E9 paty v\u00FD\u0161ky spust\u00EDme dv\u011B",   // step = 8
               "kolmice k sousedn\u00EDm stran\u00E1m ",
               "troj\u00FAheln\u00EDku."],
              ["Z ka\u017Ed\u00E9 paty v\u00FD\u0161ky spust\u00EDme dv\u011B",   // step = 9
               "kolmice k sousedn\u00EDm stran\u00E1m ",
               "troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED se pod\u00EDv\u00E1me bl\u00ED\u017Ee na tyto",     // step = 10
               "kolmice."],
              ["Vyzna\u010D\u00EDme si paty t\u011Bchto kolmic."],     // step = 11
              ["Vyzna\u010D\u00EDme si paty t\u011Bchto kolmic."],     // step = 12
              ["Vyzna\u010D\u00EDme si paty t\u011Bchto kolmic."],     // step = 13
              ["Vyzna\u010D\u00EDme si paty t\u011Bchto kolmic."],     // step = 14
              ["Vyzna\u010D\u00EDme si paty t\u011Bchto kolmic."],     // step = 15
              ["Vyzna\u010D\u00EDme si paty t\u011Bchto kolmic."],     // step = 16
              ["D\u00E1 se dok\u00E1zat, \u017Ee t\u011Bchto \u0161est pat",            // step = 17
               "kolmic le\u017E\u00ED na kru\u017Enici.",
               "Tato kru\u017Enice se naz\u00FDv\u00E1 Taylorova",
               "kru\u017Enice troj\u00FAheln\u00EDku ABC."]
               ];
