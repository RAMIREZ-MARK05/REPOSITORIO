// Dreiecks-Labor, Seitenhalbierende und Schwerpunkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 22.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var midpoint1 = "D";
var midpoint2 = "E";
var midpoint3 = "F";
var centroid = "S";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC. Na ka\u017Ed\u00E9",
               "jeho stran\u011B vyzna\u010D\u00EDme jej\u00ED st\u0159ed."], 
              ["Bod D je st\u0159ed strany [BC]."],  
              ["Bod D je st\u0159ed strany [BC].",
               "Bod E je st\u0159ed strany [CA]."], 
              ["Bod D je st\u0159ed strany [BC].",
               "Bod E je st\u0159ed strany [CA].",
               "Bod F je st\u0159ed strany [AB]."], 
              ["Ka\u017Ed\u00FD tento bod spoj\u00EDme",
               "s protilehl\u00FDm vrcholem."], 
              ["Ka\u017Ed\u00FD tento bod spoj\u00EDme",
               "s protilehl\u00FDm vrcholem."], 
              ["Ka\u017Ed\u00FD tento bod spoj\u00EDme",
               "s protilehl\u00FDm vrcholem."], 
              ["Vyzna\u010Den\u00E9 spojnice se naz\u00FDvaj\u00ED",
               "t\u011B\u017Enice troj\u00FAheln\u00EDku."],
              ["V\u0161echny t\u0159i t\u011B\u017Enice se prot\u00EDnaj\u00ED",
               "v jednom bod\u011B S, kter\u00FD se naz\u00FDv\u00E1",
               "t\u011B\u017Ei\u0161t\u011B troj\u00FAheln\u00EDku."], 
              ["Ot\u00E1zka:",
               "V jak\u00E9m pom\u011Bru se t\u011B\u017Enice d\u011Bl\u00ED?"],        
              ["Odpov\u011B\u010F:",
               "T\u011B\u017Enice se vz\u00E1jemn\u011B d\u011Bl\u00ED",
               "v pom\u011Bru 2:1.",
               "\u00DAsek mezi vrcholem a t\u011B\u017Ei\u0161t\u011Bm",
               "je dvakr\u00E1t del\u0161\u00ED ne\u017E mezi t\u011B\u017Ei\u0161t\u011Bm",
               "a st\u0159edem strany."]];
