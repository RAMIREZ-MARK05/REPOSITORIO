// Dreiecks-Labor, Satz von Feuerbach,  tschechische Texte (Miroslav Panos)
// Letzte �nderung 25.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2022"; 
var translator = "M. Pano&scaron; 2023";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Dev\u00EDtibodov\u00E1 kru\u017Enice",                      // step = 0
               "(Feuerbachova kru\u017Enice)",
               "troj\u00FAheln\u00EDku je kru\u017Enice,",
               " ..."],
              ["Dev\u00EDtibodov\u00E1 kru\u017Enice",                      // step = 1
               "(Feuerbachova kru\u017Enice)",
               "troj\u00FAheln\u00EDku je kru\u017Enice,",
               "kter\u00E1 proch\u00E1z\u00ED st\u0159edy stran,",
               "..."],
              ["Dev\u00EDtibodov\u00E1 kru\u017Enice",                      // step = 2
               "(Feuerbachova kru\u017Enice)",
               "troj\u00FAheln\u00EDku je kru\u017Enice,",
               "kter\u00E1 proch\u00E1z\u00ED st\u0159edy stran,",
               "patami v\u00FD\u0161ek ..."],
              ["Dev\u00EDtibodov\u00E1 kru\u017Enice",                      // step = 3
               "(Feuerbachova kru\u017Enice)",
               "troj\u00FAheln\u00EDku je kru\u017Enice,",
               "kter\u00E1 proch\u00E1z\u00ED st\u0159edy stran,",
               "patami v\u00FD\u0161ek a st\u0159edy",
               "spojnic vrchol\u016F s ortocentrem."],
              ["Obzvl\u00E1\u0161t\u011B zaj\u00EDmavou vlastnost",         // step = 4
               "dok\u00E1zal v roce 1822 Karl",
               "Wilhelm Feuerbach."],
              ["Dev\u00EDtibodov\u00E1 kru\u017Enice se",                   // step = 5
               "dot\u00FDk\u00E1 kru\u017Enice vepsan\u00E9"],
              ["Dev\u00EDtibodov\u00E1 kru\u017Enice se",                   // step = 6
               "dot\u00FDk\u00E1 kru\u017Enice vepsan\u00E9",
               "a t\u0159\u00ED kru\u017Enic p\u0159ipsan\u00FDch."],
              ["Dev\u00EDtibodov\u00E1 kru\u017Enice se",                   // step = 7
               "dot\u00FDk\u00E1 kru\u017Enice vepsan\u00E9",
               "a t\u0159\u00ED kru\u017Enic p\u0159ipsan\u00FDch."],
              ["Dev\u00EDtibodov\u00E1 kru\u017Enice se",                   // step = 8
               "dot\u00FDk\u00E1 kru\u017Enice vepsan\u00E9",
               "a t\u0159\u00ED kru\u017Enic p\u0159ipsan\u00FDch."],

               ];






