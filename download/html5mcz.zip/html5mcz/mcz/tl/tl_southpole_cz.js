// Dreiecks-Labor, S�dpolsatz, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 07.09.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Ka\u017Ed\u00FD troj\u00FAheln\u00EDk m\u00E1 kru\u017Enici",          // step = 0
               "opsanou, co\u017E je kru\u017Enice, kter\u00E1",
               "proch\u00E1z\u00ED v\u0161emi t\u0159emi vrcholy."],
              ["St\u0159ed kru\u017Enice opsan\u00E9 je pr\u016Fse\u010D\u00EDk",       // step = 1
               "os stran troj\u00FAheln\u00EDku."],
              ["St\u0159ed kru\u017Enice opsan\u00E9 je pr\u016Fse\u010D\u00EDk",       // step = 2
               "os stran troj\u00FAheln\u00EDku."],
              ["St\u0159ed kru\u017Enice opsan\u00E9 je pr\u016Fse\u010D\u00EDk",       // step = 3
               "os stran troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED p\u0159ich\u00E1zej\u00ED osy vnit\u0159n\u00EDch \u00FAhl\u016F."],              // step = 4
              ["Nyn\u00ED p\u0159ich\u00E1zej\u00ED osy vnit\u0159n\u00EDch \u00FAhl\u016F."],              // step = 5
              ["Nyn\u00ED p\u0159ich\u00E1zej\u00ED osy vnit\u0159n\u00EDch \u00FAhl\u016F."],              // step = 6
              ["Nyn\u00ED p\u0159ich\u00E1zej\u00ED osy vnit\u0159n\u00EDch \u00FAhl\u016F."],              // step = 7
              ["Nyn\u00ED p\u0159ich\u00E1zej\u00ED osy vnit\u0159n\u00EDch \u00FAhl\u016F."],              // step = 8
              ["Nyn\u00ED p\u0159ich\u00E1zej\u00ED osy vnit\u0159n\u00EDch \u00FAhl\u016F."],              // step = 9
              ["Vyzna\u010Dme pr\u016Fse\u010D\u00EDky v\u017Edy navz\u00E1jem",               // step = 10
               "p\u0159\u00EDslu\u0161n\u00FDch os stran a os vnit\u0159n\u00EDch",
               "\u00FAhl\u016F. Vid\u00EDme, \u017Ee le\u017E\u00ED na kru\u017Enici",
               "opsan\u00E9."],
              ["Vyzna\u010Dme pr\u016Fse\u010D\u00EDky v\u017Edy navz\u00E1jem",               // step = 11
               "p\u0159\u00EDslu\u0161n\u00FDch os stran a os vnit\u0159n\u00EDch",
               "\u00FAhl\u016F. Vid\u00EDme, \u017Ee le\u017E\u00ED na kru\u017Enici",
               "opsan\u00E9."],
              ["Vyzna\u010Dme pr\u016Fse\u010D\u00EDky v\u017Edy navz\u00E1jem",               // step = 12
               "p\u0159\u00EDslu\u0161n\u00FDch os stran a os vnit\u0159n\u00EDch",
               "\u00FAhl\u016F. Vid\u00EDme, \u017Ee le\u017E\u00ED na kru\u017Enici",
               "opsan\u00E9."]];
