// Dreiecks-Labor, Lemoine-Punkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 28.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var lemoinepoint = "L";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC se sv\u00FDmi ",          // step = 0
               "osami \u00FAhl\u016F."],
              ["D\u00E1le nar\u00FDsujeme t\u011B\u017Enice."],  // step = 1
              ["D\u00E1le nar\u00FDsujeme t\u011B\u017Enice."],  // step = 2
              ["D\u00E1le nar\u00FDsujeme t\u011B\u017Enice."],  // step = 3
              ["Nyn\u00ED t\u011B\u017Enice zobraz\u00EDme v osov\u00E9",          // step = 4
               "soum\u011Brnosti podle dan\u00E9 osy \u00FAhlu.",
               "Vzniklou p\u0159\u00EDmku naz\u00FDv\u00E1me",
               "symedi\u00E1na."],
              ["Nyn\u00ED t\u011B\u017Enice zobraz\u00EDme v osov\u00E9",          // step = 5
               "soum\u011Brnosti podle dan\u00E9 osy \u00FAhlu.",
               "Vzniklou p\u0159\u00EDmku naz\u00FDv\u00E1me",
               "symedi\u00E1na."],
              ["Nyn\u00ED t\u011B\u017Enice zobraz\u00EDme v osov\u00E9",          // step = 6
               "soum\u011Brnosti podle dan\u00E9 osy \u00FAhlu.",
               "Vzniklou p\u0159\u00EDmku naz\u00FDv\u00E1me",
               "symedi\u00E1na."],
              ["V\u0161echny symedi\u00E1ny se prot\u00EDnaj\u00ED",          // step = 7
               "v jednom bod\u011B L, kter\u00FD se naz\u00FDv\u00E1",
               "Lemoine\u016Fv bod."]];
