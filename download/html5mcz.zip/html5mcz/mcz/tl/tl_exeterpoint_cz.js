// Dreiecks-Labor, Exeter-Punkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var exeterpoint = "E";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC i se sv\u00FDm",          // step = 0
               "te\u010Dnov\u00FDm troj\u00FAheln\u00EDkem.",
               "Ten je vymezen p\u0159\u00EDmkami, kter\u00E9",
               "se ve vrcholech dot\u00FDkaj\u00ED kru\u017Enice",
               "opsan\u00E9 troj\u00FAheln\u00EDku."],
              ["Krom\u011B toho nyn\u00ED ur\u010D\u00EDme pr\u016Fse\u010D\u00EDky ",     // step = 1
               "prodlou\u017Een\u00ED t\u011B\u017Enic s kru\u017Enic\u00ED",
               "opsanou."],
              ["Krom\u011B toho nyn\u00ED ur\u010D\u00EDme pr\u016Fse\u010D\u00EDky ",     // step = 2
               "prodlou\u017Een\u00ED t\u011B\u017Enic s kru\u017Enic\u00ED",
               "opsanou."],
              ["Krom\u011B toho nyn\u00ED ur\u010D\u00EDme pr\u016Fse\u010D\u00EDky ",     // step = 3
               "prodlou\u017Een\u00ED t\u011B\u017Enic s kru\u017Enic\u00ED",
               "opsanou."],
              ["Krom\u011B toho nyn\u00ED ur\u010D\u00EDme pr\u016Fse\u010D\u00EDky ",     // step = 4
               "prodlou\u017Een\u00ED t\u011B\u017Enic s kru\u017Enic\u00ED",
               "opsanou."],
              ["Krom\u011B toho nyn\u00ED ur\u010D\u00EDme pr\u016Fse\u010D\u00EDky ",     // step = 5
               "prodlou\u017Een\u00ED t\u011B\u017Enic s kru\u017Enic\u00ED",
               "opsanou."],
              ["Krom\u011B toho nyn\u00ED ur\u010D\u00EDme pr\u016Fse\u010D\u00EDky ",     // step = 6
               "prodlou\u017Een\u00ED t\u011B\u017Enic s kru\u017Enic\u00ED",
               "opsanou."],
              ["Nalezen\u00E9 pr\u016Fse\u010D\u00EDky spoj\u00EDme",             // step = 7
               "s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "te\u010Dnov\u00E9ho troj\u00FAheln\u00EDku."],
              ["Nalezen\u00E9 pr\u016Fse\u010D\u00EDky spoj\u00EDme",             // step = 8
               "s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "te\u010Dnov\u00E9ho troj\u00FAheln\u00EDku."],
              ["Nalezen\u00E9 pr\u016Fse\u010D\u00EDky spoj\u00EDme",             // step = 9
               "s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "te\u010Dnov\u00E9ho troj\u00FAheln\u00EDku."],
              ["Nalezen\u00E9 pr\u016Fse\u010D\u00EDky spoj\u00EDme",             // step = 10
               "s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "te\u010Dnov\u00E9ho troj\u00FAheln\u00EDku."],
              ["Nalezen\u00E9 pr\u016Fse\u010D\u00EDky spoj\u00EDme",             // step = 11
               "s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "te\u010Dnov\u00E9ho troj\u00FAheln\u00EDku."],
              ["Nalezen\u00E9 pr\u016Fse\u010D\u00EDky spoj\u00EDme",             // step = 12
               "s odpov\u00EDdaj\u00EDc\u00EDmi vrcholy",
               "te\u010Dnov\u00E9ho troj\u00FAheln\u00EDku."],
              ["Tyto t\u0159i spojnice proch\u00E1zej\u00ED bodem,",         // step = 13
               "kter\u00FD je naz\u00FDv\u00E1n Exeter bod."]
              ]; 
