// Dreiecks-Labor, Gergonne-Gerade, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 27.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2017"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["M\u00E1me troj\u00FAheln\u00EDk ABC se svou",              // step = 0
               "kru\u017Enic\u00ED vepsanou."], 
              ["Vyzna\u010Dme si body, ve kter\u00FD se",         // step = 1
               "kru\u017Enice dot\u00FDk\u00E1 stran troj\u00FAheln\u00EDku."],
              ["Vyzna\u010Dme si body, ve kter\u00FD se",         // step = 2
               "kru\u017Enice dot\u00FDk\u00E1 stran troj\u00FAheln\u00EDku."],
              ["Vyzna\u010Dme si body, ve kter\u00FD se",         // step = 3
               "kru\u017Enice dot\u00FDk\u00E1 stran troj\u00FAheln\u00EDku."],
              ["Spojnice dotykov\u00FDch bod\u016F u A ",         // step = 4
               "se prot\u00EDn\u00E1 s p\u0159\u00EDmkou BC."],
              ["Obdobn\u011B spojnice dotykov\u00FDch",         // step = 5
               "bod\u016F u B prot\u00EDn\u00E1 p\u0159\u00EDmku CA."],
              ["A kone\u010Dn\u011B spojnice dotykov\u00FDch",           // step = 6
               "bod\u016F u C prot\u00EDn\u00E1 p\u0159\u00EDmku AB."],
              ["Tyto t\u0159i nalezen\u00E9 body le\u017E\u00ED na",        // step = 7
               "p\u0159\u00EDmce, kter\u00E1 se naz\u00FDv\u00E1",
               "Gergonneova p\u0159\u00EDmka."]];






