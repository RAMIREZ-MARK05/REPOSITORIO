// Dreiecks-Labor, H�hen und H�henschnittpunkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 21.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var orthocenter = "H";

var text03 = [["V\u00FD\u0161ka troj\u00FAheln\u00EDku je kolmice",	         // step = 0
               "veden\u00E1 z dan\u00E9ho vrcholu",
               "k protilehl\u00E9 stran\u011B nebo jej\u00EDmu",
               "prodlou\u017Een\u00ED."], 
              ["V\u00FD\u0161ka troj\u00FAheln\u00EDku je kolmice",	         // step = 1
               "veden\u00E1 z dan\u00E9ho vrcholu",
               "k protilehl\u00E9 stran\u011B nebo jej\u00EDmu",
               "prodlou\u017Een\u00ED."],
              ["V\u00FD\u0161ka troj\u00FAheln\u00EDku je kolmice",	         // step = 2
               "veden\u00E1 z dan\u00E9ho vrcholu",
               "k protilehl\u00E9 stran\u011B nebo jej\u00EDmu",
               "prodlou\u017Een\u00ED."],
              ["V\u0161echny t\u0159i v\u00FD\u0161ky troj\u00FAheln\u00EDku",
               "se prot\u00EDnaj\u00ED v bod\u011B H, kter\u00FD se",
               "naz\u00FDv\u00E1 pr\u016Fse\u010D\u00EDk v\u00FD\u0161ek nebo t\u00E9\u017E",
               "ortocentrum."],
              ["Ot\u00E1zka:",
               "Za jak\u00FDch podm\u00EDnek le\u017E\u00ED pr\u016Fse\u010D\u00EDk",
               "v\u00FD\u0161ek mimo troj\u00FAheln\u00EDk?"],
              ["Odpov\u011B\u010F:",
               "Pokud m\u00E1 troj\u00FAheln\u00EDk tup\u00FD \u00FAhel,",
               "le\u017E\u00ED pr\u016Fse\u010Dk v\u00FD\u0161ek mimo",
               "troj\u00FAheln\u00EDk.",
               "Pokud je troj\u00FAheln\u00EDk pravo\u00FAhl\u00FD,",
               "shoduje se pr\u016Fse\u010Dk v\u00FD\u0161ek",
               "s vrcholem prav\u00E9ho \u00FAhlu."]];
