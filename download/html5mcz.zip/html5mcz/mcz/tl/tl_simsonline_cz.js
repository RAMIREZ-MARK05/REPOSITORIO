// Dreiecks-Labor, Simson-Gerade, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.09.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2017"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var givenPoint = "P";

var text03 = [["Jsou d\u00E1ny troj\u00FAheln\u00EDk ABC a bod P."],             // step = 0
              ["Z bodu P vedeme kolmice ke",              // step = 1
               "stran\u00E1m nebo k jejich prodlou\u017Een\u00ED."],
              ["Z bodu P vedeme kolmice ke",              // step = 2
               "stran\u00E1m nebo k jejich prodlou\u017Een\u00ED."],
              ["Z bodu P vedeme kolmice ke",              // step = 3
               "stran\u00E1m nebo k jejich prodlou\u017Een\u00ED."],
              ["Nyn\u00ED zkuste pohybovat bodem P",          // step = 4
               "tak, aby paty t\u011Bchto kolmic le\u017Eely",
               "na spole\u010Dn\u00E9 p\u0159\u00EDmce."],
              ["Nyn\u00ED zkuste pohybovat bodem P",          // step = 5
               "tak, aby paty t\u011Bchto kolmic le\u017Eely",
               "na spole\u010Dn\u00E9 p\u0159\u00EDmce."],
              ["Teprve, pokud tento bod P le\u017E\u00ED",            // step = 6
               "na kru\u017Enici opsan\u00E9 troj\u00FAheln\u00EDku,",
               "le\u017E\u00ED paty komnic ke stran\u00E1m",
               "(k jejich prodlou\u017En\u00ED) na p\u0159\u00EDmce.",
               "Tato p\u0159\u00EDmka se naz\u00FDv\u00E1 Simsonova",
               "p\u0159\u00EDmka bodu P a troj\u00FAheln\u00EDku ABC."]];
