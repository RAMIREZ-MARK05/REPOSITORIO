// Dreiecks-Labor, Nagel-Punkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 25.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var nagelpoint = "N";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC se sv\u00FDmi",              // step = 0
               "t\u0159emi kru\u017Enicemi p\u0159ipsan\u00FDmi."],
              ["Nyn\u00ED spoj\u00EDme vrcholy troj\u00FAheln\u00EDku",          // step = 1
               "s protilehl\u00FDmi dotykov\u00FDmi body",
               "kru\u017Enic p\u0159ipsan\u00FDch."],
              ["Nyn\u00ED spoj\u00EDme vrcholy troj\u00FAheln\u00EDku",          // step = 2
               "s protilehl\u00FDmi dotykov\u00FDmi body",
               "kru\u017Enic p\u0159ipsan\u00FDch."],
              ["Nyn\u00ED spoj\u00EDme vrcholy troj\u00FAheln\u00EDku",          // step = 3
               "s protilehl\u00FDmi dotykov\u00FDmi body",
               "kru\u017Enic p\u0159ipsan\u00FDch."],
              ["Nyn\u00ED spoj\u00EDme vrcholy troj\u00FAheln\u00EDku",          // step = 4
               "s protilehl\u00FDmi dotykov\u00FDmi body",
               "kru\u017Enic p\u0159ipsan\u00FDch."],
              ["Nyn\u00ED spoj\u00EDme vrcholy troj\u00FAheln\u00EDku",          // step = 5
               "s protilehl\u00FDmi dotykov\u00FDmi body",
               "kru\u017Enic p\u0159ipsan\u00FDch."],
              ["Nyn\u00ED spoj\u00EDme vrcholy troj\u00FAheln\u00EDku",          // step = 6
               "s protilehl\u00FDmi dotykov\u00FDmi body",
               "kru\u017Enic p\u0159ipsan\u00FDch."],
              ["Tyto t\u0159i spojnice se prot\u00EDnaj\u00ED",             // step = 7
               "v jednom bod\u011B. Tento bod N",
               "se naz\u00FDv\u00E1 Nagel\u016Fv bod."]
               ];
