// Dreiecks-Labor, Bevan-Punkt,  tschechische Texte (Miroslav Panos)
// Letzte �nderung 25.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2023"; 
var translator = "M. Pano&scaron; 2023";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var bevanpoint = "V";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC s trojic\u00ED",              // step = 0
               "kru\u017Enic p\u0159ipsan\u00FDch."],
              ["Op\u00ED\u0161eme kru\u017Enici proch\u00E1zej\u00EDc\u00ED",       // step = 1
               "st\u0159edy kru\u017Enic p\u0159ipsan\u00FDch."],
              ["St\u0159ed V t\u00E9to kru\u017Enice se",                           // step = 2
               "naz\u00FDv\u00E1 Bevan\u016Fv bod."],
              ["Co vznikne, pokud spoj\u00EDme",                                    // step = 3
               "st\u0159edy kru\u017Enic p\u0159ipsan\u00FDch",
               "s Bevanov\u00FDm bodem?"],
              ["P\u0159\u00EDmky spojuj\u00EDc\u00ED st\u0159edy kru\u017Enic",     // step = 4
               "p\u0159ipsan\u00FDch s Bevanov\u00FDm bodem",
               "jsou kolm\u00E9 na p\u0159\u00EDslu\u0161n\u00E9 strany",
               "dan\u00E9ho troj\u00FAheln\u00EDku."],
              ["Lze vytvo\u0159it i spojinci se st\u0159edy",                       // step = 5
               "kru\u017Enic opsan\u00E9 a vepsan\u00E9."],
              ["St\u0159ed kru\u017Enice opsan\u00E9 je st\u0159edem",              // step = 6
               "\u00FAse\u010Dky spojuj\u00EDc\u00ED Bevan\u016Fv bod a",
               "st\u0159ed kru\u017Enice vepsan\u00E9."],
              ["Dal\u0161\u00ED pozoruhodn\u00E1 vlastnost",                        // step = 7
               "se t\u00FDk\u00E1 Eulerovy p\u0159\u00EDmky,",
               "kter\u00E1 proch\u00E1z\u00ED pr\u016Fse\u010D\u00EDkem",
               "v\u00FD\u0161ek, t\u011B\u017Ei\u0161t\u011Bm a st\u0159edem",
               "kru\u017Enice opsan\u00E9."],
              ["Bevan\u016Fv bod je od Eulerovy",                                   // step = 8
               "p\u0159\u00EDmky vzd\u00E1len stejn\u011B jako",
               "je od n\u00ED vzd\u00E1len st\u0159ed",
               "kru\u017Enice vepsan\u00E9."]

               ];






