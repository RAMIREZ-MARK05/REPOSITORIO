// Dreiecks-Labor, Schiffler-Punkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 29.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var centroid = "S";
var circumcenter = "U";
var orthocenter = "H";
var incenter = "I";

var text03 = [["Eulerova p\u0159\u00EDmka troj\u00FAheln\u00EDku se",          // step = 0
               "vyzna\u010Duje t\u00EDm ..."],
              ["Eulerova p\u0159\u00EDmka troj\u00FAheln\u00EDku se",          // step = 1
               "vyzna\u010Duje t\u00EDm, \u017Ee proch\u00E1z\u00ED t\u011B\u017Ei\u0161t\u011Bm,",
               "..."],
              ["Eulerova p\u0159\u00EDmka troj\u00FAheln\u00EDku se",          // step = 2
               "vyzna\u010Duje t\u00EDm, \u017Ee proch\u00E1z\u00ED t\u011B\u017Ei\u0161t\u011Bm,",
               "st\u0159edem kru\u017Enice opsan\u00E9 ..."],
              ["Eulerova p\u0159\u00EDmka troj\u00FAheln\u00EDku se",          // step = 3
               "vyzna\u010Duje t\u00EDm, \u017Ee proch\u00E1z\u00ED t\u011B\u017Ei\u0161t\u011Bm,",
               "st\u0159edem kru\u017Enice opsan\u00E9 a pr\u016Fse-",
               "\u010D\u00EDkem v\u00FD\u0161ek."],
              ["Nyn\u00ED spoj\u00EDme vrcholy troj\u00FAheln\u00EDku",            // step = 4
               "se st\u0159edem kru\u017Enice vepsan\u00E9,",
               "tak\u017Ee vzniknou t\u0159i d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDky."],
              ["Tyto d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDky (ABI, BCI a",        // step = 5
               "CAI) maj\u00ED tak\u00E9 svou Eulerovu",
               "p\u0159\u00EDmku."],
              ["Tyto d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDky (ABI, BCI a",        // step = 6
               "CAI) maj\u00ED tak\u00E9 svou Eulerovu",
               "p\u0159\u00EDmku."],
              ["Tyto d\u00EDl\u010D\u00ED troj\u00FAheln\u00EDky (ABI, BCI a",        // step = 7
               "CAI) maj\u00ED tak\u00E9 svou Eulerovu",
               "p\u0159\u00EDmku."],
              ["Eulerova p\u0159\u00EDmka p\u016Fvodn\u00EDho",          // step = 8
               "troj\u00FAheln\u00EDku a Eulerovy p\u0159\u00EDmky",
               "d\u00EDl\u010D\u00EDch troj\u00FAheln\u00EDk\u016F se prot\u00EDnaj\u00ED",
               "v jednom bod\u011B."],
              ["Podle jeho objevitele se tento bod",
               "naz\u00FDv\u00E1 Schiffler\u016Fv bod."]];               // step = 9
