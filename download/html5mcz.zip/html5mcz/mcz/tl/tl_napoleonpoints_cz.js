// Dreiecks-Labor, Napoleon-Punkte, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 28.08.2022

// Texte in HTML-Schreibweise:

var text02 = "Nov&yacute; start";
var text03 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var napoleonpoint1 = "N";
var napoleonpoint2 = "N'";

// Text f�r das Auswahlfeld:

var text01 = ["1. Napoleon\u016Fv bod", "2. Napoleon\u016Fv bod"];

// Text f�r den 1. Napoleon-Punkt:

var text04 = [["Nad stranami libovoln\u00E9ho",    // step = 0
               "troj\u00FAheln\u00EDku nar\u00FDsujeme t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nad stranami libovoln\u00E9ho",    // step = 1
               "troj\u00FAheln\u00EDku nar\u00FDsujeme t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nad stranami libovoln\u00E9ho",    // step = 2
               "troj\u00FAheln\u00EDku nar\u00FDsujeme t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nad stranami libovoln\u00E9ho",    // step = 3
               "troj\u00FAheln\u00EDku nar\u00FDsujeme t\u0159i",
               "rovnostrann\u00E9 troj\u00FAheln\u00EDky."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 4
               "troj\u00FAheln\u00EDk\u016F s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 5
               "troj\u00FAheln\u00EDk\u016F s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 6
               "troj\u00FAheln\u00EDk\u016F s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 7
               "troj\u00FAheln\u00EDk\u016F s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 8
               "troj\u00FAheln\u00EDk\u016F s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 9
               "troj\u00FAheln\u00EDk\u016F s protilehl\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Ukazuje se, \u017Ee se tyto spojnice",        // step = 10
               "navz\u00E1jem prot\u00EDnaj\u00ED v jednom bod\u011B N.",
               "Tento bod se naz\u00FDv\u00E1 1. Napoleon\u016Fv",
               "bod troj\u00FAheln\u00EDku ABC."]];
               
// Text f�r den 2. Napoleon-Punkt:

var text05 = [["Pod strany libovoln\u00E9ho troj\u00FAheln\u00EDku",    // step = 0
               "nar\u00FDsujeme t\u0159i rovnostrann\u00E9",
               "troj\u00FAheln\u00EDky."],
              ["Pod strany libovoln\u00E9ho troj\u00FAheln\u00EDku",    // step = 1
               "nar\u00FDsujeme t\u0159i rovnostrann\u00E9",
               "troj\u00FAheln\u00EDky."],
              ["Pod strany libovoln\u00E9ho troj\u00FAheln\u00EDku",    // step = 2
               "nar\u00FDsujeme t\u0159i rovnostrann\u00E9",
               "troj\u00FAheln\u00EDky."],
              ["Pod strany libovoln\u00E9ho troj\u00FAheln\u00EDku",    // step = 3
               "nar\u00FDsujeme t\u0159i rovnostrann\u00E9",
               "troj\u00FAheln\u00EDky."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 4
               "troj\u00FAheln\u00EDk\u016F s p\u0159\u00EDslu\u0161n\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 5
               "troj\u00FAheln\u00EDk\u016F s p\u0159\u00EDslu\u0161n\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 6
               "troj\u00FAheln\u00EDk\u016F s p\u0159\u00EDslu\u0161n\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 7
               "troj\u00FAheln\u00EDk\u016F s p\u0159\u00EDslu\u0161n\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 8
               "troj\u00FAheln\u00EDk\u016F s p\u0159\u00EDslu\u0161n\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Nyn\u00ED spoj\u00EDme t\u011B\u017Ei\u0161t\u011B t\u011Bchto",            // step = 10
               "troj\u00FAheln\u00EDk\u016F s p\u0159\u00EDslu\u0161n\u00FDmi vrcholy",
               "p\u016Fvodn\u00EDho troj\u00FAheln\u00EDku."],
              ["Ukazuje se, \u017Ee se tyto spojnice",        // step = 10
               "navz\u00E1jem prot\u00EDnaj\u00ED v jednom",
               "bod\u011B N'. Tento bod se naz\u00FDv\u00E1",
               "2. Napoleon\u016Fv bod troj\u00FAheln\u00EDku."]
               ];
