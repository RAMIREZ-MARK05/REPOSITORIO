// Dreiecks-Labor, Fuhrmann-Dreieck und Fuhrmann-Kreis, tschechische Texte
// Letzte �nderung 27.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2019"; 
var translator = "M. Pano&scaron; 2020";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var fuhrmannpoint = "F";    
var orthocenter = "H";    
var nagelpoint = "N";    

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC i s jeho",
               "kru\u017Enic\u00ED opsanou."],
              ["Nyn\u00ED postupn\u011B vezmeme st\u0159edy",
               "p\u0159\u00EDslu\u0161n\u00FDch oblouk\u016F..."],
              ["Nyn\u00ED postupn\u011B vezmeme st\u0159edy",
               "p\u0159\u00EDslu\u0161n\u00FDch oblouk\u016F..."],
              ["Nyn\u00ED postupn\u011B vezmeme st\u0159edy",
               "p\u0159\u00EDslu\u0161n\u00FDch oblouk\u016F..."],
              ["Nyn\u00ED postupn\u011B vezmeme st\u0159edy",
               "p\u0159\u00EDslu\u0161n\u00FDch oblouk\u016F a zobraz\u00EDme",
               "je osov\u011B symetricky podle strany."],
              ["Nyn\u00ED postupn\u011B vezmeme st\u0159edy",
               "p\u0159\u00EDslu\u0161n\u00FDch oblouk\u016F a zobraz\u00EDme",
               "je osov\u011B symetricky podle strany."],
              ["Nyn\u00ED postupn\u011B vezmeme st\u0159edy",
               "p\u0159\u00EDslu\u0161n\u00FDch oblouk\u016F a zobraz\u00EDme",
               "je osov\u011B symetricky podle strany."],
              ["Takto vytvo\u0159en\u00FD troj\u00FAheln\u00EDk se",
               "naz\u00FDv\u00E1 Fuhrmann\u016Fv troj\u00FAheln\u00EDk."],
              ["Kru\u017Enici opsanou tomuto",
               "troj\u00FAheln\u00EDku pak naz\u00FDv\u00E1me",
               "Fuhrmannova kru\u017Enice."],
              ["Na Fuhrmannov\u011B kru\u017Enici",
               "nap\u0159\u00EDklad le\u017E\u00ED pr\u016Fse\u010D\u00EDk v\u00FD\u0161ek",
               "(tzv. ortocentrum)."],
              ["Podobn\u011B na Fuhrmannov\u011B kru\u017Enici",
               "le\u017E\u00ED tzv. Nagel\u016Fv bod troj\u00FAheln\u00EDku.",
               "(pr\u016Fse\u010D\u00EDk spojnic vrchol\u016F a dob\u016F",
               "dotyku kru\u017Enic p\u0159ipsan\u00FDch)"],
              ["V\u0161imli jste si n\u011B\u010Deho dal\u0161\u00EDho?"],
              ["Spojnice Nagelova bodu a pr\u016Fse\u010D\u00EDku",
               "v\u00FD\u0161ek (ortocentra) je pr\u016Fm\u011Brem",
               "Fuhrmannovy kru\u017Enice."]];
               







