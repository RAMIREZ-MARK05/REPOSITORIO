// Dreiecks-Labor, Malfatti-Kreise, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 28.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["T\u0159i Malfattiho kru\u017Enice troj\u00FAheln\u00EDku",           // step = 0
               "jsou ur\u010Deny dotykem s jednou",
               "stranou troj\u00FAheln\u00EDku a s dv\u011Bma",
               "zbyl\u00FDmi kru\u017Enicemi."],
              ["T\u0159i Malfattiho kru\u017Enice troj\u00FAheln\u00EDku",           // step = 1
               "jsou ur\u010Deny dotykem s jednou",
               "stranou troj\u00FAheln\u00EDku a s dv\u011Bma",
               "zbyl\u00FDmi kru\u017Enicemi."],
              ["T\u0159i Malfattiho kru\u017Enice troj\u00FAheln\u00EDku",           // step = 2
               "jsou ur\u010Deny dotykem s jednou",
               "stranou troj\u00FAheln\u00EDku a s dv\u011Bma",
               "zbyl\u00FDmi kru\u017Enicemi."],
              ["T\u0159i Malfattiho kru\u017Enice troj\u00FAheln\u00EDku",           // step = 3
               "jsou ur\u010Deny dotykem s jednou",
               "stranou troj\u00FAheln\u00EDku a s dv\u011Bma",
               "zbyl\u00FDmi kru\u017Enicemi."],
              ["Ot\u00E1zka:",                                   // step = 4
               "Na jak\u00E9 v\u00FDznamn\u00E9 p\u0159\u00EDmce troj-",
               "\u00FAheln\u00EDku le\u017E\u00ED st\u0159ed kru\u017Enice, kter\u00E1",
               "le\u017E\u00ED nejbl\u00ED\u017Ee bodu A?"],
              ["Odpov\u011B\u010F:",                                 // step = 5
               "Tento st\u0159ed kru\u017Enice mus\u00ED le\u017Eet",
               "na ose \u00FAhlu \u03B1."]
               ];
