// Dreiecks-Labor, Mittelsenkrechten, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 22.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var circumcenter = "U";

var text03 = [["Pro zadan\u00FD troj\u00FAheln\u00EDk ABC je t\u0159eba",          // step = 0
               "nar\u00FDsovat v\u0161echny t\u0159i osy stran."], 
              ["Za\u010Dneme s osou \u00FAse\u010Dky [BC]."],         // step = 1
              ["Za\u010Dneme s osou \u00FAse\u010Dky [BC].",         // step = 2
               "Body t\u00E9to p\u0159\u00EDmky maj\u00ED stejnou",
               "vzd\u00E1lenost od bod\u016F B a C."],  
              ["Stejn\u011B tak i body osy \u00FAse\u010Dky [CA] ..."],            // step = 3
              ["Stejn\u011B tak i body osy \u00FAse\u010Dky [CA]",            // step = 4
               "maj\u00ED stejnou vzd\u00E1lenost od bod\u016F",
               "A a C."],
              ["Pr\u016Fse\u010Dk t\u011Bchto dvou os (U) je tedy",           // step = 5
               "stejn\u011B vzd\u00E1len od v\u0161ech t\u0159\u00ED",
               "vrchol\u016F troj\u00FAheln\u00EDk\u016F."],
              ["Vzhledem k tomu, \u017Ee pr\u016Fse\u010D\u00EDk (U)",       // step = 6
               "m\u00E1 stejnou vzd\u00E1lenost od A a B,",
               "mus\u00ED le\u017Eet i na ose t\u0159et\u00ED strany."], 
              ["Osy stran troj\u00FAheln\u00EDku se prot\u00EDnaj\u00ED",         // step = 7
               "v jednom bod\u011B. Tento bod je stejn\u011B",
               "vzd\u00E1len od v\u0161ech t\u0159\u00ED vrchol\u016F",
               "troj\u00FAheln\u00EDku."],
              ["Ot\u00E1zka:",                                   // step = 8
               "Za jak\u00FDch podm\u00EDnek le\u017E\u00ED pr\u016Fse\u010D\u00EDk",
               "os stran mimo troj\u00FAheln\u00EDk a kdy le\u017E\u00ED",
               "na jeho hranici?"],
              ["Odpov\u011B\u010F:",                                 // step = 9
               "Pokud m\u00E1 troj\u00FAheln\u00EDk tup\u00FD \u00FAhel,",
               "le\u017E\u00ED pr\u016Fse\u010Dk os stran vn\u011B",
               "troj\u00FAheln\u00EDku.",
               "Pokud je troj\u00FAheln\u00EDk pravo\u00FAhl\u00FD,",
               "shoduje se pr\u016Fse\u010Dk os stran",
               "se st\u0159edem p\u0159epony (strany",
               "proti prav\u00E9mu \u00FAhlu)."]];
