// Dreiecks-Labor, Innenwinkel, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 27.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["\u00DAhel vyty\u010Den\u00FD dv\u011Bma stranami",       // step = 0
               "troj\u00FAheln\u00EDku se naz\u00FDv\u00E1 vnit\u0159n\u00ED \u00FAhel."],
              ["Vnit\u0159n\u00ED \u00FAhel u vrcholu A se ozna\u010Duje",         // step = 1
               "\u0159eck\u00FDm p\u00EDsmenem \u03B1 (alfa)."],
              ["Vnit\u0159n\u00ED \u00FAhel u vrcholu B se ozna\u010Duje",         // step = 2
               "\u0159eck\u00FDm p\u00EDsmenem \u03B2 (beta)."],
              ["T\u0159et\u00ED \u00FAhel (\u00FAhel u vrcholu C) se",           // step = 3
               "obdobn\u011B ozna\u010Duje \u03B3 (gama)."],
              ["Ot\u00E1zka:",                                   // step = 5
               "Co dostaneme, pokud se\u010Dteme",
               "v\u0161echny t\u0159i vnit\u0159n\u00ED \u00FAhly?"],
              ["Odpov\u011B\u010F:",                                 // step = 6
               "Sou\u010Det vnit\u0159n\u00EDch \u00FAhl\u016F v troj\u00FAheln\u00EDku",
               "je 180\u00B0."]];
