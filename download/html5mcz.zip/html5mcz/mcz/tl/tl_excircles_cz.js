// Dreiecks-Labor, Ankreise, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 22.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Kru\u017Enice p\u0159ipsan\u00E9 jsou kru\u017Enice,",          // step = 0
               "kter\u00E9 se dot\u00FDkaj\u00ED jedn\u00E9 strany",
               "troj\u00FAheln\u00EDku a z\u00E1rove\u0148 se dot\u00FDkaj\u00ED",
               "prodlou\u017Een\u00ED dvou zb\u00FDvaj\u00EDc\u00EDch stran."], 
              ["St\u0159edy trojice kru\u017Enic p\u0159ipsan\u00FDch",       // step = 1
               "najdeme velmi podobn\u011B jako",
               "st\u0159ed kru\u017Enice vepsan\u00E9."],
              ["Nar\u00FDsuje se osa vnit\u0159n\u00EDho \u00FAhlu",           // step = 2
               "(zde \u03B1) ..."],  
              ["... a protneme ji s osami vn\u011Bj\u0161\u00EDch",       // step = 3
               "\u00FAhl\u016F u zbyl\u00FDch dvou vrchol\u016F."], 
              ["... a protneme ji s osami vn\u011Bj\u0161\u00EDch",       // step = 4
               "\u00FAhl\u016F u zbyl\u00FDch dvou vrchol\u016F."], 
              ["... a protneme ji s osami vn\u011Bj\u0161\u00EDch",       // step = 5
               "\u00FAhl\u016F u zbyl\u00FDch dvou vrchol\u016F."], 
              ["Obdobn\u00FDm zp\u016Fsobem najdeme",         // step = 6
               "st\u0159ed dal\u0161\u00ED kru\u017Enice p\u0159ipsan\u00E9."],
              ["Obdobn\u00FDm zp\u016Fsobem najdeme",         // step = 7
               "st\u0159ed dal\u0161\u00ED kru\u017Enice p\u0159ipsan\u00E9."],
              ["Obdobn\u00FDm zp\u016Fsobem najdeme",         // step = 8
               "st\u0159ed dal\u0161\u00ED kru\u017Enice p\u0159ipsan\u00E9."],
              ["Obdobn\u00FDm zp\u016Fsobem najdeme",         // step = 9
               "st\u0159ed dal\u0161\u00ED kru\u017Enice p\u0159ipsan\u00E9."],
              ["Samoz\u0159ejm\u011B tento postup funguje",  // step = 10
               "i pro t\u0159et\u00ED kru\u017Enici."],
              ["Samoz\u0159ejm\u011B tento postup funguje",  // step = 11
               "i pro t\u0159et\u00ED kru\u017Enici."],
              ["Samoz\u0159ejm\u011B tento postup funguje",  // step = 12
               "i pro t\u0159et\u00ED kru\u017Enici."],
              ["Samoz\u0159ejm\u011B tento postup funguje",  // step = 13
               "i pro t\u0159et\u00ED kru\u017Enici."],
              ["Ka\u017Ed\u00FD z nalezen\u00FDch bod\u016F m\u00E1",          // step = 14
               "stejnou vzd\u00E1lenost od dan\u00E9 strany",
               "a prodlou\u017Een\u00ED zbyl\u00FDch stran."],
              ["Ka\u017Ed\u00FD z nalezen\u00FDch bod\u016F m\u00E1",          // step = 15
               "stejnou vzd\u00E1lenost od dan\u00E9 strany",
               "a prodlou\u017Een\u00ED zbyl\u00FDch stran."],
              ["Ka\u017Ed\u00FD z nalezen\u00FDch bod\u016F m\u00E1",          // step = 16
               "stejnou vzd\u00E1lenost od dan\u00E9 strany",
               "a prodlou\u017Een\u00ED zbyl\u00FDch stran."],
              ["Z tohoto d\u016Fvodu je pak mo\u017En\u00E9",    // step = 17
               "nar\u00FDsovat danou kru\u017Enici p\u0159ipsanou."],
              ["Z tohoto d\u016Fvodu je pak mo\u017En\u00E9",    // step = 18
               "nar\u00FDsovat danou kru\u017Enici p\u0159ipsanou."],
              ["Z tohoto d\u016Fvodu je pak mo\u017En\u00E9",    // step = 19
               "nar\u00FDsovat danou kru\u017Enici p\u0159ipsanou."]];
