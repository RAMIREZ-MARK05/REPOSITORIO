// Dreiecks-Labor, Apollonios-Kreis und Apollonios-Punkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 25.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Apolloniova kru\u017Enice je kru\u017Enice",         // step = 0
               "opsan\u00E1 v\u0161em t\u0159em kru\u017Enic\u00EDm",
               "p\u0159ipsan\u00FDm."], 
              ["Apolloniova kru\u017Enice je kru\u017Enice",         // step = 1
               "opsan\u00E1 v\u0161em t\u0159em kru\u017Enic\u00EDm",
               "p\u0159ipsan\u00FDm."], 
              ["Nyn\u00ED se pod\u00EDvejme na body dotyku",      // step = 2
               "Apolloniovy kru\u017Enice a kru\u017Enic",
               "p\u0159ipsan\u00FDch."], 
              ["Nyn\u00ED se pod\u00EDvejme na body dotyku",      // step = 3
               "Apolloniovy kru\u017Enice a kru\u017Enic",
               "p\u0159ipsan\u00FDch."], 
              ["Nyn\u00ED se pod\u00EDvejme na body dotyku",      // step = 4
               "Apolloniovy kru\u017Enice a kru\u017Enic",
               "p\u0159ipsan\u00FDch."], 
              ["Tyto dotykov\u00E9 body spoj\u00EDme",       // step = 5
               "s protilehl\u00FDmi vrcholy troj\u00FAheln\u00EDku."],
              ["Tyto dotykov\u00E9 body spoj\u00EDme",       // step = 6
               "s protilehl\u00FDmi vrcholy troj\u00FAheln\u00EDku."],
              ["Tyto dotykov\u00E9 body spoj\u00EDme",       // step = 7
               "s protilehl\u00FDmi vrcholy troj\u00FAheln\u00EDku."],
              ["Tyto spojnice se prot\u00EDnaj\u00ED v jednom",          // step = 8
               "bod\u011B, kter\u00FD naz\u00FDv\u00E1me",
               "tzv. Apolloni\u016Fv bod."]];






