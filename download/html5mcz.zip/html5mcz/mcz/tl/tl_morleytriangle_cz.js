// Dreiecks-Labor, Morley-Dreieck, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 28.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC. Vnit\u0159n\u00ED",             // step = 0
               "\u00FAhly rozd\u011Bl\u00EDme na t\u0159i stejn\u00E9 \u010D\u00E1sti."],
              ["Je d\u00E1n troj\u00FAheln\u00EDk ABC. Vnit\u0159n\u00ED",             // step = 1
               "\u00FAhly rozd\u011Bl\u00EDme na t\u0159i stejn\u00E9 \u010D\u00E1sti."],
              ["Je d\u00E1n troj\u00FAheln\u00EDk ABC. Vnit\u0159n\u00ED",             // step = 2
               "\u00FAhly rozd\u011Bl\u00EDme na t\u0159i stejn\u00E9 \u010D\u00E1sti."],
              ["Je d\u00E1n troj\u00FAheln\u00EDk ABC. Vnit\u0159n\u00ED",             // step = 3
               "\u00FAhly rozd\u011Bl\u00EDme na t\u0159i stejn\u00E9 \u010D\u00E1sti."],
              ["Pro ka\u017Edou stranu vezmeme",        // step = 4
               "pr\u016Fse\u010D\u00EDk d\u011Bl\u00EDc\u00EDch p\u0159\u00EDmek, kter\u00E9",
               "proch\u00E1zej\u00ED koncov\u00FDmi body dan\u00E9",
               "strany a prot\u00EDnaj\u00ED se bl\u00ED\u017Ee k t\u00E9to",
               "stran\u011B."],
              ["Pro ka\u017Edou stranu vezmeme",        // step = 5
               "pr\u016Fse\u010D\u00EDk d\u011Bl\u00EDc\u00EDch p\u0159\u00EDmek, kter\u00E9",
               "proch\u00E1zej\u00ED koncov\u00FDmi body dan\u00E9",
               "strany a prot\u00EDnaj\u00ED se bl\u00ED\u017Ee k t\u00E9to",
               "stran\u011B."],
              ["Pro ka\u017Edou stranu vezmeme",        // step = 6
               "pr\u016Fse\u010D\u00EDk d\u011Bl\u00EDc\u00EDch p\u0159\u00EDmek, kter\u00E9",
               "proch\u00E1zej\u00ED koncov\u00FDmi body dan\u00E9",
               "strany a prot\u00EDnaj\u00ED se bl\u00ED\u017Ee k t\u00E9to",
               "stran\u011B."],
              ["Takto z\u00EDskan\u00E9 body vytv\u00E1\u0159ej\u00ED",            // step = 7
               "troj\u00FAheln\u00EDk."],
              ["Takto z\u00EDskan\u00E9 body vytv\u00E1\u0159ej\u00ED",            // step = 8
               "troj\u00FAheln\u00EDk."],
              ["Takto z\u00EDskan\u00E9 body vytv\u00E1\u0159ej\u00ED",            // step = 9
               "troj\u00FAheln\u00EDk."],
              ["Ot\u00E1zka:",                                   // step = 10
               "Jakou zvl\u00E1\u0161tn\u00ED vlastnost m\u00E1 tento",
               "Morley\u016Fv troj\u00FAheln\u00EDk?"],
              ["Odpov\u011B\u010F:",                                 // step = 11
               "Morley\u016Fv troj\u00FAheln\u00EDk je v\u017Edy",
               "rovnostrann\u00FD."]];
