// Dreiecks-Labor, Inkreis, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 22.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var incenter = "I";

var text03 = [["Pro zadan\u00FD troj\u00FAheln\u00EDk ABC je",           // step = 0
               "t\u0159eba nar\u00FDsovat kru\u017Enici, kter\u00E1",
               "se dot\u00FDk\u00E1 v\u0161ech t\u0159\u00ED stran troj-",
               "\u00FAheln\u00EDku. Tato kru\u017Enice se naz\u00FDv\u00E1",
               "kru\u017Enice vepsan\u00E1."], 
              ["St\u0159ed I kru\u017Enice vepsan\u00E9 mus\u00ED",          // step = 1
               "b\u00FDt ve stejn\u00E9 vzd\u00E1lenosti od v\u0161ech",
               "t\u0159\u00ED stran."],
              ["Pokud m\u00E1 m\u00EDt hledan\u00FD bod I stejnou",          // step = 2
               "vzd\u00E1lenost od stran [AB] a [AC] ..."],  
              ["... pak mus\u00ED le\u017Eet na ose \u00FAhlu \u03B1."],        // step = 3
              ["Proto, aby bod I m\u011Bl tak\u00E9 stejnou",         // step = 4
               "vzd\u00E1lenost od [AB] a [BC], mus\u00ED",
               "le\u017Eet na ose \u00FAhlu \u03B2."],
              ["Zcela obdobn\u011B p\u0159edchoz\u00EDmu",         // step = 5
               "dojdeme k z\u00E1v\u011Br, \u017Ee bod I le\u017E\u00ED",
               "tak\u00E9 i na ose \u00FAhlu \u03B3.",
               "(stejn\u00E1 vzd\u00E1lenost od [AC] a [BC])"], 
              ["Bodem I tedy mus\u00ED proch\u00E1zen",    // step = 6
               "v\u0161echny t\u0159i osy \u00FAhl\u016F."],
              ["Proto\u017Ee je bod I stejn\u011B vzd\u00E1len",          // step = 7
               "od v\u0161ech t\u0159\u00ED stran troj\u00FAheln\u00EDku",
               "m\u016F\u017Eeme kolem n\u011Bj nar\u00FDsovat",
               "kru\u017Enici, kter\u00E1 se stran dot\u00FDk\u00E1.",
               "To je hledan\u00E1 kru\u017Enice vepsan\u00E1."]];
