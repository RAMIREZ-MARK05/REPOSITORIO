// Dreiecks-Labor, Euler-Gerade, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 22.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var centroid = "S";
var circumcenter = "U";
var orthocenter = "H";

var text03 = [["V\u0161echny t\u0159i t\u011B\u017Enice troj\u00FAheln\u00EDku",              // step = 0
               "se prot\u00EDnaj\u00ED v t\u011B\u017Ei\u0161ti S a",
               "vz\u00E1jemn\u011B se d\u011Bl\u00ED ve zn\u00E1m\u00E9m",
               "pom\u011Bru 2:1."],
               ["Podobn\u011B se v\u0161echny t\u0159i  osy",          // step = 1
                "stran prot\u00EDnaj\u00ED v bod\u011B U - st\u0159edu",
                "kru\u017Enice opsan\u00E9 U."],
               ["A tak\u00E9 trojice v\u00FD\u0161ek se prot\u00EDn\u00E1",    // step = 2
                "v jednom bod\u011B H, kter\u00FD naz\u00FDv\u00E1me ",
                "jako pr\u016Fse\u010D\u00EDk v\u00FD\u0161ek nebo t\u00E9\u017E",
                "ortocentrum."],
               ["Pokud se pod\u00EDv\u00E1me na v\u0161echny",           // step = 3
                "tyto body najednou, vid\u00EDme, \u017Ee",
                "le\u017E\u00ED na p\u0159\u00EDmce.",
                "Tato p\u0159\u00EDmka je zn\u00E1m\u00E1 pod ozna-",
                "\u010Den\u00EDm Eulerova p\u0159\u00EDmka."],
               ["Ot\u00E1zka:",                                  // step = 4
                "Co m\u016F\u017Eme \u0159\u00EDci o vz\u00E1jemn\u00FDch",
                "vzd\u00E1lenostech bod\u016F H, S a U?"],
               ["Odpov\u011B\u010F:",                                // step = 5
                "Vzd\u00E1lenost mezi body H a S je",
                "dvojn\u00E1sobkem vzd\u00E1lenosti mezi",
                "body S a U."]];
