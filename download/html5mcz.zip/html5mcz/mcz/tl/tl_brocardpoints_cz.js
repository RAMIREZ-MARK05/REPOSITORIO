// Dreiecks-Labor, Brocard-Punkte, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 25.08.2022

// Texte in HTML-Schreibweise:

var text02 = "Nov&yacute; start";
var text03 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

// Text f�r das Auswahlfeld:

var text01 = ["1. Brocard\u016Fv bod", "2. Brocard\u016Fv bod"];

// Text f�r den 1. Brocard-Punkt:

var text04 = [["Je d\u00E1n - jako obvykle - obecn\u00FD",      // step = 0
               "troj\u00FAheln\u00EDk ABC."],
               ["Nar\u00FDsujeme kru\u017Enici, kter\u00E1",           // step = 1
                "proch\u00E1z\u00ED bodem A a v bod\u011B B",
                "se dot\u00FDk\u00E1 p\u0159\u00EDmky BC."],
               ["Druh\u00E1 kru\u017Enice proch\u00E1z\u00ED bodem B",        // step = 2
                "a obdobn\u011B se dot\u00FDk\u00E1 p\u0159\u00EDmky CA",
                "v bod\u011B C."],
               ["Stejn\u011B tak nar\u00FDsujeme i kru\u017Enici,",       // step = 3
                "kter\u00E1 proch\u00E1z\u00ED bodem C a dot\u00FDk\u00E1",
                "se p\u0159\u00EDmky AB v bod\u011B A."],
               ["Pod\u00EDv\u00E1me-li se na v\u0161echny",        // step = 4
                "t\u0159i kru\u017Enice najednou, vid\u00EDme ..."],
               ["... \u017Ee se vz\u00E1jemn\u011B prot\u00EDnaj\u00ED",      // step = 5
                "v jednom bod\u011B. Tento bod je",
                "ozna\u010Dov\u00E1n jako 1. Brocard\u016Fv bod",
                "troj\u00FAheln\u00EDku ABC"],
               ["Zaj\u00EDmav\u00E1 vlastnost tohoto bodu",      // step = 6
                "se uk\u00E1\u017Ee, kdy\u017E 1. Brocard\u016Fv bod",
                "spoj\u00EDme s vrcholy A, B, C ..."],
               ["Zaj\u00EDmav\u00E1 vlastnost tohoto bodu",      // step = 7
                "se uk\u00E1\u017Ee, kdy\u017E 1. Brocard\u016Fv bod",
                "spoj\u00EDme s vrcholy A, B, C ..."],
               ["Zaj\u00EDmav\u00E1 vlastnost tohoto bodu",      // step = 8
                "se uk\u00E1\u017Ee, kdy\u017E 1. Brocard\u016Fv bod",
                "spoj\u00EDme s vrcholy A, B, C ..."],
               ["... a vyzna\u010D\u00EDme \u00FAhly mezi t\u011Bmito",         // step = 9
                "spojnicemi a stranami troj\u00FAheln\u00EDku."],
               ["... a vyzna\u010D\u00EDme \u00FAhly mezi t\u011Bmito",         // step = 10
                "spojnicemi a stranami troj\u00FAheln\u00EDku."],
               ["... a vyzna\u010D\u00EDme \u00FAhly mezi t\u011Bmito",         // step = 11
                "spojnicemi a stranami troj\u00FAheln\u00EDku."],
               ["Tyto t\u0159i vyzna\u010Den\u00E9 \u00FAhly maj\u00ED",       // step = 12
                "stejnou velikost."]];
               
// Text f�r den 2. Brocard-Punkt:

var text05 = [["Je d\u00E1n - jako obvykle - obecn\u00FD",      // step = 0
               "troj\u00FAheln\u00EDk ABC."],
               ["Nar\u00FDsujeme kru\u017Enici, kter\u00E1",           // step = 1
                "proch\u00E1z\u00ED bodem A a v bod\u011B C",
                "se dot\u00FDk\u00E1 p\u0159\u00EDmky BC."],
               ["Druh\u00E1 kru\u017Enice proch\u00E1z\u00ED bodem C",        // step = 2
                "a obdobn\u011B se dot\u00FDk\u00E1 p\u0159\u00EDmky AB",
                "v bod\u011B B."],
               ["Stejn\u011B tak nar\u00FDsujeme i kru\u017Enici,",       // step = 3
                "kter\u00E1 proch\u00E1z\u00ED bodem B a dot\u00FDk\u00E1",
                "se p\u0159\u00EDmky AC v bod\u011B A."],
               ["Pod\u00EDv\u00E1me-li se na v\u0161echny",        // step = 4
                "t\u0159i kru\u017Enice najednou, vid\u00EDme ..."],
               ["... \u017Ee se vz\u00E1jemn\u011B prot\u00EDnaj\u00ED",      // step = 5
                "v jednom bod\u011B. Tento bod je",
                "ozna\u010Dov\u00E1n jako 2. Brocard\u016Fv bod",
                "troj\u00FAheln\u00EDku ABC"],
               ["Zaj\u00EDmav\u00E1 vlastnost tohoto bodu",      // step = 6
                "se uk\u00E1\u017Ee, kdy\u017E 2. Brocard\u016Fv bod",
                "spoj\u00EDme s vrcholy A, B, C ..."],
               ["Zaj\u00EDmav\u00E1 vlastnost tohoto bodu",      // step = 7
                "se uk\u00E1\u017Ee, kdy\u017E 2. Brocard\u016Fv bod",
                "spoj\u00EDme s vrcholy A, B, C ..."],
               ["Zaj\u00EDmav\u00E1 vlastnost tohoto bodu",      // step = 8
                "se uk\u00E1\u017Ee, kdy\u017E 2. Brocard\u016Fv bod",
                "spoj\u00EDme s vrcholy A, B, C ..."],
               ["... a vyzna\u010D\u00EDme \u00FAhly mezi t\u011Bmito",         // step = 9
                "spojnicemi a stranami troj\u00FAheln\u00EDku."],
               ["... a vyzna\u010D\u00EDme \u00FAhly mezi t\u011Bmito",         // step = 10
                "spojnicemi a stranami troj\u00FAheln\u00EDku."],
               ["... a vyzna\u010D\u00EDme \u00FAhly mezi t\u011Bmito",         // step = 11
                "spojnicemi a stranami troj\u00FAheln\u00EDku."],
               ["Tyto t\u0159i vyzna\u010Den\u00E9 \u00FAhly maj\u00ED",       // step = 12
                "stejnou velikost."]];
