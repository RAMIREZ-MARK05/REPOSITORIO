// Dreiecks-Labor, Spieker-Punkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 07.09.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var spiekerpoint = "Sp";

var text03 = [["V zadan\u00E9m troj\u00FAheln\u00EDku ABC",              // step = 0
               "vyzna\u010D\u00EDme st\u0159edy stran."],
              ["V zadan\u00E9m troj\u00FAheln\u00EDku ABC",              // step = 1
               "vyzna\u010D\u00EDme st\u0159edy stran."],
              ["V zadan\u00E9m troj\u00FAheln\u00EDku ABC",              // step = 2
               "vyzna\u010D\u00EDme st\u0159edy stran."],
              ["V zadan\u00E9m troj\u00FAheln\u00EDku ABC",              // step = 3
               "vyzna\u010D\u00EDme st\u0159edy stran."],
              ["Spojen\u00EDm t\u011Bchto st\u0159ed\u016F vytvo\u0159\u00EDme",           // step = 4
               "tvz. p\u0159\u00ED\u010Dkov\u00FD troj\u00FAheln\u00EDk."],
              ["Nyn\u00ED rozd\u011Bl\u00EDme vnit\u0159n\u00ED \u00FAhly p\u0159\u00ED\u010Dko-",               // step = 5
               "v\u00E9ho troj\u00FAheln\u00EDku na poloviny."],
              ["Nyn\u00ED rozd\u011Bl\u00EDme vnit\u0159n\u00ED \u00FAhly p\u0159\u00ED\u010Dko-",               // step = 6
               "v\u00E9ho troj\u00FAheln\u00EDku na poloviny."],
              ["Nyn\u00ED rozd\u011Bl\u00EDme vnit\u0159n\u00ED \u00FAhly p\u0159\u00ED\u010Dko-",               // step = 7
               "v\u00E9ho troj\u00FAheln\u00EDku na poloviny."],
              ["Pr\u016Fse\u010D\u00EDk t\u011Bchto os \u00FAhl\u016F p\u0159\u00ED\u010Dkov\u00E9ho",        // step = 8
               "troj\u00FAheln\u00EDku (t\u00E9\u017E st\u0159ed jeho kru\u017Enice",
               "vepsan\u00E9) se naz\u00FDv\u00E1 Spieker\u016Fv bod."]
               ];
