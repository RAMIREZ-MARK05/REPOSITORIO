// Dreiecks-Labor, Mittenpunkt, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.09.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var middlespoint = "M";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC i se sv\u00FDmi",              // step = 0
               "kru\u017Enicemi p\u0159ipsan\u00FDmi."],
              ["Nav\u00EDc vyzna\u010D\u00EDme st\u0159edy v\u0161ech",      // step = 1
               "t\u0159\u00ED stran."],
              ["Nav\u00EDc vyzna\u010D\u00EDme st\u0159edy v\u0161ech",      // step = 2
               "t\u0159\u00ED stran."],
              ["Nav\u00EDc vyzna\u010D\u00EDme st\u0159edy v\u0161ech",      // step = 3
               "t\u0159\u00ED stran."],
              ["Ka\u017Ed\u00FD st\u0159ed kru\u017Enice p\u0159ipsan\u00E9 ",             // step = 4
               "a st\u0159ed strany prolo\u017E\u00EDme p\u0159\u00EDmkou ..."],
              ["Ka\u017Ed\u00FD st\u0159ed kru\u017Enice p\u0159ipsan\u00E9 ",             // step = 5
               "a st\u0159ed strany prolo\u017E\u00EDme p\u0159\u00EDmkou ..."],
              ["Ka\u017Ed\u00FD st\u0159ed kru\u017Enice p\u0159ipsan\u00E9 ",             // step = 6
               "a st\u0159ed strany prolo\u017E\u00EDme p\u0159\u00EDmkou ..."],
              ["..., m\u016F\u017Eeme vid\u011Bt, \u017Ee se tyto p\u0159\u00EDmky",           // step = 7
               "prot\u00EDnaj\u00ED v jednom bod\u011B (M). Tento",
               "bod se naz\u00FDv\u00E1 st\u0159ed troj\u00FAheln\u00EDku."]];
