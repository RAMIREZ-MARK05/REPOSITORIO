// Dreiecks-Labor, H�henfu�punktdreieck, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 29.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var orthocenter = "H";

var text03 = [["Je d\u00E1n troj\u00FAheln\u00EDk ABC se sv\u00FDmi",          // step = 0
               "v\u00FD\u0161kami (tj. kolmice z vrchol\u016F",
               "k prot\u011Bj\u0161\u00ED stran\u011B nebo jej\u00EDmu",
               "prodlou\u017Een\u00ED).",
               "Pr\u016Fse\u010D\u00EDk v\u00FD\u0161ek ozna\u010D\u00EDme H."],
              ["Pro ka\u017Edou v\u00FD\u0161ku vyzna\u010D\u00EDme jej\u00ED",      // step = 1
               "patu."],
              ["Pro ka\u017Edou v\u00FD\u0161ku vyzna\u010D\u00EDme jej\u00ED",      // step = 2
               "patu."],
              ["Pro ka\u017Edou v\u00FD\u0161ku vyzna\u010D\u00EDme jej\u00ED",      // step = 3
               "patu."],
              ["Paty v\u00FD\u0161ek vz\u00E1jemn\u011B spoj\u00EDme."],          // step = 4
              ["Paty v\u00FD\u0161ek vz\u00E1jemn\u011B spoj\u00EDme."],          // step = 5
              ["Paty v\u00FD\u0161ek vz\u00E1jemn\u011B spoj\u00EDme."],          // step = 6
              ["Nov\u011B vznikl\u00FD troj\u00FAheln\u00EDk se naz\u00FDv\u00E1",              // step = 7
               "ortick\u00FD troj\u00FAheln\u00EDk."],
              ["Ot\u00E1zka:",                                   // step = 8
               "Jak\u00FD v\u00FDznam maj\u00ED v\u00FD\u0161ky v\u00FDchoz\u00EDho",
               "troj\u00FAheln\u00EDku vzhledem k ortick\u00E9mu",
               "troj\u00FAheln\u00EDku?"],
              ["Odpov\u011B\u010F:",                                 // step = 9
               "V\u00FD\u0161ky v\u00FDchoz\u00EDho troj\u00FAheln\u00EDku jsou",
               "osy \u00FAhl\u016F ortick\u00E9ho troj\u00FAheln\u00EDku."]];






