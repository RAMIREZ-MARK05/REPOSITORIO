// Dreiecks-Labor, Au�enwinkel, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 27.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Dopl\u0148kov\u00E9 \u00FAhly vnit\u0159n\u00EDch \u00FAhl\u016F",          // step = 0
               "troj\u00FAheln\u00EDku se naz\u00FDvaj\u00ED \u00FAhly",
               "vn\u011Bj\u0161\u00ED. Ka\u017Ed\u00E9mu vnit\u0159n\u00EDmu \u00FAhlu",
               "p\u0159\u00EDslu\u0161\u00ED dvojice vz\u00E1jemn\u011B stejn\u00FDch",
               "vn\u011Bj\u0161\u00EDch \u00FAhl\u016F."],
              ["Zde jsou zobrazeny oba vn\u011Bj\u0161\u00ED \u00FAhly",      // step = 1
               "p\u0159\u00EDslu\u0161n\u00E9 \u00FAhlu \u03B1.",
               "Velikost t\u011Bchto vn\u011Bj\u0161\u00EDch \u00FAhl\u016F se",
               "lehce ur\u010D\u00ED: \u03B1* = 180\u00B0 \u2212 \u03B1"],
              ["Pro velikost vn\u011Bj\u0161\u00EDch \u00FAhl\u016F k \u00FAhlu",     // step = 2
               "\u03B2 z\u00EDsk\u00E1me: \u03B2* = 180\u00B0 \u2212 \u03B2"],
              ["Tot\u00E9\u017E plat\u00ED i pro vn\u011Bj\u0161\u00ED \u00FAhly",       // step = 3
               "k \u00FAhlu \u03B3: \u03B3* = 180\u00B0 \u2212 \u03B3"],
              ["Ot\u00E1zka:",
               "Jak\u00FD je vztah mezi vn\u011Bj\u0161\u00EDm \u00FAhlem",             // step = 4
               "a dv\u011Bma zbyl\u00FDmi vnit\u0159n\u00EDmi \u00FAhly,",
               "nap\u0159\u00EDklad mezi vn\u011Bj\u0161\u00EDm \u00FAhlem \u03B3*",
               "a vnit\u0159n\u00EDmi \u00FAhly \u03B1 a \u03B2?"],
              ["Odpov\u011B\u010F:",                                 // step = 5
               "Vn\u011Bj\u0161\u00ED \u00FAhel je stejn\u011B velk\u00FD, jako",
               "oba nep\u0159il\u00E9haj\u00EDc\u00ED vnit\u0159n\u00ED \u00FAhly",
               "dohromady.",
               "\u03B3* = \u03B1 + \u03B2"],
              ["Ot\u00E1zka:",                                   // step = 6
               "Jak velk\u00FD je sou\u010Det v\u0161ech t\u0159\u00ED",
               "vn\u011Bj\u0161\u00EDch \u00FAhl\u016F?"],
              ["Odpov\u011B\u010F:",                                 // step = 7
               "Sou\u010Det v\u0161ech t\u0159\u00ED vn\u011Bj\u0161\u00EDch \u00FAhl\u016F",
               "troj\u00FAheln\u00EDku je 360\u00B0."]];
