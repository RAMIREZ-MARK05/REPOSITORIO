// Dreiecks-Labor, Umkreis, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 25.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var circumcenter = "U";

var text03 = [["Pro dan\u00FD troj\u00FAheln\u00EDk ABC existuje",           // step = 0
               "kru\u017Enice, kter\u00E1 proch\u00E1z\u00ED v\u0161emi t\u0159emi",
               "vrcholy troj\u00FAheln\u00EDku. Tato kru\u017Enice",
               "se naz\u00FDv\u00E1 kru\u017Enice opsan\u00E1."], 
              ["St\u0159ed U kru\u017Enice opsan\u00E9 mus\u00ED b\u00FDt",          // step = 1
               "stejn\u011B vzd\u00E1len od v\u0161ech t\u0159ech",
               "vrchol\u016F."],
              ["Pokud by m\u011Bl b\u00FDt po\u017Eadovan\u00FD",            // step = 2
               "st\u0159ed U stejn\u011B vzd\u00E1len od vrchol\u016F",
               "A a B, ..."],
              ["... pak mus\u00ED le\u017Eet na ose \u00FAse\u010Dky AB."],             // step = 3
              ["Obdobn\u011B mus\u00ED m\u00EDt st\u0159ed U kru\u017Enice",         // step = 4
               "opsan\u00E9 stejnou vzd\u00E1lenost od",
               "vrchol\u016F B a C. Mus\u00ED tedy le\u017Eet",
               "na ose \u00FAse\u010Dky BC."],
              ["Bod U je pr\u016Fse\u010D\u00EDkem zm\u00EDn\u011Bn\u00FDch",         // step = 5
               "os stran. Vzhledem k tomu, \u017Ee",
               "bod U mus\u00ED b\u00FDt stejn\u011B vzd\u00E1len",
               "i od bod\u016F A a C, je tak\u00E9 na ose",
               "t\u0159et\u00ED strany (konkr\u00E9tn\u011B AC)."],
              ["Tak\u017Ee v\u0161echny t\u0159i osy stran mus\u00ED",    // step = 6
               "proch\u00E1zet bodem U."],
              ["Proto\u017Ee je bod U stejn\u011b vzd\u00E1len",           // step = 7
               "od v\u0161ech t\u0159\u00ED vrchol\u016F, m\u016F\u017Eeme",
               "nar\u00FDsovat kru\u017Enici opsanou.",
               "To je kru\u017Enice, kterou hled\u00E1me."],
              ["Ot\u00E1zka:",                                   // step = 8
               "Ve zvl\u00E1\u0161tn\u00EDm p\u0159\u00EDpad\u011B pravo\u00FAhl\u00E9ho",
               "troj\u00FAheln\u00EDku m\u00E1 kru\u017Enice opsan\u00E1",
               "zn\u00E1m\u00FD n\u00E1zev. Jak\u00FD?"],
              ["Odpov\u011B\u010F:",                                 // step = 9
               "Kru\u017Enice opsan\u00E1 pravo\u00FAhl\u00E9mu",
               "troj\u00FAheln\u00EDku je Thaletova kru\u017Enice."]];
