// Dreiecks-Labor, Feuerbach-Kreis, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 28.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var orthocenter = "H";
var centroid = "S";
var circumcenter = "U";
var feuerbachcenter = "F";

var text03 = [["V\u00FD\u0161ky troj\u00FAheln\u00EDku (tedy kolmice",      // step = 0
               "z vrchol\u016F k protilehl\u00E9 stran\u011B) se",
               "prot\u00EDnaj\u00ED v bod\u011B H."], 
              ["D\u00E1le si zn\u00E1zorn\u00EDme paty v\u00FD\u0161ek."],    // step = 1
              ["D\u00E1le si zn\u00E1zorn\u00EDme paty v\u00FD\u0161ek."],    // step = 2
              ["D\u00E1le si zn\u00E1zorn\u00EDme paty v\u00FD\u0161ek."],    // step = 3
              ["T\u00E9\u017E si zobraz\u00EDme st\u0159edy \u00Fasek\u016F",            // step = 4
               "v\u00FD\u0161ek mezi spole\u010Dn\u00FDm pr\u016Fse\u010D\u00EDkem",
               "a p\u0159\u00EDslu\u0161n\u00FDm vrcholem."],
              ["T\u00E9\u017E si zobraz\u00EDme st\u0159edy \u00Fasek\u016F",            // step = 5
               "v\u00FD\u0161ek mezi spole\u010Dn\u00FDm pr\u016Fse\u010D\u00EDkem",
               "a p\u0159\u00EDslu\u0161n\u00FDm vrcholem."],
              ["T\u00E9\u017E si zobraz\u00EDme st\u0159edy \u00Fasek\u016F",            // step = 6
               "v\u00FD\u0161ek mezi spole\u010Dn\u00FDm pr\u016Fse\u010D\u00EDkem",
               "a p\u0159\u00EDslu\u0161n\u00FDm vrcholem."],
              ["A kone\u010Dn\u011B si t\u00E9\u017E vyzna\u010D\u00EDme st\u0159edy",       // step = 7
               "v\u0161ech t\u0159\u00ED stran."],
              ["A kone\u010Dn\u011B si t\u00E9\u017E vyzna\u010D\u00EDme st\u0159edy",       // step = 8
               "v\u0161ech t\u0159\u00ED stran."],
              ["A kone\u010Dn\u011B si t\u00E9\u017E vyzna\u010D\u00EDme st\u0159edy",       // step = 9
               "v\u0161ech t\u0159\u00ED stran."],
              ["Je vid\u011Bt n\u011Bco zaj\u00EDmav\u00E9ho?"],                   // step = 10
              ["Spr\u00E1vn\u011B! V\u0161echny tyto body le\u017E\u00ED",        // step = 11
               "na kru\u017Enici. Naz\u00FDv\u00E1 se Feuerba-",
               "chova kru\u017Enice nebo t\u00E9\u017E kru\u017Enice dev\u00EDti bod\u016F."],
              ["Ot\u00E1zka:",                                   // step = 12
               "Jak\u00E1 domn\u011Bnka o poloze st\u0159edu F",
               "kru\u017Enice se nab\u00EDz\u00ED?"],
              ["Odpov\u011B\u010F:",                                 // step = 13
               "St\u0159ed F Feuerbachovy kru\u017Enice ",
               "le\u017E\u00ED p\u0159esn\u00E9 mezi pr\u016Fse\u010D\u00EDkem",
               "v\u00FD\u0161ek H a st\u0159edem U kru\u017Enice",
               "opsan\u00E9."]];
