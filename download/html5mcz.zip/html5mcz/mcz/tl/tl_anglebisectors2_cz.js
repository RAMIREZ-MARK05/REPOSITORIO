// Dreiecks-Labor, Winkelhalbierende (Innen- und Au�enwinkel), tschechische Texte (Miroslav Pano�)
// Letzte �nderung 25.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2004"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";

var text03 = [["Pro zadan\u00FD troj\u00FAhlen\u00EDk ABC",      // step = 0
               "vyzna\u010D\u00EDme v\u0161echny osy \u00FAhl\u016F,",
               "tedy jak vnit\u0159n\u00EDch, tak i vn\u011Bj\u0161\u00EDch."],
              ["Nejd\u0159\u00EDve nar\u00FDsujeme osy vnit\u0159n\u00EDch",         // step = 1
               "\u00FAhl\u016F."],
              ["Nejd\u0159\u00EDve nar\u00FDsujeme osy vnit\u0159n\u00EDch",         // step = 2
               "\u00FAhl\u016F."],
              ["Nejd\u0159\u00EDve nar\u00FDsujeme osy vnit\u0159n\u00EDch",         // step = 3
               "\u00FAhl\u016F."],
              ["Pak n\u00E1sleduj\u00ED osy \u00FAhl\u016F vn\u011Bj\u0161\u00EDch.",         // step = 4
               "Ty jsou kolm\u00E9 na osu p\u0159\u00EDslu\u0161n\u00E9ho",
               "\u00FAhlu vnit\u0159n\u00EDho."],
              ["Pak n\u00E1sleduj\u00ED osy \u00FAhl\u016F vn\u011Bj\u0161\u00EDch.",         // step = 5
               "Ty jsou kolm\u00E9 na osu p\u0159\u00EDslu\u0161n\u00E9ho",
               "\u00FAhlu vnit\u0159n\u00EDho."],
              ["Pak n\u00E1sleduj\u00ED osy \u00FAhl\u016F vn\u011Bj\u0161\u00EDch.",         // step = 6
               "Ty jsou kolm\u00E9 na osu p\u0159\u00EDslu\u0161n\u00E9ho",
               "\u00FAhlu vnit\u0159n\u00EDho."],
              ["Osy vnit\u0159\u00EDch \u00FAhl\u016F se prot\u00EDnaj\u00ED",        // step = 7
               "v jednom bod\u011B.",
               "",
               "(Dal\u0161\u00ED informace o tom naleznete",
               "v jin\u00E9 animaci t\u00E9to s\u00E9rie.)"],
              ["Spole\u010Dn\u00FD pr\u016Fse\u010D\u00EDk tak\u00E9 maj\u00ED",           // step = 8
               "osa vnit\u0159n\u00EDho \u00FAhlu a osy",
               "nep\u0159\u00EDslu\u0161ej\u00EDc\u00EDch vn\u011Bj\u0161\u00EDch \u00FAhl\u016F.",
               "",
               "(Dal\u0161\u00ED informace o tom naleznete",
               "v jin\u00E9 animaci t\u00E9to s\u00E9rie.)"],
              ["Spole\u010Dn\u00FD pr\u016Fse\u010D\u00EDk tak\u00E9 maj\u00ED",           // step = 9
               "osa vnit\u0159n\u00EDho \u00FAhlu a osy",
               "nep\u0159\u00EDslu\u0161ej\u00EDc\u00EDch vn\u011Bj\u0161\u00EDch \u00FAhl\u016F.",
               "",
               "(Dal\u0161\u00ED informace o tom naleznete",
               "v jin\u00E9 animaci t\u00E9to s\u00E9rie.)"],
              ["Spole\u010Dn\u00FD pr\u016Fse\u010D\u00EDk tak\u00E9 maj\u00ED",           // step = 10
               "osa vnit\u0159n\u00EDho \u00FAhlu a osy",
               "nep\u0159\u00EDslu\u0161ej\u00EDc\u00EDch vn\u011Bj\u0161\u00EDch \u00FAhl\u016F.",
               "",
               "(Dal\u0161\u00ED informace o tom naleznete",
               "v jin\u00E9 animaci t\u00E9to s\u00E9rie.)"]]
