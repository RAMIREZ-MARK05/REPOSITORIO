// Dreiecks-Labor, Steiner-Umellipse, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.09.2022

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 2017"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var circumcenter = "U";

var text03 = [["Elipsa, kter\u00E1 proch\u00E1z\u00ED v\u0161emi t\u0159emi",        // step = 0
               "vrcholy troj\u00FAheln\u00EDku, se naz\u00FDv\u00E1",
               "elipsa opsan\u00E1."],
              ["Pro ka\u017Ed\u00FD troj\u00FAheln\u00EDk existuje",       // step = 1
               "nekone\u010Dn\u011B mnoho elips opsan\u00FDch."],
              ["Tak\u00E9 existuje kru\u017Enice opsan\u00E1.",
               "(jako speci\u00E1ln\u00ED p\u0159\u00EDpad elipsy)"],      // step = 2
              ["Poj\u010Fme naj\u00EDt elipsu opsanou, kter\u00E1",     // step = 3
               "bude m\u00EDt co nejmen\u0161\u00ED plochu."],
              ["Za t\u00EDmto \u00FA\u010Delem pot\u0159ebujeme naj\u00EDt",       // step = 4
               "st\u0159ed takov\u00E9 elipsy."],
              ["To v\u0161ak vyvol\u00E1v\u00E1 ot\u00E1zku:",             // step = 5
               "Jak ale naj\u00EDt st\u0159ed hledan\u00E9 elipsy?"],
              ["Odpov\u011B\u010F je jednoduch\u00E1:",                 // step = 6
               "Jedin\u00E9, co mus\u00EDme ud\u011Blat, je",
               "nar\u00FDsovat t\u011B\u017Enice. St\u0159ed Steinerovy",
               "elipsy opsan\u00E9 je toti\u017E shodn\u00FD",
               "s t\u011B\u017Ei\u0161t\u011Bm troj\u00FAheln\u00EDku."],
              ["Odpov\u011B\u010F je jednoduch\u00E1:",                 // step = 7
               "Jedin\u00E9, co mus\u00EDme ud\u011Blat, je",
               "nar\u00FDsovat t\u011B\u017Enice. St\u0159ed Steinerovy",
               "elipsy opsan\u00E9 je toti\u017E shodn\u00FD",
               "s t\u011B\u017Ei\u0161t\u011Bm troj\u00FAheln\u00EDku."],
              ["Odpov\u011B\u010F je jednoduch\u00E1:",                 // step = 8
               "Jedin\u00E9, co mus\u00EDme ud\u011Blat, je",
               "nar\u00FDsovat t\u011B\u017Enice. St\u0159ed Steinerovy",
               "elipsy opsan\u00E9 je toti\u017E shodn\u00FD",
               "s t\u011B\u017Ei\u0161t\u011Bm troj\u00FAheln\u00EDku."],
              ["Ze v\u0161ech elips opsan\u00FDch m\u00E1 elipsa",           // step = 9
               "se st\u0159edem v t\u011B\u017Ei\u0161ti nejmen\u0161\u00ED",
               "plochu.",
               "(tzv. Steinerova elipsa)"]];
