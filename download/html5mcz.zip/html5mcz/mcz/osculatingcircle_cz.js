// Kr�mmungskreise von Funktionsgraphen, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Funk\u010Dn\u00ED p\u0159edpis:";
var text02 = "f(x) =";
var text03 = "Lev\u00E1 mez:";
var text04 = "Prav\u00E1 mez:";
var text05 = "Doln\u00ED mez:";
var text06 = "Horn\u00ED mez:";
var text07 = "Zobrazit";

var author = "W. Fendt 2017,&nbsp; M. Pano&scaron; 2017";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text08 = "Funk\u010Dn\u00ED p\u0159edpis je nesrozumiteln\u00FD!";
var text09 = "Chyba p\u0159i derivaci!";

var symbolX = "x";
var symbolY = "y";
