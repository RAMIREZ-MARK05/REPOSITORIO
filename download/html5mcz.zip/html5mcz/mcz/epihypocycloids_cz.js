// Epizykloiden und Hypozykloiden, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Epicykloida";
var text02 = "Hypocykloida";
var text03 = "Pom\u011Br polom\u011Br\u016F:";
var text04 = "Reset";
var text05 = ["Start", "Pauza", "Pokra\u010Dovat"];  

var author = "W. Fendt 2017,&nbsp; M. Pano&scaron; 2017";    

// Texte in Unicode-Schreibweise:

var text06 = "Speci\u00E1ln\u00ED p\u0159\u00EDpad Kardioida (srdcovka)";  
var text07 = "Speci\u00E1ln\u00ED p\u0159\u00EDpad Nefroida";
var text08 = "Speci\u00E1ln\u00ED p\u0159\u00EDpad pr\u016Fm\u011Br kru\u017Enice";
var text09 = "Speci\u00E1ln\u00ED p\u0159\u00EDpad Deltoida";
var text10 = "Speci\u00E1ln\u00ED p\u0159\u00EDpad Asteroida";                   




