// T�rme von Hanoi, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 07.02.2022

// Texte in HTML-Schreibweise:

var text01 = "Po&ccaron;et disk&uring;:";
var text02 = "Zp&ecaron;t";
var text03 = "Vlastn&iacute; &rcaron;e&scaron;en&iacute;";
var text04 = "Automatick&eacute; &rcaron;e&scaron;en&iacute;";
var text05 = ["Start", "Zastavit", "D&aacute;le"];
var text06 = "Tah";
var author = "W. Fendt 2022";
var translator = "M. Pano&scaron; 2022";

// Texte in Unicode-Schreibweise:

var text07 = "Blahop\u0159ejeme!";
var text08 = "Probl\u00E9m je vy\u0159e\u0161en.";


