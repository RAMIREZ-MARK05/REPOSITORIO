// Umrechnung von Einheiten, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 26.12.2018

// Texte in HTML-Schreibweise:

var text01 = "Nov&eacute; p&rcaron;evody";
var text02 = "Start";
var text03 = "D&eacute;lka";
var text04 = "Plocha";
var text05 = "Objem";
var text06 = "Hmotnost";
var text07 = "&Ccaron;as";
var text08 = "Stupe&ncaron; obt&iacute;&zcaron;nosti:";

var author = "W. Fendt 2001,&nbsp; M. Pano&scaron; 2006";  // Autor (und �bersetzer)

// Texte in Unicode-Schreibweise:

var text09 = ["0 p\u0159\u00EDklad\u016F", 
              "1 p\u0159\u00EDklad", 
              "2 p\u0159\u00EDklady",
              "3 p\u0159\u00EDklady",
              "4 p\u0159\u00EDklady", 
              "x p\u0159\u00EDklad\u016F"];
var text10 = ["x spr\u00E1vn\u011B"];          

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)