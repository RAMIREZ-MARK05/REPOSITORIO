// Schriftliches Rechnen, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 10.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Zp&uring;sob po&ccaron;&iacute;t&aacute;n&iacute;:";
var text02 = "S&ccaron;&iacute;t&aacute;n&iacute;";
var text03 = "S&ccaron;&iacute;t&aacute;n&iacute; (v&iacute;ce s&ccaron;&iacute;tanc&#367;)";
var text04 = "Od&ccaron;&iacute;t&aacute;n&iacute;";
var text05 = "N&aacute;soben&iacute;";
var text06 = "D&ecaron;len&iacute; beze zbytku";
var text07 = "D&ecaron;len&iacute; se zbytkem";
var text08 = "Stupe&ncaron; obt&iacute;&zcaron;nosti:";
var text09 = "Dal&scaron;&iacute; p&rcaron;&iacute;klad";

var author = "W. Fendt 1998,&nbsp; M. Pano&scaron; 2006";

// Texte in Unicode-Schreibweise:

var text11 = "Nen\u00ed vybr\u00e1n \u017e\u00e1dn\u00fd v\u00fdpo\u010det!";           // Warnmeldung f�r type == 0
var text12 = ["0 p\u0159\u00EDklad\u016F",                 // 0 Aufgaben
              "1 p\u0159\u00EDklad",                       // 1 Aufgabe (Singular)
              "2 p\u0159\u00EDklady",                      // 2 Aufgaben
              "3 p\u0159\u00EDklady",                      // 3 Aufgaben
              "4 p\u0159\u00EDklady",                      // 4 Aufgaben
              "x p\u0159\u00EDklad\u016F"];                // 5 oder mehr Aufgaben (Plural)
var text13 = "z toho";
var text14 = ["x spr\u00E1vn\u011B"];                      // 0 oder mehr Aufgaben richtig
var text15 = ["0 chyb",                                    // 0 Fehler
              "1 chyba",                                   // 1 Fehler (Singular)
              "2 chyby",                                   // 2 Fehler (Dual)
              "3 chyby",                                   // 3 Fehler (Dual)
              "4 chyby",                                   // 4 Fehler (Dual)
              "x chyb"];                                   // 5 oder mehr Fehler (Plural)