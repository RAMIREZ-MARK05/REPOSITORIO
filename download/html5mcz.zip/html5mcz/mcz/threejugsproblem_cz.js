// Milchkannenr�tsel, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 30.11.2017

// Texte in Unicode-Schreibweise:

var unit0 = "Litr\u016f";                                  // Volumeneinheit, Anzahl 0
var unit1 = "Litr";                                        // Volumeneinheit, Anzahl 1
var unit2 = "Litr\u016f";                                  // Volumeneinheit, Anzahl 2
var unit3 = "Litr\u016f";                                  // Volumeneinheit, Anzahl mindestens 3
var text1 = "V\u00fdborn\u011b - GRATULUJI!";              // Text f�r Gratulation
var text2 = "Pokud chcete novou hru:";                     // Text f�r Neustart, 1. Zeile
var text3 = "Sta\u010d\u00ed jeden klik my\u0161\u00ed!";  // Text f�r Neustart, 2. Zeile
