// Online-Rechner Aussagenlogik, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 19.08.2021

// Texte in HTML-Schreibweise:

var text01 = "Smazat znak";
var text02 = "Smazat v&scaron;e";
var text03 = "Po&ccaron;et prom&ecaron;nn&yacute;ch:";
var text04 = "Prom&ecaron;nn&aacute;:";
var author = "W. Fendt 2021, &nbsp; M. Pano&scaron; 2021";

// Texte in Unicode-Schreibweise:

var text05 = "Formule:";
var text06 = "Koment\u00E1\u0159:";
var text07 = "Pravdivostn\u00ED tabulka:";
var text08 = "Disjunktivn\u00ED norm\u00E1ln\u00ED forma:";
var text09 = "Konjunktivn\u00ED norm\u00E1ln\u00ED forma:";

var variables = ["x", "y", "z"];                           // Array-Gr��e variabel

var symbolFalse = "0";
var symbolTrue = "1";

var empty = "Pr\u00E1zdn\u00FD v\u00FDraz";
var variable = "Prom\u011Bnn\u00E1";
var constant = "Konstanta";
var negation = "Negace";
var brack = "Z\u00E1vorka";
var conjunction = "Konjunkce (spojka A)";
var disjunction = "Disjunkce (spojka NEBO)";
var implication = "Implikace";
var equivalence = "Ekvivalence";

var symbolNegation = "\u00AC";
var symbolConjunction = "\u2227";
var symbolDisjunction = "\u2228";
var symbolImplication = "\u21D2";
var symbolEquivalence = "\u21D4";

// Fehlermeldungen:

var syntaxOK = "Syntaxe je v po\u0159\u00E1dku!";
var missNeg = "Negace je ne\u00FApln\u00E1!";
var missCon1 = "Konjunkce: Chyb\u00ED prvn\u00ED operand!";
var missCon2 = "Konjunkce nen\u00ED dokon\u010Dena!";
var missDis1 = "Disjunkce: Chyb\u00ED prvn\u00ED operand!";
var missDis2 = "Disjunkce nen\u00ED dokon\u010Dena!";
var missImp1 = "Implikace: Chyb\u00ED prvn\u00ED operand!";
var missImp2 = "Implikace nen\u00ED dokon\u010Dena!";
var missEqu1 = "Ekvivalence: Chyb\u00ED prvn\u00ED operand!";
var missEqu2 = "Ekvivalence nen\u00ED dokon\u010Dena!";
var openBracket = "Z\u00E1vorka otev\u0159ena!";
var emptyBracket = "Pr\u00E1zdn\u00E1 z\u00E1vorka!";
var closingBracket = "Uzav\u00EDrac\u00ED z\u00E1vorka je zbyte\u010Dn\u00E1!";
var missingBracket = "Chyb\u00ED z\u00E1vorka!";

var unknownError = "Nesrozumiteln\u00E9!";




