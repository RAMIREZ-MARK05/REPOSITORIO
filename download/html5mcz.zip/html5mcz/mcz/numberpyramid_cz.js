// Zahlenpyramide, tschechische Texte (Miroslav Panos)
// Letzte �nderung 24.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Smazat";
var text02 = "Velikost:";
var text03 = "&Ccaron;&iacute;slo:";
var text04 = "Vlo&zcaron;it";
var text05 = ["Zobrazit &rcaron;e&scaron;en&iacute;", "&Rcaron;e&scaron;en&iacute; skr&yacute;t"];


var author = "W. Fendt 2023";
var translator = "M. Pano&scaron; 2023";

// Texte in Unicode-Schreibweise:

var select2 = ["Vlastn\u00ED \u00FAkol", "N\u00E1hodn\u00FD \u00FAkol"];
var select3 = ["P\u0159irozen\u00E1 \u010D\u00EDsla", "Cel\u00E1 \u010D\u00EDsla"];

var text11 = "Rozporupln\u00E9 vstupy!";
var text12 = "Nadbyte\u010Dn\u00E9 \u010D\u00EDslo!";
var text13 = "Chyba!";
var text14 = "\u017D\u00E1dn\u00E9 celo\u010D\u00EDseln\u00E9 \u0159e\u0161en\u00ED!";
var text15 = "\u0158e\u0161en\u00ED s p\u0159irozen\u00FDmi \u010D\u00EDsly neexistuje!";

var text21 = "Matrice nen\u00ED \u010Dtvercov\u00E1!";
var text22 = "Nen\u00ED to cel\u00E9 \u010D\u00EDslo!";

