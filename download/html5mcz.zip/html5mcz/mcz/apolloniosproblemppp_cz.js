// Apollonios-Problem PPP, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text02 = ["Hledan\u00E1 kru\u017Enice mus\u00ED proch\u00E1zet", 
              "zadan\u00FDmi t\u0159emi body, jedn\u00E1 se tedy", 
              "o kru\u017Enici opsanou troj\u00FAheln\u00EDku."];
var text04 = "Celkov\u00FD po\u010Det \u0159e\u0161en\u00ED:"; 
          
var author = "W. Fendt 2008"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var namePoint1 = "B_1";
var namePoint2 = "B_2";
var namePoint3 = "B_3";

