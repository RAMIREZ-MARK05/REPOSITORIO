// Abstand zweier Punkte auf einer Kugeloberfl�che, tschechische Texte
// Letzte �nderung 23.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Polom&ecaron;r:";
var text02 = "Bod A:";
var text03 = "Bod B:";
var text04 = "Vzd&aacute;lenost:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 2021";
var translator = "M. Pano&scaron; 2021";

// Texte in Unicode-Schreibweise:

var text11 = ["v\u00FDchodn\u00ED d\u00E9lka", "z\u00E1padn\u00ED d\u00E9lka"];
var text12 = ["severn\u00ED \u0161\u00ED\u0159ka", "ji\u017En\u00ED \u0161\u00ED\u0159ka"];

var symbolA = "A";
var symbolB = "B";
var symbolN = "S";
var symbolS = "J";

var degree = "\u00B0"
var kilometer = "km";


