// Ber�hrkreise, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Zad\u00E1no:";
var text02 = "Dva body";
var text03 = "Bod a p\u0159\u00EDmka";
var text04 = "Bod a kru\u017Enice";
var text05 = "Dv\u011B p\u0159\u00EDmky";
var text06 = "P\u0159\u00EDmka a kru\u017Enice";
var text07 = "Dv\u011B kru\u017Enice";

var author = "W. Fendt 2017";
var translator = "M. Pano&scaron; 2017";
