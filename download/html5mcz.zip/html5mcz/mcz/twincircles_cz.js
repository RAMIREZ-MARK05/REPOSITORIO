// Zwillingskreise des Archimedes, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 29.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Pomocn&eacute; linie k v&yacute;po&ccaron;tu polom&ecaron;ru:";
var text02 = "lev&yacute;";
var text03 = "prav&yacute;";

var author = "W. Fendt 2000, M. Pano&scaron; 2006";
