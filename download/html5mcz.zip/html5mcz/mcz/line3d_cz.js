// Geradengleichung, tschechische Texte
// Letzte �nderung 30.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Bod A:";
var text02 = "Bod B:";

//var decimalSeparator = ",";

var author = "W. Fendt 1999";
var translator = "M. Pano&scaron; 2006";

// Texte in Unicode-Schreibweise:

var text03 = "P\u0159\u00edmka AB nen\u00ed definov\u00e1na!";

var symbolPoint1 = "A";
var symbolPoint2 = "B";
var symbolX = "x_1";
var symbolY = "x_2";
var symbolZ = "x_3";
var symbolPositionVector = "X";
var symbolParameter = "\u03BB";
