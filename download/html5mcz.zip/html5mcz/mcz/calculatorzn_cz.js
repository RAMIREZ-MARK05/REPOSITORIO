// Rechnen mit Restklassen, tschechische Texte (Miroslav Panos)
// Letzte �nderung 12.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Zbytkov&eacute; t&rcaron;&iacute;dy modulo";
var text02 = "S&ccaron;&iacute;t&aacute;n&iacute;";
var text03 = "Od&ccaron;&iacute;t&aacute;n&iacute;";
var text04 = "N&aacute;soben&iacute;";
var text05 = "D&ecaron;len&iacute;";
var text06 = "Inverzn&iacute; prvek vzhledem ke s&ccaron;&iacute;t&aacute;n&iacute;";
var text07 = "Inverzn&iacute; prvek vzhledem k n&aacute;soben&iacute;";
var text11 = "1. s&ccaron;&iacute;tanec:";
var text12 = "2. s&ccaron;&iacute;tanec:";
var text13 = "Sou&ccaron;et:";
var text21 = "Men&scaron;enec:";
var text22 = "Men&scaron;itel:";
var text23 = "Rozd&iacute;l:";
var text31 = "1. &ccaron;initel:";
var text32 = "2. &ccaron;initel:";
var text33 = "Sou&ccaron;in:";
var text41 = "D&ecaron;lenec:";
var text42 = "D&ecaron;litel:";
var text43 = "Pod&iacute;l:";
var text51 = "Dan&yacute; prvek:";
var text52 = "Inverzn&iacute; prvek:";
var text61 = "Dan&yacute; prvek:";
var text62 = "Inverzn&iacute; prvek:";
var undef = "nen\u00ED def.";

var author = "W. Fendt  2022,&nbsp; M. Pano&scaron; 2022";

// Texte in Unicode-Schreibweise:

var symbolAdd = "+";
var symbolSub = "\u2212";
var symbolMul = "\u00B7";
var symbolDiv = ":";
var symbolNeg = "\u2212x";



