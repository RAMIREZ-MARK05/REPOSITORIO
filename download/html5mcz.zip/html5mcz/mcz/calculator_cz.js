// Rechnen mit beliebiger Genauigkeit, tschechische Texte (Miroslav Panos)
// Letzte �nderung 21.09.2020

// Texte in HTML-Schreibweise:

var text01 = "Smazat znak";
var text02 = "Smazat v&scaron;e";
var text03 = "Zlomek:";                                     // text04 siehe unten!
var text05 = "Des. &ccaron;&iacute;slo:";                       // text06 siehe unten!
var text07 = "Lomen&yacute; v&yacute;raz:";                     // text08 siehe unten!
var text09 = "Mocnina:";                                    // text10 siehe unten!
var author = "W. Fendt 2020,&nbsp; M. Pano&scaron; 2020";

// Texte in Unicode-Schreibweise:

var text04 = ["", "\u010Citatel", "Jmenovatel"];
var text06 = ["", "Desetinn\u00E1 m\u00EDsta", "Perioda"];
var text08 = ["", "Nov\u00FD zlomek", "Zadat \u010Ditatele", "Zadat jmenovatele", "Ukon\u010Dit zlomek"];
var text10 = ["", "Nov\u00FD exponent", "Zadat exponent", "Ukon\u010Dit exponent"];
var text11 = ["V\u00FDsledek jako zlomek", "V\u00FDsledek jako sm\u00ED\u0161en\u00E9 \u010D\u00EDslo", "V\u00FDsledek jako desetinn\u00E9 \u010D\u00EDslo"];

var text21 = "\u0158et\u011Bzec:";
var text22 = "V\u00FDraz:";
var text23 = "Typ:";
var text24 = "Koment\u00E1\u0159:";
var text25 = "V\u00FDsledek:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMinus = "\u2212";                                // Minuszeichen
var symbolMult = "\u00B7";                                 // Multiplikationszeichen
var symbolDiv = ":";                                       // Divisionszeichen

// Termarten:

var empty = "Pr\u00E1zdn\u00FD v\u00FDraz";
var natNum = "P\u0159irozen\u00E9 \u010D\u00EDslo";
var fracNum = "Zlomek nebo \u010D\u00EDslo sm\u00ED\u0161en\u00E9";
var decNum = "Desetinn\u00E9 \u010D\u00EDslo";
var plus = "Kladn\u00FD v\u00FDraz";
var minus = "Z\u00E1porn\u00FD v\u00FDraz";
var brack = "Z\u00E1vorka";
var perc = "Procenta";
var sum = "Sou\u010Det";
var diff = "Rozd\u00EDl";
var prod = "Sou\u010Din";
var prod0 = "Sou\u010Din bez znam\u00E9nka n\u00E1soben\u00ED";
var quot = "Pod\u00EDl";
var fracTerm = "Lomen\u00FD v\u00FDraz";
var pow = "Mocnina";

// Fehlermeldungen:

var syntaxOK = "Syntaxe v po\u0159\u00E1dku!";
var leadingZero = "Po\u010D\u00E1te\u010Dn\u00ED nula!";
var missingSummand = "Chyb\u00ED 2. s\u010D\u00EDtanec!";
var missingSubtrahend = "Chyb\u00ED men\u0161itel!";
var missingFactor1 = "Chyb\u00ED 1. \u010Dinitel!";
var missingFactor2 = "Chyb\u00ED 2. \u010Dinitel!";
var missingDividend = "Chyb\u00ED d\u011Blenec!";
var missingDivisor = "Chyb\u00ED d\u011Blitel!";
var missingNumerator = "Chyb\u011Bj\u00EDc\u00ED \u010Ditatel!";
var openNumerator = "\u010Citatel! nebyl ukon\u010Den!";
var missingDenominator = "Chyb\u00ED jmenovatel!";
var openDenominator = "Jmenovatel nebyl ukon\u010Den!";
var missingBase = "Chyb\u00ED z\u00E1klad mocniny!";
var missingExponent = "Chyb\u00ED exponent!";
var openExponent = "Exponent nebyl ukon\u010Den!";
var openPlus = "Ne\u00FApln\u00FD kladn\u00FD v\u00FDraz!";
var openMinus = "Ne\u00FApln\u00FD z\u00E1porn\u00FD v\u00FDraz!";
var openBracket = "Z\u00E1vorka otev\u0159ena!";
var emptyBracket = "Z\u00E1vorka je pr\u00E1zdn\u00E1!";
var closingBracket = "Zav\u00EDrac\u00ED z\u00E1vorka je neopodstatn\u011Bn\u00E1!";
var missingBracket = "Chyb\u00ED z\u00E1vorka!";
var missingInteger = "Chyb\u00ED cel\u00E9 \u010D\u00EDslo!";
var missingFractionalPart = "Chyb\u00ED destinn\u00E1 m\u00EDsta!";
var missingPeriod = "Chyb\u00ED periodick\u00E1 destinn\u00E1 m\u00EDsta!";

var runtimeOK = "\u017D\u00E1dn\u00E1 runtime chyba!";
var divisionByZero = "D\u0115len\u00ED nulou!";
var notIntegerExponent = "Exponent nen\u00ED cel\u00E9 \u010D\u00EDslo!";
var tooBigExponent = "Exponent je p\u0159\u00EDli\u0161 velik\u00FD!";

var unknownError = "Nesrozumiteln\u00FD v\u00FDraz!";


