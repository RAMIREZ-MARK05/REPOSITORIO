// Primyphos, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 01.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Rozlo&zcaron; na sou&ccaron;in:";

var author = "W. Fendt 1998";

var symbolMultiply = "&middot;";

// Texte in Unicode-Schreibweise:

var text02 = ["V\u00FDborn\u011B - GRATULUJI!", 
              "To byla \u0161pi\u010Dka!", 
              "Vynikaj\u00EDc\u00ED!", 
              "Nebylo \u0161patn\u00E9!", 
              "Dobr\u00FD v\u00FDkon!", 
              "P\u016Fsobiv\u00E9!",
              "Fantastick\u00E9!"];
              
var text03 = ["Pokud chce\u0161 spustit hru znova:",
              "Sta\u010D\u00ED kliknout my\u0161i!"];

var symbolMultiplyUnicode = "\u00B7";
