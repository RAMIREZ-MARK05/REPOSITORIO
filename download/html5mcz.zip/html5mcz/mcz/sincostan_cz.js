// Winkelfunktionen am Einheitskreis, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 30.11.2017

// Texte in HTML-Schreibweise:

var text01 = "sinus";
var text02 = "kosinus";
var text03 = "tangens";

var author = "W. Fendt 1997";
var translator = "M. Pano&scaron; 2006";

var decimalSeparator = ",";                      // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var symbolSine = "sin";                          // Symbol f�r Sinus
var symbolCosine = "cos";                        // Symbol f�r Cosinus
var symbolTangent = "tg";                        // Symbol f�r Tangens
var undef = "nedefinov\u00e1no!";                // F�r Definitionsl�cken der Tangensfunktion
