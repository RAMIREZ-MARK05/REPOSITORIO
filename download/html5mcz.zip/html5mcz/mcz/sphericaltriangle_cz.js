// Kugeldreieck, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 29.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Strany:";
var text02 = "a = ";
var text03 = "b = ";
var text04 = "c = ";
var text05 = "Sou&ccaron;et stran: ";
var text06 = "&Uacute;hly:";
var text07 = "&alpha; = ";
var text08 = "&beta; = ";
var text09 = "&gamma; = ";
var text10 = "Sou&ccaron;et &uacute;hl&uring;: ";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1999";
var translator = "M. Pano&scaron; 2006";

// Texte in Unicode-Schreibweise:

var symbolA = "A";
var symbolB = "B";
var symbolC = "C";


