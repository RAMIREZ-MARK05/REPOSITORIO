// Gerade Strophoide, tschechische Texte
// Letzte �nderung 08.12.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "D&aacute;le"];  

var author = "W. Fendt 2020,&nbsp; M. Pano&scaron; 2020";    

                




