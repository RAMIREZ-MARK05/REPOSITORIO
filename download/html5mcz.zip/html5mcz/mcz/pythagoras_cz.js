// Kathetensatz und Satz des Pythagoras, tschechische Texte
// Letzte �nderung 30.07.2023

// Texte in Unicode-Schreibweise:

var symbolA = "a";                                         // 1. Kathete
var symbolB = "b";                                         // 2. Kathete
var symbolC = "c";                                         // Hypotenuse
var symbolA2 = "a\u00B2";                                  // 1. Kathetenquadrat
var symbolB2 = "b\u00B2";                                  // 2. Kathetenquadrat
var symbolP = "c_a";                                       // 1. Hypotenusenabschnitt
var symbolQ = "c_b";                                       // 2. Hypotenusenabschnitt
var symbolCP = "c\u00B7c_a";                               // 1. Rechteck
var symbolCQ = "c\u00B7c_b";                               // 2. Rechteck
