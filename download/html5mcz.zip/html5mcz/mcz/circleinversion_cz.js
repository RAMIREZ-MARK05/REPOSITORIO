// Kreisspiegelung, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Nov\u00E1 kresba";
var text03 = "P\u0159idat";
var text04 = "Vymazat";
var text05 = "Obraz v zobrazen&iacute";

var author = "W. Fendt 2017";
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var text02 = ["Bod", "P\u0159\u00EDmka", "Polop\u0159\u00EDmka", "\u00DAse\u010Dka", "Kru\u017Enice", "Troj\u00FAheln\u00EDk", "\u010Cty\u0159\u00FAheln\u00EDk"];
