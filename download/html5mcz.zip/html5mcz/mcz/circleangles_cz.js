// Winkel am Kreis, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 29.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Velikost st&rcaron;edov&eacute;ho &uacute;hlu:";
var text02 = "St&rcaron;edov&yacute; &uacute;hel:";
var text03 = "Obvodov&yacute; &uacute;hel:";
var text04 = "&Uacute;sekov&yacute; &uacute;hel:";

var author = "W. Fendt 1997";
var translator = "M. Pano&scaron; 2006";
