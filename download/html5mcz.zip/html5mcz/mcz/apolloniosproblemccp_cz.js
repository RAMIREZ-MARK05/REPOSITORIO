// Apollonios-Problem CCP, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Zvolen\u00E9 \u0159e\u0161en\u00ED (\u010Derven\u00E9):";
var text02 = ["(Za\u0161krtnut\u00ED u kru\u017Enice znamen\u00E1,", 
              "\u017Ee m\u00E1 s \u0159e\u0161en\u00EDm vn\u011Bj\u0161\u00ED dotyk.)"];
var text03 = ["\u0158e\u0161en\u00ED 1:",
              "\u0158e\u0161en\u00ED 2:",
              "\u0158e\u0161en\u00ED 3:",
              "\u0158e\u0161en\u00ED 4:"];   
var text04 = "Celkov\u00FD po\u010Det \u0159e\u0161en\u00ED:";           
var author = "W. Fendt 2008"; 
var translator = "M. Pano&scaron; 2017";

// Texte in Unicode-Schreibweise:

var nameCircle1 = "k_1";
var nameCircle2 = "k_2";
var namePoint1 = "B";
