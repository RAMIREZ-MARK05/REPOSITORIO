// Primzahlentabelle, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 01.12.2017

// Texte in HTML-Schreibweise:

var textError = "Chyba!";                                  // Text f�r Fehlermeldung
var textPrime = "je prvo&ccaron;&iacute;slo.";             // Text f�r Primzahl
var symbolMult = "&middot;";                               // Multiplikationszeichen
