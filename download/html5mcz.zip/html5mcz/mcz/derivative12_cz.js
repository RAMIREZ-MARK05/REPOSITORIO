// 1. und 2. Ableitungsfunktion, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 30.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Funk&ccaron;n&iacute; p&rcaron;edpis:";
var text02 = "f(x) =";
var text03 = "1. derivace";
var text04 = "2. derivace";
var text05 = "Lev&aacute; mez:";
var text06 = "Prav&aacute; mez:";
var text07 = "Doln&iacute; mez:";
var text08 = "Horn&iacute; mez:";
var text09 = "Vykreslit";

var author = "W. Fendt 1999,&nbsp; M. Pano&scaron; 2006";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text10 = "Chyba zad\u00E1n\u00ED funkce!";
var text11 = "Chyba derivace!";

var symbolX = "x";
var symbolY = "y";
