// Rechner f�r Galois-Felder, tschechische Texte (Miroslav Panos)
// Letzte �nderung 13.08.2022

// Texte in HTML-Schreibweise:

var text01 = "&Rcaron;&aacute;d (po&ccaron;et prvk&uring;):";
var text02 = "Charakteristika:";
var text03 = "S&ccaron;&iacute;t&aacute;n&iacute;";
var text04 = "Od&ccaron;&iacute;t&aacute;n&iacute;";
var text05 = "N&aacute;soben&iacute;";
var text06 = "D&ecaron;len&iacute;";
var text07 = "Inverzn&iacute; prvek vzhledem ke s&ccaron;&iacute;t&aacute;n&iacute;";
var text08 = "Inverzn&iacute; prvek vzhledem k n&aacute;soben&iacute;";

var text11 = "1. s&ccaron;&iacute;tanec:";
var text12 = "2. s&ccaron;&iacute;tanec:";
var text13 = "Sou&ccaron;et:";
var text21 = "Men&scaron;enec:";
var text22 = "Men&scaron;itel:";
var text23 = "Rozd&iacute;l:";
var text31 = "1. &ccaron;initel:";
var text32 = "2. &ccaron;initel:";
var text33 = "Sou&ccaron;in:";
var text41 = "D&ecaron;lenec:";
var text42 = "D&ecaron;litel:";
var text43 = "Pod&iacute;l:";
var text51 = "Dan&yacute; prvek:";
var text52 = "Inverzn&iacute; prvek:";
var text61 = "Dan&yacute; prvek:";
var text62 = "Inverzn&iacute; prvek:";
var undef = "nen\u00ED def.";

var author = "W. Fendt 2022,&nbsp; M. Pano&scaron; 2022";

// Texte in Unicode-Schreibweise:

var text09 = "#1 ist eine Wurzel des Polynoms #2.";        // Bemerkung zur Wurzel
var symbolAdd = "+";                                       // Pluszeichen
var symbolSub = "\u2212";                                  // Minuszeichen
var symbolMul = "\u00B7";                                  // Multiplikationszeichen
var symbolDiv = ":";                                       // Divisionszeichen
var symbolArg = "x";                                       // Symbol f�r Argument einer einstelligen Verkn�pfung
var symbolNeg = "\u2212x";                                 // Symbol f�r inverses Element bez�glich Addition
var root = "\u03B1";                                       // Symbol f�r Wurzel
var varPoly = "x";                                         // Variable f�r Polynome



