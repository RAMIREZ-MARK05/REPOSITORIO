// Einfache geometrische Abbildungen, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 30.11.2017

// Texte in HTML-Schreibweise:

var text02 = "Nov&aacute; kresba";
var text04 = "Vlo&zcaron;it";
var text05 = "Smazat";
var text06 = "Obraz v zobrazen&iacute;";

var author = "W. Fendt 1999";
var translator = "M. Pano&scaron; 2006";

// Texte in Unicode-Schreibweise:

var text01 = ["Osov\u00e1 soum\u011brnost", 
              "St\u0159edov\u00e1 soum\u011brnost", 
              "Posunut\u00ed", 
              "Oto\u010den\u00ed"];
var text03 = ["Bod", 
              "P\u0159\u00edmka", 
              "Polop\u0159\u00edmka", 
              "\u00dase\u010dka", 
              "Kru\u017enice", 
              "Troj\u00faheln\u00edk", 
              "\u010cty\u0159\u00faheln\u00edk"];

