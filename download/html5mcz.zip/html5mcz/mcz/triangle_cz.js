// Besondere Linien und Kreise im Dreieck, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "pr&uring;se&ccaron;&iacute;k os stran";
var text02 = "kru&zcaron;nice opsan&aacute;";
var text03 = "osy &uacute;hl&uring;";
var text04 = "kru&zcaron;nice vepsan&aacute;";
var text05 = "kru&zcaron;nice p&rcaron;ipsan&eacute;";
var text06 = "st&rcaron;edn&iacute; p&rcaron;&iacute;&ccaron;ky";
var text07 = "t&ecaron;&zcaron;nice";
var text08 = "v&yacute;&scaron;ky";
var text09 = "Eulerova p&rcaron;&iacute;mka";
var text10 = "Feuerbachova kru&zcaron;nice";

var author = "W. Fendt 1998";
var translator = "M. Pano&scaron; 2006";

