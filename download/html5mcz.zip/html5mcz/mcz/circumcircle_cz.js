// Umkreis eines Dreiecks, tschechische Texte
// Letzte �nderung 09.04.2020

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = "Dal&scaron;&iacute; krok";
var author = "W. Fendt 1997"; 
var translator = "M. Pano&scaron; 2020";

// Texte in Unicode-Schreibweise:

var text03 = [["Vlevo je zobrazen troj\u00FAheln\u00EDk ABC.",		// step == 0
               "Vrcholy troj\u00FAheln\u00EDku m\u016F\u017Eete",
               "p\u0159esouvat pomoc\u00ED stisknut\u00ED",
               "lev\u00E9ho tla\u010D\u00EDtka my\u0161i."],
              ["V\u0161echny body p\u0159\u00EDmky o_(c), co\u017E je",	// step == 1
               "osa \u00FAse\u010Dky AB, maj\u00ED stejnou",
               "vzd\u00E1lenost od vrchol\u016F A a B."],
              ["Stejn\u011B tak maj\u00ED body osy o_(a)",		// step == 2
               "stejnou vzd\u00E1lenost od vrchol\u016F",
               "B a C."],
              ["Bod U (jako pr\u016Fse\u010D\u00EDk t\u011Bchto",	// step == 3
               "dvou os stran), m\u00E1 tedy stejnou",
               "vzd\u00E1lenost od vrchol\u016F A a C."],
              ["Tento pr\u016Fse\u010D\u00EDk U mus\u00ED tak\u00E9",	// step == 4
               "le\u017Eet na t\u0159et\u00ED ose strany (o_(b))."],
              ["Proto\u017Ee bod U le\u017E\u00ED ve stejn\u00E9",	// step == 5
               "vzd\u00E1lenosti od v\u0161ech t\u0159\u00ED",
               "vrchol\u016F troj\u00FAheln\u00EDku, je",
               "bod U st\u0159edem kru\u017Enice",
               "proch\u00E1zej\u00EDc\u00ED vrcholy."],
              ["Tato kru\u017Enice se naz\u00FDv\u00E1",		// step == 6
               "kru\u017Enice troj\u00FAheln\u00EDku opsan\u00E1."]];
               
var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var circumcenter = "U";






