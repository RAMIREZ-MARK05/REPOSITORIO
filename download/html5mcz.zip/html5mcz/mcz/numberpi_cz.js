// Kreiszahl Pi, tschechische Texte (Miroslav Panos)
// Letzte �nderung 26.02.2021

// Texte in HTML-Schreibweise:

var text01 = "Po&ccaron;et vrchol&uring;:";
var text02 = "&Ccaron;ty&rcaron;&uacute;heln&iacute;k";
var text03 = "&Scaron;esti&uacute;heln&iacute;k";
var text04 = "Zdvojn&aacute;sobit po&ccaron;et vrchol&uring;";
var text05 = "D&eacute;lka strany";
var text06 = "Obvod";
var text07 = "Plocha";

var author = "W. Fendt 2002";
var translator = "M. Pano&scaron; 2021";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";

var text11 = "D\u00E9lka strany (vepsan\u00FD mnoho\u00FAheln\u00EDk):";
var text12 = "D\u00E9lka strany (opsan\u00FD mnoho\u00FAheln\u00EDk):";
var text13 = "Obvod (vepsan\u00FD mnoho\u00FAheln\u00EDk):";
var text14 = "Obvod (opsan\u00FD mnoho\u00FAheln\u00EDk):";
var text15 = "Plocha (vepsan\u00FD mnoho\u00FAheln\u00EDk):";
var text16 = "Plocha (opsan\u00FD mnoho\u00FAheln\u00EDk):";



