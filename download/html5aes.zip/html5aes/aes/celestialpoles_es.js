// Himmelspole, spanische Texte (Tom�s Fdez de Sevilla)
// Letzte �nderung 20.11.2017

// Texte in Unicode-Schreibweise:

var text01 = "Ecuador";
var	text02 = "Polo Norte";
var text03 = "Polo Sur";
var text04 = "Eje Terrestre";
var text05 = "Plano Horizontal";
var text06 = "Esfera Celeste";
var	text07 = "Cenit";
var text08 = "Polo Norte Celeste";
var	text09 = "Polo Sur Celeste";
var text10 = "Norte";
var text11 = "Sur";

var author = "W. Fendt 1998,  T. F. de Sevilla 2002";
