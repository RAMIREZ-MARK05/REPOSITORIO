// Leiterschaukel-Versuch zur Lorentzkraft, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 18.12.2017

// Texte in HTML-Schreibweise:

var text01 = "T&aelig;nd / Sluk";
var text02 = "Vend str&oslash;mretning";
var text03 = "Vend magnet";
var text04 = "Str&oslash;mretning";
var text05 = "Magnetfelt";
var text06 = "Lorentzkraft";

var author = "W. Fendt 1998";
var translator = "ORBIT 1999";
