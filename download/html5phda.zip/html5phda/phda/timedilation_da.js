// Beispiel zur Zeitdilatation, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 19.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Mindre hastighed";
var text02 = "H&oslash;jere hastighed";
var text03 = "Tilbage";
var text04 = ["Start", "Pause", "Forts&aelig;t"];

var author = "W. Fendt 1997,&nbsp; ORBIT 1999";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "Str\u00E6kning:";
var text06 = "5 lystimer";
var text07 = "Hastighed:";
var text08 = "Flyvetid i Jord-systemet:";
var text09 = "timer";
var text10 = "Flyvetid i raket-systemet:";