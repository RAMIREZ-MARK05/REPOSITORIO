// Einfache Wechselstromkreise, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 18.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Resistor";
var text02 = "Kondensator";
var text03 = "Spole";
var text04 = "Stop";
var text05 = ["Start", "Pause", "Forts&aelig;t"];          
var text06 = "Langsom gengivelse";
var text07 = "Frekvens:";
var text08 = "Maks. sp&aelig;nding:";
var text09 = "Resistans:";                            
var text10 = "Kapacitet:";                          
var text11 = "Induktivitet:"; 
var text12 = "Maks. str&oslash;mstyrke:"; 

var author = "W. Fendt 1998,&nbsp; ORBIT 1999";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                  
var volt = "V";                                     
var ampere = "A";                                    
var milliampere = "mA";                           
var microampere = "&mu;A";                  
var ohm = "&Omega;";                       
var microfarad = "&mu;F";                    
var henry = "H";                              

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "V";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
