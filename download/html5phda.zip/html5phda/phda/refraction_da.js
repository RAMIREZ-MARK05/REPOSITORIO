// Reflexion und Brechung von Licht, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 19.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = "1. Brydningsindeks:";
var text02 = "2. Brydningsindeks:";
var text03 = "Infaldsvinkel:";
var text04 = "Udfaldsvinkel:";
var text05 = "Brydningsvinkel:";    
var text06 = ["Gr&aelig;nsevinkel for", "totalrefleksion:"];

var author = "W. Fendt 1997,&nbsp; ORBIT 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                 

// Texte in Unicode-Schreibweise:

var text07 = [["Vakuum", "1"], ["Luft", "1.0003"],         // Stoffe und Brechungsindizes
    ["Vand", "1.33"], ["Ethanol", "1.36"],
    ["Kvartsglas", "1.46"], ["Benzol", "1.49"], 
    ["Kroneglas N-K5", "1.52"], ["Stensalt", "1.54"], 
    ["Flintglas LF5", "1.58"], ["Kroneglas N-SK4", "1.61"],
    ["Flintglas SF6", "1.81"], ["Diamant", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                      
