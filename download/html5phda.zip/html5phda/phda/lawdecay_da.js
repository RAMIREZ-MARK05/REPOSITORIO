// Zerfallsgesetz der Radioaktivit�t, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 19.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Forfra";
var text02 = ["Start", "Pause", "Forts&aelig;t"];    
var text03 = "Diagram";  

var author = "W. Fendt 1998";
var translator = "ORBIT 1999";

// Texte in Unicode-Schreibweise:

var text04 = "Tid:";                                      
var text05 = "Antal tilbagev\u00E6rende:";
var text06 = "Antal henfaldne:";
var text07 = ["Kerner", "Kerne", "Kerner", "Kerner"];      // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
