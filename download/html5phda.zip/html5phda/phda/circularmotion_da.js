// Kreisbewegung mit konstanter Winkelgeschwindigkeit, d�nische Texte
// Letzte �nderung 20.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Forfra";
var text02 = ["Start", "Pause", "Forts&aelig;t"];
var text03 = "Langsom gengivelse";
var text04 = "Radius:";
var text05 = "Periode:";
var text06 = "Masse:";
var text07 = "Position";
var text08 = "Hastighed";
var text09 = "Acceleration";
var text10 = "Kraft";

var author = "W. Fendt 2007";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Punkt)
var meter = "m";                                           // Meter
var second = "s";                                          // Sekunde
var kilogram = "kg";                                       // Kilogramm

// Texte in Unicode-Schreibweise:

var text11 = "Position:";
var text12 = "Hastighed:";
var text13 = "Vinkelhastighed:";
var text14 = "Centripetalacceleration:";
var text15 = "Centripetalkraft:";
var text16 = "(i s)";
var text17 = "(i m)";
var text18 = "(i m/s)";
var text19 = "(i m/s\u00b2)";
var text20 = "(i N)";
var text21 = "(x komposant)";
var text22 = "(y komposant)";
var text23 = "(st\u00F8rrelse)";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03c9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "m";                                    // Meter
var meterPerSecond = "m/s";                                // Meter pro Sekunde
var meterPerSecond2 = "m/s\u00b2";                         // Meter pro Sekunde hoch 2
var newton = "N";                                          // Newton
var radPerSecond = "rad/s";                                // Radiant pro Sekunde




