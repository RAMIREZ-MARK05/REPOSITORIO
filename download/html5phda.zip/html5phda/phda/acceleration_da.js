// Bewegung mit konstanter Beschleunigung, d�nische Texte (WWW-Recherche)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Forfra";
var text02 = ["Start", "Pause", "Forts&aelig;t"];
var text03 = "Langsom gengivelse";
var text04 = "Startposition:";
var text05 = "Starthastighed:";
var text06 = "Acceleration:";
var text07 = "Hastighedsvektor";
var text08 = "Accelerationsvektor";

var author = "W. Fendt 2000";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "(i s)";                                      // Einheitenangabe f�r Zeit-Achse
var text10 = "(i m)";                                      // Einheitenangabe f�r Weg-Achse
var text11 = "(i m/s)";                                    // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(i m/s\u00b2)";                              // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                 
var meter = "m";                               
var meterPerSecond = "m/s";                    
var meterPerSecond2 = "m/s\u00b2";         
