// Zerfallsreihen, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 08.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Henfaldsk&aelig;de:";
var text03 = "N&aelig;ste henfald";

var author = "W. Fendt 1998"; 
var translator = "ORBIT 1999";

// Texte in Unicode-Schreibweise:

var text02 = ["Thorium-r\u00E6kken", "Neptunium-r\u00E6kken", "Uran-radium-r\u00E6kken", "Uran-actinium-r\u00E6kken"];          





