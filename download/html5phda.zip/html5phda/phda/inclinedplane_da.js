// Kr�fte an der schiefen Ebene, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 20.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Forfra";
var text02 = ["Start", "Pause", "Forts&aelig;t"];
var text03 = "Langsom gengivelse";
var text04 = "Fjederv&aelig;gt";
var text05 = "Kraftvektorer";
var text06 = "H&aelig;ldningsvinkel:";
var text07 = "Tyngdekraft:";
var text08 = "Parallelkomposant:";
var text09 = "Normalkraft:";
var text10 = "Friktionskoefficient:";
var text11 = "Friktionskraft:";
var text12 = "Tr&aelig;kkraft:";

var author = "W. Fendt 1999,&nbsp; ORBIT 1999";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                  
var newton = "N";                                     
