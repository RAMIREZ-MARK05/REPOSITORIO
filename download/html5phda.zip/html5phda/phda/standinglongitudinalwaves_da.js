// Stehende L�ngswellen, d�nische Texte (Morten Brydensholt, unvollst�ndig wegen Erweiterung)
// Letzte �nderung 17.12.2017

// Texte in HTML-Schreibweise:

var text01 = "R&oslash;rets form:";
var text02 = "&aring;bent";
var text03 = "halv&aring;bent";
var text04 = "lukket";
var text05 = "Svingningstilstand:";
var text06 = ["Grundtone", "1. Overtone",                  // Bezeichnungen der Eigenschwingungen 
              "2. Overtone", "3. Overtone", 
              "4. Overtone", "5. Overtone"];
var text07 = "Dybere";
var text08 = "H&oslash;jere";
var text09 = "R&oslash;rets l&aelig;ngde:";
var text10 = "B&oslash;lgel&aelig;ngde:";
var text11 = "Frekvens:";

var author = "W. Fendt 1998,&nbsp; ORBIT 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                           // Meter
var hertz = "Hz";                                          // Hertz

// Texte in Unicode-Schreibweise:

var text12 = "Displacement of particles";                  // �berschrift des ersten Diagramms ???
var text13 = "Divergence from average pressure";           // �berschrift des zweiten Diagramms ???

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "K";                                      // Symbol f�r Knoten
var symbolAntinode = "B";                                  // Symbol f�r Bauch

