// Zweites Kepler-Gesetz, d�nische Texte
// Letzte �nderung 26.02.2020

// Texte in HTML-Schreibweise:
    
var text02 = "Halve storakse:";
var text03 = "Excentricitet:";
var text04 = ["Pause", "Forts&aelig;t"];
var text05 = "Langsom gengivelse";
var text06 = ["Afstand", "til Solen:"];
var text07 = "Hastighed:";
var text08 = "Aktuel:";
var text09 = "Minimum:";
var text10 = "Maksimum:";
var text11 = "Sektorer";
var text12 = "Hastighedsvektor";

var author = "W. Fendt 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "au";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Merkur", "Venus", "Jorden", "Mars", "Jupiter", "Saturn", "Uranus", "Neptun",
              "Pluto", "Halleys komet", ""];

// Symbole und Einheiten: 

var auUnicode = "au";
var symbolPeriod = "T";

