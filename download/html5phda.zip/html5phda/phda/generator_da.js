// Generator, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 18.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Uden str&oslash;mfordeler";
var text02 = "Med str&oslash;mfordeler";
var text03 = "Vend retning";
var text04 = ["Start", "Pause", "Forts&aelig;t"];
var text05 = "Bev&aelig;gelsesretning";
var text06 = "Magnetfelt";
var text07 = "Induceret str&oslash;m";

var author = "W. Fendt 1998";  
var translator = "ORBIT 1999";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "omdr./min";                      // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
