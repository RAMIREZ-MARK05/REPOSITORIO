// Elastischer und unelastischer Sto�, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Elastisk st&oslash;d";
var text02 = "Uelastisk st&oslash;d";
var text03 = "Forfra";
var text04 = "Start";
var text05 = "Langsom gengivelse";
var text06 = "Vogn 1:";
var text07 = "Vogn 2:";
var text08 = "Masse:";
var text09 = "Hastighed:";
var text10 = "Hastighed";
var text11 = "Impuls";
var text12 = "Kinetisk energi";

var author = "W. Fendt 1998, ORBIT 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                          

// Texte in Unicode-Schreibweise:

var text13 = "Vogn 1:";
var text14 = "Vogn 2:";
var text15 = "Hastighed f\u00F8r st\u00F8det:";
var text16 = "Hastighed efter st\u00F8det:";
var text17 = "Impuls f\u00F8r st\u00F8det:";
var text18 = "Impuls efter st\u00F8det:";
var text19 = "Kinetisk energi f\u00F8r st\u00F8det:";
var text20 = "Kinetisk energi efter st\u00F8det:";
var text21 = "Samlet impuls:";
var text22 = "Samlet kinetisk energi:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";               
var kilogramMeterPerSecond = "kg m/s";          
var joule = "J";                              
