// Interferenz zweier Kreis- oder Kugelwellen, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 17.12.2017

// Texte in HTML-Schreibweise:

var text01 = ["Pause", "Forts&aelig;t"];                       
var text02 = "Langsom gengivelse";
var text03 = "Avstand mellem de to";
var text04 = "b&oslash;lgegivere:";
var text05 = "B&oslash;lgel&aelig;ngde:";

var author = "W. Fendt 1999";
var translator = "ORBIT 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                             

// Texte in Unicode-Schreibweise:

var text06 = "Forskel i vejl\u00E6ngde:";
var text07 = "Konstruktiv interferens (maksimal amplitude)";
var text08 = "Destruktiv interferens (minimal amplitude)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (Lambda)
