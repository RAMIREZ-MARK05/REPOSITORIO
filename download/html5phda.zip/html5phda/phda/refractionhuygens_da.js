// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), d�nische Texte (Morten Brydensholt)
// Letzte �nderung 19.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Helt forfra";
var text02 = "N&aelig;ste skridt";
var text03 = ["Pause", "Forts&aelig;t"];                  
var text04 = "1. Brydningsindeks:";
var text05 = "2. Brydningsindeks:";
var text06 = "Infaldsvinkel:";

var author = "W. Fendt 1998";
var translator = "ORBIT 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                 

// Texte in Unicode-Schreibweise:

var text07 = [

  ["En plan b\u00F8lgefront bev\u00E6ger sig",             // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "skr\u00E5t ind mod gr\u00E6nsefladen",
   "mellem to medier.\n",
   "B\u00F8lgehastigheden i de to medier",
   "er forskellig."],
   
  ["En plan b\u00F8lge bev\u00E6ger sig",                  // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "vinkelret ind mod gr\u00E6nsefladen",
   "mellem to medier.\n",
   "B\u00F8lgehastigheden i de to medier",
   "er forskellig."],
   
  ["N\u00E5r b\u00F8lgefronten rammer",                    // i == 2 (step == 1, n1 > n2)
   "gr\u00E6nsefladen, vil der if\u00F8lge",
   "Huygens princip ske en",
   "forstyrrelse i hvert punkt p\u00E5",
   "gr\u00E6nsefladen, og hver",
   "forstyrrelse resulterer i",
   "udsendelse af en ringb\u00F8lge",
   "(en s\u00E5kaldt elementarb\u00F8lge).\n",
   "I medium 2 udbreder disse",
   "elementarb\u00F8lger sig",
   "hurtigere, da brydnings-",
   "indekset her er mindere."],
   
  ["N\u00E5r b\u00F8lgefronten rammer",                    // i == 3 (step == 1, n1 < n2)
   "gr\u00E6nsefladen, vil der if\u00F8lge",
   "Huygens princip ske en",
   "forstyrrelse i hvert punkt p\u00E5",
   "gr\u00E6nsefladen, og hver",
   "forstyrrelse resulterer i",
   "udsendelse af en ringb\u00F8lge",
   "(en s\u00E5kaldt elementarb\u00F8lge).\n",
   "I medium 2 udbreder disse",
   "elementarb\u00F8lger sig",
   "langsommere, da brydnings-",
   "indekset her er st\u00F8rre."],
   
  ["P\u00E5 grund af konstruktiv",                         // i == 4 (step == 2, total == false, esp1 > 0)
   "interferens mellem elementar-",
   "b\u00F8lgerne opst\u00E5r en ny, plan",
   "b\u00F8lgefront.\n",
   "I medium 1 udbreder der sig",
   "en reflekteret b\u00F8lge,",
   "mens der i medium 2 udbreder",
   "sig en brudt b\u00F8lge.\n",
   "Bem\u00E6rk, at b\u00F8lgens",
   "udbredelsesretning \u00E6ndrer",
   "sig, n\u00E5r b\u00F8lger bev\u00E6ger sig",
   "fra medium 1 til medium 2."],
   
  ["P\u00E5 grund af konstruktiv",                         // i == 5 (step == 2, total == false, esp1 == 0)
   "interferens mellem elementar-",
   "b\u00F8lgerne opst\u00E5r en ny, plan",
   "b\u00F8lgefront.\n",
   "I medium 1 udbreder der sig",
   "en reflekteret b\u00F8lge,",
   "mens der i medium 2 udbreder",
   "sig en brudt b\u00F8lge."], 
   
  ["P\u00E5 grund af konstruktiv",                         // i == 6 (step == 2, total == true)
   "interferens mellem elementar-",
   "b\u00F8lgerne opst\u00E5r der i",
   "medium 1 en ny, plan b\u00F8lgefront",
   "(reflekteret b\u00F8lge).\n",
   "Derimod opst\u00E5r der ingen",
   "b\u00F8lgefront i medium 2",
   "(totalrefleksion)."], 
   
  ["B\u00F8lgens udbredelsesretning",                      // i == 7 (step == 3)
   "er nu indtegnet.",
   "Det er linien vinkelret p\u00E5",
   "b\u00F8lgefronten."], 
   
  ["En b\u00F8lgefront kommer",                            // i == 8 (step == 4)
   "sj\u00E6ldent alene!"],
   
  ["Hvis brydningsindekset for",                           // i == 9 (n1 == n2)
   "begge medier er det samme,",
   "sker der ikke noget s\u00E6rligt."]];
          
var text08 = "Infaldsvinkel:"; 
var text09 = "Udfaldsvinkel:";
var text10 = "Brydningsvinkel:"; 
var text11 = "Medium 1";
var text12 = "Medium 2";      
var text13 = ["Gr\u00E6nsevinklen for", "totalrefleksion:"];

// Einheiten:

var degreeUnicode = "\u00b0";                           
