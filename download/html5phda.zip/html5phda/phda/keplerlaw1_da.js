// Erstes Kepler-Gesetz, d�nische Texte
// Letzte �nderung 26.02.2020

// Texte in HTML-Schreibweise:
    
var text01 = ["Merkur", "Venus", "Jorden", "Mars", "Jupiter", "Saturn", "Uranus", "Neptun",
              "Pluto", "Halleys komet", ""];
var text02 = "Halve storakse:";
var text03 = "Excentricitet:";
var text04 = "Halve lilleakse:";
var text05 = ["Pause", "Forts&aelig;t"];
var text06 = "Langsom gengivelse";
var text07 = "Afstand til Solen:";
var text08 = "Aktuel:"; 
var text09 = "Minimum:";
var text10 = "Maksimum:";
var text11 = "Elliptisk bane";
var text12 = "Akser";
var text13 = "Linjer til de to br&aelig;ndpunkter"; // ???

var author = "W. Fendt 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "au";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text14 = "Solen";
var text15 = "Planet";
var text16 = "Komet";
var text17 = "Perihelium";
var text18 = "Aphelium";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "au";

