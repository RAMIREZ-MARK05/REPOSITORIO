// Messung der Auftriebskraft, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 17.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Legemets tv&aelig;rsnitsareal:"; 
var text02 = "Legemets h&oslash;jde:";
var text03 = "Legemets densitet:";
var text04 = "V&aelig;skens densitet:";   
var text05 = "Nedgangsdybde:";
var text06 = "Fort&aelig;ngt volumen:"; 
var text07 = "Opdrift:";
var text08 = "Legemets tyngdekraft:";
var text09 = "M&aring;lt kraft:";
var text10 = "M&aring;leomr&aring;de:";

var author = "W. Fendt 1998,&nbsp; ORBIT 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Maksimum overskredet!";
