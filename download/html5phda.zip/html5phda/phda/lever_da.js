// Hebelgesetz, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 16.12.2017

// Texte in Unicode-Schreibweise:

var text01 = "Kraftmomentet p\u00E5 venstresiden:";
var text02 = "Kraftmomentet p\u00E5 h\u00F8jresiden:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "M_1";                              // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "M_2";                             // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

var newton = "N";
var meter = "m";

var author = "W. Fendt 1997,\u0020 ORBIT 1999";                  // Autor (und �bersetzer)
