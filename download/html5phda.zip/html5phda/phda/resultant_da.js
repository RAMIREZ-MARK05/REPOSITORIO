// Ersatzkraft mehrerer Kr�fte, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Antal enkeltkr&aelig;fter:";
var text02 = "Den resulterende kraft";
var text03 = "Slet konstruktion";

var author = "W. Fendt 1998";
var translator = "ORBIT 1999";
