// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "2 trisser";
var text02 = "4 trisser";
var text03 = "6 trisser";
var text04 = "'V&aelig;gt':";
var text05 = "'V&aelig;gt' af de l&oslash;se trisser:";
var text06 = "N&oslash;dvendig kraft:";
var text07 = "Fjederv&aelig;gt";
var text08 = "Kraftvektorer";

var author = "W. Fendt 1998";
var translator = "ORBIT 1999";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                   
