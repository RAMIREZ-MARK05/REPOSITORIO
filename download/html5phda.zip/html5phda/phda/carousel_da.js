// Kettenkarussell, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Karrusel";
var text02 = "Karrusel med kr&aelig;fter";
var text03 = "Skitse";
var text04 = "Talv&aelig;rdier";
var text05 = ["Pause", "Forts&aelig;t"];
var text06 = "Langsom gengivelse";
var text07 = "Periode:";
var text08 = ["Afstand mellem oph&aelig;ng", "og rotationsakse:"]; 
var text09 = "Snorl&aelig;ngde:";
var text10 = "Masse:";

var author = "W. Fendt 1999,&nbsp; ORBIT 1999";

// Texte in Unicode-Schreibweise:

var text11 = "Frekvenz:";
var text12 = "Vinkelhastighed:";
var text13 = "Radius:";
var text14 = "Hastighed:";
var text15 = "Vinkel:";
var text16 = "Tyngdekraft:";
var text17 = "Centripetalkraft:";
var text18 = "Snorkraft:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




