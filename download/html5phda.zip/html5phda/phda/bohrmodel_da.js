// Bohrsches Atommodell, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 19.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Partikelmodel";
var text02 = "B&oslash;lgemodel";
var text03 = "Hovedkvantetal:";


var author = "W. Fendt 1999"; 
var translator = "ORBIT 1999";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



