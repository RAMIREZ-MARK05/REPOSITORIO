// Gekoppelte Pendel, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 17.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Forfra";                           
var text02 = ["Start", "Pause", "Forts&aelig;t"];                
var text03 = "Langsom gengivelse";
var text04 = "Startposition:";

var author = "W. Fendt 1998,&nbsp; ORBIT 1999";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                   

// Texte in Unicode-Schreibweise:

var text05 = "Pendul 1";                                   // Erstes Pendel (links)
var text06 = "Pendul 2";                                   // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
