// Beispiel zum Doppler-Effekt, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 17.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Start forfra";
var text02 = ["Pause", "Forts&aelig;t"]; 

var author = "W. Fendt 1998";
var translator = "ORBIT 1999";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                             // Erl�uterungstext
  ["S\u00E5 l\u00E6ngde ambulancen",
   "n\u00E6rmer sig personen, bliver",
   "tidsintervallerne mellem",
   "b\u00F8lgefronterne mindre."],
  ["Nu fjerner lydgiveren sig",
   "fra personen, og",
   "tidsintervallerne mellem",
   "b\u00F8lgefronterne bliver",
   "st\u00F8rre."]];


  

