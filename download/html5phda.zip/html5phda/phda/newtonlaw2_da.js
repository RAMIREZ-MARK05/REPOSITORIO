// Fahrbahnversuch zum 2. Newtonschen Gesetz, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 16.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Slet m&aring;ledata";
var text02 = ["Start", "Gem m&aring;ling"];
var text03 = "Diagram";
var text04 = "Vognens masse:";
var text05 = "Loddets masse:";
var text06 = "Friktionskoefficient:";
var text07 = "M&aring;ledata:";

var author = "W. Fendt 1997,&nbsp; ORBIT 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "FC";
var text09 = "(i s)";
var text10 = "(i m)";
var text11 = "For stor friktion!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


