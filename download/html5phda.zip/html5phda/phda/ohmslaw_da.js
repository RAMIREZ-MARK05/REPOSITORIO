// Ohmsches Gesetz, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 18.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Maks. sp&aelig;nding:";
var text02 = "Maks. str&oslash;mstyrke:";
var text03 = "St&oslash;rre resistans";
var text04 = "Mindre resistans";
var text05 = "St&oslash;rre sp&aelig;nding";
var text06 = "Mindre sp&aelig;nding";

var author = "W. Fendt 1997";
var translator = "ORBIT 1999";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "M\u00E5leomr\u00E5de overskredet!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
