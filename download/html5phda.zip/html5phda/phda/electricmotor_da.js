// Gleichstrom-Elektromotor, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 18.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Forfra";
var text02 = ["Start", "Pause", "Forts&aelig;t"];             
var text03 = "Vend retning";
var text04 = "Str&oslash;mretning";
var text05 = "Magnetfelt";
var text06 = "Lorentzkraft";

var author = "W. Fendt 1997";             
var translator = "ORBIT 1999";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "omdr./min";                      // Umdrehungen pro Minute
