// Federpendel, d�nische Texte (Morten Brydensholt)
// Letzte �nderung 17.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Forfra";
var text02 = ["Start", "Pause", "Forts&aelig;t"];  
var text03 = "Langsom gengivelse";
var text04 = "Fjederkonstant:";
var text05 = "Masse:";
var text06x = "Tyngde-";                                   // Zus�tzliche Zeile!
var text06 = "acceleration:";
var text07 = "Amplitude:";
var text08 = "Udsving";
var text09 = "Hastighed";
var text10 = "Acceleration";
var text11 = "Kraft";
var text12 = "Energi";

var author = "W. Fendt 1998";   
             

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var newtonPerMeter = "N/m";                          
var kilogram = "kg";                               
var meterPerSecond2 = "m/s&sup2;";                 
var meter = "m";                                   

// Texte in Unicode-Schreibweise:

var text13 = "Maksimum";
var text14 = "Udsving";
var text15 = "Hastighed";
var text16 = "Acceleration";
var text17 = "Kraft";
var text18 = "Potentiel energi";
var text19 = "Kinetisk energi";
var text20 = "Samlet energi";
var text21 = "(i s)";
var text22 = "(i m)";
var text23 = "(i m/s)";
var text24 = "(i m/s\u00b2)";
var text25 = "(i N)";
var text26 = "(i J)";
var text27 = "Svingningstid";

// Symbole und Einheiten: 

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                    
var meterUnicode = "m";                              
var meterPerSecond = "m/s";                           
var meterPerSecond2Unicode = "m/s\u00b2";          
var newton = "N";                                     
var joule = "J";                                

