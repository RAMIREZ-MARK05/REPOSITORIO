// Druckdose (hydrostatischer Druck), d�nische Texte (Morten Brydensholt)
// Letzte �nderung 05.02.2019

// Texte in HTML-Schreibweise:

var text01 = "V&aelig;ske:";
var text03 = "Densitet:";
var text04 = "Dybde:";
var text05 = "Hydrostatisk tryk:";

var author = "W. Fendt 1999";                              // Autor
var translator = "ORBIT 1999";                             // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["ukendt", "vand", "ethanol", "benzol", "tetraklorkulstof", "kviks\u00F8lv"]; 
