// Interferenz zweier Kreis- oder Kugelwellen, albanische Texte (Arten Shuqja)
// Letzte �nderung 20.02.2018

// Texte in HTML-Schreibweise:

var text01 = ["Ndal", "Rifillo"];                          // Schaltknopf (Pause/Weiter)
var text02 = "L&euml;vizja e ngadalt&euml;";
var text03 = "Larg&euml;sia midis";
var text04 = "dy burimeve:";
var text05 = "Gjat&euml;sia e val&euml;s:";

var author = "W. Fendt 1999";
var translator = "Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                             

// Texte in Unicode-Schreibweise:

var text06 = "Diferenca e rrug\u00EBve:";
var text07 = "Interferenca konstruktive (amplituda maksimale)";
var text08 = "Interferenca destruktive (amplituda minimale)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03BB";                           // Symbol f�r Wellenl�nge (Lambda)
