// Stehende L�ngswellen, albanische Texte (Arten Shuqja, unvollst�ndig!)
// Letzte �nderung 20.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Forma e tubit:";
var text02 = "t&euml; dyja an&euml;t e hapura";
var text03 = "nj&euml;ra an&euml; e hapur";
var text04 = "t&euml; dyja an&euml;t e mbyllura";
var text05 = "Forma l&euml;kund&euml;se:";
var text06 = ["themelore",  "harmonika e par&euml;",       // Bezeichnungen der Eigenschwingungen 
              "harmonika e dyt&euml;", "harmonika e tret&euml;", 
              "harmonika e kat&euml;rt", "harmonika e pest&euml;"];
var text07 = "M&euml; e ul&euml;t";
var text08 = "M&euml; e lart";
var text09 = "Gjat&euml;sia e tubit:";
var text10 = "Gjat&euml;sia e val&euml;s:";
var text11 = "Frekuenca:";

var author = "W. Fendt 1998,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                  
var hertz = "Hz";                                  

// Texte in Unicode-Schreibweise:

var text12 = "Displacement of particles"; // ???           // �berschrift des ersten Diagramms
var text13 = "Divergence from average pressure"; // ???    // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "N";                                      // Symbol f�r Knoten
var symbolAntinode = "A";                                  // Symbol f�r Bauch

