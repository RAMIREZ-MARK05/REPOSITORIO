// Spezielle Prozesse eines idealen Gases, albanische Texte (Arten Shuqja)
// Letzte �nderung 18.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Pro&ccedil;esi Izobarik";
var text02 = "Pro&ccedil;esi Izohorik";
var text03 = "Pro&ccedil;esi Izotermik";
var text04 = "Gjendja fillestare:";
var text05 = "Shtypja:";
var text06 = "V&euml;llimi:";
var text07 = "Temperatura:";
var text08 = "Gjendja p&euml;rfundimtare:";
var text09 = "Gjendja fillestare";
var text10 = "Fillo";

var author = "W. Fendt 1999,&nbsp; A. Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Puna";
var text12 = "Nxeht\u00EBsia";
var text13 = "Energjia e brendshme e gazit";
var text14 = "rritet.";
var text15 = "Energjia e brendshme e gazit";
var text16 = "\u00EBsht\u00EB konstante.";
var text17 = "Energjia e brendshme e gazit";
var text18 = "zvog\u00EBlohet.";
var text19 = "Shtypja tep\u00EBr e vog\u00EBl!";
var text20 = "Shtypja tep\u00EBr e madhe!";
var text21 = "V\u00EBllimi tep\u00EBr e vog\u00EBl!";
var text22 = "V\u00EBllimi tep\u00EBr e madhe!";
var text23 = "Temperatura tep\u00EBr e vog\u00EBl!";
var text24 = "Temperatura tep\u00EBr e madhe!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


