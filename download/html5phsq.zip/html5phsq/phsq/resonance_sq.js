// Resonanz, albanische Texte (Arten Shuqja)
// Letzte �nderung 19.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = ["Fillo", "Ndal", "Rifillo"];
var text03 = "L&euml;vizja e ngadalt&euml;";
var text04 = "Rezonatori:";
var text05 = "Koefi&ccedil;ienti i elasticitetit:";
var text06 = "Masa:";
var text07 = "Koefi&ccedil;ienti i dob&euml;simit :";
var text08 = "Ngacmuesi:";
var text09 = "Shpejt&euml;sia k&euml;ndore:";
var text10 = "Grafiku i zgjatjes";
var text11 = "Grafiku i amplitud&euml;s";
var text12 = "Grafiku i ndryshimit fazor";

var author = "W. Fendt 1998,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                                  
var newtonPerMeter = "N/m";                           
var perSecond = "1/s";                                
var radPerSecond = "rad/s";                           

// Texte in Unicode-Schreibweise:

var text13 = "Rezonanc\u00EB shkat\u00EBruese!";
var text14 = "(Simulimi nuk \u00EBsht\u00EB aq realist!)";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                              
var radPerSecondUnicode = "rad/s";                  

