// Ersatzkraft mehrerer Kr�fte, albanische Texte (Arten Shuqja)
// Letzte �nderung 16.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Numri i forcave:";
var text02 = "Gjej rezultanten";
var text03 = "Fshih nd&euml;rtimin";

var author = "W. Fendt 1998";
var translator = "Arten Shuqja 2007";
