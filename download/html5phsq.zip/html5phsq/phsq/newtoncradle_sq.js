// Newtons Wiege, albanische Texte (Arten Shuqja)
// Letzte �nderung 18.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = "Fillo";
var text03 = "Numri i topave:";

var author = "W. Fendt 1997";
var translator = "Arten Shuqja 2007";
