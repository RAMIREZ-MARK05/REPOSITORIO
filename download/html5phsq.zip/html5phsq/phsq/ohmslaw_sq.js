// Ohmsches Gesetz, albanische Texte (Arten Shuqja)
// Letzte �nderung 21.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Maksimum n&euml; volt:";
var text02 = "Maksimum n&euml; amper:";
var text03 = "Zmadho rezistenc&euml;n";
var text04 = "Zvog&euml;lo rezistenc&euml;n";
var text05 = "Zmadho voltazhin";
var text06 = "Zvog&euml;lo voltazhin";

var author = "W. Fendt 1997";
var translator = "Arten Shuqja 2007";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Tejkalim maksimal!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
