// Kombinationen von Widerst�nden, Spulen und Kondensatoren, albanische Texte (Arten Shuqja)
// Letzte �nderung 22.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Burimi i rrym&euml;s alternative:";
var text02 = "Tensioni:";
var text03 = "Frekuenca:";
var text04 = "Elementi:";
var text06 = ["Rezistenca:", "Induktiviteti:", "Kapaciteti:"];
var text07 = "Z&euml;vend&euml;so";
var text08 = "Mblidh (n&euml; seri)";
var text09 = "Mblidh (n&euml; paralel)";
var text10 = "Fshih";
var text11 = "Njehsimet:";
var text12 = "Tensioni";
var text13 = "Intensiteti";

var author = "W. Fendt 2004";
var translator = "A. Shuqja 2007";

// Texte in Unicode-Schreibweise:

var text05 = ["Rezistenc\u00EB", "Bobin\u00EB", "Kondensator"];
var text14 = "Tensioni:";
var text15 = "Intensiteti:";
var text16 = "Rezistenca e p\u00EBrgjithshme komplekse:";
var text17 = "Rezistenca e p\u00EBrgjithshme:";
var text18 = "Diferenca e faz\u00EBs:";
var text19 = "shum\u00EB e vog\u00EBl";                    // Stromst�rke Voltmeter
var text20 = "shum\u00EB e vog\u00EBl";                    // Spannung Amperemeter
var text21 = "shum\u00EB e vog\u00EBl";                    // Impedanz/Widerstand Amperemeter
var text22 = "shum\u00EB e madhe";                         // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)