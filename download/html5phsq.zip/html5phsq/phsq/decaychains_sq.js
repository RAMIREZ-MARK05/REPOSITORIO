// Zerfallsreihen, albanische Texte (Arten Shuqja)
// Letzte �nderung 23.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Serit&euml;:";
var text03 = "Zb&euml;rthimi tjet&euml;r";

var author = "W. Fendt 1998"; 
var translator = "Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:

var text02 = ["Serit\u00EB Torium", "Serit\u00EB Neptun", "Serit\u00EB Uranium-Radium", "Serit\u00EB Uranium-Aktinium"];          





