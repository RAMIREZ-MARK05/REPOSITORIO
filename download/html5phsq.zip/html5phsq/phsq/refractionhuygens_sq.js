// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), albanische Texte (Arten Shuqja)
// Letzte �nderung 22.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rifillo";
var text02 = "Hapi tjet&euml;r";
var text03 = ["Ndal", "Vazhdo"];                  
var text04 = "Treguesi i p&euml;rthyerjes 1:";
var text05 = "Treguesi i p&euml;rthyerjes 2:";
var text06 = "K&euml;ndi r&euml;nies:";

var author = "W. Fendt 1998";
var translator = "Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                              

// Texte in Unicode-Schreibweise:

var text07 = [

  ["Fronti i nj\u00EB vale plane bie",                     // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "diagonalisht n\u00EB sip\u00EBrfaqen ndar\u00EBse",
   "nd\u00EBrmjet dy mjediseve.",
   "Vala p\u00EBhaqet me shpejt\u00EBsi",
   "t\u00EB ndryshme n\u00EB secilin mjedis."],
   
  ["Fronti i nj\u00EB vale plane bie",                     // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "pingul n\u00EB sip\u00EBrfaqen ndar\u00EBse",
   "nd\u00EBrmjet dy mjediseve.",
   "Vala p\u00EBhaqet me shpejt\u00EBsi",
   "t\u00EB ndryshme n\u00EB secilin mjedis."],
 
  ["Me arritjen e frontit valor,",                         // i == 2 (step == 1, n1 > n2) 
   "pikat e sip\u00EBrfaqes ndar\u00EBse",
   "sillen sipas parimit t\u00EB Huygensit.",
   "\u00C7do pik\u00EB vepron si nj\u00EB burim",
   "val\u00EBsh elementare t\u00EB drit\u00EBs.",
   "N\u00EB mjedin 2 k\u00EBto val\u00EB",
   "elementare l\u00EBvizin m\u00EB shpejt\u00EB",
   "meqen\u00EBse treguesi i p\u00EBrthyerjes",
   "\u00EBsht\u00EB m\u00EB i vog\u00EBl."],
   
  ["Me arritjen e frontit valor,",                         // i == 3 (step == 1, n1 < n2) 
   "pikat e sip\u00EBrfaqes ndar\u00EBse",
   "sillen sipas parimit t\u00EB Huygensit.",
   "\u00C7do pik\u00EB vepron si nj\u00EB burim",
   "val\u00EBsh elementare t\u00EB drit\u00EBs.",
   "N\u00EB mjedin 2 k\u00EBto val\u00EB",
   "elementare l\u00EBvizin m\u00EB ngadal\u00EB",
   "meqen\u00EBse treguesi i p\u00EBrthyerjes",
   "\u00EBsht\u00EB m\u00EB i madh."], 

  ["Mb\u00EBshtjell\u00EBsja e jashtme e t\u00EB",         // i == 4 (step == 2, total == false, eps1 > 0) 
   "gjith\u00EB val\u00EBve elementare \u00EBsht\u00EB",
   "nj\u00EB val\u00EB plane e re. T\u00EBrheq",
   "v\u00EBmendjen se drejtimi i p\u00EBrhapjes",
   "s\u00EB val\u00EBs plane ndryshon kur",
   "l\u00EBviz nga mjedisi 1 n\u00EB 2."], 

  ["Mb\u00EBshtjell\u00EBsja e jashtme e t\u00EB",         // i == 5 (step == 2, total == false, eps1 == 0)
   "gjith\u00EB val\u00EBve elementare \u00EBsht\u00EB",
   "nj\u00EB val\u00EB plane e re."],  
   
  ["Mb\u00EBshtjell\u00EBsja e jashtme e t\u00EB",         // i == 6 (step == 2, total == true)
   "gjith\u00EB val\u00EBve elementare \u00EBsht\u00EB",
   "nj\u00EB val\u00EB plane e re n\u00EB mjedisin 1",
   "(vala e pasqyruar).",
   "Vala nuk kalon n\u00EB mjedisin 2",
   "(pasqyrim i plot\u00EB i brendsh\u00EBm)."],
   
  ["Rrezja e p\u00EBrhapjes s\u00EB val\u00EBs",           // i == 7 (step == 3)
   "\u00EBsht\u00EB vizatuar tashm\u00EB.",
   "Ajo \u00EBsht\u00EB pingule me",
   "frontin e val\u00EBs."],   

  ["Nj\u00EB front vale vjen rrall\u00EB",                 // i == 8 (step == 4)
   "e vetme!"],
   
  ["N\u00EB se treguesi i p\u00EBrthyerjes",               // i == 9 (n1 == n2)
   "s\u00EB dy mjediseve \u00EBsht\u00EB i njejt\u00EB",
   "ndodh asgj\u00EB e ve\u00E7ant\u00EB."]];
          
var text08 = "K\u00EBndi r\u00EBnies:"; 
var text09 = "K\u00EBndi i pasqyrimit:";
var text10 = "K\u00EBndi i p\u00EBrthyerjes:"; 
var text11 = "Mjedisi 1";
var text12 = "Mjedisi 2";      
var text13 = ["K\u00EBndi kufi p\u00EBr", "pasqyrimin e plot\u00EB t\u00EB brendsh\u00EBm:"];

// Einheiten:

var degreeUnicode = "\u00B0";                     
