// Reflexion und Brechung von Licht, albanische Texte (Arten Shuqja)
// Letzte �nderung 22.02.2018

// Texte in HTML-Schreibweise:
    
var text01 = "Treguesi i p&euml;rthyerjes 1:";
var text02 = "Treguesi i p&euml;rthyerjes 2:";
var text03 = "K&euml;ndi r&euml;nies:";
var text04 = "K&euml;ndi i pasqyrimit:";
var text05 = "K&euml;ndi i p&euml;rthyerjes:";    
var text06 = ["K&euml;ndi kufi p&euml;r pasqyrimin", "e plot&euml; t&euml; brendsh&euml;m:"];

var author = "W. Fendt 1997,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise:

var text07 = [["zbraz\u00EBti", "1"], ["aj\u00EBr", "1.0003"],       // Stoffe und Brechungsindizes
    ["uj\u00EB", "1.33"], ["etanol", "1.36"],
    ["qelq kuartz", "1.46"], ["benzol", "1.49"], 
    ["qelq crown N-K5", "1.52"], ["krip\u00EB guri", "1.54"], 
    ["qelq flint LF5", "1.58"], ["qelq crown N-SK4", "1.61"],
    ["qelq flint SF6", "1.81"], ["diamand", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03B5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03B5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00B0";                              // Grad
