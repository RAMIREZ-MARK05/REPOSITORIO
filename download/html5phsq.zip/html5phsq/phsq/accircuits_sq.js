// Einfache Wechselstromkreise, albanische Texte (Arten Shuqja)
// Letzte �nderung 21.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rezistenc&euml;";
var text02 = "Kondensator";
var text03 = "Bobin&euml;";
var text04 = "Rivendos";
var text05 = ["Fillo", "Ndal", "Rifillo"];          
var text06 = "L&euml;vizja e ngadalt&euml;";
var text07 = "Frekuenca:";
var text08 = "Tensioni maksimal:";
var text09 = "Rezistenca:";                            
var text10 = "Kapaciteti:";                          
var text11 = "Induktiviteti:"; 
var text12 = "Intensiteti maksimal:"; 

var author = "W. Fendt 1998,&nbsp; Arten Shuqja 2007";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                  
var volt = "V";                                    
var ampere = "A";                                  
var milliampere = "mA";                            
var microampere = "&mu;A";                         
var ohm = "&Omega;";                                
var microfarad = "&mu;F";                           
var henry = "H";                                    

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
