// Schiefer Wurf, albanische Texte (Arten Shuqja)
// Letzte �nderung 18.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";                    
var text02 = ["Fillo", "Ndal", "Rifillo"];          
var text03 = "L&euml;vizja e ngadalt&euml;";
var text04 = "Lart&euml;sia fillestare:";
var text05 = "Shpejt&euml;sia fillestare:";
var text06 = "K&euml;ndi i pjerr&euml;sis&euml;:";
var text07 = "Masa:"; 
var text08 = "Nxitimi i r&euml;nies s&euml; lir&euml;:";
var text09 = "Vendndodhja";
var text10 = "Shpejt&euml;sia";
var text11 = "Nxitimi";
var text12 = "Forca";
var text13 = "Energjia";

var author = "W. Fendt 2000,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                  
var meterPerSecond = "m/s";                       
var meterPerSecond2 = "m/s&sup2;";                
var kilogram = "kg";                              
var degree = "&deg;";                             

// Texte in Unicode-Schreibweise:

var text14 = "(n\u00EB m)";                                // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Vendndodhja:";
var text16 = "(horizontal)";
var text17 = "(vertikal)";
var text18 = "Larg\u00EBsia horizontale:";
var text19 = "Lart\u00EBsia maksimale:";
var text20 = "Koha:";
var text21 = "P\u00EBrb\u00EBr\u00EBset e shpejt\u00EBsis\u00EB:";
var text22 = "Vlera e shpejt\u00EBsis\u00EB:";
var text23 = "K\u00EBndi i pjerr\u00EBsis\u00EB:";
var text24 = "Nxitimi:";
var text25 = "Forca:";
var text26 = "Energjia kinetike:";
var text27 = "Energjia potenciale:";
var text28 = "Energjia e plot\u00EB:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                             
var secondUnicode = "s";                            
var meterPerSecondUnicode = "m/s";                  
var meterPerSecond2Unicode = "m/s\u00B2";           
var newtonUnicode = "N";                            
var jouleUnicode = "J";                             
var degreeUnicode = "\u00B0";                       



