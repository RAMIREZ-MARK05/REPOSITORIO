// Gekoppelte Pendel, albanische Texte (Arten Shuqja)
// Letzte �nderung 19.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";                           
var text02 = ["Fillo", "Ndal", "Rifillo"];                
var text03 = "L&euml;vizja e ngadalt&euml;";
var text04 = "Pozicioni fillestar:";

var author = "W. Fendt 1998";
var translator = "Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                            

// Texte in Unicode-Schreibweise:

var text05 = "Lavjerr\u00EBsi 1";                          // Erstes Pendel (links)
var text06 = "Lavjerr\u00EBsi 2";                          // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
