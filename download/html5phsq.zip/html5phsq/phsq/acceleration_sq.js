// Bewegung mit konstanter Beschleunigung, albanische Texte (Arten Shuqja)
// Letzte �nderung 15.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = ["Fillo", "Ndal", "Rifillo"];
var text03 = "L&euml;vizja e ngadalt&euml;";
var text04 = "Zhvendosja fillestare:";
var text05 = "Shpejt&euml;sia fillestare:";
var text06 = "Nxitimi:";
var text07 = "Vektori i shpejt&euml;sis&euml;";
var text08 = "Vektori i nxitimit";

var author = "W. Fendt 2000";
var translator = "Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:

var text09 = "(n\u00EB s)";                                // Einheitenangabe f�r Zeit-Achse
var text10 = "(n\u00EB m)";                                // Einheitenangabe f�r Weg-Achse
var text11 = "(n\u00EB m/s)";                              // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(n\u00EB m/s\u00B2)";                        // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                      
var meter = "m";                                       
var meterPerSecond = "m/s";                            
var meterPerSecond2 = "m/s\u00B2";                     
