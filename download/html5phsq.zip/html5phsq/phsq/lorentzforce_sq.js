// Leiterschaukel-Versuch zur Lorentzkraft, albanische Texte (Arten Shuqja)
// Letzte �nderung 20.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Mbylle / Hape qarkun";
var text02 = "Ndrysho kahun e rrym&euml;s";
var text03 = "Rrotullo magnetin";
var text04 = "Kahu i rrym&euml;s";
var text05 = "Fusha magnetike";
var text06 = "Forca e Lorencit";

var author = "W. Fendt 1998";
var translator = "Arten Shuqja 2007";
