// Schwebungen, albanische Texte (Arten Shuqja)
// Letzte �nderung 20.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = ["Fillo", "Ndal", "Rifillo"];
var text03 = "L&euml;vizja e ngadalt&euml;";
var text04 = "Frekuencat:";
var text05 = "Vala e par&euml;:";
var text06 = "Vala e dyt&euml;:";

var author = "W. Fendt 2001"; 
var translator = "Arten Shuqja 2007";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



