// Bohrsches Atommodell, albanische Texte (Arten Shuqja)
// Letzte �nderung 24.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Modeli grimcor";
var text02 = "Modeli valor";
var text03 = "Numri kuantik themelor:";


var author = "W. Fendt 1999"; 
var translator = "Arten Shuqja 2007";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



