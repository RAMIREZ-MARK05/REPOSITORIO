// Zweites Kepler-Gesetz, albanische Texte (Arten Shuqja)
// Letzte �nderung 19.02.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Gjysm&euml;boshti i madh:";
var text03 = "Jasht&euml;q&euml;nd&euml;rsia:";
var text04 = ["Ndal", "Rifillo"];
var text05 = "L&euml;vizja e ngadalt&euml;";
var text06 = ["Larg&euml;sia", "nga Dielli:"];
var text07 = "Shpejt&euml;sia:";
var text08 = "E &ccedil;astit:";
var text09 = "Minimale:";
var text10 = "Maksimale:";
var text11 = "Sektor&euml;t";
var text12 = "Vektori i shpejt&euml;sis&euml;";

var author = "W. Fendt 2000,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["M\u00EBrkuri", "Venusi", "Toka", "Marsi", "Jupiteri", "Saturni", "Urani", "Neptuni",
              "Plutoni", "Kometa Hallei", ""];

// Symbole und Einheiten: 

var auUnicode = "AU";
var symbolPeriod = "T";

