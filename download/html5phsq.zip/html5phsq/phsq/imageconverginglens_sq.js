// Bilderzeugung Sammellinse, albanische Texte (Arten Shuqja)
// Letzte �nderung 22.02.2018

// Texte in HTML-Schreibweise:
    
var text01 = "Larg&euml;sia vatrore:";
var text02 = "Larg&euml;sia e objektit:";
var text03 = "Lart&euml;sia e objektit:";
var text04 = "Larg&euml;sia e sh&euml;mb&euml;llimit:";
var text05 = "Lart&euml;sia e sh&euml;mb&euml;llimit:";    
var text06 = "Lloji i sh&euml;mb&euml;llimit:"
var text07 = ["real", "virtual"];
var text08 = ["i p&euml;rmbysur", "i drejt&euml;"];
var text09 = ["i zvog&euml;luar", "n&euml; madh&euml;si t&euml; barabart&euml;", "i zmadhuar", "pafund&euml;sisht i zmadhuar"];
var text10 = "Rreze t&euml; vetmuara t&euml; drit&euml;s";
var text11 = "Tuf&euml; e rrezeve t&euml; drit&euml;s";
var text12 = "Theksohet:";

var author = "W. Fendt 2008,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var centimeter = "cm";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text13 = ["objekti", 
              "larg\u00EBsia e objektit", 
              "lart\u00EBsia e objektit",
              "thjerra", 
              "rrafshi i thjerr\u00EBs", 
              "boshti optik kryesor",
              "vatrat", 
              "larg\u00EBsia vatrore", 
              "sh\u00EBmb\u00EBllimi", 
              "larg\u00EBsia e sh\u00EBmb\u00EBllimit", 
              "lart\u00EBsia e sh\u00EBmb\u00EBllimit",
              "ekrani"];
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "o";
var symbolGG = "O"; 
var symbolB = "i";
var symbolBB = "I";


