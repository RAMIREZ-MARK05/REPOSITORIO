// Kepler-Fernrohr, albanische Texte (Arten Shuqja)
// Letzte �nderung 22.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Larg&euml;sit&euml; vatrore:"; 
var text02 = "Objektivi:";
var text03 = "Okulari:";
var text04 = "K&euml;ndet:";
var text05 = "Zmadhimi:";

var author = "W. Fendt 2000";
var translator = "Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite

