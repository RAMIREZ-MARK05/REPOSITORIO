// Magnetfeld eines Stabmagneten, albanische Texte (Arten Shuqja)
// Letzte �nderung 20.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Fshih vijat e forc&euml;s";
var text02 = "Rrotullo magnetin";

var author = "W. Fendt 2001";
var translator = "Arten Shuqja 2007";
