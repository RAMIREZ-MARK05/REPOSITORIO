// Zerlegung einer Kraft in zwei Komponenten, albanische Texte (Arten Shuqja)
// Letzte �nderung 16.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Vlera numerike e dh&euml;n&euml;";                       
var text02 = "forca:";
var text03 = "Madh&euml;sit&euml; e k&euml;ndeve:";
var text04 = "k&euml;ndi i par&euml;:";
var text05 = "k&euml;ndi i dyt&euml;:";
var text06 = "Vlerat numerike t&euml; p&euml;rb&euml;r&euml;sve:";
var text07 = "p&euml;rb&euml;r&euml;sja e par&euml;:";
var text08 = "p&euml;rb&euml;r&euml;sja e dyt&euml;:";
var text09 = "Gjej p&euml;rb&euml;r&euml;set";
var text10 = "Fshih nd&euml;rtimin";

var author = "W. Fendt 2003";
var translator = "Arten Shuqja 2007";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                              
var newton = "N";                                  

// Texte in Unicode-Schreibweise:

var text11 = "p\u00EBrb\u00EBr\u00EBsja e par\u00EB";          // Text f�r erste Komponente
var text12 = "p\u00EBrb\u00EBr\u00EBsja e dyt\u00EB";          // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                         