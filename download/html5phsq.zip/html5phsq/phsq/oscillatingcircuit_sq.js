// Elektromagnetischer Schwingkreis, albanische Texte (Arten Shuqja)
// Letzte �nderung 21.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = ["Fillo", "Ndal", "Rifillo"];
var text03 = "L&euml;vizja e ngadalt&euml; (10 &times;)";
var text04 = "L&euml;vizja e ngadalt&euml; (100 &times;)";
var text05 = "Kapaciteti:";
var text06 = "Induktiviteti:";
var text07 = "Rezistenca:";
var text08 = "Tensioni maksimal:";
var text09 = "Tensioni, Intensiteti";
var text10 = "Energjia";

var author = "W. Fendt 1999,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                     
var henry = "H";                              
var ohm = "&Omega;";                          
var volt = "V";                               

// Texte in Unicode-Schreibweise:

var text11 = "Perioda e l\u00EBkundjeve:";
var text12 = "Energjia e fush\u00EBs elektrike:";
var text13 = "Energjia e fush\u00EBs magnetike:";
var text14 = "Energjia e brendshme termike:";
var text15 = "L\u00EBkundje q\u00EB s'shuhen";
var text16 = "L\u00EBkundje q\u00EB shuhen";
var text17 = "Shuarje n\u00EB vlera kritike";
var text18 = "Shuarje mbi vlera kritike";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                  
var voltUnicode = "V";                             
var ampere = "A";                                  
var joule = "J";                                   
