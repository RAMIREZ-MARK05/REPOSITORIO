// Beispiel zur Zeitdilatation, albanische Texte (Arten Shuqja)
// Letzte �nderung 23.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Zvog&euml;lo shpejt&euml;sin&euml;";
var text02 = "Zmadho shpejt&euml;sin&euml;";
var text03 = "Rivendos";
var text04 = ["Fillo", "Ndal", "Rifillo"];

var author = "W. Fendt 1997,&nbsp; Arten Shuqja 2007";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "Larg\u00EBsia:";
var text06 = "5 or\u00EB drit\u00EB";
var text07 = "Shpejt\u00EBsia:";
var text08 = "Koha e fluturimit (sistemi Tok\u00EB):";
var text09 = "or\u00EB";
var text10 = "Koha e fluturimit (sistemi anije kozmike):";