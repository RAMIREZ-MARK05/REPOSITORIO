// Kr�fte an der schiefen Ebene, albanische Texte (Arten Shuqja)
// Letzte �nderung 18.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = ["Fillo", "Ndal", "Rifillo"];
var text03 = "L&euml;vizja e ngadalt&euml;";
var text04 = "Forc&euml;mat&euml;si";
var text05 = "Vektor&euml;t e forcave";
var text06 = "K&euml;ndi i pjerr&euml;sis&euml;:";
var text07 = "Forca e r&euml;ndes&euml;s:";
var text08 = "P&euml;rb&euml;r&euml;sja paralele:";
var text09 = "P&euml;rb&euml;r&euml;sja pingule:";
var text10 = "Koefi&ccedil;ienti i f&euml;rkimit";
var text11 = "Forca e f&euml;rkimit:";
var text12 = "Forca e duhur:";

var author = "W. Fendt 1999,&nbsp; Arten Shuqja 2007";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad
var newton = "N";                                          // Newton
