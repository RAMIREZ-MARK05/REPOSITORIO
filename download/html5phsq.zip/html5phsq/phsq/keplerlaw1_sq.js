// Erstes Kepler-Gesetz, albanische Texte (Arten Shuqja)
// Letzte �nderung 19.02.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Gjysm&euml;boshti i madh:";
var text03 = "Jasht&euml;q&euml;nd&euml;rsia:";
var text04 = "Gjysm&euml;boshti i vog&euml;l:";
var text05 = ["Ndal", "Rifillo"];
var text06 = "L&euml;vizja e ngadalt&euml;";
var text07 = "Larg&euml;sia nga Dielli:";
var text08 = "E &ccedil;astit:";
var text09 = "Minimale:";
var text10 = "Maksimale:";
var text11 = "Orbita eliptike";
var text12 = "Boshtet";
var text13 = "Vijat lidh&euml;se";

var author = "W. Fendt 2000,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["M\u00EBrkuri", "Venusi", "Toka", "Marsi", "Jupiteri", "Saturni", "Urani", "Neptuni",
              "Plutoni", "Kometa Hallei", ""];

var text14 = "Dielli";
var text15 = "Planeti";
var text16 = "Kometa";
var text17 = "Perihel";
var text18 = "Afel";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "AU";

