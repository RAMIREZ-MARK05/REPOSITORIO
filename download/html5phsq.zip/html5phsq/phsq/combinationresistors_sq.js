// Kombinationen von Widerst�nden, albanische Texte (Arten Shuqja)
// Letzte �nderung 20.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = "Voltazhi i bateris&euml;:";
var text03 = "Rezistanca:";
var text04 = "Mblidh rezistenc&euml;n (Lidhje n&euml; seri)";
var text05 = "Mblidh rezistenc&euml;n (Lidhje n&euml; paralel)";
var text06 = "Matjet n&euml;:";
var text07 = "Volt";
var text08 = "Amper";

var author = "W. Fendt 2002";
var translator = "Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:

var text09 = "Volt:";
var text10 = "Amper:";
var text11 = "Rezistanca:";
var text12 = "Rezistanca ekuivalente:";
var text13 = "shum\u00EB e vog\u00EBl";
var text14 = "shum\u00EB e madhe";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

