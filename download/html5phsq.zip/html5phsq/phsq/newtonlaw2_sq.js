// Fahrbahnversuch zum 2. Newtonschen Gesetz, albanische Texte (Arten Shuqja)
// Letzte �nderung 18.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = ["Fillo", "Regjistro matjen"];
var text03 = "Grafiku";
var text04 = "Masa e vagonit:";
var text05 = "Masa e varur:";
var text06 = "Koefi&ccedil;ienti i f&euml;rkimit:";
var text07 = "Matjet:";

var author = "W. Fendt 1997,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "LB";
var text09 = "(n\u00EB s)";
var text10 = "(n\u00EB m)";
var text11 = "Sip\u00EBrfaqja shum\u00EB e ashp\u00EBr!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


