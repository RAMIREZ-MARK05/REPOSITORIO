// Gleichstrom-Elektromotor, albanische Texte (Arten Shuqja)
// Letzte �nderung 21.02.2018

// Texte in HTML-Schreibweise;

var text01 = "Rivendos";
var text02 = ["Fillo", "Ndal", "Rifillo"];             
var text03 = "Ndrysho drejtimin";
var text04 = "Ndrysho drejtimin";
var text05 = "Fusha magnetike";
var text06 = "Forca e Lorencit";

var author = "W. Fendt 1997";             
var translator = "Arten Shuqja 2007";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rrot/min";                       // Umdrehungen pro Minute
