// Generator, albanische Texte (Arten Shuqja)
// Letzte �nderung 21.02.2018

// Texte in HTML-Schreibweise;

var text01 = "Pa komutator";
var text02 = "Me komutator";
var text03 = "Ndrysho drejtimin";
var text04 = ["Fillo", "Ndal", "Rifillo"];
var text05 = "Drejtimi i qarkullimit";
var text06 = "Fusha magnetike";
var text07 = "Kahu i rrym&euml;s";

var author = "W. Fendt 1998";  
var translator = "Arten Shuqja 2007";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rrot/min";                       // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
