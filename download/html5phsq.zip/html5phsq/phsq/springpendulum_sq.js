// Federpendel, albanische Texte (Arten Shuqja)
// Letzte �nderung 19.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = ["Fillo", "Ndal", "Rifillo"];  
var text03 = "L&euml;vizja e ngadalt&euml;";
var text04 = "Koefi&ccedil;ienti i elasticitetit:";
var text05 = "Masa:";
var text06x = "Nxitimi";                             // Zus�tzliche Zeile!
var text06 = "i r&euml;nies s&euml; lir&euml;:";
var text07 = "Amplituda:";
var text08 = "Zhvendosja";
var text09 = "Shpejt&euml;sia";
var text10 = "Nxitimi";
var text11 = "Forca";
var text12 = "Energjia";

var author = "W. Fendt 1998,&nbsp; Arten Shuqja 2007";   
             

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var newtonPerMeter = "N/m";                         
var kilogram = "kg";                                
var meterPerSecond2 = "m/s&sup2;";                  
var meter = "m";                                    

// Texte in Unicode-Schreibweise:

var text13 = "Maksimumi";
var text14 = "Zhvendosja";
var text15 = "Shpejt\u00EBsia";
var text16 = "Nxitimi";
var text17 = "Forca";
var text18 = "Energjia potenciale";
var text19 = "Energjia kinetike";
var text20 = "Energjia e plot\u00EB";
var text21 = "(n\u00EB s)";
var text22 = "(n\u00EB m)";
var text23 = "(n\u00EB m/s)";
var text24 = "(n\u00EB m/s\u00b2)";
var text25 = "(n\u00EB N)";
var text26 = "(n\u00EB J)";
var text27 = "Perioda e l\u00EBkundjeve";

// Symbole und Einheiten: 

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                  
var meterUnicode = "m";                            
var meterPerSecond = "m/s";                        
var meterPerSecond2Unicode = "m/s\u00B2";           
var newton = "N";                                   
var joule = "J";                                    

