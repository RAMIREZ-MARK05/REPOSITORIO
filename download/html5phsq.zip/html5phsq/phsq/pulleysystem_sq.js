// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, albanische Texte (Arten Shuqja)
// Letzte �nderung 16.02.2018

// Texte in HTML-Schreibweise:

var text01 = "2 pulexha";
var text02 = "4 pulexha";
var text03 = "6 pulexha";
var text04 = "Pesha:";
var text05 = "Pesha e humbjes s&euml; pulexha:";
var text06 = "Forca e nevojshme:";
var text07 = "Forc&euml;mat&euml;si";
var text08 = "Vektor&euml;t e forcave";

var author = "W. Fendt 1998";
var translator = "Arten Shuqja 2007";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                   
