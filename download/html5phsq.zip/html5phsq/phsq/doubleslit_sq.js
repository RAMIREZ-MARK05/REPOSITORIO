// Interferenz von Licht am Doppelspalt, albanische Texte (Arten Shuqja)
// Letzte �nderung 23.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Gjat&euml;sia e val&euml;s:";
var text02 = "Larg&euml;sia midis &ccedil;arjeve:";
var text03 = "K&euml;ndi:";
var text04 = "Maksimumet:";
var text05 = "Minimumet:";
var text06 = "Intensiteti relativ:";
var text07 = "Model interference";
var text08 = "Paraqitja e intensitetit";

var author = "W. Fendt 2003,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
