// Beispiel zum Doppler-Effekt, albanische Texte (Arten Shuqja)
// Letzte �nderung 20.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Fillo p&euml;rs&euml;ri";
var text02 = ["Ndal", "Rifillo"]; 

var author = "W. Fendt 1998";
var translator = "Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                             // Erl�uterungstext
  ["P\u00EBr sa koh\u00EB ambulanca i afrohet",
  "njeriut, larg\u00EBsit\u00EB midis",
  "sip\u00EBrfaqeve t\u00EB val\u00EBve t\u00EB arritura,",
  "shkurtohen."],
  ["Tash automjeti e l\u00EB njeriun.",
  "K\u00EBshtu q\u00EB larg\u00EBsit\u00EB nd\u00EBrmjet",
  "sip\u00EBrfaqeve t\u00EB val\u00EBve t\u00EB arritura,",
  "zgjaten."]];


  

