// Druckdose (hydrostatischer Druck), albanische Texte (Arten Shuqja)
// Letzte �nderung 06.02.2019

// Texte in HTML-Schreibweise:

var text01 = "L\u00EBng:";
var text03 = "D\u00EBnd\u00EBsia:";
var text04 = "Thell\u00EBsia:";
var text05 = "Shtypja hidrostatike:";

var author = "W. Fendt 1999";                              // Autor
var translator = "Arten Shuqja 2007";                      // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["i panjohur", "uj\u00EB", "etanoli", "benzeni", "tetrachloromethane", "zhiv\u00EB"]; 
