// Kettenkarussell, albanische Texte (Arten Shuqja)
// Letzte �nderung 18.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Karosela";
var text02 = "Karosela me forcat";
var text03 = "Skica";
var text04 = "Vlerat numerike";
var text05 = ["Ndal", "Rifillo"];
var text06 = "L&euml;vizja e ngadalt&euml;";
var text07 = "Perioda:";
var text08 = ["Larg&euml;sia midis pikave t&euml; varjeve", "dhe boshtit t&euml; rrotullimi:"]; 
var text09 = "Gjat&euml;sia e fijeve:";
var text10 = "Masa:";

var author = "W. Fendt 1999,&nbsp; Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:

var text11 = "Frekuenca:";
var text12 = "Shpejt\u00EBsia k\u00EBndore:";
var text13 = "Rrezja:";
var text14 = "Shpejt\u00EBsia:";
var text15 = "K\u00EBndi:";
var text16 = "Forca e r\u00EBndes\u00EBs:";
var text17 = "Forca q\u00EBnd\u00EBrsynuese:";
var text18 = "Tensioni i fijes:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




