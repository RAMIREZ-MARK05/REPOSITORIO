// Gleichgewicht dreier Kr�fte, albanische Texte (Arten Shuqja)
// Letzte �nderung 16.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Forcat:";
var text02 = "Majtas:";
var text03 = "Djathtas:";
var text04 = "M&euml; posht&euml;:";
var text05 = "Paralelogrami i forcave";
var text06 = "K&euml;ndet:";
var text07 = "Majtas:";
var text08 = "Djathtas:";

var author = "W. Fendt 2000";
var translator = "Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00B0";              
var newton = "N";                          
