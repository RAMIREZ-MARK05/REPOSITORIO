// Hebelgesetz, albanische Texte (Arten Shuqja)
// Letzte �nderung 24.02.2018

// Texte in Unicode-Schreibweise:

var text01 = "Momenti kund\u00EBrorar:";
var text02 = "Momenti orar:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "M_1";                              // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "M_2";                             // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

var newton = "N";
var meter = "m";

var author = "W. Fendt 1997,\u0020 Arten Shuqja 2007";     // Autor (und �bersetzer)
