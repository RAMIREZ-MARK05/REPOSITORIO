// Magnetfeld eines geraden stromdurchflossenen Leiters, albanische Texte (Arten Shuqja)
// Letzte �nderung 20.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Ndrysho kahun e rrym&euml;s";

var author = "W. Fendt 2000";
var translator = "Arten Shuqja 2007";
