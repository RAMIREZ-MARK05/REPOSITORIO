// Wheatstonesche Br�ckenschaltung, albanische Texte (Arten Shuqja)
// Letzte �nderung 21.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Matje e re";
var text02 = "Rezistenca etalon:";
var text03 = "Reokordi:";
var text04 = "Pozicioni i kontaktit rr&euml;shqit&euml;s:";
var text05 = "Tensioni i burimit:";
var text06 = "Rezistenca e metrit:";
var text07 = "Rezistanca e panjohur";
var text08 = "Tensioni i treguar";
var text09 = "Intensiteti i treguar";
var author = "W. Fendt 2006,&nbsp; Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:

var text10 = ["L\u00EBviz kontaktin rr\u00EBshqit\u00EBs",
  	          "derisa intensiteti t\u00EB b\u00EBhet zero!"];
var text11 = "Tash rezistenca mund t\u00EB llogaritet.";         

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var milliampere = "mA";
var ohm = "\u03A9";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00D7";                              
