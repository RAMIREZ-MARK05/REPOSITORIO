// Messung der Auftriebskraft, albanische Texte (Arten Shuqja)
// Letzte �nderung 19.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Baza e trupit:"; 
var text02 = "Gjat&euml;sia e trupit:";
var text03 = "Dend&euml;sia e trupit:";
var text04 = "Dend&euml;sia e l&euml;ngut:";   
var text05 = "Thell&euml;sia:";
var text06 = "V&euml;llimi i zhvendosur:"; 
var text07 = "Forca e Arkimedit:";
var text08 = "Pesha e trupit:";
var text09 = "Forca e matur:";
var text10 = "Kufiri i matjes:";

var author = "W. Fendt 1998,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Tejkalim maksimal!";
