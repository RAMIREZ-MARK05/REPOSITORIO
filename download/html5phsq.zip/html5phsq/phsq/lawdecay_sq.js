// Zerfallsgesetz der Radioaktivit�t, albanische Texte (Arten Shuqja)
// Letzte �nderung 24.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = ["Fillo", "Ndal", "Rifillo"];    
var text03 = "Grafiku";  

var author = "W. Fendt 1998";
var translator = "Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:

var text04 = "Koha:";                                      
var text05 = "Akoma t\u00EB pa zb\u00EBrthyera:";        
var text06 = "Tashm\u00EB t\u00EB zb\u00EBrthyera:";
var text07 = ["b\u00EBrthama",                             // 0 Kerne 
              "b\u00EBrtham\u00EB",                        // 1 Kern (Singular)
              "b\u00EBrthama",                             // 2 Kerne (Dual)
              "b\u00EBrthama"];                            // 3 oder mehr Kerne (Plural)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
