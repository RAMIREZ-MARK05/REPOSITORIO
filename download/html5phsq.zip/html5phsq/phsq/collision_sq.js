// Elastischer und unelastischer Sto�, albanische Texte (Arten Shuqja)
// Letzte �nderung 18.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Goditje elastike";
var text02 = "Goditje joelestike";
var text03 = "Rivendos";
var text04 = "Fillo";
var text05 = "L&euml;vizja e ngadalt&euml;";
var text06 = "Vagoni 1:";
var text07 = "Vagoni 2:";
var text08 = "Masa:";
var text09 = "Shpejt&euml;sia:";
var text10 = "Shpejt&euml;sia";
var text11 = "Impulsi";
var text12 = "Energjia kinetike";

var author = "W. Fendt 1998,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                         

// Texte in Unicode-Schreibweise:

var text13 = "Vagoni 1:";
var text14 = "Vagoni 2:";
var text15 = "Shpejt\u00EBsit\u00EB para goditjes:";
var text16 = "Shpejt\u00EBsit\u00EB pas goditjes:";
var text17 = "Impulsi para goditjes:";
var text18 = "Impulsi pas goditjes:";
var text19 = "Energjia kinetike para goditjes:";
var text20 = "Energjia kinetike pas goditjes:";
var text21 = "Impulsi i plot\u00EB:";
var text22 = "Energjia kinetike e plot\u00EB:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                  
var kilogramMeterPerSecond = "kg m/s";              
var joule = "J";                                    
