// Kreisbewegung mit konstanter Winkelgeschwindigkeit, albanische Texte (Arten Shuqja)
// Letzte �nderung 18.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rivendos";
var text02 = ["Fillo", "Ndal", "Rifillo"];
var text03 = "L&euml;vizja e ngadalt&euml;";
var text04 = "Rrezja:";
var text05 = "Perioda:";
var text06 = "Masa:";
var text07 = "Larg&euml;sia";
var text08 = "Shpejt&euml;sia";
var text09 = "Nxitimi";
var text10 = "Forca";

var author = "W. Fendt 2007";
var translator = "Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                   
var second = "s";                                  
var kilogram = "kg";                               

// Texte in Unicode-Schreibweise:

var text11 = "Larg\u00EBsia:";
var text12 = "Shpejt\u00EBsia:";
var text13 = "Shpejt\u00EBsia k\u00EBndore:";
var text14 = "Nxitimi q\u00EBnd\u00EBrsynues:";
var text15 = "Forca q\u00EBnd\u00EBrsynuese:";
var text16 = "(n\u00EB s)";
var text17 = "(n\u00EB m)";
var text18 = "(n\u00EB m/s)";
var text19 = "(n\u00EB m/s\u00b2)";
var text20 = "(n\u00EB N)";
var text21 = "(p\u00EBrb\u00EBr\u00EBsja x)";
var text22 = "(p\u00EBrb\u00EBr\u00EBsja y)";
var text23 = "(vlera)";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03C9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "m";                            
var meterPerSecond = "m/s";                         
var meterPerSecond2 = "m/s\u00B2";                  
var newton = "N";                                   
var radPerSecond = "rad/s";                         




