// Potentiometerschaltung, albanische Texte (Arten Shuqja)
// Letzte �nderung 21.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Tensioni i burimit:";
var text02 = "Reokordi:";
var text03 = "Pozicioni i kontaktit rr&euml;shqit&euml;s:";
var text04 = "Rezistenca e zbatimit:";
var text05 = "Tensioni i treguar";
var text06 = "Intensiteti i treguar";
var author = "W. Fendt 2006";
var translator = "Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "U";                                  // Symbol f�r Spannung
var symbolVoltage2 = "a";                                  // Index f�r Verbraucher
                      
