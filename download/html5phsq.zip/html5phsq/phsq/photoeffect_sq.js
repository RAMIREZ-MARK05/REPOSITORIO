// Photoelektrischer Effekt, albanische Texte (Arten Shuqja)
// Letzte �nderung 23.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Materiali i katod&euml;s:";
var text03 = "Vija spektrale (Hg):";
var text04 = "Tensioni i frenimit:";
var text05 = "Frekuenca:";
var text06 = ["Energjia e nj&euml;", "fotoni:"];
var text07 = "Puna e daljes:";
var text08 = ["Energjia kinetike maksimale", "e nj&euml; elektroni:"];
var text09 = "Fshih matjet";

var author = "W. Fendt 2000,&nbsp; Arten Shuqja 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                            // Volt
var terahertz = "THz";                                     // Terahertz
var electronvolt = "eV";                                   // Elektronenvolt

// Texte in Unicode-Schreibweise:

var text02 = ["cezium", "natrium"];
var text10 = ["e verdh\u00EB", "e gjelb\u00EBrt", "violet", "ultraviolet", "ultraviolet"];
var text11 = "(n\u00EB THz)";
var text12 = "(n\u00EB V)";
var text13 = [
             ["Energjia e nj\u00EB fotoni nuk \u00EBsht\u00EB e mjaftueshme", 
              "p\u00EBr shk\u00EBputjen e nj\u00EB elektroni."],
             ["Rritja e tensionit t\u00EB frenimit \u00EBsht\u00EB aq sa t\u00EB mos", 
              "pengoj elektronet t\u00EB arrijn\u00EB anod\u00EBn!"],
             ["Tensioni i frenimit \u00EBsht\u00EB aq i madh sa elektronet", 
              "kthehen n\u00EB katod\u00EB."],
             ["Vazhdo me nj\u00EB matje t\u00EB re p\u00EBr nj\u00EB tjet\u00EBr", 
              "vij\u00EB spektrale!"],
             ["Vazhdo me nj\u00EB seri t\u00EB re matjesh p\u00EBr", 
              "materialin tjet\u00EBr t\u00EB katod\u00EBs!"],
             ["Matjet u kryen."]
             ];

var symbolCathode = "C";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
