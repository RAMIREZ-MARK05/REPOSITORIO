// Stehende Welle, Erkl�rung durch Reflexion, albanische Texte (Arten Shuqja)
// Letzte �nderung 20.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Pasqyrimi";
var text02 = "nga nj&euml; skaj i fiksuar";
var text03 = "nga nj&euml; skaj i lir&euml;";
var text04 = "Rivendos";
var text05 = ["Fillo", "Ndal", "Rifillo"];
var text06 = "L&euml;vizja e ngadalt&euml;";
var text07 = "Animacioni";
var text08 = "Hapat nj&euml; pas nj&euml;";
var text09 = "Vala r&euml;n&euml;se";
var text10 = "Vala e pasqyruar";
var text11 = "Vala e q&euml;ndrueshme rezultante";

var author = "W. Fendt 2003"; 
var translator = "Arten Shuqja 2007";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "N";
var symbolAntiNode = "A";

