// Gleichgewicht dreier Kr�fte, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u0421\u0438\u043b\u044b:";                  // Kr�fte
var text02 = "\u041b\u0435\u0432\u0430\u044f:";            // Links
var text03 = "\u041f\u0440\u0430\u0432\u0430\u044f:";      // Rechts
var text04 = "\u041d\u0438\u0436\u043d\u044f\u044f:";      // Unten
var text05 = "\u041f\u0430\u0440\u0430\u043b\u043b\u0435\u043b\u043e"  // Kr�fteparallelogramm (1)
           + "\u0433\u0440\u0430\u043c\u043c \u0441\u0438\u043b";      // Kr�fteparallelogramm (2)
var text06 = "\u0423\u0433\u043e\u043b:";                  // Winkel
var text07 = "\u041b\u0435\u0432\u0430\u044f:";            // Links
var text08 = "\u041f\u0440\u0430\u0432\u0430\u044f:";      // Rechts

var author = "W. Fendt 2000";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var degree = "\u00b0";                                     // Symbol f�r Grad
var newton = "\u041d";                                     // Abk�rzung f�r Newton
