// Elektromagnetischer Schwingkreis, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";                                 // Zur�ck
var text02 = ["\u0421\u0442\u0430\u0440\u0442",                                // Start
             "\u041f\u0430\u0443\u0437\u0430",                                 // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text03 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe 10 x (1)
           + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435 (10 \u00d7)";             // Zeitlupe 10 x (2)
var text04 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe 100 x (1)
           + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435 (100 \u00d7)";            // Zeitlupe 100 x (2)
var text05 = "\u00cb\u043c\u043a\u043e\u0441\u0442\u044c:";                              // Kapazit�t
var text06 = "\u0418\u043d\u0434\u0443\u043a\u0442\u0438\u0432"                          // Induktivit�t (1)
           + "\u043d\u043e\u0441\u0442\u044c:";                                          // Induktivit�t (2)
var text07 = "\u0421\u043e\u043f\u0440\u043e\u0442\u0438\u0432"                          // Widerstand (1)
           + "\u043b\u0435\u043d\u0438\u0435:";                                          // Widerstand (2)
var text08 = "\u041c\u0430\u043a\u0441. "                                                // Maximale Spannung (1)
           + "\u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435:";            // Maximale Spannung (2)
var text09 = "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435, "            // Spannung, ...
           + "\u0441\u0438\u043b\u0430 \u0442\u043e\u043a\u0430";                        // ... Stromst�rke
var text10 = "\u042d\u043d\u0435\u0440\u0433\u0438\u044f";                               // Energie

var author = "W. Fendt 1999,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 
var microfarad = "\u043c\u043a\u0424";  
var henry = "\u0413\u043d";
var ohm = "\u041e\u043c";  
var volt = "\u0412";   

// Texte in Unicode-Schreibweise:

var text11 = "\u041f\u0435\u0440\u0438\u043e\u0434 "                                     // Schwingungsdauer (1)
           + "\u043a\u043e\u043b\u0435\u0431\u0430\u043d\u0438\u0439:";                  // Schwingungsdauer (2)
var text12 = "\u042d\u043d\u0435\u0440\u0433\u0438\u044f "                               // Elektrische Feldenergie (1)
           + "\u044d\u043b\u0435\u043a\u0442\u0440\u0438\u0447\u0435\u0441\u043a\u043e\u0433\u043e " // Elektrische Feldenergie (2)
           + "\u043f\u043e\u043b\u044f:";                                                // Elektrische Feldenergie (3)
var text13 = "\u042d\u043d\u0435\u0440\u0433\u0438\u044f "                               // Magnetische Feldenergie (1)
           + "\u043c\u0430\u0433\u043d\u0438\u0442\u043d\u043e\u0433\u043e "             // Magnetische Feldenergie (2)
           + "\u043f\u043e\u043b\u044f:";                                                // Magnetische Feldenergie (3)
var text14 = "\u0412\u043d\u0443\u0442\u0440\u0435\u043d\u043d\u044f\u044f "             // Innere Energie (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f:";                              // Innere Energie (2)
var text15 = "\u041d\u0435\u0437\u0430\u0442\u0443\u0445\u0430\u044e\u0449\u0438\u0435 " // Unged�mpfte Schwingung (1)
           + "\u043a\u043e\u043b\u0435\u0431\u0430\u043d\u0438\u044f";                   // Unged�mpfte Schwingung (2)
var text16 = "\u0417\u0430\u0442\u0443\u0445\u0430\u044e\u0449\u0438\u0435 "             // Ged�mpfte Schwingung (1)
           + "\u043a\u043e\u043b\u0435\u0431\u0430\u043d\u0438\u044f";                   // Ged�mpfte Schwingung (2)
var text17 = "\u0410\u043f\u0435\u0440\u0438\u043e\u0434\u0438\u0447\u0435\u0441\u043a\u043e\u0435 " // Aperiodischer Grenzfall (1)
           + "\u0437\u0430\u0442\u0443\u0445\u0430\u043d\u0438\u0435";                   // Aperiodischer Grenzfall (2)
var text18 = "\u0421\u0432\u0435\u0440\u0445\u043a\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043a\u043e\u0435 " // Kriechfall (1)
           + "\u0437\u0430\u0442\u0443\u0445\u0430\u043d\u0438\u0435";                   // Kriechfall (2)

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "\u0441";                                 
var voltUnicode = "\u0412";                         
var ampere = "\u0410";                            
var joule = "\u0414\u0436";                                   
