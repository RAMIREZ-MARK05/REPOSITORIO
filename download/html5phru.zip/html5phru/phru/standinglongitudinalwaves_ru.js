// Stehende L�ngswellen, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0424\u043e\u0440\u043c\u0430 \u0442\u0440\u0443\u0431\u044b:"; // Rohrform
var text02 = "\u043e\u0442\u043a\u0440\u044b\u0442\u0430 \u0441 \u043e\u0431\u0435\u0438\u0445 "   // beidseitig offen (1)
           + "\u0441\u0442\u043e\u0440\u043e\u043d";                                               // beidseitig offen (2)
var text03 = "\u043e\u0442\u043a\u0440\u044b\u0442\u0430 \u0441 \u043e\u0434\u043d\u043e\u0439 "   // einseitig offen (1)
           + "\u0441\u0442\u043e\u0440\u043e\u043d\u044b";                                         // einseitig offen (2)
var text04 = "\u0437\u0430\u043a\u0440\u044b\u0442\u0430 \u0441 \u043e\u0431\u0435\u0438\u0445 "   // beidseitig geschlossen (1)
           + "\u0441\u0442\u043e\u0440\u043e\u043d";                                               // beidseitig geschlossen (2)
var text05 = "\u041c\u043e\u0434\u0430 \u043a\u043e\u043b\u0435\u0431\u0430\u043d\u0438\u0439:";   // Eigenschwingung
var text06 = ["\u041e\u0441\u043d\u043e\u0432\u043d\u043e\u0439 \u0442\u043e\u043d",               // Grundschwingung
             "1-\u044f \u0433\u0430\u0440\u043c\u043e\u043d\u0438\u043a\u0430",                    // 1. Oberschwingung 
             "2-\u044f \u0433\u0430\u0440\u043c\u043e\u043d\u0438\u043a\u0430",                    // 2. Oberschwingung
             "3-\u044f \u0433\u0430\u0440\u043c\u043e\u043d\u0438\u043a\u0430",                    // 3. Oberschwingung
             "4-\u044f \u0433\u0430\u0440\u043c\u043e\u043d\u0438\u043a\u0430",                    // 4. Oberschwingung
             "5-\u044f \u0433\u0430\u0440\u043c\u043e\u043d\u0438\u043a\u0430"];                   // 5. Oberschwingung
var text07 = "\u041d\u0438\u0436\u0435";                   // Tiefer
var text08 = "\u0412\u044b\u0448\u0435";                   // H�her
var text09 = "\u0414\u043b\u0438\u043d\u0430 \u0442\u0440\u0443\u0431\u044b:"; // Rohrl�nge
var text10 = "\u0414\u043b\u0438\u043d\u0430 \u0432\u043e\u043b\u043d\u044b:"; // Wellenl�nge
var text11 = "\u0427\u0430\u0441\u0442\u043e\u0442\u0430:";                    // Frequenz

var author = "W. Fendt 1998,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "\u043c";                                
var hertz = "\u0413\u0446";                    

var text12 = "\u0421\u043c\u0435\u0449\u0435\u043d\u0438\u0435 "               // Elongation der Teilchen (1)
           + "\u0447\u0430\u0441\u0442\u0438\u0446";                           // Elongation der Teilchen (2)
var text13 = "\u041e\u0442\u043a\u043b\u043e\u043d\u0435\u043d\u0438\u0435"    // Abweichung vom mittleren Druck (1)
           + "\u043e\u0442 \u0441\u0440\u0435\u0434\u043d\u0435\u0433\u043e "  // Abweichung vom mittleren Druck (2)
           + "\u0434\u0430\u0432\u043b\u0435\u043d\u0438\u044f";               // Abweichung vom mittleren Druck (3)

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "\u0423";                                 // Symbol f�r Knoten
var symbolAntinode = "\u041f";                             // Symbol f�r Bauch

