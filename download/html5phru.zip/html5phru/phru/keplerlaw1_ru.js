// Erstes Kepler-Gesetz, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017
    
var text02 = "\u0411\u043e\u043b\u044c\u0448\u0430\u044f "                     // Gro�e Halbachse (1)
  	       + "\u043f\u043e\u043b\u0443\u043e\u0441\u044c:";                    // Gro�e Halbachse (2)
var text03 = "\u042d\u043a\u0441\u0446\u0435\u043d\u0442\u0440\u0438"          // Numerische Exzentrizit�t (1)
  	       + "\u0441\u0438\u0442\u0435\u0442:";                                // Numerische Exzentrizit�t (2)
var text04 = "\u041c\u0430\u043b\u0430\u044f "                                 // Kleine Halbachse (1)
           + "\u043f\u043e\u043b\u0443\u043e\u0441\u044c:";                    // Kleine Halbachse (2)
var text05 = ["\u041f\u0430\u0443\u0437\u0430",                                // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text06 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe (1)
  	       + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                         // Zeitlupe (2)
var text07 = "\u0420\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 "   // Entfernung von der Sonne (1) 
           + "\u0434\u043e \u0421\u043e\u043b\u043d\u0446\u0430:";             // Entfernung von der Sonne (2)
var text08 = "\u0422\u0435\u043a\u0443\u0449\u0435\u0435:";                    // Aktueller Wert
var text09 = "\u041c\u0438\u043d\u0438\u043c\u0443\u043c:";                    // Minimum
var text10 = "\u041c\u0430\u043a\u0441\u0438\u043c\u0443\u043c:";              // Maximum
var text11 = "\u042d\u043b\u043b\u0438\u043f\u0442\u0438\u0447\u0435\u0441\u043a\u0430\u044f "     // Bahnellipse (1)
           + "\u043e\u0440\u0431\u0438\u0442\u0430";                                               // Bahnellipse (2)
var text12 = "\u041e\u0441\u0438";                                             // Achsen
var text13 = "\u0421\u043e\u0435\u0434\u0438\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u044b\u0435 " // Verbindungsstrecken (1)
           + "\u043b\u0438\u043d\u0438\u0438";                                                       // Verbindungsstrecken (2)

var author = "W. Fendt 2000,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit

var text01 = ["\u041c\u0435\u0440\u043a\u0443\u0440\u0438\u0439",    // Merkur
             "\u0412\u0435\u043d\u0435\u0440\u0430",                 // Venus
             "\u0417\u0435\u043c\u043b\u044f",                       // Erde
             "\u041c\u0430\u0440\u0441",                             // Mars
             "\u042e\u043f\u0438\u0442\u0435\u0440",                 // Jupiter
             "\u0421\u0430\u0442\u0443\u0440\u043d",                 // Saturn
             "\u0423\u0440\u0430\u043d",                             // Uranus
             "\u041d\u0435\u043f\u0442\u0443\u043d",                 // Neptun
             "\u041f\u043b\u0443\u0442\u043e\u043d",                 // Pluto
             "\u043a\u043e\u043c\u0435\u0442\u0430 "                 // Halleyscher Komet (1)
           + "\u0413\u0430\u043b\u043b\u0435\u044f",                 // Halleyscher Komet (2)
             ""];

var text14 = "\u0421\u043e\u043b\u043d\u0446\u0435";       // Sonne
var text15 = "\u041f\u043b\u0430\u043d\u0435\u0442\u0430"; // Planet
var text16 = "\u041a\u043e\u043c\u0435\u0442\u0430";       // Komet
var text17 = "\u043f\u0435\u0440\u0438\u0433\u0435\u043b\u0438\u0439";         // Perihel
var text18 = "\u0430\u0444\u0435\u043b\u0438\u0439";                           // Aphel

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "AU";

