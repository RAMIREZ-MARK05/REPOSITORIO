// Zweites Kepler-Gesetz, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017
    
var text02 = "\u0411\u043e\u043b\u044c\u0448\u0430\u044f "                     // Gro�e Halbachse (1)
  	       + "\u043f\u043e\u043b\u0443\u043e\u0441\u044c:";                    // Gro�e Halbachse (2)
var text03 = "\u042d\u043a\u0441\u0446\u0435\u043d\u0442\u0440\u0438"          // Numerische Exzentrizit�t (1)
  	       + "\u0441\u0438\u0442\u0435\u0442:";                                // Numerische Exzentrizit�t (2)
var text04 = ["\u041f\u0430\u0443\u0437\u0430",                                // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text05 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe (1)
  	       + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                         // Zeitlupe (2)
var text06 = ["\u0420\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435",  // Entfernung ... 
             "\u0434\u043e \u0421\u043e\u043b\u043d\u0446\u0430:"];            // ... von der Sonne
var text07 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c:";              // Geschwindigkeit
var text08 = "\u0422\u0435\u043a\u0443\u0449\u0430\u044f:";                    // Aktueller Wert
var text09 = "\u041c\u0438\u043d\u0438\u043c\u0443\u043c:";                    // Minimum
var text10 = "\u041c\u0430\u043a\u0441\u0438\u043c\u0443\u043c:";              // Maximum
var text11 = "\u0421\u0435\u043a\u0442\u043e\u0440\u0430";                     // Sektoren
var text12 = "\u0412\u0435\u043a\u0442\u043e\u0440 "                           // Geschwindigkeitsvektor (1)
           + "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438";               // Geschwindigkeitsvektor (2)

var author = "W. Fendt 2000,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit
var kilometerPerSecond = "\u043a\u043c/\u0441";

var text01 = ["\u041c\u0435\u0440\u043a\u0443\u0440\u0438\u0439",    // Merkur
             "\u0412\u0435\u043d\u0435\u0440\u0430",                 // Venus
             "\u0417\u0435\u043c\u043b\u044f",                       // Erde
             "\u041c\u0430\u0440\u0441",                             // Mars
             "\u042e\u043f\u0438\u0442\u0435\u0440",                 // Jupiter
             "\u0421\u0430\u0442\u0443\u0440\u043d",                 // Saturn
             "\u0423\u0440\u0430\u043d",                             // Uranus
             "\u041d\u0435\u043f\u0442\u0443\u043d",                 // Neptun
             "\u041f\u043b\u0443\u0442\u043e\u043d",                 // Pluto
             "\u043a\u043e\u043c\u0435\u0442\u0430 "                 // Halleyscher Komet (1)
           + "\u0413\u0430\u043b\u043b\u0435\u044f",                 // Halleyscher Komet (2)
             ""];

// Symbole und Einheiten: 

var auUnicode = "AU";
var symbolPeriod = "T";

