// Schiefer Wurf, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";             // Zur�ck                    
var text02 = ["\u0421\u0442\u0430\u0440\u0442",            // Start 
             "\u041f\u0430\u0443\u0437\u0430",             // Pause 
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter          
var text03 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "  // Zeitlupe (1)
  	       + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                    // Zeitlupe (2)
var text04 = "\u041d\u0430\u0447\u0430\u043b\u044c\u043d\u0430\u044f "         // Ausgangsh�he (1)
           + "\u0432\u044b\u0441\u043e\u0442\u0430:";                          // Ausgangsh�he (2)
var text05 = "\u041d\u0430\u0447\u0430\u043b\u044c\u043d\u0430\u044f "         // Anfangsgeschwindigkeit (1)
           + "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c:";              // Anfangsgeschwindigkeit (2)
var text06 = "\u0423\u0433\u043e\u043b:";                  // Winkel
var text07 = "\u041c\u0430\u0441\u0441\u0430:";            // Masse
var text08 = "\u0413\u0440\u0430\u0432\u0438\u0442\u0430\u0446\u0438"          // Fallbeschleunigung (1)
           + "\u043e\u043d\u043d\u043e\u0435 "                                 // Fallbeschleunigung (2)
           + "\u0443\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435:";        // Fallbeschleunigung (3)
var text09 = "\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b";   // Position
var text10 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c";               // Geschwindigkeit
var text11 = "\u0423\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435";         // Beschleunigung
var text12 = "\u0421\u0438\u043b\u0430";                   // Kraft
var text13 = "\u042d\u043d\u0435\u0440\u0433\u0438\u044f"; // Energie

var author = "W. Fendt 2000,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "\u043c";                                   
var meterPerSecond = "\u043c/\u0441";                        
var meterPerSecond2 = "\u043c/\u0441&sup2;";                    
var kilogram = "\u043a\u0433";                         
var degree = "&deg;";                               

var text14 = "(\u043c)";                                   // Einheitenangabe f�r Koordinatenachsen 
var text15 = "\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b:";  // Position
var text16 = "(\u0433\u043e\u0440\u0438\u0437\u043e\u043d\u0442\u0430\u043b\u044c\u043d\u043e)";   // waagrecht
var text17 = "(\u0432\u0435\u0440\u0442\u0438\u043a\u0430\u043b\u044c\u043d\u043e)";               // senkrecht
var text18 = "\u0414\u0430\u043b\u044c\u043d\u043e\u0441\u0442\u044c "                   // Wurfweite (1) 
           + "\u043f\u043e\u043b\u0435\u0442\u0430:";                                    // Wurfweite (2)
var text19 = "\u041c\u0430\u043a\u0441. \u0432\u044b\u0441\u043e\u0442\u0430 " // Maximale H�he (1)
           + "\u043f\u043e\u0434\u044c\u0435\u043c\u0430:";                    // Maximale H�he (2)
var text20 = "\u0412\u0440\u0435\u043c\u044f "                       // Wurfdauer (1)
           + "\u043f\u043e\u043b\u0435\u0442\u0430:";                // Wurfdauer (2)
var text21 = "\u041a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442\u044b "   // Geschwindigkeitskomponenten (1)
           + "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438:";              // Geschwindigkeitskomponenten (2)
var text22 = "\u0410\u0431\u0441\u043e\u043b\u044e\u0442\u043d\u043e\u0435 "   // Geschwindigkeitsbetrag (1)
           + "\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435:";              // Geschwindigkeitsbetrag (2)
var text23 = "\u0423\u0433\u043e\u043b:";                  // Winkel
var text24 = "\u0423\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435:";        // Beschleunigung
var text25 = "\u0421\u0438\u043b\u0430:";                  // Kraft
var text26 = "\u041a\u0438\u043d\u0435\u0442\u0438\u0447\u0435\u0441\u043a\u0430\u044f " // Kinetische Energie (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f:";                              // Kinetische Energie (2)
var text27 = "\u041f\u043e\u0442\u0435\u043d\u0446\u0438\u0430\u043b\u044c\u043d\u0430\u044f "     // Potentielle Energie (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f:";                                        // Potentielle Energie (2)
var text28 = "\u041f\u043e\u043b\u043d\u0430\u044f "                 // Gesamtenergie (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f:";          // Gesamtenergie (2)

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "\u043c";                         
var secondUnicode = "\u0441";                 
var meterPerSecondUnicode = "\u043c/\u0441";              
var meterPerSecond2Unicode = "\u043c/\u0441\u00b2";      
var newtonUnicode = "\u041d";                           
var jouleUnicode = "\u0414\u0436";                                
var degreeUnicode = "\u00b0";                        



