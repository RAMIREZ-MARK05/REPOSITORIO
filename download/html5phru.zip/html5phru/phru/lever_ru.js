// Hebelgesetz, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

// Texte in Unicode-Schreibweise:

var text01 = "\u0412\u0440\u0430\u0449\u0430\u044e\u0449\u0438\u0439 "               // Linksdrehendes Drehmoment (1)
           + "\u043c\u043e\u043c\u0435\u043d\u0442 \u0441\u043b\u0435\u0432\u0430:"; // Linksdrehendes Drehmoment (2)
var text02 = "\u0412\u0440\u0430\u0449\u0430\u044e\u0449\u0438\u0439 "                     // Rechtsdrehendes Drehmoment (1)
           + "\u043c\u043e\u043c\u0435\u043d\u0442 \u0441\u043f\u0440\u0430\u0432\u0430:"; // Rechtsdrehendes Drehmoment (2)

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "M_1";                              // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "M_2";                             // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

var newton = "\u041d";
var meter = "\u043c";

var author = "W. Fendt 1997,  \u041d\u0413\u0422\u0423 2010";  // Autor (und �bersetzer)
