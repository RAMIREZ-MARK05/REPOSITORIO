// Reflexion und Brechung von Licht, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017
    
var text01 = "1. \u043f\u043e\u043a. "                                                   // 1. Brechungsindex (1)
           + "\u043f\u0440\u0435\u043b\u043e\u043c\u043b\u0435\u043d\u0438\u044f:";      // 1. Brechungsindex (2)
var text02 = "2. \u043f\u043e\u043a. "                                                   // 2. Brechungsindex (1)
           + "\u043f\u0440\u0435\u043b\u043e\u043c\u043b\u0435\u043d\u0438\u044f:";      // 2. Brechungsindex (2)
var text03 = "\u0423\u0433\u043e\u043b \u043f\u0430\u0434\u0435\u043d\u0438\u044f:";     // Einfallswinkel
var text04 = "\u0423\u0433\u043e\u043b "                                                 // Reflexionswinkel (1)
           + "\u043e\u0442\u0440\u0430\u0436\u0435\u043d\u0438\u044f:";                  // Reflexionswinkel (2)
var text05 = "\u0423\u0433\u043e\u043b "                                                 // Brechungswinkel (1)
           + "\u043f\u0440\u0435\u043b\u043e\u043c\u043b\u0435\u043d\u0438\u044f:";      // Brechungswinkel (2)
var text06 = ["\u0423\u0433\u043e\u043b \u043f\u043e\u043b\u043d\u043e\u0433\u043e",     // Grenzwinkel der Totalreflexion (1)
             "\u0432\u043d\u0443\u0442\u0440\u0435\u043d\u043d\u0435\u0433\u043e "       // Grenzwinkel der Totalreflexion (2)
           + "\u043e\u0442\u0440\u0430\u0436\u0435\u043d\u0438\u044f:"];                 // Grenzwinkel der Totalreflexion (3)

var author = "W. Fendt 1997,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise:

var text07 = [["\u0432\u0430\u043a\u0443\u0443\u043c", "1"],                   // Vakuum 
              ["\u0432\u043e\u0437\u0434\u0443\u0445", "1.0003"],              // Luft
              ["\u0432\u043e\u0434\u0430", "1.33"],                            // Wasser 
              ["\u044d\u0442\u0430\u043d\u043e\u043b", "1.36"],                // Ethanol
              ["\u043a\u0432\u0430\u0440\u0446\u0435\u0432\u043e\u0435 "       // Quarzglas (1)
            + "\u0441\u0442\u0435\u043a\u043b\u043e", "1.46"],                 // Quarzglas (2)
              ["\u0431\u0435\u043d\u0437\u043e\u043b", "1.49"],                // Benzol
              ["\u043a\u0440\u043e\u043d N-K5", "1.52"],                       // Kronglas N-K5
              ["\u0445\u043b\u043e\u0440\u0438\u0441\u0442\u044b\u0439 "       // Steinsalz (1)
            + "\u043d\u0430\u0442\u0440\u0438\u0439", "1.54"],                 // Steinsalz (2)
              ["\u0444\u043b\u0438\u043d\u0442 LF5", "1.58"],                  // Flintglas LF5 
              ["\u043a\u0440\u043e\u043d N-SK4", "1.61"],                      // Kronglas N-SK4
              ["\u0444\u043b\u0438\u043d\u0442 SF6", "1.81"],                  // Flintglas SF8 
              ["\u0430\u043b\u043c\u0430\u0437", "2.42"],                      // Diamant
              ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                              // Grad
