// Wheatstonesche Br�ckenschaltung, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u041d\u043e\u0432\u043e\u0435 \u0438\u0437\u043c\u0435\u0440\u0435\u043d\u0438\u0435";    // Neue Messung
var text02 = "\u0421\u043e\u043f\u043e\u0441\u0442\u0430\u0432\u043b\u044f\u0435\u043c\u043e\u0435 "     // Vergleichswiderstand (1)
           + "\u0441\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435:"           // Vergleichswiderstand (2)
var text03 = "\u041f\u043e\u043b\u0437\u0443\u043d\u043a\u043e\u0432\u044b\u0439 "                       // Schiebewiderstand (1)
  	       + "\u0440\u0435\u0437\u0438\u0441\u0442\u043e\u0440:";                                        // Schiebewiderstand (2)
var text04 = "\u041f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435 "                                   // Position Schleifkontakt (1)
  	       + "\u0441\u043a\u043e\u043b\u044c\u0437\u044f\u0449\u0435\u0433\u043e "                       // Position Schleifkontakt (2)
  	       + "\u043a\u043e\u043d\u0442\u0430\u043a\u0442\u0430:";                                        // Position Schleifkontakt (3)
var text05 = "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 "                             // Spannung Stromquelle (1)
  	       + "\u043f\u0438\u0442\u0430\u043d\u0438\u044f:";                                              // Spannung Stromquelle (2)
var text06 = "\u0421\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435 "           // Widerstand Messger�t (1)
  	       + "\u043f\u0440\u0438\u0431\u043e\u0440\u0430:";                                              // Widerstand Messger�t (2)
var text07 = "\u0412\u044b\u0447\u0438\u0441\u043b\u0438\u0442\u044c "                                   // Widerstand berechnen (1)
  	       + "\u0441\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435";           // Widerstand berechnen (2)
var text08 = "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c "                                         // Spannung angeben (1)
  	       + "\u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u044f";                             // Spannung angeben (2)
var text09 = "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c "                                         // Stromst�rke angeben (1)
  	       + "\u0441\u0438\u043b\u0443 \u0442\u043e\u043a\u0430";                                        // Stromst�rke angeben (2)
var author = "W. Fendt 2006,&nbsp; \u041d\u0413\u0422\u0423 2010";                          

var text10 = ["\u041f\u0435\u0440\u0435\u043c\u0435\u0449\u0430\u0439\u0442\u0435 "                      // Verschiebe Schleifkontakt (1)
           + "\u0441\u043a\u043e\u043b\u044c\u0437\u044f\u0449\u0438\u0439 "                             // Verschiebe Schleifkontakt (2)
           + "\u043a\u043e\u043d\u0442\u0430\u043a\u0442,",                                              // Verschiebe Schleifkontakt (3)
             "\u043f\u043e\u043a\u0430 \u0442\u043e\u043a \u043d\u0435 "                                 // bis Stromst�rke gleich 0 (1)
           + "\u0441\u0442\u0430\u043d\u0435\u0442 "                                                     // bis Stromst�rke gleich 0 (2)
           + "\u0440\u0430\u0432\u043d\u044b\u043c \u043d\u0443\u043b\u044e!"];                          // bis Stromst�rke gleich 0 (3)
var text11 = "\u0422\u0435\u043f\u0435\u0440\u044c "                                                     // Berechne Widerstand (1)
  	       + "\u0441\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435 "           // Berechne Widerstand (2)
  	       + "\u043c\u043e\u0436\u0435\u0442 \u0431\u044b\u0442\u044c "                                  // Berechne Widerstand (3)
  	       + "\u0432\u044b\u0447\u0438\u0441\u043b\u0435\u043d\u043e.";                                  // Berechne Widerstand (4)         

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "\u0412";
var milliampere = "\u043c\u0410";
var ohm = "\u041e\u043c";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00B7";                              
