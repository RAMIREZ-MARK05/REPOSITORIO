// Einfache Wechselstromkreise, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0420\u0435\u0437\u0438\u0441\u0442\u043e\u0440";                                   // Widerstand (Bauteil)
var text02 = "\u041a\u043e\u043d\u0434\u0435\u043d\u0441\u0430\u0442\u043e\u0440";                 // Kondensator
var text03 = "\u041a\u0430\u0442\u0443\u0448\u043a\u0430 "                                         // Spule (1)
           + "\u0438\u043d\u0434\u0443\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u0438";     // Spule (2)
var text04 = "\u0421\u0431\u0440\u043e\u0441";                                 // Zur�ck
var text05 = ["\u0421\u0442\u0430\u0440\u0442",                                // Start
             "\u041f\u0430\u0443\u0437\u0430",                                 // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter          
var text06 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe (1)
           + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                         // Zeitlupe (2)
var text07 = "\u0427\u0430\u0441\u0442\u043e\u0442\u0430:";                    // Frequenz
var text08 = "\u041c\u0430\u043a\u0441. "                                      // Max. Spannung (1)
           + "\u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435:";  // Max. Spannung (2)
var text09 = "\u0421\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435:";    // Widerstand (Gr��e)        
var text10 = "\u00cb\u043c\u043a\u043e\u0441\u0442\u044c:";                                        // Kapazit�t                          
var text11 = "\u0418\u043d\u0434\u0443\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u044c:";    // Induktivit�t 
var text12 = "\u041c\u0430\u043a\u0441. \u0441\u0438\u043b\u0430 \u0442\u043e\u043a\u0430:";       // Max. Stromst�rke 

var author = "W. Fendt 1998,&nbsp; \u041d\u0413\u0422\u0423 2010";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "\u0413\u0446";           
var volt = "\u0412";                      
var ampere = "\u0410";          
var milliampere = "\u043c\u0410";         
var microampere = "\u043c\u043a\u0410";               
var ohm = "\u041e\u043c";                   
var microfarad = "\u043c\u043a\u0424";  
var henry = "\u0413\u043d";                    

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
