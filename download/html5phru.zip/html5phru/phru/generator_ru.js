// Generator, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0411\u0435\u0437 \u043a\u043e\u043c\u043c\u0443\u0442\u0430\u0442\u043e\u0440\u0430";   // Ohne Kommutator
var text02 = "\u0421 \u043a\u043e\u043c\u043c\u0443\u0442\u0430\u0442\u043e\u0440\u043e\u043c";         // Mit Kommutator
var text03 = "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c "                                        // Umgekehrte Richtung (1)
           + "\u043d\u0430\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435";                      // Umgekehrte Richtung (2)
var text04 = ["\u0421\u0442\u0430\u0440\u0442",                                // Start
             "\u041f\u0430\u0443\u0437\u0430",                                 // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text05 = "\u041d\u0430\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 "       // Bewegungsrichtung (1)
           + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u044f";                         // Bewegungsrichtung (2)
var text06 = "\u041c\u0430\u0433\u043d\u0438\u0442\u043d\u043e\u0435 "                   // Magnetfeld (1)
           + "\u043f\u043e\u043b\u0435";                                                 // Magnetfeld (2)
var text07 = "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c "             // Induzierter Strom (1)
           + "\u0442\u043e\u043a";                                                       // Induzierter Strom (2)

var author = "W. Fendt 1998";  
var translator = "\u041d\u0413\u0422\u0423 2010";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "U/min";                          // Umdrehungen pro Minute

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
