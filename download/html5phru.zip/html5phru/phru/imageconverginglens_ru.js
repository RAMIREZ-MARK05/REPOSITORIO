// Bilderzeugung Sammellinse, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017
    
var text01 = "\u0424\u043e\u043a\u0443\u0441\u043d\u043e\u0435 "               // Brennweite (1)
           + "\u0440\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435:";  // Brennweite (2)
var text02 = "\u0420\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 "   // Gegenstandsweite (1)
           + "\u0434\u043e \u043e\u0431\u044a\u0435\u043a\u0442\u0430:";       // Gegenstandsweite (2)
var text03 = "\u0412\u044b\u0441\u043e\u0442\u0430 "                           // Gegenstandsgr��e (1)
           + "\u043e\u0431\u044a\u0435\u043a\u0442\u0430:";                    // Gegenstandsgr��e (2)
var text04 = "\u0420\u0430\u0441\u0441\u0442. \u0434\u043e "                             // Bildweite (1)
           + "\u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f:";      // Bildweite (2)
var text05 = "\u0412\u044b\u0441\u043e\u0442\u0430 "                                     // Bildgr��e (1)
           + "\u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f:";      // Bildgr��e (2)    
var text06 = "\u0418\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u0435:";      // Art des Bildes
var text07 = ["\u0440\u0435\u0430\u043b\u044c\u043d\u043e\u0435",                        // reell
              "\u043c\u043d\u0438\u043c\u043e\u0435"];                                   // virtuell
var text08 = ["\u043f\u0435\u0440\u0435\u0432\u0435\u0440\u043d\u0443\u0442\u043e\u0435",// umgekehrt
              "\u043f\u0440\u044f\u043c\u043e\u0435"];                                   // aufrecht
var text09 = ["\u0443\u043c\u0435\u043d\u044c\u0448\u0435\u043d\u043d\u043e\u0435",      // verkleinert
              "\u0440\u0430\u0432\u043d\u043e\u0435",                                    // gleich gro�
              "\u0443\u0432\u0435\u043b\u0438\u0447\u0435\u043d\u043d\u043e\u0435",      // vergr��ert
              "\u043d\u0430 \u0431\u0435\u0441\u043a\u043e\u043d\u0435\u0447\u043d\u043e\u0441\u0442\u0438"];// unendlich gro�
var text10 = "\u0415\u0434\u0438\u043d\u0438\u0447\u043d\u044b\u0435 "         // Spezielle Lichtstrahlen (1)
           + "\u043b\u0443\u0447\u0438 \u0441\u0432\u0435\u0442\u0430";        // Spezielle Lichtstrahlen (2)
var text11 = "\u041f\u0443\u0447\u043e\u043a \u043b\u0443\u0447\u0435\u0439";  // Lichtb�ndel
var text12 = "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c:";              // Hervorheben

var author = "W. Fendt 2008,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var centimeter = "\u0441\u043c";
var decimalSeparator = ",";                                                    // Dezimaltrennzeichen (Komma/Punkt)

var text13 = ["\u043e\u0431\u044a\u0435\u043a\u0442",                                              // Gegenstand 
              "\u0440\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u0434\u043e "         // Gegenstandsweite (1)
            + "\u043e\u0431\u044a\u0435\u043a\u0442\u0430",                                        // Gegenstandsweite (2)
              "\u0432\u044b\u0441\u043e\u0442\u0430 \u043e\u0431\u044a\u0435\u043a\u0442\u0430",   // Gegenstandsgr��e
              "\u043b\u0438\u043d\u0437\u0430",                                                    // Linse 
              "\u043f\u043b\u043e\u0441\u043a\u043e\u0441\u0442\u044c "                            // Linsenebene (1)
            + "\u043b\u0438\u043d\u0437\u044b",                                                    // Linsenebene (2)
              "\u043e\u043f\u0442\u0438\u0447\u0435\u0441\u043a\u0430\u044f \u043e\u0441\u044c",   // Optische Achse
              "\u0442\u043e\u0447\u043a\u0438 \u0444\u043e\u043a\u0443\u0441\u0430",               // Brennpunkte
              "\u0444\u043e\u043a\u0443\u0441\u043d\u043e\u0435 "                                  // Brennweite (1)
            + "\u0440\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435",                      // Brennweite (2)
              "\u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u0435",                // Bild
              "\u0440\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u0434\u043e "         // Bildweite (1)
            + "\u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f",                // Bildweite (2)
              "\u0432\u044b\u0441\u043e\u0442\u0430 "                                              // Bildgr��e (1)
            + "\u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f",                // Bildgr��e (2)
              "\u044d\u043a\u0440\u0430\u043d"];                                                   // Mattscheibe
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "g";
var symbolGG = "G"; 
var symbolB = "b";
var symbolBB = "B";


