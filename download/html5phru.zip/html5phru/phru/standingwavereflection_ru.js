// Stehende Welle, Erkl�rung durch Reflexion, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u041e\u0442\u0440\u0430\u0436\u0435\u043d\u0438\u0435";         // Reflexion
var text02 = "\u043e\u0442 \u0437\u0430\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u043d\u043e\u0433\u043e "  // am festen Ende (1)
           + "\u043a\u043e\u043d\u0446\u0430";                                                               // am festen Ende (2)
var text03 = "\u043e\u0442 \u0441\u0432\u043e\u0431\u043e\u0434\u043d\u043e\u0433\u043e "          // am losen Ende (1)
           + "\u043a\u043e\u043d\u0446\u0430";                                                     // am losen Ende (2)
var text04 = "\u0421\u0431\u0440\u043e\u0441";             // Zur�ck
var text05 = ["\u0421\u0442\u0430\u0440\u0442",            // Start
             "\u041f\u0430\u0443\u0437\u0430",             // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text06 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe (1)
           + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                         // Zeitlupe (2)
var text07 = "\u041d\u0435\u043f\u0440\u0435\u0440\u044b\u0432\u043d\u043e";   // Animation
var text08 = "\u0421 \u0448\u0430\u0433\u043e\u043c";                          // Einzelschritte
var text09 = "\u041f\u0430\u0434\u0430\u044e\u0449\u0430\u044f "               // Einfallende Welle (1)
           + "\u0432\u043e\u043b\u043d\u0430";                                 // Einfallende Welle (2)
var text10 = "\u041e\u0442\u0440\u0430\u0436\u0435\u043d\u043d\u0430\u044f "   // Reflektierte Welle (1)
           + "\u0432\u043e\u043b\u043d\u0430";                                 // Reflektierte Welle (2)
var text11 = "\u0420\u0435\u0437\u0443\u043b\u044c\u0442\u0438\u0440\u0443\u044e\u0449\u0430\u044f " // Res. steh. Welle (1)
           + "\u0441\u0442\u043e\u044f\u0447\u0430\u044f "                     // Resultierende stehende Welle (2) 
           + "\u0432\u043e\u043b\u043d\u0430";                                 // Resultierende stehende Welle (3)

var author = "W. Fendt 2003"; 
var translator = "\u041d\u0413\u0422\u0423 2010";

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "\u0423";
var symbolAntiNode = "\u041f";

