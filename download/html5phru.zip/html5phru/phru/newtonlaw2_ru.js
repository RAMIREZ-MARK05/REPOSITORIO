// Fahrbahnversuch zum 2. Newtonschen Gesetz, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";                                 // Messreihe l�schen
var text02 = ["\u0421\u0442\u0430\u0440\u0442",                                // Start
              "\u0417\u0430\u043f\u0438\u0441\u0430\u0442\u044c "              // Ergebnis registrieren (1)
  	        + "\u0434\u0430\u043d\u043d\u044b\u0435"];                         // Ergebnis registrieren (2)
var text03 = "\u0413\u0440\u0430\u0444\u0438\u043a";                           // Diagramm
var text04 = "\u041c\u0430\u0441\u0441\u0430 "                                 // Masse des Wagens (1)
    	   + "\u0442\u0435\u043b\u0435\u0436\u043a\u0438:";                    // Masse des Wagens (2)
var text05 = "\u041f\u043e\u0434\u0432\u0435\u0448\u0435\u043d\u043d\u0430\u044f "       // Masse des W�gest�cks (1)
           + "\u043c\u0430\u0441\u0441\u0430:";                                          // Masse des W�gest�cks (2)
var text06 = "\u041a\u043e\u044d\u0444\u0444\u0438\u0446\u0438\u0435\u043d\u0442 "       // Reibungszahl (1)
           + "\u0442\u0440\u0435\u043d\u0438\u044f:";                                    // Reibungszahl (2)
var text07 = "\u0420\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u044b:";  // Messwerte

var author = "W. Fendt 1997,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "\u0433";

var text08 = "LB";
var text09 = "(\u0441)";
var text10 = "(\u043c)";
var text11 = "\u0421\u043b\u0438\u0448\u043a\u043e\u043c "                     // Reibung zu gro� (1)
           + "\u0431\u043e\u043b\u044c\u0448\u043e\u0435 "                     // Reibung zu gro� (2)
           + "\u0442\u0440\u0435\u043d\u0438\u0435!";                          // Reibung zu gro� (3)

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "\u043c";
var second = "\u0441";
var meterPerSecond2 = "\u043c/\u0441\u00B2";


