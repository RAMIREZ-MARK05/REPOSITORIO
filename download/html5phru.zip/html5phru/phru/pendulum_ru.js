// Fadenpendel, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";             // Zur�ck
var text02 = ["\u0421\u0442\u0430\u0440\u0442",            // Start
             "\u041f\u0430\u0443\u0437\u0430",             // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text03 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe (1)
           + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                         // Zeitlupe (2)
var text04 = "\u0414\u043b\u0438\u043d\u0430 "                                 // Pendell�nge (1)
           + "\u043c\u0430\u044f\u0442\u043d\u0438\u043a\u0430:";              // Pendell�nge (2)
var text05x = "\u0413\u0440\u0430\u0432\u0438\u0442\u0430\u0446\u0438"         // Fallbeschleunigung (1)
            + "\u043e\u043d\u043d\u043e\u0435";                                // Fallbeschleunigung (2)
var text05 = "\u0443\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435:";        // Fallbeschleunigung (3)
var text06 = "\u041c\u0430\u0441\u0441\u0430:";                                // Masse
var text07 = "\u0410\u043c\u043f\u043b\u0438\u0442\u0443\u0434\u0430:";        // Amplitude
var text08 = "\u041e\u0442\u043a\u043b\u043e\u043d\u0435\u043d\u0438\u0435";   // Elongation
var text09 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c";               // Geschwindigkeit
var text10 = "\u0423\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435";         // Beschleunigung
var text11 = "\u0421\u0438\u043b\u0430";                                       // Kraft
var text12 = "\u042d\u043d\u0435\u0440\u0433\u0438\u044f";                     // Energie

var author = "W. Fendt 1998,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var meter = "\u043c";                                   
var meterPerSecond2 = "\u043c/\u0441&sup2;";               
var kilogram = "\u043a\u0433";                        
var degree = "&deg;";                                 

var text13 = "\u041c\u0430\u043a\u0441\u0438\u043c\u0443\u043c";               // Maximum
var text14 = "\u041e\u0442\u043a\u043b\u043e\u043d\u0435\u043d\u0438\u0435";   // Elongation
var text15 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c";               // Geschwindigkeit
var text16 = "\u0423\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435 "         // Beschleunigung, tangentiale Komponente (1)
           + "(\u0442\u0430\u043d\u0433\u0435\u043d\u0446\u0438\u0430\u043b\u044c\u043d\u0430\u044f " // Beschl. tang. Komp. (2)
           + "\u043a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442\u0430)";  // Beschleunigung, tangentiale Komponente (3)
var text17 = "\u0421\u0438\u043b\u0430 "                                       // Kraft, tangentiale Komponente (1)
           + "(\u0442\u0430\u043d\u0433\u0435\u043d\u0446\u0438\u0430\u043b\u044c\u043d\u0430\u044f " // Kraft tang. Komp. (2)
           + "\u043a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442\u0430)";  // Kraft, tangentiale Komponente (3)
var text18 = "\u041f\u043e\u0442\u0435\u043d\u0446\u0438\u0430\u043b\u044c\u043d\u0430\u044f "     // Potentielle Energie (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f";                                         // Potentielle Energie (2)
var text19 = "\u041a\u0438\u043d\u0435\u0442\u0438\u0447\u0435\u0441\u043a\u0430\u044f "           // Kinetische Energie (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f";                                         // Kinetische Energie (2)
var text20 = "\u041f\u043e\u043b\u043d\u0430\u044f "                           // Gesamtenergie (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f";                     // Gesamtenergie (2)
var text21 = "(\u0441)";                                   // Einheit f�r Zeitachse (s)
var text22 = "(\u043c)";                                   // Einheit f�r senkrechte Achse (m)
var text23 = "(\u043c/\u0441)";                            // Einheit f�r senkrechte Achse (m/s)
var text24 = "(\u043c/\u0441\u00b2)";                      // Einheit f�r senkrechte Achse (m/s�)
var text25 = "(\u041d)";                                   // Einheit f�r senkrechte Achse (N)
var text26 = "(\u0414\u0436)";                             // Einheit f�r senkrechte Achse (J)
var text27 = "\u041f\u0435\u0440\u0438\u043e\u0434 "                           // Schwingungsdauer (1)
           + "\u043a\u043e\u043b\u0435\u0431\u0430\u043d\u0438\u0439";         // Schwingungsdauer (2)

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolTangential = "tang";                             // Symbol f�r tangential
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "\u0441";                                          
var meterUnicode = "\u043c";                     
var meterPerSecond = "\u043c/\u0441";                     
var meterPerSecond2Unicode = "\u043c/\u0441\u00b2";
var newton = "\u041d";                          
var joule = "\u0414\u0436";               


