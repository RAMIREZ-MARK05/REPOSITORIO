// Kombinationen von Widerst�nden, Spulen und Kondensatoren, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 23.03.2020

// Spannungsquelle:
var text01 = "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u0442\u043e\u043a\u0430:";
// Spannung:
var text02 = "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435:";
// Frequenz:
var text03 = "\u0427\u0430\u0441\u0442\u043e\u0442\u0430:";
// Bauteil:
var text04 = "\u041a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442\u044b:";
// Widerstand (Bauteil), Spule, Kondensator:
var text05 = ["\u0440\u0435\u0437\u0438\u0441\u0442\u043e\u0440", 
              "\u043a\u0430\u0442\u0443\u0448\u043a\u0430 "
  	        + "\u0438\u043d\u0434\u0443\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u0438", 
  	          "\u043a\u043e\u043d\u0434\u0435\u043d\u0441\u0430\u0442\u043e\u0440"];
// Widerstand (Gr��e), Induktivit�t, Kapazit�t:
var text06 = ["\u0421\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435:", 
              "\u0418\u043d\u0434\u0443\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u044c:", 
              "\u00cb\u043c\u043a\u043e\u0441\u0442\u044c:"];
// Ersetzen:
var text07 = "\u0417\u0430\u043c\u0435\u043d\u044f\u0442\u044c";
// Hinzuf�gen (in Serie):
var text08 = "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c "
  	       + "\u043f\u043e\u0441\u043b\u0435\u0434\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u043d\u043e";
// Hinzuf�gen (parallel):
var text09 = "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c "
  	       + "\u043f\u0430\u0440\u0430\u043b\u043b\u0435\u043b\u044c\u043d\u043e";
// Entfernen:
var text10 = "\u0423\u0434\u0430\u043b\u0438\u0442\u044c";
// Messger�te:
var text11 = "\u0418\u0437\u043c\u0435\u0440\u044f\u0442\u044c:";
// Spannung:
var text12 = "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435";
// Stromst�rke:
var text13 = "\u0421\u0438\u043b\u0443 \u0442\u043e\u043a\u0430";

var author = "W. Fendt 2004";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Spannung:
var text14 = "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435:";
// Stromst�rke:
var text15 = "\u0421\u0438\u043b\u0443 \u0442\u043e\u043a\u0430:";
// Impedanz:
var text16 = "\u041f\u043e\u043b\u043d\u043e\u0435 "
  	       + "\u0441\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435 "
  	       + "(\u0438\u043c\u043f\u0435\u0434\u0430\u043d\u0441):";
// Impedanz (Betrag):
var text17 = "\u0418\u043c\u043f\u0435\u0434\u0430\u043d\u0441 (\u043c\u043e\u0434\u0443\u043b\u044c):";
// Phasenverschiebung:
var text18 = "\u0424\u0430\u0437\u043e\u0432\u044b\u0439 \u0441\u0434\u0432\u0438\u0433:";
// Sehr klein (Stromst�rke Voltmeter):
var text19 = "\u043e\u0447\u0435\u043d\u044c \u043c\u0430\u043b\u043e";
// Sehr klein (Spannung Amperemeter):
var text20 = "\u043e\u0447\u0435\u043d\u044c \u043c\u0430\u043b\u043e";
// Sehr klein (Impedanz/Widerstand Amperemeter):
var text21 = "\u043e\u0447\u0435\u043d\u044c \u043c\u0430\u043b\u043e";           
// Sehr gro� (Impedanz/Widerstand Voltmeter):
var text22 = "\u043e\u0447\u0435\u043d\u044c \u0432\u0435\u043b\u0438\u043a\u043e";           

var volt = "\u0412";
var ampere = "\u0410";
var ohm = "\u041e\u043c";
var hertz = "\u0413\u0446";
var henry = "\u0413\u043d";
var microfarad = "\u043c\u043a\u0424";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)