// Magnetfeld eines geraden stromdurchflossenen Leiters, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0442\u043e\u043a";      // Umpolen

var author = "W. Fendt 2000";
var translator = "\u041d\u0413\u0422\u0423 2010";
