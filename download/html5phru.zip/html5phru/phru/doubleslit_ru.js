// Interferenz von Licht am Doppelspalt, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0414\u043b\u0438\u043d\u0430 \u0432\u043e\u043b\u043d\u044b:"; // Wellenl�nge
var text02 = "\u0420\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 "   // Spaltabstand (1)
           + "\u043c\u0435\u0436\u0434\u0443 "                                 // Spaltabstand (2)
           + "\u0449\u0435\u043b\u044f\u043c\u0438:";                          // Spaltabstand (3)
var text03 = "\u0423\u0433\u043e\u043b:";                                      // Winkel
var text04 = "\u041c\u0430\u043a\u0441\u0438\u043c\u0443\u043c:";              // Maxima
var text05 = "\u041c\u0438\u043d\u0438\u043c\u0443\u043c:";                    // Minima
var text06 = "\u0418\u043d\u0442\u0435\u043d\u0441\u0438\u0432\u043d\u043e\u0441\u0442\u044c "     // Relative Intensit�t (1)
           + "(\u043e\u0442\u043d.):";                                                             // Relative Intensit�t (2)
var text07 = "\u0418\u043d\u0442\u0435\u0440\u0444\u0435\u0440\u0435\u043d\u0446\u0438\u043e\u043d\u043d\u0430\u044f " // Interferenzmuster (1)
           + "\u043a\u0430\u0440\u0442\u0438\u043d\u0430";                                                             // Interferenzmuster (2)
var text08 = "\u041f\u0440\u043e\u0444\u0438\u043b\u044c "                                         // Intensit�tsverteilung (1)
           + "\u0438\u043d\u0442\u0435\u043d\u0441\u0438\u0432\u043d\u043e\u0441\u0442\u0438";     // Intensit�tsverteilung (2)

var author = "W. Fendt 2003,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "\u043d\u043c";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00b0";
