// Gekoppelte Pendel, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 29.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";             // Zur�ck                           
var text02 = ["\u0421\u0442\u0430\u0440\u0442",            // Start
             "\u041f\u0430\u0443\u0437\u0430",             // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text03 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe (1)
           + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                         // Zeitlupe (2)
var text04 = "\u0418\u0441\u0445\u043e\u0434\u043d\u043e\u0435 "               // Anfangspositionen (1)
           + "\u0441\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435:";        // Anfangspositionen (2)

var author = "W. Fendt 1998";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                   

var text05 = "\u041c\u0430\u044f\u0442\u043d\u0438\u043a 1";         // Pendel 1 (links)
var text06 = "\u041c\u0430\u044f\u0442\u043d\u0438\u043a 2";         // Pendel 2 (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
