// Bohrsches Atommodell, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

// Texte in HTML-Schreibweise:

var text01 = "\u041a\u043e\u0440\u043f\u0443\u0441\u043a\u0443\u043b"          // Teilchenbild (1)
           + "\u044f\u0440\u043d\u0430\u044f "                                 // Teilchenbild (2)                           
           + "\u043c\u043e\u0434\u0435\u043b\u044c";                           // Teilchenbild (3)
var text02 = "\u0412\u043e\u043b\u043d\u043e\u0432\u0430\u044f "               // Wellenbild (1)
           + "\u043c\u043e\u0434\u0435\u043b\u044c";                           // Wellenbild (2)
var text03 = "\u0413\u043b\u0430\u0432\u043d\u043e\u0435 "                     // Hauptquantenzahl (1)
           + "\u043a\u0432\u0430\u043d\u0442\u043e\u0432\u043e\u0435 "         // Hauptquantenzahl (2)
           + "\u0447\u0438\u0441\u043b\u043e:";                                // Hauptquantenzahl (3)

var author = "W. Fendt 1999"; 
var translator = "\u041d\u0413\u0422\u0423 2010";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00b7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "\u043c";                       
var joule = "\u0414\u0436";
var electronVolt = "\u044d\u0412";



