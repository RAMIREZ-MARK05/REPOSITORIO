// Zerfallsreihen, russische Texte
// Letzte �nderung 07.01.2018

// Texte in HTML-Schreibweise:

var text01 = "\u0420\u0430\u0434\u0438\u043e\u0430\u043a\u0442\u0438\u0432\u043d\u044b\u0439 " // Zerfallskette
           + "\u0440\u044f\u0434:";
var text03 = "\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0439 "         // N�chster Zerfall
           + "\u0440\u0430\u0441\u043f\u0430\u0434";

var author = "W. Fendt 1998"; 
var translator = "\u041d\u0413\u0422\u0423 2010";

// Texte in Unicode-Schreibweise:

var text02 = ["\u0420\u044f\u0434 \u0442\u043e\u0440\u0438\u044f",             // Thorium-Reihe
              "\u0420\u044f\u0434"                                             // Neptunium-Reihe
  	        + "\u043d\u0435\u043f\u0442\u0443\u043d\u0438\u044f",
  	          "\u0420\u044f\u0434 \u0443\u0440\u0430\u043d\u0430-"             // Uran-Radium-Reihe
  	        + "\u0440\u0430\u0434\u0438\u044f",
  	          "\u0420\u044f\u0434 \u0430\u043a\u0442\u0438\u043d\u043e-"       // Uran-Actinium-Reihe
            + "\u0443\u0440\u0430\u043d\u0430"];        






