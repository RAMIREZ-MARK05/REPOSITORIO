// Elastischer und unelastischer Sto�, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u0423\u043f\u0440\u0443\u0433\u0438\u0439 "                     // Elastischer Sto� (1)
  	       + "\u0443\u0434\u0430\u0440";                                       // Elastischer Sto� (2)
var text02 = "\u041d\u0435\u0443\u043f\u0440\u0443\u0433\u0438\u0439 "         // Unelastischer Sto� (1)
  	       + "\u0443\u0434\u0430\u0440";                                       // Unelastischer Sto� (2)
var text03 = "\u0421\u0431\u0440\u043e\u0441";                                 // Zur�ck
var text04 = "\u0421\u0442\u0430\u0440\u0442";                                 // Start
var text05 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "  // Zeitlupe (1)
  	       + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                    // Zeitlupe (2)
var text06 = "\u0422\u0435\u043b\u0435\u0436\u043a\u0430 1:";                  // Wagen 1
var text07 = "\u0422\u0435\u043b\u0435\u0436\u043a\u0430 2:";                  // Wagen 2
var text08 = "\u041c\u0430\u0441\u0441\u0430:";                                // Masse
var text09 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c:";              // Geschwindigkeit
var text10 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c";               // Geschwindigkeit
var text11 = "\u0418\u043c\u043f\u0443\u043b\u044c\u0441";                     // Impuls
var text12 = "\u041a\u0438\u043d\u0435\u0442\u0438\u0447\u0435\u0441\u043a\u0430\u044f " // Kinetische Energie (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f";                               // Kinetische Energie (2)

var author = "W. Fendt 1998,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "\u043a\u0433";
var meterPerSecond = "\u043c/\u0441";                        

var text13 = "\u0422\u0435\u043b\u0435\u0436\u043a\u0430 1:";                  // Wagen 1
var text14 = "\u0422\u0435\u043b\u0435\u0436\u043a\u0430 2:";                  // Wagen 2
var text15 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0434\u043e "              // Geschwindigkeiten vor dem Sto� (1)
           + "\u0441\u0442\u043e\u043b\u043a\u043d\u043e\u0432\u0435\u043d\u0438\u044f:";  // Geschwindigkeiten vor dem Sto� (2)
var text16 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u043f\u043e\u0441\u043b\u0435 " // Geschwindigkeiten nach dem Sto� (1)
           + "\u0441\u0442\u043e\u043b\u043a\u043d\u043e\u0432\u0435\u043d\u0438\u044f:"        // Geschwindigkeiten nach dem Sto� (2)
var text17 = "\u0418\u043c\u043f\u0443\u043b\u044c\u0441 \u0434\u043e "                    // Impulse vor dem Sto� (1)
           + "\u0441\u0442\u043e\u043b\u043a\u043d\u043e\u0432\u0435\u043d\u0438\u044f:";  // Impulse vor dem Sto� (2)
var text18 = "\u0418\u043c\u043f\u0443\u043b\u044c\u0441 \u043f\u043e\u0441\u043b\u0435 "  // Impulse nach dem Sto� (1)
           + "\u0441\u0442\u043e\u043b\u043a\u043d\u043e\u0432\u0435\u043d\u0438\u044f:";  // Impulse nach dem Sto� (2)
var text19 = "\u041a\u0438\u043d\u0435\u0442\u0438\u0447\u0435\u0441\u043a\u0430\u044f "   // Kinetische Energie vor dem Sto� (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f \u0434\u043e "                    // Kinetische Energie vor dem Sto� (2)
           + "\u0441\u0442\u043e\u043b\u043a\u043d\u043e\u0432\u0435\u043d\u0438\u044f:";  // Kinetische Energie vor dem Sto� (3)
var text20 = "\u041a\u0438\u043d\u0435\u0442\u0438\u0447\u0435\u0441\u043a\u0430\u044f "   // Kinetische Energie nach dem Sto� (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f \u043f\u043e\u0441\u043b\u0435 "  // Kinetische Energie nach dem Sto� (2)
           + "\u0441\u0442\u043e\u043b\u043a\u043d\u043e\u0432\u0435\u043d\u0438\u044f:";  // Kinetische Energie nach dem Sto� (3)
var text21 = "\u0421\u0443\u043c\u043c\u0430\u0440\u043d\u044b\u0439 "                     // Gesamtimpuls (1)
           + "\u0438\u043c\u043f\u0443\u043b\u044c\u0441:";                                // Gesamtimpuls (2)
var text22 = "\u0421\u0443\u043c\u043c\u0430\u0440\u043d\u0430\u044f "                     // Gesamte kinetische Energie (1)
           + "\u043a\u0438\u043d\u0435\u0442\u0438\u0447\u0435\u0441\u043a\u0430\u044f "   // Gesamte kinetische Energie (2)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f:";                                // Gesamte kinetische Energie (3)

// Symbole und Einheiten:

var meterPerSecondUnicode = "\u043c/\u0441";                   
var kilogramMeterPerSecond = "\u043a\u0433 \u043c/\u0441";                
var joule = "\u0414\u0436";                                         
