// Newtons Wiege, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";             // Zur�ck
var text02 = "\u0421\u0442\u0430\u0440\u0442";             // Start
var text03 = "\u0427\u0438\u0441\u043b\u043e \u0448\u0430\u0440\u043e\u0432:"; // Zahl der ausgelenkten Kugeln

var author = "W. Fendt 1997";
var translator = "\u041d\u0413\u0422\u0423 2010";
