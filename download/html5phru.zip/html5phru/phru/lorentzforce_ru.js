// Leiterschaukel-Versuch zur Lorentzkraft, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0412\u043a\u043b / \u0412\u044b\u043a\u043b";                  // Ein / Aus
var text02 = "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0442\u043e\u043a";      // Umpolen
var text03 = "\u041f\u043e\u0432\u0435\u0440\u043d\u0443\u0442\u044c "         // Magnet umdrehen (1)
  	       + "\u043c\u0430\u0433\u043d\u0438\u0442";                           // Magnet umdrehen (2)
var text04 = "\u041d\u0430\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 "       // Stromrichtung (1)
           + "\u0442\u043e\u043a\u0430";                                                 // Stromrichtung (2)
var text05 = "\u041c\u0430\u0433\u043d\u0438\u0442\u043d\u043e\u0435 "         // Magnetfeld (1)
           + "\u043f\u043e\u043b\u0435";                                       // Magnetfeld (2)
var text06 = "\u0421\u0438\u043b\u0430 "                                       // Lorentzkraft (1)
           + "\u041b\u043e\u0440\u0435\u043d\u0446\u0430";                     // Lorentzkraft (2)

var author = "W. Fendt 1998";
var translator = "\u041d\u0413\u0422\u0423 2010";
