// Photoelektrischer Effekt, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

// Texte in HTML-Schreibweise:

var text01 = "\u041c\u0430\u0442\u0435\u0440\u0438\u0430\u043b "     // Kathodenmaterial (1)
           + "\u043a\u0430\u0442\u043e\u0434\u0430:";                // Kathodenmaterial (2)
var text03 = "\u0421\u043f\u0435\u043a\u0442\u0440\u0430\u043b\u044c\u043d\u0430\u044f " // Spektrallinie Hg (1)
           + "\u043b\u0438\u043d\u0438\u044f (Hg):";                                     // Spektrallinie Hg (2)
var text04 = "\u0417\u0430\u0434\u0435\u0440. "                                          // Gegenspannung (1)
           + "\u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435:";            // Gegenspannung (2)
var text05 = "\u0427\u0430\u0441\u0442\u043e\u0442\u0430:";                              // Frequenz
var text06 = ["\u042d\u043d\u0435\u0440\u0433\u0438\u044f",                              // Energie eines Photons (1) 
             "\u0444\u043e\u0442\u043e\u043d\u043e\u0432:"];                             // Energie eines Photons (2)
var text07 = "\u0420\u0430\u0431\u043e\u0442\u0430 "                                     // Austrittsarbeit (1)
           + "\u0432\u044b\u0445\u043e\u0434\u0430:";                                    // Austrittsarbeit (2)
var text08 = ["\u041c\u0430\u043a\u0441. \u043a\u0438\u043d. "                           // Maximale kinetische Energie ... (1)
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f",                               // Maximale kinetische Energie ... (2)
             "\u044d\u043b\u0435\u043a\u0442\u0440\u043e\u043d\u043e\u0432:"];           // ... eines Elektrons
var text09 = "\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c";                         // Messergebnisse l�schen

var author = "W. Fendt 2000,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "\u0412";                               
var terahertz = "\u0422\u0413\u0446";     
var electronvolt = "\u044d\u0412";                     

// Texte in Unicode-Schreibweise:

var text02 = ["\u0426\u0435\u0437\u0438\u0439",                                // C�sium 
             "\u041d\u0430\u0442\u0440\u0438\u0439"];                          // Natrium
var text10 = ["\u0436\u0435\u043b\u0442\u044b\u0439",                          // gelb 
             "\u0437\u0435\u043b\u0435\u043d\u044b\u0439",                     // gr�n
             "\u0444\u0438\u043e\u043b\u0435\u0442\u043e\u0432\u044b\u0439",   // violett 
             "\u0443\u043b\u044c\u0442\u0440\u0430\u0444\u0438\u043e\u043b\u0435\u0442\u043e\u0432\u044b\u0439",  // ultraviolett 
             "\u0443\u043b\u044c\u0442\u0440\u0430\u0444\u0438\u043e\u043b\u0435\u0442\u043e\u0432\u044b\u0439"]; // ultraviolett
var text11 = "(\u0422\u0413\u0446)";                       // Einheit f�r waagrechte Achse (THz)
var text12 = "(\u0412)";                                   // Einheit f�r senkrechte Achse (V)
var text13 = [
             ["\u042d\u043d\u0435\u0440\u0433\u0438\u044f "                              // Energie nicht ausreichend ... (1)
           + "\u0444\u043e\u0442\u043e\u043d\u043e\u0432 "                               // Energie nicht ausreichend ... (2)
           + "\u043d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043e\u0447\u043d\u0430 " // Energie nicht ausreichend ... (3)
           + "\u0434\u043b\u044f \u044d\u043c\u0438\u0441\u0441\u0438\u0438",            // Energie nicht ausreichend ... (4)
             "\u044d\u043b\u0435\u043a\u0442\u0440\u043e\u043d\u043e\u0432."],           // ... f�r Abl�sung eines Elektrons
             ["\u0423\u0432\u0435\u043b\u0438\u0447\u0438\u0432\u0430\u0439\u0442\u0435 "          // Erh�he Gegenspannung ... (1)
           + "\u0437\u0430\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044e\u0449\u0435\u0435 "     // Erh�he Gegenspannung ... (2)
           + "\u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 \u0434\u043e "          // Erh�he Gegenspannung ... (3)
           + "\u0442\u0435\u0445 \u043f\u043e\u0440",                                              // Erh�he Gegenspannung ... (4)
             "\u043f\u043e\u043a\u0430 \u044d\u043b\u0435\u043a\u0442\u0440\u043e\u043d\u044b "    // ... bis kein Strom mehr (1)
           + "\u043f\u0435\u0440\u0435\u0441\u0442\u0430\u043d\u0443\u0442 "                       // ... bis kein Strom mehr (2)
           + "\u0434\u043e\u0441\u0442\u0438\u0433\u0430\u0442\u044c "                             // ... bis kein Strom mehr (3)
           + "\u0430\u043d\u043e\u0434\u0430!"],                                                   // ... bis kein Strom mehr (4)
             ["\u0417\u0430\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044e\u0449\u0435\u0435 "    // Gegenspannung zu gro� ... (1)
           + "\u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 "                       // Gegenspannung zu gro� ... (2)
           + "\u043d\u0430\u0441\u0442\u043e\u043b\u044c\u043a\u043e "                             // Gegenspannung zu gro� ... (3)
           + "\u0432\u0435\u043b\u0438\u043a\u043e,",                                              // Gegenspannung zu gro� ... (4)
             "\u0447\u0442\u043e \u044d\u043b\u0435\u043a\u0442\u0440\u043e\u043d\u044b "          // ... R�ckkehr zur Kathode (1)
           + "\u0432\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u044e\u0442\u0441\u044f "           // ... R�ckkehr zur Kathode (2)
           + "\u043d\u0430 \u043a\u0430\u0442\u043e\u0434."],                                      // ... R�ckkehr zur Kathode (3)
             ["\u041f\u0440\u043e\u0432\u0435\u0434\u0438\u0442\u0435 "                            // Neue Messung ... (1)
           + "\u043d\u043e\u0432\u043e\u0435 "                                                     // Neue Messung ... (2)
           + "\u0438\u0437\u043c\u0435\u0440\u0435\u043d\u0438\u0435 "                             // Neue Messung ... (3)
           + "\u0441 \u0434\u0440\u0443\u0433\u043e\u0439",                                        // Neue Messung ... (4)
             "\u0441\u043f\u0435\u043a\u0442\u0440\u0430\u043b\u044c\u043d\u043e\u0439 "           // ... f�r andere Spektrallinie (1)
           + "\u043b\u0438\u043d\u0438\u0435\u0439!"],                                             // ... f�r andere Spektrallinie (2)
             ["\u041f\u0440\u043e\u0432\u0435\u0434\u0438\u0442\u0435 "                            // Neue Messreihe ... (1)
           + "\u043d\u043e\u0432\u0443\u044e \u0441\u0435\u0440\u0438\u044e "                      // Neue Messreihe ... (2)
           + "\u0438\u0437\u043c\u0435\u0440\u0435\u043d\u0438\u0439 "                             // Neue Messreihe ... (3)
           + "\u0441 \u0434\u0440\u0443\u0433\u0438\u043c",                                        // Neue Messreihe ... (4)
             "\u043a\u0430\u0442\u043e\u0434\u043d\u044b\u043c "                                   // ... f�r anderes Material (1)
           + "\u043c\u0430\u0442\u0435\u0440\u0438\u0430\u043b\u043e\u043c!"],                     // ... f�r anderes Material (2)
             ["\u0418\u0437\u043c\u0435\u0440\u0435\u043d\u0438\u044f "                            // Messungen abgeschlossen (1)
           + "\u043e\u043a\u043e\u043d\u0447\u0435\u043d\u044b.",                                  // Messungen abgeschlossen (2) 
             ""]                                                                                   // Messungen abgeschlossen (3)
             ];

var symbolCathode = "K";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
