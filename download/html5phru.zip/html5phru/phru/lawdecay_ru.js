// Zerfallsgesetz der Radioaktivit�t, russische Texte (Tomass Romanovskis)
// Letzte �nderung 30.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";
var text02 = ["\u0421\u0442\u0430\u0440\u0442",                                          // Start
             "\u041f\u0430\u0443\u0437\u0430",                                           // Pause
             "\u0412\u043e\u0437\u043e\u0431\u043d\u043e\u0432\u0438\u0442\u044c"];      // Weiter    
var text03 = "\u0413\u0440\u0430\u0444\u0438\u043a";                                     // Diagramm

var author = "W. Fendt 1998";
var translator = "T. Romanovskis 2002";

var text04 = "\u0412\u0440\u0435\u043c\u044f:";                                          // Zeit
var text05 = "\u0415\u0449\u0435 \u043d\u0435 "                                          // Noch nicht zerfallen (1)
           + "\u0440\u0430\u0441\u043f\u0430\u043b\u043e\u0441\u044c:";                  // Noch nicht zerfallen (2)
var text06 = "\u0420\u0430\u0441\u043f\u0430\u043b\u043e\u0441\u044c "                   // Schon zerfallen (1)
           + "\u044f\u0434\u0435\u0440:";                                                // Schon zerfallen (2)
var text07 = ["", "", "", ""];                                                           // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
