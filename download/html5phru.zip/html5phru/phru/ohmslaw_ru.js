// Ohmsches Gesetz, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u041c\u0430\u043a\u0441\u0438\u043c\u0430\u043b\u044c\u043d\u043e\u0435 " // Maximale Spannung (1)
  	       + "\u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435:";            // Maximale Spannung (2)
var text02 = "\u041c\u0430\u043a\u0441\u0438\u043c\u0430\u043b\u044c\u043d\u0430\u044f " // Maximale Stromst�rke (1)
  	       + "\u0441\u0438\u043b\u0430 \u0442\u043e\u043a\u0430:";                       // Maximale Stromst�rke (2)
var text03 = "\u0423\u0432\u0435\u043b\u0438\u0447\u0438\u0442\u044c R";                 // Widerstand vergr��ern
var text04 = "\u0423\u043c\u0435\u043d\u044b\u0448\u0438\u0442\u044c R";                 // Widerstand verkleinern
var text05 = "\u0423\u0432\u0435\u043b\u0438\u0447\u0438\u0442\u044c U";                 // Spannung vergr��ern
var text06 = "\u0423\u043c\u0435\u043d\u044b\u0448\u0438\u0442\u044c U";                 // Spannung verkleinern

var author = "W. Fendt 1997";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "\u043c";
var volt = "\u0412";
var ampere = "\u0410";

var text07 = "\u041f\u0440\u0435\u0432\u044b\u0448\u0435\u043d "                         // Messbereich �berschritten (1)
           + "\u043c\u0430\u043a\u0441\u0438\u043c\u0443\u043c!";                        // Messbereich �berschritten (2)

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u041e\u043c";
