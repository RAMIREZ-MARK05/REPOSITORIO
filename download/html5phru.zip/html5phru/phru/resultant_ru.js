// Ersatzkraft mehrerer Kr�fte, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e "   // Zahl der Einzelkr�fte (1)  
           + "\u0441\u0438\u043b:";                                            // Zahl der Einzelkr�fte (2)
var text02 = "\u0421\u043b\u043e\u0436\u0438\u0442\u044c "                     // Gesamtkraft ermitteln (1)
           + "\u0441\u0438\u043b\u044b";                                       // Gesamtkraft ermitteln (2)
var text03 = "\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c";               // Konstruktion l�schen

var author = "W. Fendt 1998";
var translator = "\u041d\u0413\u0422\u0423 2010";
