// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "2 \u0431\u043b\u043e\u043a\u0430";           // 2 Rollen
var text02 = "4 \u0431\u043b\u043e\u043a\u0430";           // 4 Rollen
var text03 = "6 \u0431\u043b\u043e\u043a\u043e\u0432";     // 6 Rollen
var text04 = "\u0412\u0435\u0441 \u0433\u0440\u0443\u0437\u0430:";   // Gewicht der Last
var text05 = "\u0412\u0435\u0441 \u0441\u0432\u043e\u0431\u043e\u0434\u043d\u043e\u0433\u043e "  // Gewicht der losen Flasche (1)
           + "\u0431\u043b\u043e\u043a\u0430(\u043e\u0432):";                                    // Gewicht der losen Flasche (2)
var text06 = "\u041d\u0435\u043e\u0431\u0445\u043e\u0434\u0438\u043c\u0430\u044f "       // Ben�tigte Kraft (1)
           + "\u0441\u0438\u043b\u0430:";                                                // Ben�tigte Kraft (2)
var text07 = "\u0414\u0438\u043d\u0430\u043c\u043e\u043c\u0435\u0442\u0440";   // Federwaage
var text08 = "\u0412\u0435\u043a\u0442\u043e\u0440\u0430 "                     // Kraftvektoren (1)
           + "\u0441\u0438\u043b";                                             // Kraftvektoren (2)

var author = "W. Fendt 1998";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "\u041d";                             
