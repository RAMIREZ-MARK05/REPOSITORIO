// Kreisbewegung mit konstanter Winkelgeschwindigkeit, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";             // Zur�ck
var text02 = ["\u0421\u0442\u0430\u0440\u0442",            // Start
             "\u041f\u0430\u0443\u0437\u0430",             // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text03 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe (1)
  	       + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                         // Zeitlupe (2)
var text04 = "\u0420\u0430\u0434\u0438\u0443\u0441:";      // Radius
var text05 = "\u041f\u0435\u0440\u0438\u043e\u0434:";      // Umlaufdauer
var text06 = "\u041c\u0430\u0441\u0441\u0430:";            // Masse
var text07 = "\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b";   // Position
var text08 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c";               // Geschwindigkeit
var text09 = "\u0423\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435";         // Beschleunigung
var text10 = "\u0421\u0438\u043b\u0430";                   // Kraft

var author = "W. Fendt 2007";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "\u043c";                                  
var second = "\u0441";                                
var kilogram = "\u043a\u0433";                                      

var text11 = "\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b:";  // Position
var text12 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c:";              // Geschwindigkeit
var text13 = "\u0423\u0433\u043b\u043e\u0432\u0430\u044f "                     // Winkelgeschwindigkeit (1)
  	       + "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c:";              // Winkelgeschwindigkeit (2)
var text14 = "\u0426\u0435\u043d\u0442\u0440\u043e\u0441\u0442\u0440\u0435\u043c\u0438"  // Zentripetalbeschleunigung (1)
  	       + "\u0442\u0435\u043b\u044c\u043d\u043e\u0435 "                               // Zentripetalbeschleunigung (2)
  	       + "\u0443\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435:";                  // Zentripetalbeschleunigung (3)
var text15 = "\u0426\u0435\u043d\u0442\u0440\u043e\u0441\u0442\u0440\u0435\u043c\u0438"  // Zentripetalkraft (1)
  	       + "\u0442\u0435\u043b\u044c\u043d\u0430\u044f "                               // Zentripetalkraft (2)
  	       + "\u0441\u0438\u043b\u0430:";                                                // Zentripetalkraft (3)
var text16 = "(\u0441)";                                                       // (in s)
var text17 = "(\u043c)";                                                       // (in m)
var text18 = "(\u043c/\u0441)";                                                // (in m/s)         
var text19 = "(\u043c/\u0441\u00b2)";                                          // (in m/s�)
var text20 = "(\u043d)";                                                       // (in N)
var text21 = "(x-\u043f\u0440\u043e\u0435\u043a\u0446\u0438\u044f)";           // (in x-Richtung)
var text22 = "(y-\u043f\u0440\u043e\u0435\u043a\u0446\u0438\u044f)";           // (in y-Richtung)
var text23 = "(\u043c\u043e\u0434\u0443\u043b\u044c)";                         // (Betrag)

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03c9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "\u043c";                         
var meterPerSecond = "\u043c/\u0441";                     
var meterPerSecond2 = "\u043c/\u0441\u00b2";                
var newton = "\u043d";                                    
var radPerSecond = "\u0440\u0430\u0434/\u0441";                         




