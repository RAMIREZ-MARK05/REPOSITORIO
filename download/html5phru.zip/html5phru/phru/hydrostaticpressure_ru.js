// Druckdose (hydrostatischer Druck), russische Texte (Tomass Romanovskis)
// Letzte �nderung 28.02.2019

var text01 = "\u0416\u0438\u0434\u043a\u043e\u0441\u0442\u044c:";              // Fl�ssigkeit
var text03 = "\u041f\u043b\u043e\u0442\u043d\u043e\u0441\u0442\u044c:";        // Dichte
var text04 = "\u0413\u043b\u0443\u0431\u0438\u043d\u0430:";                    // Tiefe
var text05 = "\u0414\u0430\u0432\u043b\u0435\u043d\u0438\u0435:";              // (Schwere-)Druck

var author = "W. Fendt 1999";                              // Autor
var translator = "T. Romanovskis 2002";                    // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "\u0433/\u0441\u043c&sup3;";
var centimeter = "\u0441\u043c";
var hectoPascal = "\u0433\u041f\u0430";

// Texte in Unicode-Schreibweise:

var text02 = ["\u043d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u0430\u044f "      // Unbekannte ...
           +  "\u0436\u0438\u0434\u043a\u043e\u0441\u0442\u044c",                        // ... Fl�ssigkeit
              "\u0432\u043e\u0434\u0430",                                                // Wasser
              "\u044d\u0442\u0430\u043d\u043e\u043b",                                    // Ethanol
              "\u0431\u0435\u043d\u0437\u043e\u043b",                                    // Benzol
              "\u0442\u0435\u0442\u0440\u0430\u0445\u043b\u043e\u0440"                   // Tetrachlor-...
           +  "\u043c\u0435\u0442\u0430\u043d",                                          // ...-kohlenstoff
              "\u0440\u0442\u0443\u0442\u044c"];                                         // Quecksilber 
