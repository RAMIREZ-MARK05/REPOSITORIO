// Potentiometerschaltung, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 31.12.2017

var text01 = "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 "             // Spannung der Stromquelle
  	       + "\u043f\u0438\u0442\u0430\u043d\u0438\u044f:";
var text02 = "\u041f\u043e\u043b\u0437\u0443\u043d\u043a\u043e\u0432\u044b\u0439 "       // Schiebewiderstand
  	       + "\u0440\u0435\u0437\u0438\u0441\u0442\u043e\u0440:";
var text03 = "\u041f\u043e\u0437\u0438\u0446\u0438\u044f "                               // Position des Schleifkontakts
  	       + "\u0441\u043a\u043e\u043b\u044c\u0437\u044f\u0449\u0435\u0433\u043e "
  	       + "\u043a\u043e\u043d\u0442\u0430\u043a\u0442\u0430:";
var text04 = "\u0421\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435 "     // Verbraucherwiderstand
  	       + "\u043d\u0430\u0433\u0440\u0443\u0437\u043a\u0438:";
var text05 = "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c "             // Spannung angeben
  	       + "\u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435";
var text06 = "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c "             // Strmst�rke angeben
  	       + "\u0441\u0438\u043b\u0443 \u0442\u043e\u043a\u0430";
var author = "W. Fendt 2006";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "U";                                  // Symbol f�r Spannung
var symbolVoltage2 = "V";                                  // Index f�r Verbraucher
                      
