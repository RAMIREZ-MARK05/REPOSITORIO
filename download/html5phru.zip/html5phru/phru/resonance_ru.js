// Resonanz, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";             // Zur�ck
var text02 = ["\u0421\u0442\u0430\u0440\u0442",            // Start
             "\u041f\u0430\u0443\u0437\u0430",             // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text03 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe (1)
           + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                         // Zeitlupe (2)
var text04 = "\u041c\u0430\u044f\u0442\u043d\u0438\u043a:";                              // Resonator
var text05 = "\u041a\u043e\u044d\u0444\u0444\u0438\u0446\u0438\u0435\u043d\u0442 "       // Federkonstante (1)
           + "\u0436\u0435\u0441\u0442\u043a\u043e\u0441\u0442\u0438:";                  // Federkonstante (2)
var text06 = "\u041c\u0430\u0441\u0441\u0430:";            // Masse
var text07 = "\u041a\u043e\u044d\u0444\u0444\u0438\u0446\u0438\u0435\u043d\u0442 "       // D�mpfung (1)
           + "\u0437\u0430\u0442\u0443\u0445\u0430\u043d\u0438\u044f:";                  // D�mpfung (2)
var text08 = "\u0412\u043d\u0435\u0448\u043d\u044f\u044f \u0441\u0438\u043b\u0430:";     // Erreger
var text09 = "\u041a\u0440\u0443\u0433\u043e\u0432\u0430\u044f "                         // Kreisfrequenz (1)
           + "\u0447\u0430\u0441\u0442\u043e\u0442\u0430:";                              // Kreisfrequenz (2)
var text10 = "\u041e\u0442\u043a\u043b\u043e\u043d\u0435\u043d\u0438\u0435";             // Diagramm Elongation
var text11 = "\u0410\u043c\u043f\u043b\u0438\u0442\u0443\u0434\u0430";                   // Diagramm Amplitude
var text12 = "\u0420\u0430\u0437\u043d\u043e\u0441\u0442\u044c \u0444\u0430\u0437";      // Diagramm Phasenunterschied

var author = "W. Fendt 1998,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "\u043a\u0433";                          
var newtonPerMeter = "\u041d/\u043c";       
var perSecond = "1/\u0441";  
var radPerSecond = "\u0440\u0430\u0434/\u0441";

var text13 = "\u041a\u0430\u0442\u0430\u0441\u0442\u0440\u043e\u0444\u0430!";            // Resonanzkatastrophe
var text14 = "(\u041c\u043e\u0434\u0435\u043b\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u0435 "    // Simulation ...
           + "\u0443\u0436\u0435 \u043d\u0435 "                                                    // ... nicht mehr ...
           + "\u0440\u0435\u0430\u043b\u0438\u0441\u0442\u0438\u0447\u043d\u043e)";                // ... realistisch

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz (omega)
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz (omega_0)
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "\u0441\u043c";      
var radPerSecondUnicode = "\u0440\u0430\u0434/\u0441";      


