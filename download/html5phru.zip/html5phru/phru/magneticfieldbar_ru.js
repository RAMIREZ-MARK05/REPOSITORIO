// Magnetfeld eines Stabmagneten, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c "               // Feldlinien l�schen (1)
           + "\u043b\u0438\u043d\u0438\u0438";                                 // Feldlinien l�schen (2)
var text02 = "\u041f\u043e\u0432\u0435\u0440\u043d\u0443\u0442\u044c "         // Magnet umdrehen (1)
  	       + "\u043c\u0430\u0433\u043d\u0438\u0442";                           // Magnet umdrehen (2)

var author = "W. Fendt 2001";
var translator = "\u041d\u0413\u0422\u0423 2010";
