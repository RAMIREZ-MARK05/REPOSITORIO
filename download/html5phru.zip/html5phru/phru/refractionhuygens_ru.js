// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0421\u0442\u0430\u0440\u0442";                                           // Neustart
var text02 = "\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0439 "                   // N�chster Schritt (1)
           + "\u0448\u0430\u0433";                                                       // N�chster Schritt (2)
var text03 = ["\u041f\u0430\u0443\u0437\u0430",                                          // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];            // Weiter
var text04 = "1. \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044c "          // 1. Brechungsindex (1)
           + "\u043f\u0440\u0435\u043b\u043e\u043c\u043b\u0435\u043d\u0438\u044f:";      // 1. Brechungsindex (2)
var text05 = "2. \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044c "          // 2. Brechungsindex (1)
           + "\u043f\u0440\u0435\u043b\u043e\u043c\u043b\u0435\u043d\u0438\u044f:";      // 2. Brechungsindex (2)
var text06 = "\u0423\u0433\u043e\u043b \u043f\u0430\u0434\u0435\u043d\u0438\u044f:";     // Einfallswinkel

var author = "W. Fendt 1998";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise:

var text07 = [
  [ // i == 0 (step == 0, n1 != n2, eps1 > 0)
    // Eine gerade Wellenfront l�uft\\ schr�g gegen die Grenze\\
  	// zweier Medien, in denen die\\ Phasengeschwindigkeiten\\
    // unterschiedlich gro� sind.
      "\u041f\u043b\u043e\u0441\u043a\u043e\u0441\u0442\u044c "
    + "\u0432\u043e\u043b\u043d\u043e\u0432\u043e\u0433\u043e "
    + "\u0444\u0440\u043e\u043d\u0442\u0430\n"
    + "\u043f\u0430\u0434\u0430\u0435\u0442 \u043f\u043e "
    + "\u0434\u0438\u0430\u0433\u043e\u043d\u0430\u043b\u0438 "
    + "\u043a \u0433\u0440\u0430\u043d\u0438\u0446\u0435\n"
    + "\u0440\u0430\u0437\u0434\u0435\u043b\u0430 \u0434\u0432\u0443\u0445 \u0441\u0440\u0435\u0434.\n"
    + "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u0438 \u0432\u043e\u043b\u043d "
    + "\u0440\u0430\u0437\u043b\u0438\u0447\u043d\u044b \u0432 "
    + "\u043a\u0430\u0436\u0434\u043e\u0439\n"
    + "\u0441\u0440\u0435\u0434\u0435."],
   
  [ // i == 1 (step == 0, n1 != n2, eps1 == 0)
    // Eine gerade Wellenfront l�uft\\ senkrecht gegen die Grenze\\
    // zweier Medien, in denen die\\ Phasengeschwindigkeiten\\
    // unterschiedlich gro� sind.    	
      "\u041f\u043b\u043e\u0441\u043a\u0438\u0439 "
    + "\u0444\u0440\u043e\u043d\u0442 \u0432\u043e\u043b\u043d\u044b "
    + "\u043f\u0430\u0434\u0430\u0435\u0442\n"
    + "\u043f\u0435\u0440\u043f\u0435\u043d\u0434\u0438\u043a\u0443\u043b\u044f\u0440\u043d\u043e "
    + "\u043a \u0433\u0440\u0430\u043d\u0438\u0446\u0435\n"
    + "\u0440\u0430\u0437\u0434\u0435\u043b\u0430 \u0434\u0432\u0443\u0445 \u0441\u0440\u0435\u0434.\n"
    + "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u0438 \u0432\u043e\u043b\u043d "
    + "\u0440\u0430\u0437\u043b\u0438\u0447\u043d\u044b \u0432 "
    + "\u043a\u0430\u0436\u0434\u043e\u0439\n"
    + "\u0441\u0440\u0435\u0434\u0435."],
   
  [ // i == 2 (step == 1, n1 > n2)
    // Bei Ankunft der Wellenfront\\ werden in den Punkten der\\
    // Grenze nach dem Prinzip von\\ Huygens Kreis- bzw. Kugel-\\ 
    // wellen (so genannte Elementar-\\ wellen) angeregt.\\
    // Im Medium 2 breiten sich diese\\ Elementarwellen schneller\\
    // aus, da dort der Brechungs-\\ index kleiner ist.
      "\u041f\u043e \u043f\u0440\u0438\u0431\u044b\u0442\u0438\u0438 "
    + "\u0444\u0440\u043e\u043d\u0442\u0430 \u0442\u043e\u0447\u043a\u0438 \u0432\u0434\u043e\u043b\u044c\n"
    + "\u0433\u0440\u0430\u043d\u0438\u0446\u044b "
    + "\u0432\u0435\u0434\u0443\u0442 \u0441\u0435\u0431\u044f \u0432 "
    + "\u0441\u043e\u043e\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0438\n"
    + "\u0441 \u043f\u0440\u0438\u043d\u0446\u0438\u043f\u043e\u043c "
    + "\u0413\u044e\u0439\u0433\u0435\u043d\u0441\u0430.\n"
    + "\u041a\u0430\u0436\u0434\u0430\u044f \u0442\u043e\u0447\u043a\u0430 "
    + "\u043c\u043e\u0436\u043d\u043e "
    + "\u0440\u0430\u0441\u0441\u043c\u0430\u0442\u0440\u0438\u0432\u0430\u0442\u044c\n"
    + "\u043a\u0430\u043a \u0441\u0444\u0435\u0440\u0438\u0447\u0435\u0441\u043a\u0438\u0439 "
    + "\u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u0441\u0432\u0435\u0442\u0430.\n"
    + "\u0412 \u0441\u0440\u0435\u0434\u0435 2 \u044d\u0442\u0438 "
    + "\u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0430\u0440\u043d\u044b\u0435 "
    + "\u0432\u043e\u043b\u043d\u044b\n"
    + "\u0434\u0432\u0438\u0436\u0443\u0442\u0441\u044f "
    + "\u0432\u044b\u0441\u0442\u0440\u0435\u0435, \u0442\u0430\u043a \u043a\u0430\u043a\n"
    + "\u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044c "
    + "\u043f\u0440\u0435\u043b\u043e\u043c\u043b\u0435\u043d\u0438\u044f "
    + "\u043c\u0435\u043d\u044c\u0448\u0435."],
   
  [ // i == 3 (step == 1, n1 < n2)
    // Bei Ankunft der Wellenfront\\ werden in den Punkten der\\
    // Grenze nach dem Prinzip von\\ Huygens Kreis- bzw. Kugel-\\ 
    // wellen (so genannte Elementar-\\ wellen) angeregt.\\
    // Im Medium 2 breiten sich diese\\ Elementarwellen langsamer\\
    // aus, da dort der Brechungs-\\ index gr��er ist.
      "\u041f\u043e \u043f\u0440\u0438\u0431\u044b\u0442\u0438\u0438 "
    + "\u0444\u0440\u043e\u043d\u0442\u0430 \u0442\u043e\u0447\u043a\u0438 \u0432\u0434\u043e\u043b\u044c\n"
    + "\u0433\u0440\u0430\u043d\u0438\u0446\u044b "
    + "\u0432\u0435\u0434\u0443\u0442 \u0441\u0435\u0431\u044f \u0432 "
    + "\u0441\u043e\u043e\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0438\n"
    + "\u0441 \u043f\u0440\u0438\u043d\u0446\u0438\u043f\u043e\u043c "
    + "\u0413\u044e\u0439\u0433\u0435\u043d\u0441\u0430.\n"
    + "\u041a\u0430\u0436\u0434\u0430\u044f \u0442\u043e\u0447\u043a\u0430 "
    + "\u043c\u043e\u0436\u043d\u043e "
    + "\u0440\u0430\u0441\u0441\u043c\u0430\u0442\u0440\u0438\u0432\u0430\u0442\u044c\n"
    + "\u043a\u0430\u043a \u0441\u0444\u0435\u0440\u0438\u0447\u0435\u0441\u043a\u0438\u0439 "
    + "\u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u0441\u0432\u0435\u0442\u0430.\n"
    + "\u0412 \u0441\u0440\u0435\u0434\u0435 2 \u044d\u0442\u0438 "
    + "\u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0430\u0440\u043d\u044b\u0435 "
    + "\u0432\u043e\u043b\u043d\u044b\n"
    + "\u0434\u0432\u0438\u0436\u0443\u0442\u0441\u044f "
    + "\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u0435\u0435, "
    + "\u043f\u043e\u0441\u043a\u043e\u043b\u044c\u043a\u0443\n"
    + "\u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044c "
    + "\u043f\u0440\u0435\u043b\u043e\u043c\u043b\u0435\u043d\u0438\u044f "
    + "\u0431\u043e\u043b\u044c\u0448\u0435."],
   
  [ // i == 4 (step == 2, total == false, eps1 > 0)
    // Durch �berlagerung der\\ Elementarwellen entstehen\\
    // neue, gerade Wellenfronten.\\ Im Medium 1 bildet sich eine\\
    // reflektierte Welle, im Medium\\ 2 dagegen eine gebrochene\\
    // Welle.
      "\u0412 \u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u0435 "
    + "\u043d\u0430\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0432\u0441\u0435\u0445\n"
    + "\u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0430\u0440\u043d\u044b\u0445 "
    + "\u0432\u043e\u043b\u043d \u0432\u043e\u0437\u043d\u0438\u043a\u0430\u0435\u0442\n"
    + "\u043d\u043e\u0432\u0430\u044f \u043f\u043b\u043e\u0441\u043a\u0430\u044f "
    + "\u0432\u043e\u043b\u043d\u0430.\n"
    + "\u0417\u0430\u043c\u0435\u0442\u0438\u043c, \u0447\u0442\u043e "
    + "\u043d\u0430\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 "
    + "\u0432\u0434\u043e\u043b\u044c\n"
    + "\u043a\u043e\u0442\u043e\u0440\u043e\u0433\u043e "
    + "\u0440\u0430\u0441\u043f\u0440\u043e\u0441\u0442\u0440\u0430\u043d\u044f\u0435\u0442\u0441\u044f "
    + "\u043f\u043b\u043e\u0441\u043a\u0430\u044f \n"
    + "\u0432\u043e\u043b\u043d\u0430 \u0438\u0437\u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f "
    + "\u043f\u0440\u0438 \u043f\u0435\u0440\u0435\u0445\u043e\u0434\u0435\n"
    + "\u0438\u0437 \u0441\u0440\u0435\u0434\u044b 1 \u0432 2."], 
   
  [ // i == 5 (step == 2, total == false, eps1 == 0)
    // Durch �berlagerung der\\ Elementarwellen entstehen\\
    // neue, gerade Wellenfronten.\\ Im Medium 1 bildet sich eine\\
    // reflektierte Welle, im Medium\\ 2 dagegen eine gebrochene\\
    // Welle.
      "\u0412 \u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u0435 "
    + "\u043d\u0430\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0432\u0441\u0435\u0445\n"
    + "\u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0430\u0440\u043d\u044b\u0445 "
    + "\u0432\u043e\u043b\u043d \u0432\u043e\u0437\u043d\u0438\u043a\u0430\u0435\u0442\n"
    + "\u043d\u043e\u0432\u0430\u044f \u043f\u043b\u043e\u0441\u043a\u0430\u044f "
    + "\u0432\u043e\u043b\u043d\u0430."],  
   
  [ // i == 6 (step == 2, total == true)
    // Durch �berlagerung der\\ Elementarwellen entsteht\\
    // im Medium 1 eine neue, gerade\\ Wellenfront (reflektierte Welle).\\
    // Im Medium 2 dagegen kommt\\ keine Wellenfront zustande\\
    // (Totalreflexion).
      "\u0412 \u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u0435 "
    + "\u043d\u0430\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0432\u0441\u0435\u0445\n"
    + "\u044d\u043b\u0435\u043c\u0435\u043d\u0442\u0430\u0440\u043d\u044b\u0445 "
    + "\u0432\u043e\u043b\u043d \u0432\u043e\u0437\u043d\u0438\u043a\u0430\u0435\u0442\n"
    + "\u043d\u043e\u0432\u0430\u044f \u043f\u043b\u043e\u0441\u043a\u0430\u044f "
    + "\u0432\u043e\u043b\u043d\u0430 \u0432 \u0441\u0440\u0435\u0434\u0435 1\n"
    + "(\u043e\u0442\u0440\u0430\u0436\u0435\u043d\u043d\u0430\u044f "
    + "\u0432\u043e\u043b\u043d\u0430).\n"
    + "\u0412\u043e\u043b\u043d\u0430 \u043d\u0435 \u043f\u0440\u043e\u0445\u043e\u0434\u0438\u0442 "
    + "\u0432 \u0441\u0440\u0435\u0434\u0443 2\n"
    + "(\u043f\u043e\u043b\u043d\u043e\u0435 \u0432\u043d\u0443\u0442\u0440\u0435\u043d\u043d\u0435\u0435 "
    + "\u043e\u0442\u0440\u0430\u0436\u0435\u043d\u0438\u0435)."], 
   
  [ // i == 7 (step == 3)
    // Zus�tzlich sind nun Wellen-\\ strahlen eingezeichnet, an\\
    // denen man die Richtung der\\ Wellenausbreitung erkennen\\
    // kann.
      "\u041d\u0430\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 "
    + "\u0440\u0430\u0441\u043f\u0440\u043e\u0441\u0442\u0440\u0430\u043d\u0435\u043d\u0438\u044f\n"
    + "\u0432\u043e\u043b\u043d\u044b "
    + "\u043f\u0435\u0440\u043f\u0435\u043d\u0434\u0438\u043a\u0443\u043b\u044f\u0440\u043d\u043e "
    + "\u043a \u0432\u043e\u043b\u043d\u043e\u0432\u043e\u043c\u0443 \n"
    + "\u0444\u0440\u043e\u043d\u0442\u0443.\n"
    + "\u042d\u0442\u0438 \u043b\u0438\u043d\u0438\u0438 \u0432 \u0434\u0430\u043d\u043d\u044b\u0439 "
    + "\u043c\u043e\u043c\u0435\u043d\u0442\n"
    + "\u043d\u0430\u0447\u0435\u0440\u0447\u0435\u043d\u044b."],
   
  [ // i == 8 (step == 4)
    // Eine Wellenfront kommt\\ selten allein.
      "\u0412\u043e\u043b\u043d\u043e\u0432\u043e\u0439 \u0444\u0440\u043e\u043d\u0442 "
    + "\u0440\u0435\u0434\u043a\u043e \u043f\u0440\u0438\u0445\u043e\u0434\u0438\u0442\n"
    + "\u043e\u0434\u0438\u043d!"],

  [ // i == 9 (n1 == n2)
    // Wenn die Brechungsindizes\\ �bereinstimmen, tut sich\\
    // nichts Besonderes.
      "\u0415\u0441\u043b\u0438 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044c "
    + "\u043f\u0440\u0435\u043b\u043e\u043c\u043b\u0435\u043d\u0438\u044f\n"
    + "\u043e\u0431\u0435\u0438\u0445 \u0441\u0440\u0435\u0434 "
    + "\u043e\u0434\u0438\u043d\u0430\u043a\u043e\u0432, \u0442\u043e "
    + "\u043e\u0442\u0440\u0430\u0436\u0435\u043d\u0438\u044f\n"
    + "\u043d\u0435 \u043f\u0440\u043e\u0438\u0441\u0445\u043e\u0434\u0438\u0442."]

  ];
          
var text08 = "\u0423\u0433\u043e\u043b \u043f\u0430\u0434\u0435\u043d\u0438\u044f:";     // Einfallswinkel
var text09 = "\u0423\u0433\u043e\u043b "                                                 // Reflexionswinkel (1)
           + "\u043e\u0442\u0440\u0430\u0436\u0435\u043d\u0438\u044f:";                  // Reflexionswinkel (2)
var text10 = "\u0423\u0433\u043e\u043b "                                                 // Brechungswinkel (1)
           + "\u043f\u0440\u0435\u043b\u043e\u043c\u043b\u0435\u043d\u0438\u044f:";      // Brechungswinkel (2)
var text11 = "\u0421\u0440\u0435\u0434\u0430 1";                                         // Medium 1
var text12 = "\u0421\u0440\u0435\u0434\u0430 2";                                         // Medium 2
var text13 = ["\u0423\u0433\u043e\u043b \u043f\u043e\u043b\u043d\u043e\u0433\u043e",     // Grenzwinkel der ...
             "\u0432\u043d\u0443\u0442\u0440\u0435\u043d\u043d\u0435\u0433\u043e "       // ... Totalreflexion (1)
           + "\u043e\u0442\u0440\u0430\u0436\u0435\u043d\u0438\u044f:"];                 // ... Totalreflexion (2)

// Einheiten:

var degreeUnicode = "\u00b0";                              // Grad
