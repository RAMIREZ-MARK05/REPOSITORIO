// Messung der Auftriebskraft, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u041f\u043b\u043e\u0449\u0430\u0434\u044c "                                         // Grundfl�che des Quaders (1)
  	       + "\u043e\u0441\u043d\u043e\u0432\u0430\u043d\u0438\u044f \u0442\u0435\u043b\u0430:";   // Grundfl�che des Quaders (2)
var text02 = "\u0412\u044b\u0441\u043e\u0442\u0430 \u0442\u0435\u043b\u0430:";                     // H�he des Quaders
var text03 = "\u041f\u043b\u043e\u0442\u043d\u043e\u0441\u0442\u044c \u0442\u0435\u043b\u0430:";   // Dichte des Quaders
var text04 = "\u041f\u043b\u043e\u0442\u043d\u043e\u0441\u0442\u044c "                             // Dichte der Fl�ssigkeit (1)
           + "\u0436\u0438\u0434\u043a\u043e\u0441\u0442\u0438:";                                  // Dichte der Fl�ssigkeit (2)
var text05 = "\u0413\u043b\u0443\u0431\u0438\u043d\u0430 "                                         // Eintauchtiefe (1)
           + "\u043f\u043e\u0433\u0440\u0443\u0436\u0435\u043d\u0438\u044f:";                      // Eintauchtiefe (2)
var text06 = "\u0412\u044b\u0442\u0435\u0441\u043d\u0435\u043d\u043d\u044b\u0439 "                 // Verdr�ngtes Volumen (1)
           + "\u043e\u0431\u044a\u0435\u043c:";                                                    // Verdr�ngtes Volumen (2)
var text07 = "\u0410\u0440\u0445\u0438\u043c\u0435\u0434\u043e\u0432\u0430 "                       // Auftriebskraft (1)
           + "\u0441\u0438\u043b\u0430:";                                                          // Auftriebskraft (2)
var text08 = "\u0412\u0435\u0441 \u0442\u0435\u043b\u0430:";                                       // Gewichtskraft
var text09 = "\u0418\u0437\u043c\u0435\u0440\u0435\u043d\u043d\u0430\u044f "                       // Gemessene Kraft (1)
           + "\u0441\u0438\u043b\u0430:";                                                          // Gemessene Kraft (2)
var text10 = "\u0414\u0438\u0430\u043f\u0430\u0437\u043e\u043d "                                   // Messbereich (1)
           + "\u0438\u0437\u043c\u0435\u0440\u0435\u043d\u0438\u0439:";                            // Messbereich (2)

var author = "W. Fendt 1998,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "\u0441\u043c";
var centimeter3 = "\u0441\u043c&sup3;";
var centimeter2 = "\u0441\u043c&sup2;";
var gramPerCentimeter3 = "\u0433/\u0441\u043c&sup3;";
var newton = "\u041d";                  

var text11 = "\u041f\u0440\u0435\u0432\u044b\u0448\u0435\u043d "               // Messbereich �berschritten (1)
           + "\u043c\u0430\u043a\u0441\u0438\u043c\u0443\u043c!";              // Messbereich �berschritten (2)
