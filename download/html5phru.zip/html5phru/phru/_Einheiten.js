// Physikalische Einheiten russisch

// Ampere:

var ampere = "\u0410";          
var milliampere = "\u043c\u0410";         
var microampere = "\u043c\u043a\u0410";

// Farad:

var microfarad = "\u043c\u043a\u0424";

// Henry:

var henry = "\u0413\u043d";

// Hertz:

var hertz = "\u0413\u0446"; 

// Joule:

var joule = "\u0414\u0436";

// Kelvin:

var kelvin = "\u041a";

// Kilogramm:

var kilogram = "\u043a\u0433"; 

// Meter:

var meter = "\u043C";
var decimeter = "\u0434\u043C";
var centimeter = "\u0441\u043C";

// Meter durch Sekunde:

var meterPerSecond = "\u043c/\u0441";

// Meter durch Sekunde hoch 2:

var meterPerSecond2 = "\u043c/\u0441\u00b2";

// Newton:

var newton = "\u041d";

// Ohm:

var ohm = "\u041e\u043c";

// Pascal:

var pascal = "\u041F\u0430";
var kiloPascal = "\u043A\u041F\u0430";

// Rad durch Sekunde:

var radPerSecond = "\u0440\u0430\u0434/\u0441";

// Sekunde:

var second = "\u0441";

// Volt:

var volt = "\u0412";                          
