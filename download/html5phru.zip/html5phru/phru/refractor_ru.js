// Kepler-Fernrohr, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0424\u043e\u043a\u0443\u0441\u043d\u043e\u0435 "               // Brennweiten (1)
           + "\u0440\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435:";  // Brennweiten (2)
var text02 = "\u041e\u0431\u044a\u0435\u043a\u0442\u0438\u0432:";              // Objektiv
var text03 = "\u041e\u043a\u0443\u043b\u044f\u0440:";                          // Okular
var text04 = "\u0423\u0433\u043e\u043b \u0437\u0440\u0435\u043d\u0438\u044f:"; // Sehwinkel
var text05 = "\u0423\u0432\u0435\u043b\u0438\u0447\u0435\u043d\u0438\u0435:";  // Vergr��erung

var author = "W. Fendt 2000";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "\u043c";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite
