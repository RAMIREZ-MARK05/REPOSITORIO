// Gleichstrom-Elektromotor, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";                                 // Zur�ck
var text02 = ["\u0421\u0442\u0430\u0440\u0442",                                // Start
             "\u041f\u0430\u0443\u0437\u0430",                                 // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text03 = "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0442\u043e\u043a";      // Umpolen
var text04 = "\u041d\u0430\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 "       // Stromrichtung (1)
           + "\u0442\u043e\u043a\u0430";                                                 // Stromrichtung (2)
var text05 = "\u041c\u0430\u0433\u043d\u0438\u0442\u043d\u043e\u0435 "                   // Magnetfeld (1)
           + "\u043f\u043e\u043b\u0435";                                                 // Magnetfeld (2)
var text06 = "\u0421\u0438\u043b\u0430 \u041b\u043e\u0440\u0435\u043d\u0446\u0430";      // Lorentzkraft

var author = "W. Fendt 1997";               
var translator = "\u041d\u0413\u0422\u0423 2010";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "U/min";                          // Umdrehungen pro Minute
