// Bewegung mit konstanter Beschleunigung, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u0421\u0431\u0440\u043e\u0441";             // Reset
var text02 = ["\u0421\u0442\u0430\u0440\u0442",            // Start 
             "\u041f\u0430\u0443\u0437\u0430",             // Pause 
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter
var text03 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "  // Zeitlupe (1)
  	       + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                    // Zeitlupe (2)
var text04 = "\u041d\u0430\u0447\u0430\u043b\u044c\u043d\u0430\u044f "    // Anfangsposition (1)
           + "\u043f\u043e\u0437\u0438\u0446\u0438\u044f:";               // Anfangsposition (2)
var text05 = "\u041d\u0430\u0447\u0430\u043b\u044c\u043d\u0430\u044f "    // Anfangsgeschwindigkeit (1)
           + "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c:";         // Anfangsgeschwindigkeit (2)
var text06 = "\u0423\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u0435:";   // Beschleunigung
var text07 = "\u0412\u0435\u043a\u0442\u043e\u0440 "                      // Geschwindigkeitsvektor (1)
           + "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438";          // Geschwindigkeitsvektor (2)
var text08 = "\u0412\u0435\u043a\u0442\u043e\u0440 "                      // Beschleunigungsvektor (1)
           + "\u0443\u0441\u043a\u043e\u0440\u0435\u043d\u0438\u044f";    // Beschleunigungsvektor (2)

var author = "W. Fendt 2000";
var translator = "\u041d\u0413\u0422\u0423 2010";

var text09 = "(\u0441)";                                   // Einheitenangabe f�r Zeit-Achse
var text10 = "(\u043c)";                                   // Einheitenangabe f�r Weg-Achse
var text11 = "(\u043c/\u0441)";                            // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(\u043c/\u0441\u00b2)";                      // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "\u0441";                                     // Sekunde
var meter = "\u043c";                                      // Meter
var meterPerSecond = "\u043c/\u0441";                      // Meter pro Sekunde
var meterPerSecond2 = "\u043c/\u0441\u00b2";               // Meter pro Sekunde hoch 2
