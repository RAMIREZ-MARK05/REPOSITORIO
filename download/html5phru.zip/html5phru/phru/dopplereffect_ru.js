// Beispiel zum Doppler-Effekt, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

var text01 = "\u0421\u0442\u0430\u0440\u0442";                                 // Zur�ck
var text02 = ["\u041f\u0430\u0443\u0437\u0430",                                // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter 

var author = "W. Fendt 1998";
var translator = "\u041d\u0413\u0422\u0423 2010";                 

var text03 = [                                        
             [ // Dadurch, dass sich der Notarztwagen der Person n�hert,
               // kommen die Wellenfronten in k�rzeren Zeitabst�nden an.
             " \u0415\u0441\u043b\u0438 \u0442\u0440\u0430\u043d\u0441\u043f\u043e\u0440\u0442\u043d\u043e\u0435 "
           + "\u0441\u0440\u0435\u0434\u0441\u0442\u0432\u043e\n"
           + " \u043f\u0440\u0438\u0431\u043b\u0438\u0436\u0430\u0435\u0442\u0441\u044f "
           + "\u043a \u0447\u0435\u043b\u043e\u0432\u0435\u043a\u0443, \u0442\u043e\n"
           + " \u0438\u043d\u0442\u0435\u0440\u0432\u0430\u043b\u044b "
           + "\u043c\u0435\u0436\u0434\u0443 \u043f\u0440\u0438\u0445\u043e\u0434\u044f\u0449\u0438\u043c\u0438\n"
           + " \u0432\u043e\u043b\u043d\u043e\u0432\u044b\u043c\u0438 \u0444\u0440\u043e\u043d\u0442\u0430\u043c\u0438 "
           + "\u043a\u043e\u0440\u043e\u0442\u043a\u0438\u0435."],
             [ // Wenn sich das Fahrzeug von der Person entfernt,
               // sind die zeitlichen Abst�nde zwischen den eintreffenden
               // Wellenfronten verl�ngert.
             " \u0422\u0435\u043f\u0435\u0440\u044c \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044c "
           + "\u043f\u0440\u043e\u0435\u0445\u0430\u043b\n"
           + " \u043c\u0438\u043c\u043e \u0447\u0435\u043b\u043e\u0432\u0435\u043a\u0430. "
           + "\u0418\u043d\u0442\u0435\u0440\u0432\u0430\u043b\u044b \u043c\u0435\u0436\u0434\u0443\n"
           + " \u0432\u043e\u043b\u043d\u043e\u0432\u044b\u043c\u0438 \u0444\u0440\u043e\u043d\u0442\u0430\u043c\u0438,\n"
           + " \u0434\u043e\u0441\u0442\u0438\u0433\u0430\u044e\u0449\u0438\u043c\u0438 "
           + "\u0447\u0435\u043b\u043e\u0432\u0435\u043a\u0430,\n"
           + " \u0443\u0432\u0435\u043b\u0438\u0447\u0438\u043b\u0438\u0441\u044c."]
             ];
  

