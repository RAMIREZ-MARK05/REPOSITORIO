// Spezielle Prozesse eines idealen Gases, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 18.10.2019

var text01 = "\u0418\u0437\u043e\u0431\u0430\u0440\u0438\u0447\u0435\u0441\u043a\u0438\u0439 "     // Isobare Zustands�nderung
           + "\u043f\u0440\u043e\u0446\u0435\u0441\u0441";
var text02 = "\u0418\u0437\u043e\u0445\u043e\u0440\u0438\u0447\u0435\u0441\u043a\u0438\u0439 "     // Isochore Zustands�nderung
           + "\u043f\u0440\u043e\u0446\u0435\u0441\u0441";
var text03 = "\u0418\u0437\u043e\u0442\u0435\u0440\u043c\u0438\u0447\u0435\u0441\u043a\u0438\u0439 "  // Isotherme Zustands�nderung
           + "\u043f\u0440\u043e\u0446\u0435\u0441\u0441";
var text04 = "\u041d\u0430\u0447\u0430\u043b\u044c\u043d\u043e\u0435 "                             // Anfangszustand
           + "\u0441\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435:";
var text05 = "\u0414\u0430\u0432\u043b\u0435\u043d\u0438\u0435:";                                  // Druck
var text06 = "\u041e\u0431\u044a\u0435\u043c:";                                                    // Volumen
var text07 = "\u0422\u0435\u043c\u043f\u0435\u0440\u0430\u0442\u0443\u0440\u0430:";                // Temperatur
var text08 = "\u041a\u043e\u043d\u0435\u0447\u043d\u043e\u0435 "                                   // Endzustand
           + "\u0441\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435";
var text09 = "\u041d\u0430\u0447\u0430\u043b\u044c\u043d\u043e\u0435 "                             // Anfangszustand
           + "\u0441\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435";
var text10 = "\u0421\u0442\u0430\u0440\u0442";                                                     // Start

var author = "W. Fendt 1999,&nbsp; \u041d\u0413\u0422\u0423 2010";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var text11 = "\u0440\u0430\u0431\u043e\u0442\u0430";                                               // Arbeit
var text12 = "\u0442\u0435\u043f\u043b\u043e\u0442\u0430";                                         // W�rme
var text13 = "\u0412\u043d\u0443\u0442\u0440\u0435\u043d\u043d\u044f\u044f "                       // Die innere Energie des Gases ...
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f \u0433\u0430\u0437\u0430";
var text14 = "\u0443\u0432\u0435\u043b\u0438\u0447\u0438\u0432\u0430\u0435\u0442\u0441\u044f.";    // ... vergr��ert sich
var text15 = "\u0412\u043d\u0443\u0442\u0440\u0435\u043d\u043d\u044f\u044f "                       // Die innere Energie des Gases ...
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f \u0433\u0430\u0437\u0430";
var text16 = "\u043f\u043e\u0441\u0442\u043e\u044f\u043d\u043d\u0430.";                            // ... ist konstant
var text17 = "\u0412\u043d\u0443\u0442\u0440\u0435\u043d\u043d\u044f\u044f "                       // Die innere Energie des Gases ...
           + "\u044d\u043d\u0435\u0440\u0433\u0438\u044f \u0433\u0430\u0437\u0430";
var text18 = "\u0443\u043c\u0435\u043d\u044c\u0448\u0430\u0435\u0442\u0441\u044f.";                // ... verkleinert sich
var text19 = "\u0414\u0430\u0432\u043b\u0435\u043d\u0438\u0435 "                                   // Druck zu klein
           + "\u0441\u043b\u0438\u0448\u043a\u043e\u043c \u043c\u0430\u043b\u043e!";
var text20 = "\u0414\u0430\u0432\u043b\u0435\u043d\u0438\u0435 "                                   // Druck zu gro�
           + "\u0441\u043b\u0438\u0448\u043a\u043e\u043c \u0432\u0435\u043b\u0438\u043a\u043e!";
var text21 = "\u041e\u0431\u044a\u0435\u043c "                                                     // Volumen zu klein
           + "\u0441\u043b\u0438\u0448\u043a\u043e\u043c \u043c\u0430\u043b\u043e!";
var text22 = "\u041e\u0431\u044a\u0435\u043c "                                                     // Volumen zu gro�
           + "\u0441\u043b\u0438\u0448\u043a\u043e\u043c \u0432\u0435\u043b\u0438\u043a\u043e!";
var text23 = "\u0422\u0435\u043c\u043f\u0435\u0440\u0430\u0442\u0443\u0440\u0430 "                 // Temperatur zu klein
           + "\u0441\u043b\u0438\u0448\u043a\u043e\u043c \u043c\u0430\u043b\u0430!";
var text24 = "\u0422\u0435\u043c\u043f\u0435\u0440\u0430\u0442\u0443\u0440\u0430 "                 // Temperatur zu gro�
           + "\u0441\u043b\u0438\u0448\u043a\u043e\u043c \u0432\u0435\u043b\u0438\u043a\u0430!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "\u043A\u041F\u0430";
var decimeter3 = "\u0434\u043C\u00B3";
var kelvin = "\u041A";


