// Kettenkarussell, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 28.12.2017

var text01 = "\u041a\u0430\u0440\u0443\u0441\u0435\u043b\u044c";               // Karussell
var text02 = "\u041a\u0430\u0440\u0443\u0441\u0435\u043b\u044c \u0441 "        // Karussell mit Kr�ften (1)
  	       + "\u0441\u0438\u043b\u0430\u043c\u0438";                           // Karussell mit Kr�ften (2)
var text03 = "\u0421\u0445\u0435\u043c\u0430 \u0441\u0438\u043b";              // Skizze
var text04 = "\u0427\u0438\u0441\u043b\u043e\u0432\u044b\u0435 "               // Zahlenwerte (1)
  	       + "\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u044f";               // Zahlenwerte (2)
var text05 = ["\u041f\u0430\u0443\u0437\u0430",                                // Pause
              "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"]; // Weiter
var text06 = "\u0417\u0430\u043c\u0435\u0434\u043b\u0435\u043d\u043d\u043e\u0435 "       // Zeitlupe (1)
  	       + "\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435";                         // Zeitlupe (2)
var text07 = "\u041f\u0435\u0440\u0438\u043e\u0434:";                          // Umlaufzeit
var text08 = ["\u0420\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435 "                      // Abstand der Aufh�ngungen (1)
           + "\u043c\u0435\u0436\u0434\u0443 \u0433\u0440\u0443\u0437\u0430\u043c\u0438",          // Abstand der Aufh�ngungen (2)
             "\u0438 \u043e\u0441\u044c\u044e \u0432\u0440\u0430\u0449\u0435\u043d\u0438\u044f:"]; // von der Drehachse
var text09 = "\u0414\u043b\u0438\u043d\u0430 \u043d\u0438\u0442\u0438:";       // Fadenl�nge
var text10 = "\u041c\u0430\u0441\u0441\u0430 \u0433\u0440\u0443\u0437\u0430:"; // Masse

var author = "W. Fendt 1999,&nbsp; \u041d\u0413\u0422\u0423 2010";

var text11 = "\u0427\u0430\u0441\u0442\u043e\u0442\u0430:";                    // Frequenz
var text12 = "\u0423\u0433\u043b\u043e\u0432\u0430\u044f "                     // Winkelgeschwindigkeit (1)
  	       + "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c:";              // Winkelgeschwindigkeit (2)
var text13 = "\u0420\u0430\u0434\u0438\u0443\u0441:";                          // Radius
var text14 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c:";              // Geschwindigkeit
var text15 = "\u0423\u0433\u043e\u043b:";                                      // Winkel
var text16 = "\u0412\u0435\u0441:";                                            // Gewichtskraft
var text17 = "\u0426\u0435\u043d\u0442\u0440\u043e\u0441\u0442\u0440\u0435\u043c\u0438"   // Zentripetalkraft (1)
  	       + "\u0442\u0435\u043b\u044c\u043d\u0430\u044f \u0441\u0438\u043b\u0430:";      // Zentripetalkraft (2)
var text18 = "\u041d\u0430\u0442\u044f\u0436\u0435\u043d\u0438\u0435 "         // Belastung des Fadens (1)
           + "\u043d\u0438\u0442\u0438:";                                      // Belastung des Fadens (2)

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "\u0441";
var meter = "\u043c";
var kilogram = "\u043a\u0433";
var hertz = "\u0413\u0446";
var radPerSecond = "\u0440\u0430\u0434/\u0441";
var meterPerSecond = "\u043c/\u0441";
var degree = "\u00b0";
var newton = "\u041d";




