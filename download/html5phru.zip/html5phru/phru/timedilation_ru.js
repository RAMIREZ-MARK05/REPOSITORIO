// Beispiel zur Zeitdilatation, russische Texte (Technische Universit�t Nowosibirsk)
// Letzte �nderung 30.12.2017

// Texte in HTML-Schreibweise:

var text01 = "\u0421\u043d\u0438\u0437\u0438\u0442\u044c "                     // Geschwindigkeit verkleinern (1)
           + "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c";               // Geschwindigkeit verkleinern (2)
var text02 = "\u041f\u043e\u0432\u044b\u0441\u0438\u0442\u044c "               // Geschwindigkeit vergr��ern (1)
           + "\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c";               // Geschwindigkeit vergr��ern (2)
var text03 = "\u0421\u0431\u0440\u043e\u0441";                                 // Zur�ck
var text04 = ["\u0421\u0442\u0430\u0440\u0442",                                // Start
             "\u041f\u0430\u0443\u0437\u0430",                                 // Pause
             "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"];  // Weiter

var author = "W. Fendt 1997,&nbsp; \u041d\u0413\u0422\u0423 2010";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "\u0420\u0430\u0441\u0441\u0442\u043e\u044f\u043d\u0438\u0435:";  // Flugstrecke
var text06 = "5 \u0441\u0432\u0435\u0442\u043e\u0432\u044b\u0445 "             // 5 Lichtstunden (1)
           + "\u0447\u0430\u0441\u043e\u0432";                                 // 5 Lichtstunden (2)
var text07 = "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c:";              // Geschwindigkeit
var text08 = "\u0412\u0440\u0435\u043c\u044f \u043f\u043e\u043b\u0435\u0442\u0430 "      // Flugzeit im Erd-System (1)
           + "\u0432 \u0441\u0438\u0441\u0442\u0435\u043c\u0435 "                        // Flugzeit im Erd-System (2)
           + "\u0417\u0435\u043c\u043b\u0438:";                                          // Flugzeit im Erd-System (3)
var text09 = "\u0447\u0430\u0441\u0430";                                                 // Stunden
var text10 = "\u0412\u0440\u0435\u043c\u044f \u043f\u043e\u043b\u0435\u0442\u0430 "      // Flugzeit im Raketen-System (1)
           + "\u0432 \u0441\u0438\u0441\u0442\u0435\u043c\u0435 "                        // Flugzeit im Raketen-System (2)
           + "\u0440\u0430\u043a\u0435\u0442\u044b:";                                    // Flugzeit im Raketen-System (3)