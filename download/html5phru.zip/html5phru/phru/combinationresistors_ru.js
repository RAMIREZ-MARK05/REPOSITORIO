// Kombinationen von Widerst�nden, russische Texte
// Letzte �nderung 19.02.2020

// Texte in HTML-Schreibweise:

var text01 = "\u0421\u0431\u0440\u043e\u0441";                                  // Reset
var text02 = "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 "
  	       + "\u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u0430:";         // Spannung der Batterie
var text03 = "\u0421\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435:";    // Widerstand
var text04 = "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0440\u0435\u0437\u0438\u0441\u0442\u043e\u0440 "
           + "(\u041f\u043e\u0441\u043b\u0435\u0434\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u043d\u043e)";
// text04: Widerstand hinzuf�gen (in Serie)
var text05 = "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0440\u0435\u0437\u0438\u0441\u0442\u043e\u0440 "
           + "(\u041f\u0430\u0440\u0430\u043b\u043b\u0435\u043b\u044c\u043d\u043e)";
// text05: Widerstand hinzuf�gen (parallel)
var text06 = "\u0418\u0437\u043c\u0435\u0440\u044f\u0442\u044c:";              // Messger�te
var text07 = "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435";   // Spannung
var text08 = "\u0421\u0438\u043b\u0430 \u0442\u043e\u043a\u0430";              // Stromst�rke

var author = "W. Fendt 2002";
var translator = "\u041d\u0413\u0422\u0423 2010";

// Texte in Unicode-Schreibweise:

var text09 = "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435:";  // Spannung
var text10 = "\u0421\u0438\u043b\u0430 \u0442\u043e\u043a\u0430:";             // Stromst�rke
var text11 = "\u0421\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435:";    // Widerstand
var text12 = "\u042d\u043a\u0432\u0438\u0432\u0430\u043b\u0435\u043d\u0442\u043d\u043e\u0435 "
  	       + "\u0441\u043e\u043f\u0440\u043e\u0442\u0438\u0432\u043b\u0435\u043d\u0438\u0435:";
// text12: Ersatzwiderstand
var text13 = "\u043e\u0447\u0435\u043d\u044c \u043c\u0430\u043b\u043e";        // sehr klein
var text14 = "\u043e\u0447\u0435\u043d\u044c \u043c\u043d\u043e\u0433\u043e";  // sehr gro�

var volt = "\u0412";
var ampere = "\u0410";
var ohm = "\u041e\u043c";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

