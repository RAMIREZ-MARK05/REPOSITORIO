// Generator, griechische Texte
// Letzte �nderung 27.01.2022

// Texte in HTML-Schreibweise;

var text01 = "&Chi;&omega;&rho;&#943;&sigmaf; "                                                    // Ohne Kommutator (1)
           + "&mu;&epsilon;&tau;&alpha;&gamma;&omega;&gamma;&#942;";                               // Ohne Kommutator (2)
var text02 = "&Mu;&epsilon; &mu;&epsilon;&tau;&alpha;&gamma;&omega;&gamma;&#942;";                 // Mit Kommutator
var text03 = "&Alpha;&lambda;&lambda;&alpha;&gamma;&#942; "                                        // Umgekehrte Richtung (1)
           + "&kappa;&alpha;&tau;&epsilon;&#973;&theta;&upsilon;&nu;&sigma;&eta;&sigmaf;";         // Umgekehrte Richtung (2)
var text04 = ["Start",                                                                             // Start (nicht ben�tigt)
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter
var text05 = "&Kappa;&alpha;&tau;&epsilon;&#973;&theta;&upsilon;&nu;&sigma;&eta; "                 // Bewegungsrichtung (1)
           + "&kappa;&#943;&nu;&eta;&sigma;&eta;&sigmaf;";                                         // Bewegungsrichtung (2)
var text06 = "&Mu;&alpha;&gamma;&nu;&eta;&tau;&iota;&kappa;&#972; "                                // Magnetfeld (1)
           + "&pi;&epsilon;&delta;&#943;&omicron;";                                                // Magnetfeld (2)
var text07 = "&Epsilon;&pi;&alpha;&gamma;&#972;&mu;&epsilon;&nu;&omicron; "                        // Induzierter Strom (1)
           + "&rho;&epsilon;&#973;&mu;&alpha;";                                                    // Induzierter Strom (2)

var author = "W. Fendt 1998";  
var translator = "NHRF 2000";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "&sigma;&tau;&rho;&omicron;&phi;&#941;&sigmaf;/min";                      // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
