// Schiefer Wurf, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";                    
var text02 = ["&#904;&nu;&alpha;&rho;&xi;&eta;", 
              "&Pi;&alpha;&#973;&sigma;&eta;", 
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];          
var text03 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";
var text04 = "&#910;&psi;&omicron;&sigmaf; &epsilon;&kappa;&tau;&#972;&xi;&epsilon;&upsilon;&sigma;&eta;&sigmaf;:";
var text05 = "&Tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha; &epsilon;&kappa;&tau;&#972;&xi;&epsilon;&upsilon;&sigma;&eta;&sigmaf;:";
var text06 = "&Gamma;&omega;&nu;&#943;&alpha; &beta;&omicron;&lambda;&#942;&sigmaf;:";
var text07 = "&Mu;&#940;&zeta;&alpha;:"; 
var text08 = "&Epsilon;&pi;&iota;&tau;&#940;&chi;&upsilon;&nu;&sigma;&eta; "
           + "&tau;&eta;&sigmaf; &beta;&alpha;&rho;&#973;&tau;&eta;&tau;&alpha;&sigmaf;:";
var text09 = "&Theta;&#941;&sigma;&eta;";
var text10 = "&Tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;";
var text11 = "&Epsilon;&pi;&iota;&tau;&#940;&chi;&upsilon;&nu;&sigma;&eta;";
var text12 = "&Delta;&#973;&nu;&alpha;&mu;&eta;";
var text13 = "&Epsilon;&nu;&#941;&rho;&gamma;&epsilon;&iota;&alpha;";

var author = "W. Fendt 2000,&nbsp; &Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                           
var meterPerSecond = "m/s";                                
var meterPerSecond2 = "m/s&sup2;";                        
var kilogram = "kg";                                       
var degree = "&deg;";                                  

// Texte in Unicode-Schreibweise:

var text14 = "(\u03c3\u03b5 m)";                          
var text15 = "\u0398\u03ad\u03c3\u03b7:";
var text16 = "(\u03bf\u03c1\u03b9\u03b6\u03cc\u03bd\u03c4\u03b9\u03b1)"; 
var text17 = "(\u03ba\u03b1\u03c4\u03b1\u03ba\u03cc\u03c1\u03c5\u03c6\u03b1)"; 
var text18 = "\u039f\u03c1\u03b9\u03b6\u03cc\u03bd\u03c4\u03b9\u03b1 \u03b1\u03c0\u03cc\u03c3\u03c4\u03b1\u03c3\u03b7:"; 
var text19 = "\u039c\u03ad\u03b3\u03b9\u03c3\u03c4\u03bf \u03cd\u03c8\u03bf\u03c2:"; 
var text20 = "\u03a7\u03c1\u03cc\u03bd\u03bf\u03c2 \u03ba\u03af\u03bd\u03b7\u03c3\u03b7\u03c2:"; 
var text21 = "\u03a3\u03c5\u03bd\u03b9\u03c3\u03c4\u03ce\u03c3\u03b5\u03c2 \u03c4\u03b1\u03c7\u03cd\u03c4\u03b7\u03c4\u03b1\u03c2:";
var text22 = "\u039c\u03ad\u03c4\u03c1\u03bf \u03c4\u03b1\u03c7\u03cd\u03c4\u03b7\u03c4\u03b1\u03c2:"; 
var text23 = "\u0393\u03c9\u03bd\u03af\u03b1:"; 
var text24 = "\u0395\u03c0\u03b9\u03c4\u03ac\u03c7\u03c5\u03bd\u03c3\u03b7:"; 
var text25 = "\u0394\u03cd\u03bd\u03b1\u03bc\u03b7:"; 
var text26 = "\u039a\u03b9\u03bd\u03b7\u03c4\u03b9\u03ba\u03ae \u03b5\u03bd\u03ad\u03c1\u03b3\u03b5\u03b9\u03b1:"; 
var text27 = "\u0394\u03c5\u03bd\u03b1\u03bc\u03b9\u03ba\u03ae \u03b5\u03bd\u03ad\u03c1\u03b3\u03b5\u03b9\u03b1:";
var text28 = "\u039f\u03bb\u03b9\u03ba\u03ae \u03b5\u03bd\u03ad\u03c1\u03b3\u03b5\u03b9\u03b1:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                                    
var secondUnicode = "s";                                   
var meterPerSecondUnicode = "m/s";                         
var meterPerSecond2Unicode = "m/s\u00b2";                  
var newtonUnicode = "N";                                   
var jouleUnicode = "J";                                    
var degreeUnicode = "\u00b0";                              



