// Newtons Wiege, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";
var text02 = "&#904;&nu;&alpha;&rho;&xi;&eta;";
var text03 = "&Pi;&lambda;&#942;&theta;&omicron;&sigmaf; &kappa;&iota;&nu;&omicron;&#973;&mu;&epsilon;&nu;&omega;&nu; "
           + "&sigma;&phi;&alpha;&iota;&rho;&#974;&nu;:";

var author = "W. Fendt 1997";
var translator = "&Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";
