// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "2 &tau;&rho;&omicron;&chi;&alpha;&lambda;&#943;&epsilon;&sigmaf;";
var text02 = "4 &tau;&rho;&omicron;&chi;&alpha;&lambda;&#943;&epsilon;&sigmaf;";
var text03 = "6 &tau;&rho;&omicron;&chi;&alpha;&lambda;&#943;&epsilon;&sigmaf;"; 
var text04 = "&Beta;&#940;&rho;&omicron;&sigmaf; &alpha;&nu;&alpha;&rho;&tau;&eta;&mu;&#941;&nu;&omicron;&upsilon; " 
           + "&sigma;&#974;&mu;&alpha;&tau;&omicron;&sigmaf;:"; 
var text05 = "&Beta;&#940;&rho;&omicron;&sigmaf; &alpha;&nu;&alpha;&rho;&tau;&eta;&mu;&#941;&nu;&eta;&sigmaf;(&omega;&nu;) "
           + "&tau;&rho;&omicron;&chi;&alpha;&lambda;&#943;&alpha;&sigmaf;(&#974;&nu;):"; 
var text06 = "&Alpha;&pi;&alpha;&iota;&tau;&omicron;&#973;&mu;&epsilon;&nu;&eta; &delta;&#973;&nu;&alpha;&mu;&eta;:"; 
var text07 = "&Delta;&upsilon;&nu;&alpha;&mu;&#972;&mu;&epsilon;&tau;&rho;&omicron;";
var text08 = "&Delta;&iota;&alpha;&nu;&#973;&sigma;&mu;&alpha;&tau;&alpha; &delta;&upsilon;&nu;&#940;&mu;&epsilon;&omega;&nu;";

var author = "W. Fendt 1998";
var translator = "&Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = "&divide;";                           // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                    
