// Einfache Wechselstromkreise, griechische Texte
// Letzte �nderung 31.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Alpha;&nu;&tau;&iota;&sigma;&tau;&#940;&tau;&eta;&sigmaf;";                         // Widerstand
var text02 = "&Pi;&upsilon;&kappa;&nu;&omega;&tau;&#942;&sigmaf;"                                  // Kondensator
var text03 = "&Pi;&eta;&nu;&#943;&omicron;";                                                       // Spule
var text04 = "&Epsilon;&pi;&alpha;&nu;&epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;";         // Zur�ck
var text05 = ["&#904;&nu;&alpha;&rho;&xi;&eta;",                                                   // Start 
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter          
var text06 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";                       // Zeitlupe
var text07 = "&Sigma;&upsilon;&chi;&nu;&#972;&tau;&eta;&tau;&alpha;:";                             // Frequenz
var text08 = "&Mu;&#941;&gamma;&iota;&sigma;&tau;&eta; &tau;&#940;&sigma;&eta;:";                  // Max. Spannung
var text09 = "&Alpha;&nu;&tau;&#943;&sigma;&tau;&alpha;&sigma;&eta;:";                             // Widerstand                            
var text10 = "&Chi;&omega;&rho;&eta;&tau;&iota;&kappa;&#972;&tau;&eta;&tau;&alpha;:";              // Kapazit�t                     
var text11 = "&Alpha;&upsilon;&tau;&epsilon;&pi;&alpha;&gamma;&omega;&gamma;&#942;:";              // Induktivit�t
var text12 = "&Mu;&#941;&gamma;&iota;&sigma;&tau;&omicron; &rho;&epsilon;&#973;&mu;&alpha;:";      // Max. Stromst�rke 

var author = "W. Fendt 1998,&nbsp; NHRF 2000";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                          // Hertz
var volt = "V";                                            // Volt
var ampere = "A";                                          // Ampere
var milliampere = "mA";                                    // Milliampere
var microampere = "&mu;A";                                 // Mikroampere
var ohm = "&Omega;";                                       // Ohm
var microfarad = "&mu;F";                                  // Mikrofarad
var henry = "H";                                           // Henry

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
