// Bewegung mit konstanter Beschleunigung, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;";         // Zur�ck
var text02 = ["&#904;&nu;&alpha;&rho;&xi;&eta;",                                                   // Start 
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter
var text03 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";                       // Zeitlupe
var text04 = "&Alpha;&rho;&chi;&iota;&kappa;&#942; &theta;&#941;&sigma;&eta;:";                    // Anfangsposition
var text05 = "&Alpha;&rho;&chi;&iota;&kappa;&#942; &tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;:";// Anfangsgeschwindigkeit
var text06 = "&Epsilon;&pi;&iota;&tau;&#940;&chi;&upsilon;&nu;&sigma;&eta;:";                      // Beschleunigung
var text07 = "&Delta;&iota;&#940;&nu;&upsilon;&sigma;&mu;&alpha; "                                 // Geschwindigkeitsvektor (1)
           + "&tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;&sigmaf;";                              // Geschwindigkeitsvektor (2)
var text08 = "&Delta;&iota;&#940;&nu;&upsilon;&sigma;&mu;&alpha; "                                 // Beschleunigungsvektor (1)
           + "&epsilon;&pi;&iota;&tau;&#940;&chi;&upsilon;&nu;&sigma;&eta;&sigmaf;";               // Beschleunigungsvektor (2)

var author = "W. Fendt 2000";
var translator = "&Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

// Texte in Unicode-Schreibweise:

var text09 = "(\u03C3\u03B5 s)";                           // Einheitenangabe f�r Zeit-Achse
var text10 = "(\u03C3\u03B5 m)";                           // Einheitenangabe f�r Weg-Achse
var text11 = "(\u03C3\u03B5 m/s)";                         // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(\u03C3\u03B5 m/s\u00b2)";                   // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                          // Sekunde
var meter = "m";                                           // Meter
var meterPerSecond = "m/s";                                // Meter pro Sekunde
var meterPerSecond2 = "m/s\u00b2";                         // Meter pro Sekunde hoch 2
