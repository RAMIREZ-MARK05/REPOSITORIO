// Zerfallsreihen, griechische Texte
// Letzte �nderung 29.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Sigma;&epsilon;&iota;&rho;&#940; "                                                  // Zerfallsreihe (1)
           + "&delta;&iota;&#940;&sigma;&pi;&alpha;&sigma;&eta;&sigmaf;:";                         // Zerfallsreihe (2)
var text03 = "&Epsilon;&pi;&#972;&mu;&epsilon;&nu;&eta; "                                          // N�chster Zerfall (1)
           + "&delta;&iota;&#940;&sigma;&pi;&alpha;&sigma;&eta;";                                  // N�chster Zerfall (2)
// N&auml;chster Zerfall

var author = "W. Fendt 1998"; 
var translator = "NHRF 2000";

// Texte in Unicode-Schreibweise:

var text02 = ["\u03A3\u03B5\u03B9\u03C1\u03AC \u0398\u03BF\u03C1\u03AF\u03BF\u03C5",               // Thorium-Reihe
              "\u03A3\u03B5\u03B9\u03C1\u03AC "                                                    // Neptunium-Reihe (1)
            + "\u03A0\u03BF\u03C3\u03B5\u03B9\u03B4\u03C9\u03BD\u03AF\u03BF\u03C5",                // Neptunium-Reihe (2)
              "\u03A3\u03B5\u03B9\u03C1\u03AC "                                                    // Uran-Radium-Reihe (1)
            + "\u039F\u03C5\u03C1\u03B1\u03BD\u03AF\u03BF\u03C5-"                                  // Uran-Radium-Reihe (2)
            + "\u03A1\u03B1\u03B4\u03AF\u03BF\u03C5",                                              // Uran-Radium-Reihe (3)
              "\u03A3\u03B5\u03B9\u03C1\u03AC "                                                    // Uran-Actinium-Reihe (1)
            + "\u039F\u03C5\u03C1\u03B1\u03BD\u03AF\u03BF\u03C5-"                                  // Uran-Actinium-Reihe (2)
            + "\u0391\u03BA\u03C4\u03B9\u03BD\u03AF\u03BF\u03C5"];                                 // Uran-Actinium-Reihe (3)      





