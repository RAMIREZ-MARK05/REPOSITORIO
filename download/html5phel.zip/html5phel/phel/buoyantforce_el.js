// Messung der Auftriebskraft, griechische Texte
// Letzte �nderung 30.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&mu;&beta;&alpha;&delta;&#972; &beta;&#940;&sigma;&eta;&sigmaf; "           // Grundfl�che des Quaders (1)
           + "&sigma;&#974;&mu;&alpha;&tau;&omicron;&sigmaf;:";                                    // Grundfl�che des Quaders (2)
var text02 = "&#910;&psi;&omicron;&sigmaf; &sigma;&#974;&mu;&alpha;&tau;&omicron;&sigmaf;:";       // H�he des Quaders
var text03 = "&Pi;&upsilon;&kappa;&nu;&#972;&tau;&eta;&tau;&alpha; "                               // Dichte des Quaders (1)
           + "&sigma;&#974;&mu;&alpha;&tau;&omicron;&sigmaf;:";                                    // Dichte des Quaders (2)
var text04 = "&Pi;&upsilon;&kappa;&nu;&#972;&tau;&eta;&tau;&alpha; "                               // Dichte der Fl�ssigkeit (1)
           + "&upsilon;&gamma;&rho;&omicron;&#973;:";                                              // Dichte der Fl�ssigkeit (2)
var text05 = "&#902;&nu;&omicron;&delta;&omicron;&sigmaf; "                                        // Eintauchtiefe (1)
           + "&sigma;&tau;&#940;&theta;&mu;&eta;&sigmaf;:";                                        // Eintauchtiefe (2)
var text06 = "&#908;&gamma;&kappa;&omicron;&sigmaf; "                                              // Verdr�ngtes Volumen (1)
           + "&epsilon;&kappa;&tau;&omicron;&pi;&#943;&sigma;&mu;&alpha;&tau;&omicron;&sigmaf;:";  // Verdr�ngtes Volumen (2)
var text07 = "&#902;&nu;&omega;&sigma;&eta;:";                                                     // Auftriebskraft
var text08 = "&Beta;&#940;&rho;&omicron;&sigmaf; &sigma;&#974;&mu;&alpha;&tau;&omicron;&sigmaf;:"; // Gewichtskraft
var text09 = "&Mu;&epsilon;&tau;&rho;&omicron;&#973;&mu;&epsilon;&nu;&eta; "                       // Gemessene Kraft (1)
           + "&delta;&#973;&nu;&alpha;&mu;&eta;:";                                                 // Gemessene Kraft (2)
var text10 = "&Epsilon;&#973;&rho;&omicron;&sigmaf; "                                              // Messbereich (1)
           + "&mu;&#941;&tau;&rho;&eta;&sigma;&eta;&sigmaf;:";                                     // Messbereich (2)

var author = "W. Fendt 1998,&nbsp; NHRF 2000";                                                     // Autor (und �bersetzer)

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "\u03A5\u03C0\u03AD\u03C1\u03B2\u03B1\u03C3\u03B7 \u03C4\u03BF\u03C5 "                // Messbereich �berschritten (1)
           + "\u03B5\u03CD\u03C1\u03BF\u03C5\u03C2 "                                               // Messbereich �berschritten (2)
           + "\u03BC\u03AD\u03C4\u03C1\u03B7\u03C3\u03B7\u03C2!";                                  // Messbereich �berschritten (3)
