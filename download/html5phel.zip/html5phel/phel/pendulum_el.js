// Fadenpendel, griechische Texte
// Letzte �nderung 26.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";                           // Zur�ck
var text02 = ["&Epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;",                                // Start 
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter
var text03 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";                       // Zeitlupe
var text04 = "&Mu;&#942;&kappa;&omicron;&sigmaf;:";                                                // (Pendel-)L�nge
// Falls n�tig, Variable text05x f�r zus�tzliche Zeile!
var text05x = "&Epsilon;&pi;&iota;&tau;&#940;&chi;&upsilon;&nu;&sigma;&eta;";                      // Fallbeschleunigung (1)
var text05 = "&tau;&eta;&sigmaf; &beta;&alpha;&rho;&#973;&tau;&eta;&tau;&alpha;&sigmaf;:";         // Fallbeschleunigung (2)
var text06 = "&Mu;&#940;&zeta;&alpha;:";                                                           // Masse
var text07 = "&Epsilon;&#973;&rho;&omicron;&sigmaf; "                                              // Amplitude (1)
           + "&tau;&alpha;&lambda;&#940;&nu;&tau;&omega;&sigma;&eta;&sigmaf;:";                    // Amplitude (2)
var text08 = "&Mu;&#942;&kappa;&omicron;&sigmaf; &tau;&#972;&xi;&omicron;&upsilon;";               // Elongation
var text09 = "&Tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;";                                      // Geschwindigkeit
var text10 = "&Epsilon;&pi;&iota;&tau;&#940;&chi;&upsilon;&nu;&sigma;&eta;";                       // Beschleunigung
var text11 = "&Delta;&#973;&nu;&alpha;&mu;&eta;";                                                  // Kraft
var text12 = "&Epsilon;&nu;&#941;&rho;&gamma;&epsilon;&iota;&alpha;";                              // Energie

var author = "W. Fendt 1998";                                                                      // Autor (und �bersetzer)

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)

var meter = "m";                                                                                   // Meter
var meterPerSecond2 = "m/s&sup2;";                                                                 // Meter pro Sekunde hoch 2
var kilogram = "kg";                                                                               // Kilogramm
var degree = "&deg;";                                                                              // Grad

// Texte in Unicode-Schreibweise:

var text13 = "\u039C\u03AD\u03B3\u03B9\u03C3\u03C4\u03BF";                                         // Maximum
var text14 = "\u039c\u03ae\u03ba\u03bf\u03c2 \u03c4\u03cc\u03be\u03bf\u03c5";                      // Elongation
var text15 = "\u03a4\u03b1\u03c7\u03cd\u03c4\u03b7\u03c4\u03b1";                                   // Geschwindigkeit
var text16 = "\u0395\u03c6\u03b1\u03c0\u03c4\u03bf\u03bc\u03b5\u03bd\u03b9\u03ba\u03ae "           // Tangentiale Beschleunigung (1)
           + "\u03B5\u03c0\u03b9\u03c4\u03ac\u03c7\u03c5\u03bd\u03c3\u03b7";                       // Tangentiale Beschleunigung (2)
var text17 = "\u0395\u03c6\u03b1\u03c0\u03c4\u03bf\u03bc\u03b5\u03bd\u03b9\u03ba\u03ae "           // Tangentiale Kraft (1)
           + "\u03B4\u03cd\u03bd\u03b1\u03bc\u03b7";                                               // Tangentiale Kraft (2)
var text18 = "\u0394\u03c5\u03bd\u03b1\u03bc\u03b9\u03ba\u03ae "                                   // Potentielle Energie (1)
           + "\u03b5\u03bd\u03ad\u03c1\u03b3\u03b5\u03b9\u03b1";                                   // Potentielle Energie (2)
var text19 = "\u039a\u03b9\u03bd\u03b7\u03c4\u03b9\u03ba\u03ae "                                   // Kinetische Energie (1)
           + "\u03b5\u03bd\u03ad\u03c1\u03b3\u03b5\u03b9\u03b1";                                   // Kinetische Energie (2)
var text20 = "\u03A3\u03C5\u03BD\u03BF\u03BB\u03B9\u03BA\u03AE "                                   // Gesamtenergie (1)
           + "\u03b5\u03bd\u03ad\u03c1\u03b3\u03b5\u03b9\u03b1";                                   // Gesamtenergie (2)
var text21 = "(in s)";
var text22 = "(in m)";
var text23 = "(in m/s)";
var text24 = "(in m/s\u00b2)";
var text25 = "(in N)";
var text26 = "(in J)";
var text27 = "\u03a0\u03b5\u03c1\u03af\u03bf\u03b4\u03bf\u03c2 "                                   // Schwingungsdauer (1)
           + "\u03c4\u03b1\u03bb\u03ac\u03bd\u03c4\u03c9\u03c3\u03b7\u03c2";                       // Schwingungsdauer (2)

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolTangential = "tang";                             // Symbol f�r tangential
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                          // Sekunde
var meterUnicode = "m";                                    // Meter
var meterPerSecond = "m/s";                                // Meter pro Sekunde
var meterPerSecond2Unicode = "m/s\u00b2";                  // Meter pro Sekunde hoch 2
var newton = "N";                                          // Newton
var joule = "J";                                           // Joule


