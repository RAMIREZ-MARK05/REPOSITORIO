// Leiterschaukel-Versuch zur Lorentzkraft, griechische Texte
// Letzte �nderung 31.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Alpha;&nu;&omicron;&iota;&kappa;&tau;&#972; / "                 // Ein/Aus (1)
           + "&Kappa;&lambda;&epsilon;&iota;&sigma;&tau;&#972;";               // Ein/Aus (2)
var text02 = "&Alpha;&nu;&tau;&iota;&sigma;&tau;&rho;&omicron;&phi;&#942; "    // Umpolen (1)
           + "&rho;&epsilon;&#973;&mu;&alpha;&tau;&omicron;&sigmaf;";          // Umpolen (2)
var text03 = "&Sigma;&tau;&rho;&omicron;&phi;&#942; "                          // Magnet umdrehen (1)
           + "&mu;&alpha;&gamma;&nu;&#942;&tau;&eta;";                         // Magnet umdrehen (2)
var text04 = "&Phi;&omicron;&rho;&#940; "                                      // Stromrichtung (1)
           + "&rho;&epsilon;&#973;&mu;&alpha;&tau;&omicron;&sigmaf;";          // Stromrichtung (2)
var text05 = "&Mu;&alpha;&gamma;&nu;&eta;&tau;&iota;&kappa;&#972; "            // Magnetfeld (1)
           + "&pi;&epsilon;&delta;&#943;&omicron;";                            // Magnetfeld (2)
var text06 = "&Delta;&#973;&nu;&alpha;&mu;&eta; "                              // Lorentzkraft (1)
           + "&Lambda;&#972;&rho;&epsilon;&nu;&tau;&zeta;";                    // Lorentzkraft (2)

var author = "W. Fendt 1998";
var translator = "NHRF 2000";
