// Kreisbewegung mit konstanter Winkelgeschwindigkeit, griechische Texte (Wikipedia, DeepL)
// Letzte �nderung 23.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;"          // Zur�ck
var text02 = ["&#904;&nu;&alpha;&rho;&xi;&eta;",                                                   // Start 
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter
var text03 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";                       // Zeitlupe
var text04 = "&Alpha;&kappa;&tau;&#943;&nu;&alpha;:";                                              // Radius
var text05 = "&Pi;&epsilon;&rho;&#943;&omicron;&delta;&omicron;&sigmaf;:";                         // Umlaufdauer
var text06 = "&Mu;&#940;&zeta;&alpha;:";                                                           // Masse
var text07 = "&Theta;&#941;&sigma;&eta;";                                                          // Position
var text08 = "&Tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;";                                      // Geschwindigkeit
var text09 = "&Epsilon;&pi;&iota;&tau;&#940;&chi;&upsilon;&nu;&sigma;&eta;";                       // Beschleunigung
var text10 = "&Delta;&#973;&nu;&alpha;&mu;&eta;";                                                  // Kraft

var author = "W. Fendt 2007";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma)
var meter = "m";                                                                                   // Meter
var second = "s";                                                                                  // Sekunde
var kilogram = "kg";                                                                               // Kilogramm

// Texte in Unicode-Schreibweise:

var text11 = "\u0398\u03AD\u03C3\u03B7:";                                                          // Position
var text12 = "\u03A4\u03B1\u03C7\u03CD\u03C4\u03B7\u03C4\u03B1:";                                  // Geschwindigkeit
var text13 = "\u0393\u03C9\u03BD\u03B9\u03B1\u03BA\u03AE "                                         // Winkelgeschwindigkeit (1)
           + "\u03C4\u03B1\u03C7\u03CD\u03C4\u03B7\u03C4\u03B1";                                   // Winkelgeschwindigkeit (2)
var text14 = "\u039A\u03B5\u03BD\u03C4\u03C1\u03BF\u03BC\u03CC\u03BB\u03BF\u03C2 "                 // Zentripetalbeschleunigung (1)
           + "\u03B5\u03C0\u03B9\u03C4\u03AC\u03C7\u03C5\u03BD\u03C3\u03B7:";                      // Zentripetalbeschleunigung (2)
var text15 = "\u039A\u03B5\u03BD\u03C4\u03C1\u03BF\u03BC\u03CC\u03BB\u03BF\u03C2 "                 // Zentripetalkraft (1)
           + "\u03B4\u03CD\u03BD\u03B1\u03BC\u03B7:";                                              // Zentripetalkraft (2)
var text16 = "(s)";
var text17 = "(m)";
var text18 = "(m/s)";
var text19 = "(m/s\u00B2)";
var text20 = "(N)";
var text21 = "(x-\u03BA\u03B1\u03C4\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7)";                   // x-Richtung
var text22 = "(y-\u03BA\u03B1\u03C4\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7)";                   // y-Richtung
var text23 = "(\u03BC\u03AD\u03C4\u03C1\u03BF)";                                                   // Betrag

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03C9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "m";                                    // Meter
var meterPerSecond = "m/s";                                // Meter pro Sekunde
var meterPerSecond2 = "m/s\u00B2";                         // Meter pro Sekunde hoch 2
var newton = "N";                                          // Newton
var radPerSecond = "rad/s";                                // Radiant pro Sekunde




