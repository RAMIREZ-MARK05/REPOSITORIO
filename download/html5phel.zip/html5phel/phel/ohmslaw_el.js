// Ohmsches Gesetz, griechische Texte
// Letzte �nderung 27.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Mu;&#941;&gamma;&iota;&sigma;&tau;&eta; &tau;&#940;&sigma;&eta;:";                  // Maximale Spannung
var text02 = "&Mu;&#941;&gamma;&iota;&sigma;&tau;&eta; &#941;&nu;&tau;&alpha;&sigma;&eta;:";       // Maximale Stromst�rke
var text03 = "&Alpha;&#973;&xi;&eta;&sigma;&eta; &tau;&eta;&sigmaf; "                              // Widerstand vergr��ern (1)
           + "&alpha;&nu;&tau;&#943;&sigma;&tau;&alpha;&sigma;&eta;&sigmaf;";                      // Widerstand vergr��ern (2)
var text04 = "&Epsilon;&lambda;&#940;&tau;&tau;&omega;&sigma;&eta; &tau;&eta;&sigmaf; "            // Widerstand verkleinern (1)
           + "&alpha;&nu;&tau;&#943;&sigma;&tau;&alpha;&sigma;&eta;&sigmaf;";                      // Widerstand verkleinern (2)
// Widerstand verkleinern
var text05 = "&Alpha;&#973;&xi;&eta;&sigma;&eta; &tau;&eta;&sigmaf; "                              // Spannung vergr��ern (1)
           + "&tau;&#940;&sigma;&eta;&sigmaf;";                                                    // Spannung vergr��ern (2)
var text06 = "&Epsilon;&lambda;&#940;&tau;&tau;&omega;&sigma;&eta; &tau;&eta;&sigmaf; "            // Spannung verkleinern (1)
           + "&tau;&#940;&sigma;&eta;&sigmaf;";                                                    // Spannung verkleinern (2)

var author = "W. Fendt 1997";
var translator = "NHRF 2000";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "\u03A5\u03C0\u03AD\u03C1\u03B2\u03B1\u03C3\u03B7 "                                   // Messbereich �berschritten
           + "\u03C4\u03BF\u03C5 \u03BC\u03AD\u03B3\u03B9\u03C3\u03C4\u03BF\u03C5!";               // Messbereich �berschritten

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
