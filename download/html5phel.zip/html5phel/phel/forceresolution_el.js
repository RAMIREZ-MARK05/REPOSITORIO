// Zerlegung einer Kraft in zwei Komponenten, griechische Version (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Mu;&#941;&tau;&rho;&omicron; &tau;&eta;&sigmaf; &delta;&epsilon;&delta;&omicron;&mu;&#941;&nu;&eta;&sigmaf;";                       
var text02 = "&delta;&#973;&nu;&alpha;&mu;&eta;&sigmaf;:";
var text03 = "&Tau;&iota;&mu;&#941;&sigmaf; &gamma;&omega;&nu;&iota;&#974;&nu;:";
var text04 = "1&eta; &gamma;&omega;&nu;&#943;&alpha;:";
var text05 = "2&eta; &gamma;&omega;&nu;&#943;&alpha;:";
var text06 = "&Mu;&#941;&tau;&rho;&alpha; &tau;&omega;&nu; &sigma;&upsilon;&nu;&iota;&sigma;&tau;&omega;&sigma;&#974;&nu;:";
var text07 = "1&eta; &sigma;&upsilon;&nu;&iota;&sigma;&tau;&#974;&sigma;&alpha;:";
var text08 = "2&eta; &sigma;&upsilon;&nu;&iota;&sigma;&tau;&#974;&sigma;&alpha;:";
var text09 = "&Upsilon;&pi;&omicron;&lambda;&#972;&gamma;&iota;&sigma;&epsilon; "
           + "&tau;&iota;&sigmaf; &sigma;&upsilon;&nu;&iota;&sigma;&tau;&#974;&sigma;&epsilon;&sigmaf;";
var text10 = "&Kappa;&alpha;&theta;&alpha;&rho;&iota;&sigma;&mu;&#972;&sigmaf; "
           + "&sigma;&chi;&epsilon;&delta;&iota;&alpha;&sigma;&mu;&omicron;&#973;";

var author = "W. Fendt 2003";
var translator = "&Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                            
var newton = "N";                            

// Texte in Unicode-Schreibweise:

var text11 = "1\u03b7 \u03c3\u03c5\u03bd\u03b9\u03c3\u03c4\u03ce\u03c3\u03b1";                           
var text12 = "2\u03b7 \u03c3\u03c5\u03bd\u03b9\u03c3\u03c4\u03ce\u03c3\u03b1";                            

// Symbole und Einheiten:

var newtonUnicode = "N";                          