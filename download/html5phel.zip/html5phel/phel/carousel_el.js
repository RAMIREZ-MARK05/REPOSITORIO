// Kettenkarussell, griechische Texte
// Letzte �nderung 30.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Mu;&omicron;&nu;&tau;&#941;&lambda;&omicron; "                                      // Karussell (1)
           + "&lambda;&omicron;&#973;&nu;&alpha;-&pi;&alpha;&rho;&kappa;";                         // Karussell (2)
var text02 = "&Mu;&omicron;&nu;&tau;&#941;&lambda;&omicron; "                                      // Karussell mit Kr�ften (1)
           + "&lambda;&omicron;&#973;&nu;&alpha;-&pi;&alpha;&rho;&kappa; "                         // Karussell mit Kr�ften (2)
           + "&mu;&epsilon; &delta;&upsilon;&nu;&#940;&mu;&epsilon;&iota;&sigmaf;";                // Karussell mit Kr�ften (3)
var text03 = "&Gamma;&rho;&#940;&phi;&eta;&mu;&alpha;";                                            // Skizze
var text04 = "&Alpha;&rho;&iota;&theta;&mu;&eta;&tau;&iota;&kappa;&#941;&sigmaf; "                 // Zahlenwerte (1)
           + "&tau;&iota;&mu;&#941;&sigmaf;";                                                      // Zahlenwerte (2)
var text05 = ["&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter
var text06 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";                       // Zeitlupe
var text07 = "&Pi;&epsilon;&rho;&#943;&omicron;&delta;&omicron;&sigmaf;:";                         // Umlaufzeit
var text08 = ["&Alpha;&pi;&#972;&sigma;&tau;&alpha;&sigma;&eta; "                                  // Abstand der Aufh�ngungen ... (1)
           +  "&mu;&epsilon;&tau;&alpha;&xi;&#973; &sigma;&eta;&mu;&epsilon;&#943;&omega;&nu; "    // Abstand der Aufh�ngungen ... (2)
           +  "&alpha;&nu;&#940;&rho;&tau;&eta;&sigma;&eta;&sigmaf;",                              // Abstand der Aufh�ngungen ... (3)
              "&kappa;&alpha;&iota; &#940;&xi;&omicron;&nu;&alpha; "                               // ... von der Drehachse (1)
           +  "&pi;&epsilon;&rho;&iota;&sigma;&tau;&rho;&omicron;&phi;&#942;&sigmaf;:"];           // ... von der Drehachse (2)
var text09 = "&Mu;&#942;&kappa;&omicron;&sigmaf; "
           + "&sigma;&chi;&omicron;&iota;&nu;&iota;&#974;&nu;:"; // Fadenl�nge
var text10 = "&Mu;&#940;&zeta;&alpha;:"; // Masse

var author = "W. Fendt 1999,&nbsp; NHRF 2000";                                                     // Autor (und �bersetzer)

// Texte in Unicode-Schreibweise:

var text11 = "\u03A3\u03C5\u03C7\u03BD\u03CC\u03C4\u03B7\u03C4\u03B1:";                            // Frequenz
var text12 = "\u0393\u03C9\u03BD\u03B9\u03B1\u03BA\u03AE "                                         // Winkelgeschwindigkeit (1)
           + "\u03C4\u03B1\u03C7\u03CD\u03C4\u03B7\u03C4\u03B1:";                                  // Winkelgeschwindigkeit (2)
var text13 = "\u0391\u03BA\u03C4\u03AF\u03BD\u03B1:";                                              // Radius
var text14 = "\u03A4\u03B1\u03C7\u03CD\u03C4\u03B7\u03C4\u03B1:";                                  // Geschwindigkeit
var text15 = "\u0393\u03C9\u03BD\u03AF\u03B1:";                                                    // Winkel
var text16 = "\u0392\u03AC\u03C1\u03BF\u03C2:";                                                    // Gewichtskraft
var text17 = "\u039A\u03B5\u03BD\u03C4\u03C1\u03BF\u03BC\u03CC\u03BB\u03BF\u03C2 "                 // Zentripetalkraft (1)
           + "\u03B4\u03CD\u03BD\u03B1\u03BC\u03B7:";                                              // Zentripetalkraft (2)
var text18 = "\u03A6\u03BF\u03C1\u03C4\u03AF\u03BF \u03C3\u03B5 "                                  // Belastung eines Fadens (1)
           + "\u03C3\u03C7\u03BF\u03B9\u03BD\u03AF:";
// Belastung des Fadens

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




