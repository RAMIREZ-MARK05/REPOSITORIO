// Elastischer und unelastischer Sto�, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&lambda;&alpha;&sigma;&tau;&iota;&kappa;&#942; &kappa;&rho;&omicron;&#973;&sigma;&eta;";
var text02 = "&Pi;&lambda;&alpha;&sigma;&tau;&iota;&kappa;&#942; &kappa;&rho;&omicron;&#973;&sigma;&eta;";
var text03 = "&Epsilon;&pi;&alpha;&nu;&epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;";
var text04 = "&#904;&nu;&alpha;&rho;&xi;&eta;";
var text05 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";
var text06 = "&Alpha;&mu;&alpha;&xi;&#943;&delta;&iota;&omicron; 1:";
var text07 = "&Alpha;&mu;&alpha;&xi;&#943;&delta;&iota;&omicron; 2:";
var text08 = "&Mu;&#940;&zeta;&alpha;:";
var text09 = "&Tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;:";
var text10 = "&Tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;";
var text11 = "&Omicron;&rho;&mu;&#942;";
var text12 = "&Kappa;&iota;&nu;&eta;&tau;&iota;&kappa;&#942; &epsilon;&nu;&#941;&rho;&gamma;&epsilon;&iota;&alpha;";

var author = "W. Fendt 1998,&nbsp; &Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                      

// Texte in Unicode-Schreibweise:

var text13 = "\u0391\u03bc\u03b1\u03be\u03af\u03b4\u03b9\u03bf 1:";
var text14 = "\u0391\u03bc\u03b1\u03be\u03af\u03b4\u03b9\u03bf 2:";
var text15 = "\u03a4\u03b1\u03c7\u03cd\u03c4\u03b7\u03c4\u03b5\u03c2 "
           + "\u03c0\u03c1\u03b9\u03bd \u03c4\u03b7\u03bd \u03ba\u03c1\u03bf\u03cd\u03c3\u03b7:";
var text16 = "\u03a4\u03b1\u03c7\u03cd\u03c4\u03b7\u03c4\u03b5\u03c2 "
           + "\u03bc\u03b5\u03c4\u03ac \u03c4\u03b7\u03bd \u03ba\u03c1\u03bf\u03cd\u03c3\u03b7:";
var text17 = "\u039f\u03c1\u03bc\u03ad\u03c2 "
           + "\u03c0\u03c1\u03b9\u03bd \u03c4\u03b7\u03bd \u03ba\u03c1\u03bf\u03cd\u03c3\u03b7:";
var text18 = "\u039f\u03c1\u03bc\u03ad\u03c2 "
           + "\u03bc\u03b5\u03c4\u03ac \u03c4\u03b7\u03bd \u03ba\u03c1\u03bf\u03cd\u03c3\u03b7:";
var text19 = "\u039a\u03b9\u03bd\u03b7\u03c4\u03b9\u03ba\u03ae \u03b5\u03bd\u03ad\u03c1\u03b3\u03b5\u03b9\u03b1 "
           + "\u03c0\u03c1\u03b9\u03bd \u03c4\u03b7\u03bd \u03ba\u03c1\u03bf\u03cd\u03c3\u03b7:";
var text20 = "\u039a\u03b9\u03bd\u03b7\u03c4\u03b9\u03ba\u03ae \u03b5\u03bd\u03ad\u03c1\u03b3\u03b5\u03b9\u03b1 "
           + "\u03bc\u03b5\u03c4\u03ac \u03c4\u03b7\u03bd \u03ba\u03c1\u03bf\u03cd\u03c3\u03b7:";
var text21 = "\u039f\u03bb\u03b9\u03ba\u03ae \u03bf\u03c1\u03bc\u03ae:";
var text22 = "\u039f\u03bb\u03b9\u03ba\u03ae "
           + "\u03ba\u03b9\u03bd\u03b7\u03c4\u03b9\u03ba\u03ae \u03b5\u03bd\u03ad\u03c1\u03b3\u03b5\u03b9\u03b1:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                  
var kilogramMeterPerSecond = "kg m/s";                
var joule = "J";                                       
