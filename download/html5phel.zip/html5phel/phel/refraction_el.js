// Reflexion und Brechung von Licht, griechische Texte
// Letzte �nderung 28.01.2022

// Texte in HTML-Schreibweise:
    
var text01 = "&Delta;&epsilon;&#943;&kappa;&tau;&eta;&sigmaf; "                                    // 1. Brechungsindex (1)
           + "&delta;&iota;&#940;&theta;&lambda;&alpha;&sigma;&eta;&sigmaf; 1:";                   // 1. Brechungsindex (2)
var text02 = "&Delta;&epsilon;&#943;&kappa;&tau;&eta;&sigmaf; "                                    // 2. Brechungsindex (1)
           + "&delta;&iota;&#940;&theta;&lambda;&alpha;&sigma;&eta;&sigmaf; 2:";                   // 2. Brechungsindex (2)
var text03 = "&Gamma;&omega;&nu;&#943;&alpha; "                                                    // Einfallswinkel (1)
           + "&pi;&rho;&#972;&sigma;&pi;&tau;&omega;&sigma;&eta;&sigmaf;:";                        // Einfallswinkel (2)
var text04 = "&Gamma;&omega;&nu;&#943;&alpha; "                                                    // Reflexionswinkel (1)
           + "&alpha;&nu;&#940;&kappa;&lambda;&alpha;&sigma;&eta;&sigmaf;:";                       // Reflexionswinkel (2)
var text05 = "&Gamma;&omega;&nu;&#943;&alpha; "                                                    // Brechungswinkel (1)
           + "&delta;&iota;&#940;&theta;&lambda;&alpha;&sigma;&eta;&sigmaf;:";                     // Brechungswinkel (2) 
var text06 = ["&Omicron;&rho;&iota;&alpha;&kappa;&#942; &gamma;&omega;&nu;&#943;&alpha;",
              "(&omicron;&lambda;&iota;&kappa;&#942; "
            + "&alpha;&nu;&#940;&kappa;&lambda;&alpha;&sigma;&eta;):"];
// ["Grenzwinkel der", "Totalreflexion:"];

var author = "W. Fendt 1997";

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                                                              // Grad

// Texte in Unicode-Schreibweise:

var text07 = [["\u03BA\u03B5\u03BD\u03CC", "1"],                                                   // Vakuum
              ["\u03B1\u03AD\u03C1\u03B1\u03C2", "1.0003"],                                        // Luft
              ["\u03BD\u03B5\u03C1\u03CC", "1.33"],                                                // Wasser
              ["\u03B1\u03B9\u03B8\u03B1\u03BD\u03CC\u03BB\u03B7", "1.36"],                        // Ethanol
              ["\u03B3\u03C5\u03B1\u03BB\u03AF \u03C7\u03B1\u03BB\u03B1\u03B6\u03AF\u03B1", "1.46"], // Quarzglas
              ["\u03B2\u03B5\u03BD\u03B6\u03CC\u03BB\u03B9\u03BF", "1.49"],                        // Benzol
              ["\u03B3\u03C5\u03B1\u03BB\u03AF Crown N-K5", "1.52"],                               // Kron(?)glas 
              ["\u03B1\u03BB\u03AC\u03C4\u03B9", "1.54"],                                          // Stein(?)salz
              ["\u03B3\u03C5\u03B1\u03BB\u03AF Flint LF5", "1.58"],                                // Flint(?)glas
              ["\u03B3\u03C5\u03B1\u03BB\u03AF Crown N-SK4", "1.61"],                              // Kron(?)glas
              ["\u03B3\u03C5\u03B1\u03BB\u03AF Flint SF6", "1.81"],                                // Flint(?)glas
              ["\u03B4\u03B9\u03B1\u03BC\u03AC\u03BD\u03C4\u03B9", "2.42"],                        // Diamant
              ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                                                                       // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                                                                      // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                                                                      // Grad
