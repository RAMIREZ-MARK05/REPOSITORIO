// Fahrbahnversuch zum 2. Newtonschen Gesetz, griechische Texte
// Letzte �nderung 30.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";                           // Messreihe l�schen
var text02 = ["&Epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;",                                // Start
              "&Kappa;&alpha;&tau;&alpha;&gamma;&rho;&alpha;&phi;&#942; "                          // Ergebnis registrieren (1)
           +  "&delta;&epsilon;&delta;&omicron;&mu;&#941;&nu;&omega;&nu;"];                        // Ergebnis registrieren (2)
var text03 = "&Delta;&iota;&#940;&gamma;&rho;&alpha;&mu;&mu;&alpha;";                              // Diagramm
var text04 = "&Mu;&#940;&zeta;&alpha; &beta;&alpha;&gamma;&omicron;&nu;&iota;&omicron;&#973;:"     // Masse des Wagens
var text05 = "&Kappa;&rho;&epsilon;&mu;&#940;&mu;&epsilon;&nu;&eta; &mu;&#940;&zeta;&alpha;:";     // Masse des W�gest�cks
var text06 = "&Sigma;&upsilon;&nu;&tau;&epsilon;&lambda;&epsilon;&sigma;&tau;&#942;&sigmaf; "      // Reibungszahl (1)
           + "&tau;&rho;&iota;&beta;&#942;&sigmaf;:";                                              // Reibungszahl (2)
var text07 = "&Delta;&epsilon;&delta;&omicron;&mu;&#941;&nu;&alpha;:";                             // Messwerte

var author = "W. Fendt 1997,&nbsp; NHRF 2000";                                                     // Autor (und �bersetzer)

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "LB";                                                                                 // Abk�rzung Lichtschranke
var text09 = "(in s)";
var text10 = "(in m)";
var text11 = "\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03B7 "                      // Reibung zu gro� (1)
           + "\u03C4\u03C1\u03B9\u03B2\u03AE!";                                                    // Reibung zu gro� (2)

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


