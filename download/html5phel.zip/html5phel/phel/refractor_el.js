// Kepler-Fernrohr, griechische Texte
// Letzte �nderung 28.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&sigma;&tau;&iota;&alpha;&kappa;&#941;&sigmaf; "                            // Brennweiten (1)
           + "&alpha;&pi;&omicron;&sigma;&tau;&#940;&sigma;&epsilon;&iota;&sigmaf;:";              // Brennweiten (2)
var text02 = "&Alpha;&nu;&tau;&iota;&kappa;&epsilon;&iota;&mu;&epsilon;&nu;&iota;&kappa;&omicron;&#973; " // Objektiv (1)
           + "&phi;&alpha;&kappa;&omicron;&#973;:";                                                // Objektiv (2)
var text03 = "&Pi;&rho;&omicron;&sigma;&omicron;&phi;&theta;&#940;&lambda;&mu;&iota;&omicron;&upsilon;:"; // Okular
var text04 = "&Gamma;&omega;&nu;&#943;&epsilon;&sigmaf;:";                                         // Sehwinkel
var text05 = "&Mu;&epsilon;&gamma;&#941;&theta;&upsilon;&nu;&sigma;&eta;:";                        // Vergr��erung

var author = "W. Fendt 2000";
var translator = "NHRF 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                                                                       // Symbol f�r Brennweite
