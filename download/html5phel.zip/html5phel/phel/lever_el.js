// Hebelgesetz, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in Unicode-Schreibweise:

var text01 = "\u03a1\u03bf\u03c0\u03ae \u03b1\u03c1\u03b9\u03c3\u03c4\u03b5\u03c1\u03cc\u03c3\u03c4\u03c1\u03bf\u03c6\u03b1:";
var text02 = "\u03a1\u03bf\u03c0\u03ae \u03b4\u03b5\u03be\u03b9\u03cc\u03c3\u03c4\u03c1\u03bf\u03c6\u03b1:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "\u03c4_1";                         // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "\u03c4_2";                        // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

var newton = "N";
var meter = "m";

var author = "W. Fendt 1997,\u0020 "
           + "\u03a7. \u03a7\u03c1\u03c5\u03c3\u03bf\u03c7\u03bf\u0390\u03b4\u03b7\u03c2 2016";    // Autor (und �bersetzer)
