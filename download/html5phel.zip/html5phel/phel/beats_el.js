// Schwebungen, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;";
var text02 = ["&#904;&nu;&alpha;&rho;&xi;&eta;", 
              "&Pi;&alpha;&#973;&sigma;&eta;", 
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];
var text03 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";
var text04 = "&Sigma;&upsilon;&chi;&nu;&#972;&tau;&eta;&tau;&epsilon;&sigmaf;:";
var text05 = "1&omicron; &kappa;&#973;&mu;&alpha;:";
var text06 = "2&omicron; &kappa;&#973;&mu;&alpha;:";

var author = "W. Fendt 2001"; 
var translator = "&Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



