// Stehende L�ngswellen, griechische Texte
// Letzte �nderung 27.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Mu;&omicron;&rho;&phi;&#942; &sigma;&omega;&lambda;&#942;&nu;&alpha;:";             // Rohrform
var text02 = "&kappa;&alpha;&iota; &omicron;&iota; &delta;&#973;&omicron; "                        // beidseitig offen (1)
           + "&mu;&epsilon;&rho;&iota;&#941;&sigmaf; &alpha;&nu;&omicron;&iota;&chi;&tau;&#941;&sigmaf;"; // beidseitig offen (2)
var text03 = "&mu;&#943;&alpha; &mu;&epsilon;&rho;&iota;&#940; "                                   // einseitig offen (1)
           + "&alpha;&nu;&omicron;&iota;&chi;&tau;&#942;";                                         // einseitig offen (2)
var text04 = "&kappa;&alpha;&iota; &omicron;&iota; &delta;&#973;&omicron; "                        // beidseitig geschlossen (1)
           + "&mu;&epsilon;&rho;&iota;&#941;&sigmaf; &kappa;&lambda;&epsilon;&iota;&sigma;&tau;&#941;&sigmaf;"; // beidseitig geschlossen (2)
var text05 = "&Iota;&delta;&iota;&omicron;&sigma;&upsilon;&chi;&nu;&#972;&tau;&eta;&tau;&alpha;:"; // Eigenschwingung
var text06 = ["&theta;&epsilon;&mu;&epsilon;&lambda;&iota;&alpha;&kappa;&#942;",                   // Grundschwingung   
              "1&eta; &alpha;&rho;&mu;&omicron;&nu;&iota;&kappa;&#942;",                           // 1. Oberschwingung
              "1&eta; &alpha;&rho;&mu;&omicron;&nu;&iota;&kappa;&#942;",                           // 2. Oberschwingung
              "1&eta; &alpha;&rho;&mu;&omicron;&nu;&iota;&kappa;&#942;",                           // 3. Oberschwingung
              "1&eta; &alpha;&rho;&mu;&omicron;&nu;&iota;&kappa;&#942;",                           // 4. Oberschwingung
              "1&eta; &alpha;&rho;&mu;&omicron;&nu;&iota;&kappa;&#942;"];                          // 5. Oberschwingung

var text07 = "&Chi;&alpha;&mu;&eta;&lambda;&#972;&tau;&epsilon;&rho;&eta;";                        // Tiefer
var text08 = "&Upsilon;&psi;&eta;&lambda;&#972;&tau;&epsilon;&rho;&eta;";                          // H�her
var text09 = "&Mu;&#942;&kappa;&omicron;&sigmaf; &sigma;&omega;&lambda;&#942;&nu;&alpha;:";        // Rohrl�nge
var text10 = "&Mu;&#942;&kappa;&omicron;&sigmaf; &kappa;&#973;&mu;&alpha;&tau;&omicron;&sigmaf;:"; // Wellenl�nge
var text11 = "&Sigma;&upsilon;&chi;&nu;&#972;&tau;&eta;&tau;&alpha;:";                             // Frequenz

var author = "W. Fendt 1998,&nbsp; NHRF 2000";                                                     // Autor (und �bersetzer)

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                                                                   // Meter
var hertz = "Hz";                                                                                  // Hertz

// Texte in Unicode-Schreibweise:

var text12 = "\u0395\u03C0\u03B9\u03BC\u03AE\u03BA\u03C5\u03BD\u03C3\u03B7 "                       // Elongation der Teilchen (1)
           + "\u03C4\u03C9\u03BD \u03C3\u03C9\u03BC\u03B1\u03C4\u03B9\u03B4\u03AF\u03C9\u03BD";    // Elongation der Teilchen (2)
var text13 = "\u0391\u03C0\u03CC\u03BA\u03BB\u03B9\u03C3\u03B7 \u03B1\u03C0\u03CC \u03C4\u03B7 "   // Abweichung vom mittl. Druck (1)
           + "\u03BC\u03AD\u03C3\u03B7 \u03C0\u03AF\u03B5\u03C3\u03B7";                            // Abweichung vom mittl. Druck (2)

// Symbole:

var symbolPosition = "x";                                                                          // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                                                                      // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                                                                      // Symbol f�r Druckunterschied 
var symbolNode = "\u0394";                                                                         // Symbol f�r Knoten
var symbolAntinode = "\u039A";                                                                     // Symbol f�r Bauch

