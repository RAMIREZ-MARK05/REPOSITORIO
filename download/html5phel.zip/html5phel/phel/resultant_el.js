// Ersatzkraft mehrerer Kr�fte, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Pi;&lambda;&#942;&theta;&omicron;&sigmaf; &delta;&upsilon;&nu;&#940;&mu;&epsilon;&omega;&nu;:";
var text02 = "&Upsilon;&pi;&omicron;&lambda;&#972;&gamma;&iota;&sigma;&epsilon; "
           + "&tau;&eta; &sigma;&upsilon;&nu;&iota;&sigma;&tau;&alpha;&mu;&#941;&nu;&eta;";
var text03 = "&Kappa;&alpha;&theta;&alpha;&rho;&iota;&sigma;&mu;&#972;&sigmaf; "
           + "&sigma;&chi;&epsilon;&delta;&iota;&alpha;&sigma;&mu;&omicron;&#973;";

var author = "W. Fendt 1998";
var translator = "&Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";
