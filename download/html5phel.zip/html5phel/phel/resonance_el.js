// Resonanz, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;";
var text02 = ["&#904;&nu;&alpha;&rho;&xi;&eta;", 
              "&Pi;&alpha;&#973;&sigma;&eta;", 
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];
var text03 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";
var text04 = "&Delta;&iota;&epsilon;&gamma;&epsilon;&iota;&mu;&#972;&mu;&epsilon;&nu;&omicron; "
           + "&sigma;&#973;&sigma;&tau;&eta;&mu;&alpha;:";
var text05 = "&Sigma;&tau;&alpha;&theta;&epsilon;&rho;&#940; "
           + "&epsilon;&lambda;&alpha;&tau;&eta;&rho;&#943;&omicron;&upsilon;:";
var text06 = "&Mu;&#940;&zeta;&alpha;:";
var text07 = "&Alpha;&pi;&#972;&sigma;&beta;&epsilon;&sigma;&eta;:";
var text08 = "&Delta;&iota;&epsilon;&gamma;&#941;&rho;&tau;&eta;&sigmaf;:";
var text09 = "&Gamma;&omega;&nu;&iota;&alpha;&kappa;&#942; "
           + "&sigma;&upsilon;&chi;&nu;&#972;&tau;&eta;&tau;&alpha;:";
var text10 = "&Delta;&iota;&#940;&gamma;&rho;&alpha;&mu;&mu;&alpha; "
           + "&epsilon;&pi;&iota;&mu;&#942;&kappa;&upsilon;&nu;&sigma;&eta;&sigmaf;";
var text11 = "&Delta;&iota;&#940;&gamma;&rho;&alpha;&mu;&mu;&alpha; "
           + "&pi;&lambda;&#940;&tau;&omicron;&upsilon;&sigmaf;";
var text12 = "&Delta;&iota;&#940;&gamma;&rho;&alpha;&mu;&mu;&alpha; "
           + "&delta;&iota;&alpha;&phi;&omicron;&rho;&#940;&sigmaf; &phi;&#940;&sigma;&eta;&sigmaf;";

var author = "W. Fendt 1998,&nbsp; &Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                                
var newtonPerMeter = "N/m";                         
var perSecond = "1/s";                                 
var radPerSecond = "rad/s";                           

// Texte in Unicode-Schreibweise:

var text13 = "\u039a\u03b1\u03c4\u03b1\u03c3\u03c4\u03c1\u03bf\u03c6\u03ae "
           + "\u03b4\u03b9\u03b5\u03b3\u03b5\u03b9\u03c1\u03cc\u03bc\u03b5\u03bd\u03bf\u03c5 "
           + "\u03c3\u03c5\u03c3\u03c4\u03ae\u03bc\u03b1\u03c4\u03bf\u03c2!";
var text14 = "(\u0397 \u03c0\u03c1\u03bf\u03c3\u03bf\u03bc\u03bf\u03af\u03c9\u03c3\u03b7 "
           + "\u03b4\u03b5\u03bd \u03b5\u03af\u03bd\u03b1\u03b9 "
           + "\u03c0\u03bb\u03ad\u03bf\u03bd \u03c1\u03b5\u03b1\u03bb\u03b9\u03c3\u03c4\u03b9\u03ba\u03ae!)";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_\u03b4\u03b9\u03b5\u03b3";// Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_\u03c3\u03c5\u03c3";    // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_\u03b4\u03b9\u03b5\u03b3"; // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz (omega)
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz (omega_0)
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                                
var radPerSecondUnicode = "rad/s";                    


