// Zerfallsgesetz der Radioaktivit�t, griechische Texte
// Letzte �nderung 31.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";                           // Zur�ck
var text02 = ["&Epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;",                                // Start
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter
var text03 = "&Delta;&iota;&#940;&gamma;&rho;&alpha;&mu;&mu;&alpha;";                              // Diagramm 

var author = "W. Fendt 1998";
var translator = "";

// Texte in Unicode-Schreibweise:

var text04 = "\u03A7\u03C1\u03CC\u03BD\u03BF\u03C2:";                                              // Zeit                                   
var text05 = "\u039C\u03B7 "                                                                       // Nicht zerfallen (1)
           + "\u03B4\u03B9\u03B1\u03C3\u03C0\u03B1\u03C3\u03BC\u03AD\u03BD\u03BF\u03B9:";          // Nicht zerfallen (2)
var text06 = "\u0389\u03B4\u03B7 "                                                                 // Schon zerfallen (1)
           + "\u03B4\u03B9\u03B1\u03C3\u03C0\u03B1\u03C3\u03BC\u03AD\u03BD\u03BF\u03B9:";          // Schon zerfallen (2)
var text07 = ["\u03C0\u03C5\u03C1\u03AE\u03BD\u03B5\u03C2",                                        // Kerne (Anzahl 0) 
              "\u03C0\u03C5\u03C1\u03AE\u03BD\u03B1\u03C2",                                        // Kern (Anzahl 1)
              "\u03C0\u03C5\u03C1\u03AE\u03BD\u03B5\u03C2",                                        // Kerne (Anzahl 2)
              "\u03C0\u03C5\u03C1\u03AE\u03BD\u03B5\u03C2"];                                       // Kerne (Anzahl �ber 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
