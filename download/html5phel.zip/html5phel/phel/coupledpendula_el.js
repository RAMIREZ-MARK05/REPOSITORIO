// Gekoppelte Pendel, griechische Texte
// Letzte �nderung 26.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";                           // Zur�ck
var text02 = ["&Epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;",                                // Start 
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter
var text03 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";                       // Zeitlupe                          
var text04 = "&Alpha;&rho;&chi;&iota;&kappa;&#941;&sigmaf; "                                       // Anfangspositionen (1)
           + "&theta;&#941;&sigma;&epsilon;&iota;&sigmaf;:";                                       // Anfangspositionen (2)

var author = "W. Fendt 1998";          
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                                                              // Grad

// Texte in Unicode-Schreibweise:

var text05 = "\u0395\u03ba\u03ba\u03c1\u03b5\u03bc\u03ad\u03c2 1";                                 // Erstes Pendel (links)
var text06 = "\u0395\u03ba\u03ba\u03c1\u03b5\u03bc\u03ad\u03c2 2";                                 // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                                                              // Symbol f�r Zeit
