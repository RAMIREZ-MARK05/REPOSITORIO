// Interferenz zweier Kreis- oder Kugelwellen, griechische Texte
// Letzte �nderung 31.01.2022

// Texte in HTML-Schreibweise:

var text01 = ["&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter
var text02 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";                       // Zeitlupe
var text03 = "&Alpha;&pi;&#972;&sigma;&tau;&alpha;&sigma;&eta; "                                   // Entfernung zwischen ... (1)
           + "&mu;&epsilon;&tau;&alpha;&xi;&#973; &tau;&omega;&nu;";                               // Entfernung zwischen ... (2)                  
var text04 = "&delta;&upsilon;&omicron; &pi;&eta;&gamma;&#974;&nu;:";                              // ... Wellenzentren
var text05 = "&Mu;&#942;&kappa;&omicron;&sigmaf; &kappa;&#973;&mu;&alpha;&tau;&omicron;&sigmaf;:"; // Wellenl�nge

var author = "W. Fendt 1999";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";  

// Texte in Unicode-Schreibweise:

var text06 = "\u0394\u03B9\u03B1\u03C6\u03BF\u03C1\u03AC "                                         // Gangunterschied (1)
           + "\u03B4\u03C1\u03CC\u03BC\u03BF\u03C5:";                                              // Gangunterschied (2)
var text07 = "\u0395\u03BD\u03B9\u03C3\u03C7\u03C5\u03C4\u03B9\u03BA\u03AE "                       // Konstruktive Interferenz (1)
           + "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03AE "                                         // Konstruktive Interferenz (2)
           + "(\u03BC\u03AD\u03B3\u03B9\u03C3\u03C4\u03BF \u03C0\u03BB\u03AC\u03C4\u03BF\u03C2)";  // Maximale Amplitude
// Konstruktive Interferenz (Amplitude maximal)
var text08 = "\u0391\u03BD\u03B1\u03B9\u03C1\u03B5\u03C4\u03B9\u03BA\u03AE "                       // Destruktive Interferenz (1)
           + "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03AE "                                         // Destruktive Interferenz (2)
           + "(\u03B5\u03BB\u03AC\u03C7\u03B9\u03C3\u03C4\u03BF \u03C0\u03BB\u03AC\u03C4\u03BF\u03C2)";  // Minimale Amplitude
           
// ?????st? p??t??

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03BB";                           // Symbol f�r Wellenl�nge (Lambda)
