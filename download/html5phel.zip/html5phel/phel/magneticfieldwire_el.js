// Magnetfeld eines geraden stromdurchflossenen Leiters, griechische Texte
// Letzte �nderung 31.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Alpha;&nu;&tau;&iota;&sigma;&tau;&rho;&omicron;&phi;&#942; "    // Umpolen (1)
           + "&rho;&epsilon;&#973;&mu;&alpha;&tau;&omicron;&sigmaf;";          // Umpolen (2)

var author = "W. Fendt 2000";
var translator = "";
