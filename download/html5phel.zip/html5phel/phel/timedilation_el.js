// Beispiel zur Zeitdilatation, griechische Texte
// Letzte �nderung 29.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&lambda;&#940;&tau;&tau;&omega;&sigma;&eta; "                               // Geschwindigkeit verkleinern (1)
           + "&tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;&sigmaf;";                              // Geschwindigkeit verkleinern (2)
var text02 = "&Alpha;&#973;&xi;&eta;&sigma;&eta; "                                                 // Geschwindigkeit vergr��ern (1)
           + "&tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;&sigmaf;";                              // Geschwindigkeit vergr��ern (2)
var text03 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";                           // Zur�ck
var text04 = ["&Epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;",                                // Start
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter

var author = "W. Fendt 1997";                                                                      // Autor (und �bersetzer)

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text05 = "\u0391\u03C0\u03CC\u03C3\u03C4\u03B1\u03C3\u03B7:";                                  // Flugstrecke
var text06 = "5 \u03CE\u03C1\u03B5\u03C2 \u03C6\u03C9\u03C4\u03CC\u03C2";                          // 5 Lichtstunden
var text07 = "\u03A4\u03B1\u03C7\u03CD\u03C4\u03B7\u03C4\u03B1:";                                  // Geschwindigkeit
var text08 = "\u0394\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1 \u03C0\u03C4\u03AE\u03C3\u03B7\u03C2 " // Flugdauer Erd-System (1)
           + "(\u03A3\u03CD\u03C3\u03C4\u03B7\u03BC\u03B1 \u0393\u03B7\u03C2)";                    // Flugdauer Erd-System (2)
var text09 = "\u03CE\u03C1\u03B5\u03C2";                                                           // Stunden
var text10 = "\u0394\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1 \u03C0\u03C4\u03AE\u03C3\u03B7\u03C2 " // Flugdauer Raketen-System (1)
           + "(\u03A3\u03CD\u03C3\u03C4\u03B7\u03BC\u03B1 \u03C0\u03C5\u03C1\u03B1\u03CD\u03BB\u03BF\u03C5)"; // Flugdauer Raketen-System (2)
           