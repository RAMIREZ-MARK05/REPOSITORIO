// Gleichgewicht dreier Kr�fte, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Delta;&upsilon;&nu;&#940;&mu;&epsilon;&iota;&sigmaf;:";
var text02 = "&Alpha;&rho;&iota;&sigma;&tau;&epsilon;&rho;&#942;:";
var text03 = "&Delta;&epsilon;&xi;&iota;&#940;:";
var text04 = "&Kappa;&#940;&tau;&omega;:";
var text05 = "&Kappa;&alpha;&nu;&#972;&nu;&alpha;&sigmaf; &tau;&omicron;&upsilon; "
           + "&pi;&alpha;&rho;&alpha;&lambda;&lambda;&eta;&lambda;&omicron;&gamma;&rho;&#940;&mu;&mu;&omicron;&upsilon;";
var text06 = "&Gamma;&omega;&nu;&#943;&epsilon;&sigmaf;:";
var text07 = "&Alpha;&rho;&iota;&sigma;&tau;&epsilon;&rho;&#942;:";
var text08 = "&Delta;&epsilon;&xi;&iota;&#940;:";

var author = "W. Fendt 2000";
var translator = "&Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                            
var newton = "N";                                      
