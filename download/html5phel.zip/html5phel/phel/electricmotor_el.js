// Gleichstrom-Elektromotor, griechische Texte
// Letzte �nderung 31.10.2017

// Texte in HTML-Schreibweise;

var text01 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";                           // Zur�ck
var text02 = ["&#904;&nu;&alpha;&rho;&xi;&eta;",                                                   // Start 
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter            
var text03 = "&Alpha;&lambda;&lambda;&alpha;&gamma;&#942; "                                        // Umpolen (1)
           + "&kappa;&alpha;&tau;&epsilon;&#973;&theta;&upsilon;&nu;&sigma;&eta;&sigmaf;";         // Umpolen (2)
var text04 = "&Phi;&omicron;&rho;&#940; "                                                          // Stromrichtung (1)
           + "&rho;&epsilon;&#973;&mu;&alpha;&tau;&omicron;&sigmaf;";                              // Stromrichtung (2)
var text05 = "&Mu;&alpha;&gamma;&nu;&eta;&tau;&iota;&kappa;&#972; "                                // Magnetfeld (1)
           + "&pi;&epsilon;&delta;&#943;&omicron;";                                                // Magnetfeld (2)
var text06 = "&Delta;&#973;&nu;&alpha;&mu;&eta; "                                                  // Lorentzkraft (1)
           + "&Lambda;&#972;&rho;&epsilon;&nu;&tau;&zeta;";                                        // Lorentzkraft (2)

var author = "W. Fendt 1997";               
var translator = "NHRF 2000";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "&sigma;&tau;&rho;&omicron;&phi;&#941;&sigmaf;/min";                      // Umdrehungen pro Minute
