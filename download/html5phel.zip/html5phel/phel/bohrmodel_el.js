// Bohrsches Atommodell, griechische Texte
// Letzte �nderung 28.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Sigma;&omega;&mu;&alpha;&tau;&iota;&delta;&iota;&alpha;&kappa;&#972; "              // Teilchenbild (1)
           + "&mu;&omicron;&nu;&tau;&#941;&lambda;&omicron;";                                      // Teilchenbild (2)
var text02 = "&Kappa;&upsilon;&mu;&alpha;&tau;&iota;&kappa;&#972; "                                // Wellenbild (1)
           + "&mu;&omicron;&nu;&tau;&#941;&lambda;&omicron;";                                      // Wellenbild (2)
var text03 = "&Kappa;&#973;&rho;&iota;&omicron;&sigmaf; "                                          // Hauptquantenzahl (1)
           + "&kappa;&beta;&alpha;&nu;&tau;&iota;&kappa;&#972;&sigmaf; "                           // Hauptquantenzahl (2)
           + "&alpha;&rho;&iota;&theta;&mu;&#972;&sigmaf;:";                                       // Hauptquantenzahl (3)

var author = "W. Fendt 1999"; 
var translator = "NHRF 2000";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                                                                 // Hauptquantenzahl
var symbolR = "r";                                                                                 // Bahnradius
var symbolE = "E";                                                                                 // Gesamtenergie
var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                                                         // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



