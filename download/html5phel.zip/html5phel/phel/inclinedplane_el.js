// Kr�fte an der schiefen Ebene, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";
var text02 = ["&Epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;", 
              "&Pi;&alpha;&#973;&sigma;&eta;", 
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];
var text03 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";
var text04 = "&Delta;&upsilon;&nu;&alpha;&mu;&#972;&mu;&epsilon;&tau;&rho;&omicron;";
var text05 = "&Delta;&iota;&alpha;&nu;&#973;&sigma;&mu;&alpha;&tau;&alpha; &delta;&upsilon;&nu;&#940;&mu;&epsilon;&omega;&nu;";
var text06 = "&Gamma;&omega;&nu;&#943;&alpha; &kappa;&lambda;&#943;&sigma;&eta;&sigmaf;:";
var text07 = "&Beta;&#940;&rho;&omicron;&sigmaf;:";
var text08 = "&Pi;&alpha;&rho;&#940;&lambda;&lambda;&eta;&lambda;&eta; &sigma;&upsilon;&nu;&iota;&sigma;&tau;&#974;&sigma;&alpha;:";
var text09 = "&Kappa;&#940;&theta;&epsilon;&tau;&eta; &sigma;&upsilon;&nu;&iota;&sigma;&tau;&#974;&sigma;&alpha;:";
var text10 = "&Sigma;&upsilon;&nu;&tau;&epsilon;&lambda;&epsilon;&sigma;&tau;&#942;&sigmaf; &tau;&rho;&iota;&beta;&#942;&sigmaf;:";
var text11 = "&Delta;&#973;&nu;&alpha;&mu;&eta; &tau;&rho;&iota;&beta;&#942;&sigmaf;:";
var text12 = "&Alpha;&pi;&alpha;&iota;&tau;&omicron;&#973;&mu;&epsilon;&nu;&eta; "
           + "&epsilon;&xi;&omega;&tau;&epsilon;&rho;&iota;&kappa;&#942; &delta;&#973;&nu;&alpha;&mu;&eta;:";

var author = "W. Fendt 1999,&nbsp; &Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                
var newton = "N";                               
