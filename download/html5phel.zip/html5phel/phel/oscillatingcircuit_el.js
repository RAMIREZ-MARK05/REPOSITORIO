// Elektromagnetischer Schwingkreis, griechische Texte
// Letzte �nderung 28.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;";                           // Zur�ck
var text02 = ["&Epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;",                                // Start 
              "&Pi;&alpha;&#973;&sigma;&eta;",                                                     // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];                                // Weiter  
var text03 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta; (10 &times;)";          // Zeitlupe (10 x)
var text04 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta; (100 &times;)";         // Zeitlupe (100 x)
var text05 = "&Chi;&omega;&rho;&eta;&tau;&iota;&kappa;&#972;&tau;&eta;&tau;&alpha;:";              // Kapazit�t
var text06 = "&Alpha;&upsilon;&tau;&epsilon;&pi;&alpha;&gamma;&omega;&gamma;&#942;:";              // Induktivit�t
var text07 = "&Alpha;&nu;&tau;&#943;&sigma;&tau;&alpha;&sigma;&eta;:";                             // Widerstand
var text08 = "&Mu;&#941;&gamma;&iota;&sigma;&tau;&eta; &tau;&#940;&sigma;&eta;:";                  // Maximale Spannung
var text09 = "&Tau;&#940;&sigma;&eta;, &#904;&nu;&tau;&alpha;&sigma;&eta;";                        // Spannung, Stromst�rke
var text10 = "&Epsilon;&nu;&#941;&rho;&gamma;&epsilon;&iota;&alpha;";                              // Energie

var author = "W. Fendt 1999";                                                                      // Autor (und �bersetzer)

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                                                                          // Mikrofarad
var henry = "H";                                                                                   // Henry
var ohm = "&Omega;";                                                                               // Ohm
var volt = "V";                                                                                    // Volt

// Texte in Unicode-Schreibweise:

var text11 = "\u03a0\u03b5\u03c1\u03af\u03bf\u03b4\u03bf\u03c2 "                                   // Schwingungsdauer (1)
           + "\u03c4\u03b1\u03bb\u03ac\u03bd\u03c4\u03c9\u03c3\u03b7\u03c2:";                      // Schwingungsdauer (2)
var text12 = "\u0395\u03BD\u03AD\u03C1\u03B3\u03B5\u03B9\u03B1 "                                   // Elektrische Feldenergie (1)
           + "\u03B7\u03BB\u03B5\u03BA\u03C4\u03C1\u03B9\u03BA\u03BF\u03CD "                       // Elektrische Feldenergie (2)
           + "\u03C0\u03B5\u03B4\u03AF\u03BF\u03C5:";                                              // Elektrische Feldenergie (3)
var text13 = "\u0395\u03BD\u03AD\u03C1\u03B3\u03B5\u03B9\u03B1 "                                   // Magnetische Feldenergie (1)
           + "\u03BC\u03B1\u03B3\u03BD\u03B7\u03C4\u03B9\u03BA\u03BF\u03CD "                       // Magnetische Feldenergie (2)
           + "\u03C0\u03B5\u03B4\u03AF\u03BF\u03C5:";                                              // Magnetische Feldenergie (3)
var text14 = "\u0395\u03C3\u03C9\u03C4\u03B5\u03C1\u03B9\u03BA\u03AE "                             // Innere Energie (1)
           + "\u03B5\u03BD\u03AD\u03C1\u03B3\u03B5\u03B9\u03B1:";                                  // Innere Energie (2)
var text15 = "\u03A4\u03B1\u03BB\u03AC\u03BD\u03C4\u03C9\u03C3\u03B7 "                             // Unged�mpfte Schwingung (1)
           + "\u03C7\u03C9\u03C1\u03AF\u03C2 "                                                     // Unged�mpfte Schwingung (2)
           + "\u03B1\u03C0\u03CC\u03C3\u03B2\u03B5\u03C3\u03B7";                                   // Unged�mpfte Schwingung (3)
var text16 = "\u0391\u03C0\u03BF\u03C3\u03B2\u03B5\u03C3\u03BC\u03AD\u03BD\u03B7 "                 // Ged�mpfte Schwingung (1)
           + "\u03C4\u03B1\u03BB\u03AC\u03BD\u03C4\u03C9\u03C3\u03B7";                             // Ged�mpfte Schwingung (2)
var text17 = "\u039A\u03C1\u03AF\u03C3\u03B9\u03BC\u03B7 "                                         // Aperiodischer Grenzfall (1)
           + "\u03B1\u03C0\u03CC\u03C3\u03B2\u03B5\u03C3\u03B7";                                   // Aperiodischer Grenzfall (2)
var text18 = "\u03A5\u03C0\u03B5\u03C1\u03BA\u03C1\u03AF\u03C3\u03B9\u03BC\u03B7 "                 // Kriechfall (1)
           + "\u03B1\u03C0\u03CC\u03C3\u03B2\u03B5\u03C3\u03B7";                                   // Kriechfall (2)

// Symbole und Einheiten:

var symbolTime = "t";                                                                              // Symbol f�r Zeit
var symbolPeriod = "T";                                                                            // Symbol f�r Periode
var symbolVoltage = "U";                                                                           // Symbol f�r Spannung
var symbolAmperage = "I";                                                                          // Symbol f�r Stromst�rke
var second = "s";                                                                                  // Sekunde
var voltUnicode = "V";                                                                             // Volt
var ampere = "A";                                                                                  // Ampere
var joule = "J";                                                                                   // Joule
