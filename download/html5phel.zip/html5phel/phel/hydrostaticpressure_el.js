// Druckdose (hydrostatischer Druck), griechische Texte
// Letzte �nderung 31.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Rho;&epsilon;&upsilon;&sigma;&tau;&#940;:";                                         // Fl�ssigkeit
var text03 = "&Pi;&upsilon;&kappa;&nu;&#972;&tau;&eta;&tau;&alpha;:";                              // Dichte
var text04 = "&Beta;&#940;&theta;&omicron;&sigmaf;:";                                              // Tiefe
var text05 = "&Upsilon;&delta;&rho;&omicron;&sigma;&tau;&alpha;&tau;&iota;&kappa;&#942; "          // Schweredruck (1)
           + "&pi;&#943;&epsilon;&sigma;&eta;:";

var author = "W. Fendt 1999";                                                                      // Autor
var translator = "NHRF 2000";                                                                      // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["\u03AC\u03B3\u03BD\u03C9\u03C3\u03C4\u03BF",                                        // Unbekannt
              "\u03BD\u03B5\u03C1\u03CC",                                                          // Wasser
              "\u03B1\u03B9\u03B8\u03B1\u03BD\u03CE\u03BB\u03B7",                                  // Ethanol
              "\u03B2\u03B5\u03BD\u03B6\u03CE\u03BB\u03B9\u03BF",                                  // Benzol
              "\u03C4\u03B5\u03C4\u03C1\u03B1\u03C7\u03BB\u03C9\u03C1\u03BF"                       // Tetrachlorkohlenstoff (1)                    
            + "\u03BC\u03B5\u03B8\u03AC\u03BD\u03B9\u03BF",                                        // Tetrachlorkohlenstoff (2)
              "\u03C5\u03B4\u03C1\u03AC\u03C1\u03B3\u03C5\u03C1\u03BF\u03C2"];                     // Quecksilber
