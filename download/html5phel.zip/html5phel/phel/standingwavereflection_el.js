// Stehende Welle, Erkl�rung durch Reflexion, griechische Texte (Harilaos Hrisohoidis)
// Letzte �nderung 15.12.2017

// Texte in HTML-Schreibweise:

var text01 = "&Alpha;&nu;&#940;&kappa;&lambda;&alpha;&sigma;&eta;"; 
var text02 = "&sigma;&epsilon; &delta;&epsilon;&mu;&#941;&nu;&omicron; &#940;&kappa;&rho;&omicron;"; 
var text03 = "&sigma;&epsilon; &epsilon;&lambda;&epsilon;&#973;&theta;&epsilon;&rho;&omicron; &#940;&kappa;&rho;&omicron;"; 
var text04 = "&Epsilon;&pi;&alpha;&nu;&alpha;&phi;&omicron;&rho;&#940;"; 
var text05 = ["&Epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;",  
              "&Pi;&alpha;&#973;&sigma;&eta;", 
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"]; 
var text06 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;"; 
var text07 = "&Kappa;&iota;&nu;&omicron;&#973;&mu;&epsilon;&nu;&eta; &epsilon;&iota;&kappa;&#972;&nu;&alpha;"; 
var text08 = "&Delta;&iota;&alpha;&kappa;&rho;&iota;&tau;&#940; &beta;&#942;&mu;&alpha;&tau;&alpha;"; 
var text09 = "&Pi;&rho;&omicron;&sigma;&pi;&#943;&pi;&tau;&omicron;&nu; &kappa;&#973;&mu;&alpha;"; 
var text10 = "&Alpha;&nu;&alpha;&kappa;&lambda;&#974;&mu;&epsilon;&nu;&omicron; &kappa;&#973;&mu;&alpha;"; 
var text11 = "&Delta;&eta;&mu;&iota;&omicron;&upsilon;&rho;&gamma;&omicron;&#973;&mu;&epsilon;&nu;&omicron; "
           + "&Sigma;&tau;&#940;&sigma;&iota;&mu;&omicron; &kappa;&#973;&mu;&alpha;";

var author = "W. Fendt 2003"; 
var translator = "&Chi;. &Chi;&rho;&upsilon;&sigma;&omicron;&chi;&omicron;&#912;&delta;&eta;&sigmaf; 2016";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "N";
var symbolAntiNode = "A";

