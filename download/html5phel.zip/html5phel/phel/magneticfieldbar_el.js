// Magnetfeld eines Stabmagneten, griechische Texte
// Letzte �nderung 31.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Delta;&iota;&alpha;&gamma;&rho;&alpha;&phi;&#942; "                                 // Feldlinien l�schen (1)
           + "&gamma;&rho;&alpha;&mu;&mu;&#974;&nu; &pi;&epsilon;&delta;&#943;&omicron;&upsilon;"; // Feldlinien l�schen (2)
var text02 = "&Sigma;&tau;&rho;&omicron;&phi;&#942; &mu;&alpha;&gamma;&nu;&#942;&tau;&eta;";       // Magnet umdrehen

var author = "W. Fendt 2001";
var translator = "";
