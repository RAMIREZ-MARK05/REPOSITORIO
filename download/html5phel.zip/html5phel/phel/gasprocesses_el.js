// Spezielle Prozesse eines idealen Gases, griechische Texte
// Letzte �nderung 31.01.2022

// Texte in HTML-Schreibweise:

var text01 = "&Iota;&sigma;&omicron;&beta;&alpha;&rho;&#942;&sigmaf; "                             // Isobare Zustands�nderung (1)
           + "&mu;&epsilon;&tau;&alpha;&beta;&omicron;&lambda;&#942;";                             // Isobare Zustands�nderung (2)
var text02 = "&Iota;&sigma;&#972;&chi;&omega;&rho;&eta; "                                          // Isochore Zustands�nderung (1)
           + "&mu;&epsilon;&tau;&alpha;&beta;&omicron;&lambda;&#942;";                             // Isochore Zustands�nderung (2)
var text03 = "&Iota;&sigma;&#972;&theta;&epsilon;&rho;&mu;&eta; "                                  // Isotherme Zustands�nderung (1)
           + "&mu;&epsilon;&tau;&alpha;&beta;&omicron;&lambda;&#942;";                             // Isotherme Zustands�nderung (2)
var text04 = "&Alpha;&rho;&chi;&iota;&kappa;&#942; "                                               // Anfangszustand (1)
           + "&kappa;&alpha;&tau;&#940;&sigma;&tau;&alpha;&sigma;&eta;:";                          // Anfangszustand (2)
var text05 = "&Pi;&#943;&epsilon;&sigma;&eta;:";                                                   // Druck
var text06 = "&#908;&gamma;&kappa;&omicron;&sigmaf;:";                                             // Volumen
var text07 = "&Theta;&epsilon;&rho;&mu;&omicron;&kappa;&rho;&alpha;&sigma;&#943;&alpha;:";         // Temperatur
var text08 = "&Tau;&epsilon;&lambda;&iota;&kappa;&#942; "                                          // Endzustand (1)
           + "&kappa;&alpha;&tau;&#940;&sigma;&tau;&alpha;&sigma;&eta;:";                          // Endzustand (2)
var text09 = "&Alpha;&rho;&chi;&iota;&kappa;&#942; "                                               // Anfangszustand (1)
           + "&kappa;&alpha;&tau;&#940;&sigma;&tau;&alpha;&sigma;&eta;";                           // Anfangszustand (2)
var text10 = "&Epsilon;&kappa;&kappa;&#943;&nu;&eta;&sigma;&eta;";                                 // Start

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var decimalSeparator = ",";                                                                        // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "\u0388\u03C1\u03B3\u03BF";                                                           // Arbeit
var text12 = "\u0398\u03B5\u03C1\u03BC\u03CC\u03C4\u03B7\u03C4\u03B1";                             // W�rme
var text13 = "\u0397 \u03B5\u03C3\u03C9\u03C4\u03B5\u03C1\u03B9\u03BA\u03AE "                      // Die innere ...
           + "\u03B5\u03BD\u03AD\u03C1\u03B3\u03B5\u03B9\u03B1 "                                   // ... Energie ...
           + "\u03C4\u03BF\u03C5 \u03B1\u03B5\u03C1\u03AF\u03BF\u03C5";                            // ... des Gases ...
var text14 = "\u03B1\u03C5\u03BE\u03AC\u03BD\u03B5\u03C4\u03B1\u03B9.";                            // ... vergr��ert sich
var text15 = "\u0397 \u03B5\u03C3\u03C9\u03C4\u03B5\u03C1\u03B9\u03BA\u03AE "                      // Die innere ...
           + "\u03B5\u03BD\u03AD\u03C1\u03B3\u03B5\u03B9\u03B1 "                                   // ... Energie ...
           + "\u03C4\u03BF\u03C5 \u03B1\u03B5\u03C1\u03AF\u03BF\u03C5";                            // ... des Gases ...
var text16 = "\u03B5\u03AF\u03BD\u03B1\u03B9 \u03C3\u03C4\u03B1\u03B8\u03B5\u03C1\u03AE.";         // ist konstant
var text17 = "\u0397 \u03B5\u03C3\u03C9\u03C4\u03B5\u03C1\u03B9\u03BA\u03AE "                      // Die innere ...
           + "\u03B5\u03BD\u03AD\u03C1\u03B3\u03B5\u03B9\u03B1 "                                   // ... Energie ...
           + "\u03C4\u03BF\u03C5 \u03B1\u03B5\u03C1\u03AF\u03BF\u03C5";                            // ... des Gases ...
var text18 = "\u03BC\u03B5\u03B9\u03CE\u03BD\u03B5\u03C4\u03B1\u03B9.";                            // ... verkleinert sich
var text19 = "\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03AE "                            // Druck zu klein (1)
           + "\u03C0\u03AF\u03B5\u03C3\u03B7!";                                                    // Druck zu klein (2)
var text20 = "\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03B7 "                      // Druck zu gro� (1)
           + "\u03C0\u03AF\u03B5\u03C3\u03B7!";                                                    // Druck zu gro� (2)
var text21 = "\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC\u03C2 "                      // Volumen zu klein (1)
           + "\u03CC\u03B3\u03BA\u03BF\u03C2";                                                     // Volumen zu klein (2)
var text22 = "\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF\u03C2 "                // Volumen zu gro� (1)
           + "\u03CC\u03B3\u03BA\u03BF\u03C2";                                                     // Volumen zu gro� (2)
var text23 = "\u03A0\u03BF\u03BB\u03CD \u03C7\u03B1\u03BC\u03B7\u03BB\u03AE "                      // Temperatur zu klein (1)
           + "\u03B8\u03B5\u03C1\u03BC\u03BF\u03BA\u03C1\u03B1\u03C3\u03AF\u03B1";                 // Temperatur zu klein (2)
var text24 = "\u03A0\u03BF\u03BB\u03CD \u03C5\u03C8\u03B7\u03BB\u03AE "                            // Temperatur zu gro� (1)
           + "\u03B8\u03B5\u03C1\u03BC\u03BF\u03BA\u03C1\u03B1\u03C3\u03AF\u03B1";                 // Temperatur zu gro� (2)

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


