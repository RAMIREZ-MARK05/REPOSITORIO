// Zweites Kepler-Gesetz, griechische Texte (nach Wikipedia)
// Letzte �nderung 23.01.2022

// Texte in HTML-Schreibweise:
    
var text02 = "&Mu;&epsilon;&gamma;&#940;&lambda;&omicron;&sigmaf; "            // Gro�e Halbachse (1)
           + "&eta;&mu;&iota;&#940;&xi;&omicron;&nu;&alpha;&sigmaf;:";         // Gro�e Halbachse (2)
var text03 = "&Epsilon;&kappa;&kappa;&epsilon;&nu;&tau;&rho;&#972;&tau;&eta;&tau;&alpha;:"; // Exzentrizit�t
var text04 = ["&Pi;&alpha;&#973;&sigma;&eta;",                                 // Pause
              "&Sigma;&upsilon;&nu;&#941;&chi;&iota;&sigma;&eta;"];            // Weiter
var text05 = "&Alpha;&rho;&gamma;&#942; &kappa;&#943;&nu;&eta;&sigma;&eta;";   // Zeitlupe
var text06 = ["&Alpha;&pi;&#972;&sigma;&tau;&alpha;&sigma;&eta; ",             // Entfernung von der Sonne (1)
              "&alpha;&pi;&#972; &tau;&omicron;&nu; &#942;&lambda;&iota;&omicron;:"]; // Entfernung von der Sonne (2)
var text07 = "&Tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;:";                 // Geschwindigkeit
var text08 = "&Tau;&rho;&#941;&chi;&omicron;&upsilon;&sigma;&alpha; "          // Aktueller Wert (1)
           + "&tau;&iota;&mu;&#942;:";                                         // Aktueller Wert (2)
var text09 = "&Epsilon;&lambda;&#940;&chi;&iota;&sigma;&tau;&omicron;:";       // Minimum
var text10 = "&Mu;&#941;&gamma;&iota;&sigma;&tau;&omicron;:";                  // Maximum
var text11 = "&Tau;&omicron;&mu;&epsilon;&#943;&sigmaf;";                      // Sektoren
var text12 = "&Delta;&iota;&#940;&nu;&upsilon;&sigma;&mu;&alpha; "             // Geschwindigkeitsvektor (1)
           + "&tau;&alpha;&chi;&#973;&tau;&eta;&tau;&alpha;&sigmaf;";          // Geschwindigkeitsvektor (2)

var author = "W. Fendt 2000";

// Symbole und Einheiten:

var decimalSeparator = ",";                                                    // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                                                 // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["\u0395\u03C1\u03BC\u03AE\u03C2",                                // Merkur
              "\u0391\u03C6\u03C1\u03BF\u03B4\u03AF\u03C4\u03B7",              // Venus
              "\u0393\u03B7",                                                  // Erde
              "\u0386\u03C1\u03B7\u03C2",                                      // Mars
              "\u0394\u03AF\u03B1\u03C2",                                      // Jupiter
              "\u039A\u03C1\u03CC\u03BD\u03BF\u03C2",                          // Saturn 
              "\u039F\u03C5\u03C1\u03B1\u03BD\u03CC\u03C2",                    // Uranus 
              "\u03A0\u03BF\u03C3\u03B5\u03B9\u03B4\u03CE\u03BD\u03B1\u03C2",  // Neptun
              "\u03A0\u03BB\u03BF\u03CD\u03C4\u03C9\u03BD\u03B1\u03C2",        // Pluto 
              "\u039A\u03BF\u03BC\u03AE\u03C4\u03B7\u03C2 \u03C4\u03BF\u03C5 " // Halleyscher Komet
            + "\u03A7\u03AC\u03BB\u03B5\u03CB", 
              ""];

// Symbole und Einheiten: 

var auUnicode = "AU";
var symbolPeriod = "T";

