// Einfache Wechselstromkreise, estnische Texte (Kaido Reivelt)
// Letzte �nderung 03.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Takisti";
var text02 = "Kondensaator";
var text03 = "Pool";
var text04 = "Algseis";
var text05 = ["Start", "Peata", "J&auml;tka"];          
var text06 = "Aegluubis";
var text07 = "Sagedus:";
var text08 = "Max. pinge:";
var text09 = "Takistus:";                            
var text10 = "Mahtuvus:";                          
var text11 = "Induktiivsus:"; 
var text12 = "Max. vool:"; 

var author = "W. Fendt 1998,&nbsp; K. Reivelt 2007";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                  
var volt = "V";                                    
var ampere = "A";                                  
var milliampere = "mA";                            
var microampere = "&mu;A";                         
var ohm = "&Omega;";                                
var microfarad = "&mu;F";                           
var henry = "H";                                    

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
