// Ohmsches Gesetz, estnische Texte (Kaido Reivelt)
// Letzte �nderung 03.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Max. pinge:";
var text02 = "Max. vool:";
var text03 = "Suurenda takistust";
var text04 = "V&auml;henda takistust";
var text05 = "Suurenda pinget";
var text06 = "V&auml;henda pinget";

var author = "W. Fendt 1997";
var translator = "K. Reivelt 2007";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Maksimum \u00FCletatud!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
