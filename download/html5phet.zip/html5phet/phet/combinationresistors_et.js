// Kombinationen von Widerst�nden, estnische Texte (Kaido Reivelt)
// Letzte �nderung 19.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Algseis";
var text02 = "Patarei pinge:";
var text03 = "Takistus:";
var text04 = "Lisa takisti (Jada&uuml;hendus)";
var text05 = "Lisa takisti (R&ouml;&ouml;p&uuml;hendus)";
var text06 = "M&otilde;&otilde;teriistad:";
var text07 = "Pinge";
var text08 = "Voolutugevus";

var author = "W. Fendt 2002";
var translator = "K. Reivelt 2007";

// Texte in Unicode-Schreibweise:

var text09 = "Pinge:";
var text10 = "Voolutugevus:";
var text11 = "Takistus:";
var text12 = "Kogutakistus:";
var text13 = "v\u00E4ga v\u00E4ike";
var text14 = "v\u00E4ga suur";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

