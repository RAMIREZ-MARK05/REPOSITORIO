// Kepler-Fernrohr, estnische Texte (Kaido Reivelt)
// Letzte �nderung 05.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Fookuskaugus:"; 
var text02 = "Objektiiv:";
var text03 = "Okulaar:";
var text04 = "Nurgad:";
var text05 = "Suurendus:";

var author = "W. Fendt 2000";
var translator = "K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite

