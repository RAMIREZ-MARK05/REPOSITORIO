// Newtons Wiege, estnische Texte (Kaido Reivelt)
// Letzte �nderung 28.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Algseis";
var text02 = "Start";
var text03 = "Kuulikeste arv:";

var author = "W. Fendt 1997";
var translator = "K. Reivelt 2007";
