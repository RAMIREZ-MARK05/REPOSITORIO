// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, estnische Texte (Kaido Reivelt)
// Letzte �nderung 27.02.2018

// Texte in HTML-Schreibweise:

var text01 = "2 plokki";
var text02 = "4 plokki";
var text03 = "6 plokki";
var text04 = "Kaal:";
var text05 = "Fikseerimata plokkide kaal:";
var text06 = "Vajalik j&otilde;ud:";
var text07 = "Vedruskaala";
var text08 = "J&otilde;uvektorid";

var author = "W. Fendt 1998";
var translator = "K. Reivelt 2007";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                   
