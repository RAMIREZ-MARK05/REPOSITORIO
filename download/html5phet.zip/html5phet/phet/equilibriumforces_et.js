// Gleichgewicht dreier Kr�fte, estnische Texte (Kaido Reivelt)
// Letzte �nderung 27.02.2018

// Texte in HTML-Schreibweise:

var text01 = "J&otilde;ud:";
var text02 = "Vasakule:";
var text03 = "Paremale:";
var text04 = "Below:";
var text05 = "J&otilde;udude r&ouml;&ouml;pk&uuml;lik";
var text06 = "Nurgad:";
var text07 = "Vasakule:";
var text08 = "Paremale:";

var author = "W. Fendt 2000";
var translator = "K. Reivelt 2007";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00B0";                              
var newton = "N";                                   
