// Schwebungen, estnische Texte (Kaido Reivelt)
// Letzte �nderung 01.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Algseis";
var text02 = ["Start", "Peata", "J&auml;tka"];
var text03 = "Aegluubis";
var text04 = "Sagedused:";
var text05 = "1. laine:";
var text06 = "2. laine:";

var author = "W. Fendt 2001"; 
var translator = "K. Reivelt 2007";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



