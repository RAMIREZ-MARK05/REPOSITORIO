// Spezielle Prozesse eines idealen Gases, estnische Texte (Kaido Reivelt)
// Letzte �nderung 16.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Isobaar";
var text02 = "Isohoor";
var text03 = "Isoterm";
var text04 = "Algolek:";
var text05 = "R&otilde;hk:";
var text06 = "Ruumala:";
var text07 = "Temperatuur:";
var text08 = "L&otilde;ppolek:";
var text09 = "Algolek";
var text10 = "Start";

var author = "W. Fendt 1999,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "T\u00F6\u00F6";
var text12 = "Soojus";
var text13 = "Gaasi siseenergia";
var text14 = "kasvab.";
var text15 = "Gaasi siseenergia";
var text16 = "ei muutu.";
var text17 = "Gaasi siseenergia";
var text18 = "kahaneb.";
var text19 = "R\u00F5hk liiga v\u00E4ike!";
var text20 = "R\u00F5hk liiga suur!";
var text21 = "Ruumala liiga v\u00E4ike!";
var text22 = "Ruumala liiga suur!";
var text23 = "Temperatuur liiga v\u00E4ike!";
var text24 = "Temperatuur liiga suur!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


