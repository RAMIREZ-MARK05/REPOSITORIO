// Kettenkarussell, estnische Texte (Kaido Reivelt)
// Letzte �nderung 28.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Karussell";
var text02 = "Karussell koos j&otilde;ududega";
var text03 = "Joonis";
var text04 = "Arvv&auml;&auml;rtused";
var text05 = ["Peata", "J&auml;tka"];
var text06 = "Aegluubis";
var text07 = "Periood:";
var text08 = ["Vahekaugus kinnituskohtade", "ja p&ouml;&ouml;rlemistelje vahel:"]; 
var text09 = "K&ouml;ite pikkus:";
var text10 = "Mass:";

var author = "W. Fendt 1999,&nbsp; K. Reivelt 2007";

// Texte in Unicode-Schreibweise:

var text11 = "Sagedus:";
var text12 = "Nurkkiirus:";
var text13 = "Raadius:";
var text14 = "Kiirus:";
var text15 = "Nurk:";
var text16 = "Kaal:";
var text17 = "Keskt\u00F5mbej\u00F5ud:";
var text18 = "T\u00F5mme k\u00F6ies:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




