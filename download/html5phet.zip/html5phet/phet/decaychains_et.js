// Zerfallsreihen, estnische Texte (Kaido Reivelt, unvollst�ndig!)
// Letzte �nderung 07.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Decay chain:"; // ???
var text03 = "J&auml;rgmine lagunemine";

var author = "W. Fendt 1998"; 
var translator = "K. Reivelt 2007";

// Texte in Unicode-Schreibweise:

var text02 = ["Tooriumi ahel", "Neptuuniumi ahel", "Uraan-raadium ahel", "Uraan-aktiinium ahel"];          





