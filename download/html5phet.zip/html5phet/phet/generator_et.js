// Generator, estnische Texte (Kaido Reivelt)
// Letzte �nderung 03.03.2018

// Texte in HTML-Schreibweise;

var text01 = "Ilma kommutaatorita";
var text02 = "Kommutaatoriga";
var text03 = "Muuda suunda";
var text04 = ["Start", "Peata", "J&auml;tka"];
var text05 = "Liikumissuund";
var text06 = "Magnetv&auml;li";
var text07 = "Indutseeritud vool";

var author = "W. Fendt 1998";  
var translator = "K. Reivelt 2007";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "p/min";                          // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
