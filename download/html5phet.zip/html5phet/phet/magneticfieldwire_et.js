// Magnetfeld eines geraden stromdurchflossenen Leiters, estnische Texte (Kaido Reivelt)
// Letzte �nderung 02.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Muuda voolusuunda";

var author = "W. Fendt 2000";
var translator = "K. Reivelt 2007";
