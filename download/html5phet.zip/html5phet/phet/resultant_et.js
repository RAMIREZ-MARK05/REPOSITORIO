// Ersatzkraft mehrerer Kr�fte, enstnische Texte (Kaido Reivelt)
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "J&otilde;udude arv:";
var text02 = "Arvuta resultant";
var text03 = "Eemalda konstruktsioon";

var author = "W. Fendt 1998";
var translator = "K. Reivelt 2007";
