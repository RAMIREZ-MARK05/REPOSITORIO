// Photoelektrischer Effekt, estnische Texte (Kaido Reivelt, unvollst�ndig!)
// Letzte �nderung 06.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Katoodi materjal:";
var text03 = "Spektrijoon (Hg):";
var text04 = "Aeglustuspinge:";
var text05 = "Sagedus:";
var text06 = ["Footoni", "energia:"];
var text07 = "V&auml;ljumist&ouml;&ouml;:";
var text08 = ["Elektroni maksimaalne kineetiline", "energia:"];
var text09 = "Uus m&otilde;&otilde;tmisseeria";

var author = "W. Fendt 2000,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                   
var terahertz = "THz";                             
var electronvolt = "eV";                           

// Texte in Unicode-Schreibweise:

var text02 = ["tseesium", "naatrium"];
var text10 = ["kollane", "roheline", "violetne", "ultravioletne", "ultravioletne"];
var text11 = "(THz)";
var text12 = "(V)";
var text13 = [
             ["Footoni energia pole piisav elektroni", "v\u00E4ljal\u00F6\u00F6miseks."],
             ["T\u00F5sta aeglustuspinget seni, kuni \u00FCkski", "elektron ei j\u00F5u anoodile!"],
             ["Aeglustuspinge on nii k\u00F5rge, et elektronid", "naasevad katoodile."],
             ["J\u00E4tka m\u00F5\u00F5tmisi m\u00F5ne muu", "spektrijoonega!"],
             ["J\u00E4tka m\u00F5\u00F5tmisi m\u00F5ne muu", "katoodimatejaliga!"],
             ["The measurements are finished."] // ???
             ];

var symbolCathode = "K";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
