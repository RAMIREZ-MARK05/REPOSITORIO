// Kombinationen von Widerst�nden, Spulen und Kondensatoren, estnische Texte (Kaido Reivelt)
// Letzte �nderung 21.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Vahelduvvoolu allikas:";
var text02 = "Pinge:";
var text03 = "Sagedus:";
var text04 = "Komponent:";
var text05 = ["Takisti", "Pool", "Kondensaator"];
var text06 = ["Takistus:", "Induktiivsus:", "Mahtuvus:"];
var text07 = "Asenda";
var text08 = "Lisa (jadamisi)";
var text09 = "Lisa (r&ouml;&ouml;biti)";
var text10 = "Eemalda";
var text11 = "M&otilde;&otilde;teriistad:";
var text12 = "Pinge";
var text13 = "Voolutugevus";

var author = "W. Fendt 2004";
var translator = "";

// Texte in Unicode-Schreibweise:

var text14 = "Pinge:";
var text15 = "Voolutugevus:";
var text16 = "Kompleksne n\u00E4ivtakistus:";
var text17 = "N\u00E4ivtakistus:";
var text18 = "Faasinurk:";
var text19 = "v\u00E4ga v\u00E4ike";                       // Stromst�rke Voltmeter
var text20 = "v\u00E4ga v\u00E4ike";                       // Spannung Amperemeter
var text21 = "v\u00E4ga v\u00E4ike";                       // Impedanz/Widerstand Amperemeter
var text22 = "v\u00E4ga suur";                             // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)