// Kr�fte an der schiefen Ebene, estnische Texte (Kaido Reivelt)
// Letzte �nderung 27.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Algseis";
var text02 = ["Start", "Peata", "J&auml;tka"];
var text03 = "Aegluubis";
var text04 = "Vedruskaala";
var text05 = "J&otilde;uvektorid";
var text06 = "Kaldenurk:";
var text07 = "Kaal:";
var text08 = "J&otilde;u paralleelkomponent:";
var text09 = "J&otilde;u ristkomponent:";
var text10 = "H&otilde;&otilde;rdetegur:";
var text11 = "H&otilde;&otilde;rdej&otilde;ud:";
var text12 = "Vajalik j&otilde;ud:";

var author = "W. Fendt 1999,&nbsp; K. Reivelt 2007";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                              
var newton = "N";                                  
