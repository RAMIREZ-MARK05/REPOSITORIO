// Bewegung mit konstanter Beschleunigung, estnische Texte (Kaido Reivelt)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Algseis";
var text02 = ["Start", "Peata", "J&auml;tka"];
var text03 = "Aegluubis";
var text04 = "Algkoordinaat:";
var text05 = "Algkiirus:";
var text06 = "Kiirendus:";
var text07 = "Kiirusvektor";
var text08 = "Kiirendusvektor";

var author = "W. Fendt 2000";
var translator = "K. Reivelt 2007";

// Texte in Unicode-Schreibweise:

var text09 = "(s)";                                        // Einheitenangabe f�r Zeit-Achse
var text10 = "(m)";                                        // Einheitenangabe f�r Weg-Achse
var text11 = "(m/s)";                                      // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(m/s\u00B2)";                                // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                     
var meter = "m";                                      
var meterPerSecond = "m/s";                            
var meterPerSecond2 = "m/s\u00B2";                     
