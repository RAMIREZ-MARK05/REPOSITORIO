// Gekoppelte Pendel, estnische Texte (Kaido Reivelt)
// Letzte �nderung 01.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Algseis";                           
var text02 = ["Start", "Peata", "J&auml;tka"];                
var text03 = "Aegluubis";
var text04 = "Algasend:";

var author = "W. Fendt 1998";
var translator = "K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      

// Texte in Unicode-Schreibweise:

var text05 = "Pendel 1";                                   // Erstes Pendel (links)
var text06 = "Pendel 2";                                   // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
