// Erstes Kepler-Gesetz, estnische Texte (Kaido Reivelt)
// Letzte �nderung 28.02.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Pikem pooltelg:";
var text03 = "Ekstsentrilisus:";
var text04 = "L&uuml;hem pooltelg:";
var text05 = ["Peata", "J&auml;tka"];
var text06 = "Aegluubis";
var text07 = "Kaugus P&auml;ikesest:";
var text08 = "Hetkel:";
var text09 = "V&auml;him:";
var text10 = "Suurim:";
var text11 = "Elliptiline orbiit";
var text12 = "Teljed";
var text13 = "&Uuml;hendusjooned fookusteni";

var author = "W. Fendt 2000,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Merkuur", "Veenus", "Maa", "Marss", "Jupiter", "Saturn", "Uraan", "Neptuun",
              "Pluuto", "Halley komeet", ""];

var text14 = "P\u00E4ike";
var text15 = "Planeet";
var text16 = "Komeet";
var text17 = "Periheel";
var text18 = "Afeel";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "AU";

