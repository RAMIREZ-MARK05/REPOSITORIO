// Interferenz zweier Kreis- oder Kugelwellen, estnische Texte (Kaido Reivelt)
// Letzte �nderung 01.03.2018

// Texte in HTML-Schreibweise:

var text01 = ["Peata", "J&auml;tka"];                      // Schaltknopf (Pause/Weiter)
var text02 = "Aegluubis";
var text03 = "Kahe laineallika vaheline";
var text04 = "kaugus:";
var text05 = "Lainepikkus:";

var author = "W. Fendt 1999";
var translator = "K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                              

// Texte in Unicode-Schreibweise:

var text06 = "Teepikkuste erinevus:";
var text07 = "Konstruktiivne interferents (maksimaalne amplituud)";
var text08 = "Destruktiivne interferents (minimaalne amplituud)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03BB";                           // Symbol f�r Wellenl�nge (Lambda)
