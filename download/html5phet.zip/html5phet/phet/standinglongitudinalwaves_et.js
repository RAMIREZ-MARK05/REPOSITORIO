// Stehende L�ngswellen, estnische Texte (Kaido Reivelt)
// Letzte �nderung 01.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Toru t&uuml;&uuml;p:";
var text02 = "m&otilde;lemad otsad avatud";
var text03 = "&uuml;ks ots avatud";
var text04 = "m&otilde;lemad otsad suletud";
var text05 = "V&otilde;nkumine:";
var text06 = ["p&otilde;hitoon",  "1. &uuml;lemtoon",      // Bezeichnungen der Eigenschwingungen 
              "2. &uuml;lemtoon", "3. &uuml;lemtoon", 
              "4. &uuml;lemtoon", "5. &uuml;lemtoon"];
var text07 = "Madalam";
var text08 = "K&otilde;rgem";
var text09 = "Toru pikkus:";
var text10 = "Lainepikkus:";
var text11 = "Sagedus:";

var author = "W. Fendt 1998,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                           // Meter
var hertz = "Hz";                                          // Hertz

// Texte in Unicode-Schreibweise:

var text12 = "Osakeste \u00FCmberpaiknemine";              // �berschrift des ersten Diagramms
var text13 = "Erinevus keskmisest r\u00F5hust";            // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "S";                                      // Symbol f�r Knoten
var symbolAntinode = "P";                                  // Symbol f�r Bauch

