// Gleichstrom-Elektromotor, estnische Texte (Kaido Reivelt)
// Letzte �nderung 03.03.2018

// Texte in HTML-Schreibweise;

var text01 = "Reset";
var text02 = ["Start", "Peata", "J&auml;tka"];             
var text03 = "Muuda suunda";
var text04 = "Voolusuund";
var text05 = "Magnetv&auml;li";
var text06 = "M&otilde;juv j&otilde;ud";

var author = "W. Fendt 1997";             
var translator = "K. Reivelt 2007";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "p/min";                          // Umdrehungen pro Minute
