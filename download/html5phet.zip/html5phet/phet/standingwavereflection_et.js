// Stehende Welle, Erkl�rung durch Reflexion, estnische Texte (Kaido Reivelt)
// Letzte �nderung 01.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Peegeldus";
var text02 = "kinnitatud otsalt";
var text03 = "lahtiselt otsalt";
var text04 = "Reset";
var text05 = ["Start", "Peata", "J&auml;tka"];
var text06 = "Aegluubis";
var text07 = "Animatsioon";
var text08 = "Sammude kaupa";
var text09 = "Algne laine";
var text10 = "Peegeldunud laine";
var text11 = "Summaarne laine";

var author = "W. Fendt 2003"; 
var translator = "K. Reivelt 2007";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "S";
var symbolAntiNode = "P";

