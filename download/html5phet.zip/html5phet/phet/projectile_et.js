// Schiefer Wurf, estnische Texte (Kaido Reivelt)
// Letzte �nderung 28.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Algseis";                    
var text02 = ["Start", "Peata", "J&auml;tka"];          
var text03 = "Aegluubis";
var text04 = "Algk&otilde;rgus:";
var text05 = "Algkiirus:";
var text06 = "Kaldenurk:";
var text07 = "Mass:"; 
var text08 = "Raskuskiirendus:";
var text09 = "Asukoht";
var text10 = "Kiirus";
var text11 = "Kiirendus";
var text12 = "J&otilde;ud";
var text13 = "Energia";

var author = "W. Fendt 2000,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                     
var meterPerSecond = "m/s";                           
var meterPerSecond2 = "m/s&sup2;";                    
var kilogram = "kg";                                  
var degree = "&deg;";                                 

// Texte in Unicode-Schreibweise:

var text14 = "(m)";                                        // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Asukoht:";
var text16 = "(horisontaalne)";
var text17 = "(vertikaalne)";
var text18 = "Horisontaalne kaugus:";
var text19 = "Suurim k\u00F5rgus:";
var text20 = "Aeg:";
var text21 = "Kiirusvektori komponendid:";
var text22 = "Kiiruse arvv\u00E4\u00E4rtus:";
var text23 = "Kaldenurk:";
var text24 = "Kiirendus:";
var text25 = "J\u00F5ud:";
var text26 = "Kineetiline energia:";
var text27 = "Potentsiaalne energia:";
var text28 = "Koguenergia:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                             
var secondUnicode = "s";                            
var meterPerSecondUnicode = "m/s";                  
var meterPerSecond2Unicode = "m/s\u00B2";           
var newtonUnicode = "N";                            
var jouleUnicode = "J";                             
var degreeUnicode = "\u00B0";                       



