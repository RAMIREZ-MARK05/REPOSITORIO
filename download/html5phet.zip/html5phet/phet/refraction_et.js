// Reflexion und Brechung von Licht, estnische Texte (Kaido Reivelt)
// Letzte �nderung 04.03.2018

// Texte in HTML-Schreibweise:
    
var text01 = "1. murdumisn&auml;itaja:";
var text02 = "2. murdumisn&auml;itaja:";
var text03 = "Langemisnurk:";
var text04 = "Peegeldumisnurk:";
var text05 = "Murdumisnurk:";    
var text06 = ["T&auml;ieliku sisepeegelduse", "piirdenurk:"];

var author = "W. Fendt 1997,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                              

// Texte in Unicode-Schreibweise:

var text07 = [["vaakum", "1"], ["\u00F5hk", "1.0003"],     // Stoffe und Brechungsindizes
    ["vesi", "1.33"], ["etanool", "1.36"],
    ["kvartsklaas", "1.46"], ["benseen", "1.49"], 
    ["kroonklaas N-K5", "1.52"], ["haliit", "1.54"], 
    ["flintklaas LF5", "1.58"], ["kroonklaas N-SK4", "1.61"],
    ["flintklaas SF6", "1.81"], ["teemant", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                       
