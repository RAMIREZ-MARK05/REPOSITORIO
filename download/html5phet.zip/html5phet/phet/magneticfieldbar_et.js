// Magnetfeld eines Stabmagneten, estnische Texte (Kaido Reivelt)
// Letzte �nderung 01.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Eemalda j&otilde;ujooned";
var text02 = "P&ouml;&ouml;ra magnetit";

var author = "W. Fendt 2001";
var translator = "K. Reivelt 2007";
