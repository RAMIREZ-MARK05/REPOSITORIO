// Elektromagnetischer Schwingkreis, estnische Texte (Kaido Reivelt, unvollst�ndig!)
// Letzte �nderung 03.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Peata", "J&auml;tka"];
var text03 = "Aegluubis (10 &times;)";
var text04 = "Aegluubis (100 &times;)";
var text05 = "Mahtuvus:";
var text06 = "Induktiivsus:";
var text07 = "Takistus:";
var text08 = "Max. pinge:";
var text09 = "Pinge, voolutugevus";
var text10 = "Energia";

var author = "W. Fendt 1999,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                     
var henry = "H";                              
var ohm = "&Omega;";                          
var volt = "V";                               

// Texte in Unicode-Schreibweise:

var text11 = "V\u00F5nkeperiood:";
var text12 = "Elektriv\u00E4lja energia:";
var text13 = "Magnetv\u00E4lja energia:";
var text14 = "Internal energy:"; // ???
var text15 = "Sumbumatu v\u00F5nkumine";
var text16 = "Sumbuv v\u00F5nkumine";
var text17 = "Kriitilne sumbumine";
var text18 = "\u00DClekriitiline sumbumine";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                  
var voltUnicode = "V";                             
var ampere = "A";                                  
var joule = "J";                                   
