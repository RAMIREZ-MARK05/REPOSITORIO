// Leiterschaukel-Versuch zur Lorentzkraft, estnische Texte (Kaido Reivelt)
// Letzte �nderung 02.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Sees / V&auml;ljas";
var text02 = "Muuda voolusuunda";
var text03 = "P&ouml;&ouml;ra magnetit";
var text04 = "Voolu suund";
var text05 = "Magnetv&auml;li";
var text06 = "M&otilde;juv j&otilde;ud";

var author = "W. Fendt 1998";
var translator = "K. Reivelt 2007";
