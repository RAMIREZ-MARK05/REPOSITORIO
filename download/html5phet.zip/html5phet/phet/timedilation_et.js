// Beispiel zur Zeitdilatation, estnische Texte (Kaido Reivelt)
// Letzte �nderung 06.03.2018

// Texte in HTML-Schreibweise:

var text01 = "V&auml;henda kiirust";
var text02 = "Suurenda kiirust";
var text03 = "Algseis";
var text04 = ["Start", "Peata", "J&auml;tka"];

var author = "W. Fendt 1997,&nbsp; K. Reivelt 2007";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "Kaugus:";
var text06 = "5 valgustundi";
var text07 = "Kiirus:";
var text08 = "Lennuaeg (Maa tausts\u00FCst.):";
var text09 = "tundi";
var text10 = "Lennuaeg (kosmoselaeva tausts\u00FCst.):";