// Zerlegung einer Kraft in zwei Komponenten, estnische Texte (Kaido Reivelt)
// Letzte �nderung 27.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Antud j&otilde;u";                       
var text02 = "suurus:";
var text03 = "Nurkade suurused:";
var text04 = "1. nurk:";
var text05 = "2. nurk:";
var text06 = "Komponentide suurused:";
var text07 = "1. komponent:";
var text08 = "2. komponent:";
var text09 = "Arvuta komponendid";
var text10 = "Eemalda konstruktsioon";

var author = "W. Fendt 2003";
var translator = "K. Reivelt 2007";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                           
var newton = "N";                               

// Texte in Unicode-Schreibweise:

var text11 = "1. komponent";                               // Text f�r erste Komponente
var text12 = "2. komponent";                               // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                        