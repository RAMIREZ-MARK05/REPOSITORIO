// Druckdose (hydrostatischer Druck), estnische Texte (Kaido Reivelt)
// Letzte �nderung 05.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Vedelik:";
var text03 = "Tihedus:";
var text04 = "S&uuml;gavus:";
var text05 = "H&uuml;drostaatiline r&otilde;hk:";

var author = "W. Fendt 1999";                              // Autor
var translator = "K. Reivelt 2007";                        // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["teadmata", "vesi", "etanool", "benseen", "tetraklorometaan", "elavh\u00F5be"]; 
