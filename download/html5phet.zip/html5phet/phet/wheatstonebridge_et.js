// Wheatstonesche Br�ckenschaltung, estnische Texte (Kaido Reivelt)
// Letzte �nderung 03.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Uus m&otilde;&otilde;tmine";
var text02 = "P&uuml;sitakisti:";
var text03 = "Potentsiomeeter:";
var text04 = "Liugkontakti asend:";
var text05 = "Vooluallika pinge:";
var text06 = "M&otilde;&otilde;teriista takistus:";
var text07 = "Arvuta takistus";
var text08 = "N&auml;ita pinget";
var text09 = "N&auml;ita voolutugevust";
var author = "W. Fendt 2006,&nbsp; K. Reivelt 2007";

// Texte in Unicode-Schreibweise:

var text10 = ["Liiguta liugkontakti",
  	          "kuni voolutugevus on null!"];
var text11 = "N\u00FC\u00FCd on v\u00F5imalik arvutada takistus.";         

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var milliampere = "mA";
var ohm = "\u03A9";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00D7";                              
