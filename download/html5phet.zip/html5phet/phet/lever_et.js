// Hebelgesetz, estnische Texte (Kaido Reivelt)
// Letzte �nderung 27.02.2018

// Texte in Unicode-Schreibweise:

var text01 = "Vasaku poole j\u00F5umoment:";
var text02 = "Parema poole j\u00F5umoment:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "M_1";                              // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "M_2";                             // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

var newton = "N";
var meter = "m";

var author = "W. Fendt 1997,\u0020 K. Reivelt 2007";       // Autor (und �bersetzer)
