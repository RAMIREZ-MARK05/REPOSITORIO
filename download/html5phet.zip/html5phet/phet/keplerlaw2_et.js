// Zweites Kepler-Gesetz, estnische Texte (Kaido Reivelt)
// Letzte �nderung 01.03.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Pikem pooltelg:";
var text03 = "Ekstsentrilisus:";
var text04 = ["Peata", "J&auml;tka"];
var text05 = "Aegluubis";
var text06 = ["Kaugus", "p&auml;ikesest:"];
var text07 = "Kiirus:";
var text08 = "Hetkel:";
var text09 = "V&auml;him:";
var text10 = "Suurim:";
var text11 = "Sektorid";
var text12 = "Kiirusvektor";

var author = "W. Fendt 2000,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Merkuur", "Veenus", "Maa", "Marss", "Jupiter", "Saturn", "Uraan", "Neptuun",
              "Pluuto", "Halley komeet", ""];

// Symbole und Einheiten: 

var auUnicode = "AU";
var symbolPeriod = "T";

