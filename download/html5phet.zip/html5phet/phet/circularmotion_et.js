// Kreisbewegung mit konstanter Winkelgeschwindigkeit, estnische Texte (Kaido Reivelt)
// Letzte �nderung 28.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Algseis";
var text02 = ["Start", "Peata", "J&auml;tka"];
var text03 = "Aegluubis";
var text04 = "Raadius:";
var text05 = "Periood:";
var text06 = "Mass:";
var text07 = "Asukoht";
var text08 = "Kiirus";
var text09 = "Kiirendus";
var text10 = "J&otilde;ud";

var author = "W. Fendt 2007";
var translator = "K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                   
var second = "s";                                  
var kilogram = "kg";                               

// Texte in Unicode-Schreibweise:

var text11 = "Asukoht:";
var text12 = "Kiirus:";
var text13 = "Nurkkiirus:";
var text14 = "Keskt\u00F5mbekiirendus:";
var text15 = "Keskt\u00F5mbej\u00F5ud:";
var text16 = "(s)";
var text17 = "(m)";
var text18 = "(m/s)";
var text19 = "(m/s\u00B2)";
var text20 = "(N)";
var text21 = "(x komponent)";
var text22 = "(y komponent)";
var text23 = "(suurus)";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03C9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "m";                           
var meterPerSecond = "m/s";                       
var meterPerSecond2 = "m/s\u00B2";                
var newton = "N";                                 
var radPerSecond = "rad/s";                       




