// Potentiometerschaltung, estnische Texte (Kaido Reivelt)
// Letzte �nderung 03.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Vooluallika pinge:";
var text02 = "Potentsiomeeter:";
var text03 = "Liugkontakti asend:";
var text04 = "P&uuml;sitakisti:";
var text05 = "N&auml;ita pinget";
var text06 = "N&auml;ita voolutugevust";
var author = "W. Fendt 2006";
var translator = "K. Reivelt 2007";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "U";                                  // Symbol f�r Spannung
var symbolVoltage2 = "a";                                  // Index f�r Verbraucher
                      
