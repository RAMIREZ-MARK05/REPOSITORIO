// Elastischer und unelastischer Sto�, estnische Texte (Kaido Reivelt)
// Letzte �nderung 28.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Elastne p&otilde;rge";
var text02 = "Mitteelastne p&otilde;rge";
var text03 = "Algseis";
var text04 = "Start";
var text05 = "Aegluubis";
var text06 = "Vagun 1:";
var text07 = "Vagun 2:";
var text08 = "Mass:";
var text09 = "Kiirus:";
var text10 = "Kiirus";
var text11 = "Impulss";
var text12 = "Kineetiline energia";

var author = "W. Fendt 1998,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                          

// Texte in Unicode-Schreibweise:

var text13 = "Vagun 1:";
var text14 = "Vagun 2:";
var text15 = "Kiirused enne p\u00F5rget:";
var text16 = "Kiirused p\u00E4rast p\u00F5rget:";
var text17 = "Impulss enne p\u00F5rget:";
var text18 = "Impulls p\u00E4rast p\u00F5rget:";
var text19 = "Kineetiline energia enne p\u00F5rget:";
var text20 = "Kineetiline energia p\u00E4rast p\u00F5rget:";
var text21 = "Koguimpulss:";
var text22 = "Kogu kineetiline energia:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                     
var kilogramMeterPerSecond = "kg m/s";                 
var joule = "J";                                       
