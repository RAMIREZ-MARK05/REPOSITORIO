// Beispiel zum Doppler-Effekt, estnische Texte (Kaido Reivelt)
// Letzte �nderung 01.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Alusta uuesti";
var text02 = ["Peata", "J&auml;tka"]; 

var author = "W. Fendt 1998";
var translator = "K. Reivelt 2007";

// Texte in Unicode-Schreibweise:              

var text03 = [                                             // Erl�uterungstext
  ["Seni, kui kiirabiauto",
  "l\u00E4heneb inimesele, on",
  "lainefrontide vahelised",
  "kaugused l\u00FChenenud."],
  ["N\u00FC\u00FCd s\u00F5iduk eemaldub",
  "inimesest. Seet\u00F5ttu on",
  "lainefrontide vahelised",
  "kaugused pikenenud."]];


  

