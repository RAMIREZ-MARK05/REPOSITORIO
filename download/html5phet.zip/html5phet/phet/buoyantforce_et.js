// Messung der Auftriebskraft, estnische Texte (Kaido Reivelt)
// Letzte �nderung 01.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Keha p&otilde;hjapindala:"; 
var text02 = "Keha k&otilde;rgus:";
var text03 = "Keha tihedus:";
var text04 = "Vedeliku tihedus:";   
var text05 = "S&uuml;gavus:";
var text06 = "Asendatud ruumala:"; 
var text07 = "&Uuml;lesl&uuml;kkej&otilde;ud:";
var text08 = "Keha kaal:";
var text09 = "M&otilde;&otilde;detud j&otilde;ud:";
var text10 = "M&otilde;&otilde;tepiirkond:";

var author = "W. Fendt 1998,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Maksimum \u00FCletatud!";
