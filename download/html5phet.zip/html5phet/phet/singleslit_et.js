// Beugung von Licht am Einfachspalt, estnische Texte (Kaido Reivelt)
// Letzte �nderung 06.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Lainepikkus:";
var text02 = "Pilu laius:";
var text03 = "Nurk:";
var text04 = "Maksimum:";
var text05 = "Miinimum:";
var text06 = "Suhteline intensiivsus:";
var text07 = "Difraktsioonmuster";
var text08 = "Intensiivsuse graafik";

var author = "W. Fendt 2003,&nbsp; K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
