// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), estnische Texte (Kaido Reivelt)
// Letzte �nderung 05.03.2018

// Texte in HTML-Schreibweise:

var text01 = "Algseis";
var text02 = "J&auml;rgmine samm";
var text03 = ["Peata", "J&auml;tka"];                  
var text04 = "1. murdumisn&auml;itaja:";
var text05 = "2. murdumisn&auml;itaja:";
var text06 = "Langemisnurk:";

var author = "W. Fendt 1998";
var translator = "K. Reivelt 2007";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                           

// Texte in Unicode-Schreibweise:

var text07 = [

  ["Tasalaine front",                                      // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "j\u00F5uab diagonaalselt kahe",
   "keskkonna piirpinnale.",
   "Laine levimise kiirus",
   "keskkondades on erinev."],
   
  ["Tasalaine front j\u00F5uab",                           // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "kahe keskkonna piirpinnale",
   "olles sellega risti.",
   "Laine levimise kiirus",
   "keskkondades on erinev."],
 
  ["Keskkondade piirpinna punktid",                        // i == 2 (step == 1, n1 > n2) 
   "k\u00E4ituvad lainefrondi nendeni",
   "j\u00F5udmisel Huygensi printsiibi",
   "kohaselt. Igat punkti v\u00F5ib",
   "k\u00E4sitleda iseseisva sf\u00E4\u00E4rilise",
   "laine allikana.",
   "Keskkonnas 2 liiguvad need",
   "elementaarlained kiiremini,",
   "sest murdumisn\u00E4itaja",
   "on v\u00E4iksem."],
   
  ["Keskkondade piirpinna punktid",                        // i == 3 (step == 1, n1 < n2) 
   "k\u00E4ituvad lainefrondi nendeni",
   "j\u00F5udmisel Huygensi printsiibi",
   "kohaselt. Igat punkti v\u00F5ib",
   "k\u00E4sitleda iseseisva sf\u00E4\u00E4rilise",
   "laine allikana.",
   "Keskkonnas 2 liiguvad need",
   "elementaarlained aeglasemalt,",
   "sest murdumisn\u00E4itaja",
   "on suurem."], 

  ["K\u00F5igi elementaarlainete",                         // i == 4 (step == 2, total == false, eps1 > 0) 
   "superpositsiooni t\u00F5ttu tekib",
   "uus tasalaine. M\u00E4rkame, et",
   "\u00FChest keskkonnast teise",
   "levimisel tasalaine",
   "suund muutub."], 

  ["K\u00F5igi elementaarlainete",                         // i == 5 (step == 2, total == false, eps1 == 0)
   "superpositsiooni t\u00F5ttu",
   "tekib uus tasalaine."], 
   
  ["K\u00F5igi elementaarlainete",                         // i == 6 (step == 2, total == true)
   "superpositsiooni t\u00F5ttu tekib",
   "uus tasalaine Keskkonnas 1",
   "(peegeldunud laine).",
   "Laine ei kandu \u00FCle",
   "Keskkonda 2 (t\u00E4ielik",
   "sisepeegeldumine)."],
   
  ["Laine levimise suund",                                 // i == 7 (step == 3)
   "on n\u00FC\u00FCd n\u00E4idatud.",
   "Selleks on lainefrondiga",
   "ristine joon."], 

  ["Tavaliselt lainefronte \u00FCksikuna",                 // i == 8 (step == 4)
   "ei esine!"],
   
  ["Kui keskkondade",                                      // i == 9 (n1 == n2)
   "murdumisn\u00E4itajad",                
   "on v\u00F5rdsed, siis",
   "ei juhtu midagi."]];
          
var text08 = "Langemisnurk:"; 
var text09 = "Peegeldumisnurk:";
var text10 = "Murdumisnurk:"; 
var text11 = "Keskkond 1";
var text12 = "Keskkond 2";      
var text13 = ["T\u00E4ieliku sisepeegeldumise", "piirdenurk:"];

// Einheiten:

var degreeUnicode = "\u00B0";              
