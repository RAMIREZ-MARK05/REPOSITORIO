// 1. und 2. Ableitungsfunktion, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Equation of the function:";
var text02 = "f(x) =";
var text03 = "1st derivative";
var text04 = "2nd derivative";
var text05 = "Left border:";
var text06 = "Right border:";
var text07 = "Lower border:";
var text08 = "Upper border:";
var text09 = "Draw";

var author = "W. Fendt 1999";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text10 = "Incorrect function term!";
var text11 = "Differentiation error!";

var symbolX = "x";
var symbolY = "y";
