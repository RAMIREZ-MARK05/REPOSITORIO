// Zwillingskreise des Archimedes, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Auxiliary lines:";
var text02 = "left side";
var text03 = "right side";

var author = "W. Fendt 2000";
