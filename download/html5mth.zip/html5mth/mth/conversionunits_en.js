// Umrechnung von Einheiten, englische Texte
// Letzte �nderung 10.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Start";
var text03 = "Length";
var text04 = "Area";
var text05 = "Volume";
var text06 = "Mass";
var text07 = "Time";
var text08 = "Level:";
var text09 = ["1 problem", 
              "x problems"];  
var text10 = ["1 hit", 
              "x hits"];        
     
var author = "W. Fendt 2001";                              // Autor (und �bersetzer)

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

