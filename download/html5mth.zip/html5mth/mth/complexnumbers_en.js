// Rechnen mit komplexen Zahlen, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Operation:";
var text02 = "Addition";
var text03 = "Subtraction";
var text04 = "Multiplication";
var text05 = "Division";
var text06 = "Coordinate System:";
var text07 = "Cartesian Coordinates";
var text08 = "Polar Coordinates";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1998";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "not defined!";

var symbolOperation = ["+", "\u2212", "x", "\u00F7"];      // Rechenzeichen
