// Kreiszahl Pi, englische Texte
// Letzte �nderung 03.02.2021

// Texte in HTML-Schreibweise:

var text01 = "Number of vertices:";
var text02 = "Square";
var text03 = "Hexagon";
var text04 = "Double number of vertices";
var text05 = "Length of one side";
var text06 = "Circumference";
var text07 = "Area";

var author = "W. Fendt 2002";
var translator = "";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ".";

var text11 = "Length of one side (inscribed polygon):";
var text12 = "Length of one side (circumscribed polygon):";
var text13 = "Circumference of the inscribed polygon:";
var text14 = "Circumference of the circumscribed polygon:";
var text15 = "Area of the inscribed polygon:";
var text16 = "Area of the circumscribed polygon:";



