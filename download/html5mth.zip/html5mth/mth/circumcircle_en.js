// Umkreis eines Dreiecks, englische Texte
// Letzte �nderung 05.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Restart";
var text02 = "Next step";
var author = "W. Fendt 1997"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var text03 = [["A triangle ABC is shown",                  // step == 0
               "at the left. You can move",
               "the vertices of this triangle",
               "with pressed mouse button."],
              ["The points of the perpendicular",          // step == 1
               "bisector p_(c) have the same",
               "distance from points A and B."],
              ["Similarly, the points of the",             // step == 2
               "perpendicular bisector p_(a)",
               "have the same distance from",
               "points B and C."],
              ["Consequently, the intersection O",         // step == 3
               "of these two bisectors has",
               "the same distance from A and C."],
              ["This point of intersection (O)",           // step == 4
               "must therefore lie on the third",
               "perpendicular bisector p_(b), too."],
              ["Since the point O has the same",           // step == 5
               "distance from all three vertices",
               "of the triangle, there is a circle",
               "around O that passes through all",
               "three vertices simultaneously."],
              ["This circle is known as the",              // step == 6
               "circumcircle (circumscribed",
               "circle) of the triangle."]];
               
var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var circumcenter = "O";






