// Besondere Linien und Kreise im Dreieck, englische Texte
// Letzte �nderung 28.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Perpendicular Bisectors";
var text02 = "Circumcircle";
var text03 = "Angle Bisectors";
var text04 = "Incircle";
var text05 = "Excircles";
var text06 = "Midparallels";
var text07 = "Medians";
var text08 = "Altitudes";
var text09 = "Euler Line";
var text10 = "Feuerbach Circle";

var author = "W. Fendt 1998";
var translator = "";

