// Winkel am Kreis, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Size of the angles:";
var text02 = "Angle at the centre:";
var text03 = "Angle at the circumference:";
var text04 = "Angle between the chord and the tangent:";

var author = "W. Fendt 1997";
var translator = "G. Moont 2003";
