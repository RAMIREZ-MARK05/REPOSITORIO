// Kathetensatz und Satz des Pythagoras, deutsche Texte
// Letzte �nderung 30.07.2023

// Texte in Unicode-Schreibweise:

var symbolA = "a";                                         // 1. Kathete
var symbolB = "b";                                         // 2. Kathete
var symbolC = "c";                                         // Hypotenuse
var symbolA2 = "a\u00B2";                                  // 1. Kathetenquadrat
var symbolB2 = "b\u00B2";                                  // 2. Kathetenquadrat
var symbolP = "p";                                         // 1. Hypotenusenabschnitt
var symbolQ = "q";                                         // 2. Hypotenusenabschnitt
var symbolCP = "cp";                                       // 1. Rechteck
var symbolCQ = "cq";                                       // 2. Rechteck
