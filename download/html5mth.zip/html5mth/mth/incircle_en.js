// Inkreis eines Dreiecks, englische Texte
// Letzte �nderung 05.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Restart";
var text02 = "Next step";
var author = "W. Fendt 1998"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var text03 = [["A triangle ABC is shown",                  // step == 0
               "at the left. You can move",
               "the vertices of this triangle",
               "with pressed mouse button."],
              ["The points of the angle",                  // step == 1
               "bisector b_(\u03B1) have the same",
               "distance from the lines",
               "AB and AC."],
              ["Similarly, the points of",                 // step == 2
               "the angle bisector b_(\u03B2)",
               "have the same distance",
               "from the lines AB and BC."],
              ["Consequently, the intersection I",         // step == 3
               "of these two angle bisectors",
               "has the same distance from",
               "the lines AC and BC."],
              ["This point of intersection (I)",           // step == 4
               "must therefore lie on the third",
               "angle bisector b_(\u03B3), too."],
              ["Since the point I has the same",           // step == 5
               "distance from the sides of the",
               "triangle, there is a circle",
               "around I that is tangent to all",
               "three sides."],
              ["This circle is known as the",              // step == 6
               "incircle (inscribed circle)",
               "of the triangle."]];
               
var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var angle1 = "\u03B1";                                     // alpha
var angle2 = "\u03B2";                                     // beta
var angle3 = "\u03B3";                                     // gamma
var incenter = "I";






