// Winkelfunktionen am Einheitskreis, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Sine";
var text02 = "Cosine";
var text03 = "Tangent";

var author = "W. Fendt 1997";
var translator = "";

var decimalSeparator = ".";                      // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var symbolSine = "sin";                          // Symbol f�r Sinus
var symbolCosine = "cos";                        // Symbol f�r Cosinus
var symbolTangent = "tan";                       // Symbol f�r Tangens
var undef = "undefined";                         // F�r Definitionsl�cken der Tangensfunktion
