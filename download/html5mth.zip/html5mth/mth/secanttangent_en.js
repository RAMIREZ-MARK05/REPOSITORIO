// Sekanten- und Tangentensteigung, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Fixed point:";
var text02 = "Variable point:";
var text03 = "Slope of secant line:";
var text04 = "Slope of tangent line:";

var author = "W. Fendt 1998";
var translator = "";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var textUndefValue = "undefined";                          // Text f�r "nicht definiert"
