// Position eines Gestirns, deutsche Texte und Defaultwerte
// Letzte �nderung 17.10.2017

// Texte in HTML-Schreibweise:

var text01 = "Geogr. L&auml;nge:";
var text03 = "Geogr. Breite:";
var text05 = "Datum:";
var text06 = "Uhrzeit:";
var text07 = "Uhr (MEZ)";
var text08 = "Rektaszension:";
var text09 = "Deklination:";
var text10 = "Zur&uuml;ck";
var text11 = ["Start", "Pause", "Weiter"];
var text12 = "Hervorheben:";

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var dateSeparator = ".";
var timeSeparator = ":";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var text02 = ["(\u00F6stliche L\u00E4nge)", "(westliche L\u00E4nge)"];
var text04 = ["(n\u00F6rdliche Breite)", "(s\u00FCdliche Breite)"];
var text13 = ["", "Beobachtungsort", "Horizont",
              "Nordpunkt", "Westpunkt", "S\u00FCdpunkt", "Ostpunkt", 
              "Zenit", "Nadir", "Ortsmeridian", "H\u00F6henkreis", 
              "Himmelsnordpol", "Himmelss\u00FCdpol", "Himmelsachse", "Himmels\u00E4quator",
              "Fr\u00FChlingspunkt", "Stundenkreis", "Sternzeit",
              "Stundenwinkel", "Stern", "Sternbahn",
              "Rektaszension", "Deklination", "Azimut", "H\u00F6he", "Nautisches Dreieck"];
var text14 = "Uhrzeit:";
var text15 = "Sternzeit:";
var text16 = "Azimut:";
var text17 = "Stundenwinkel:";
var text18 = "H\u00F6he:";

// Symbole und Einheiten:

var symbolObserver = "B";                                  // Beobachtungsort
var symbolNorth = "N";                                     // Nordpunkt
var symbolWest = "W";                                      // Westpunkt
var symbolSouth = "S";                                     // S�dpunkt
var symbolEast = "O";                                      // Ostpunkt
var symbolZenith = "Ze";                                   // Zenit
var symbolNadir = "Na";                                    // Nadir
var symbolNorthPole = "NP";                                // Himmelsnordpol
var symbolSouthPole = "SP";                                // Himmelss�dpol
var symbolVernalEquinox = "F";                             // Fr�hlingspunkt
var symbolStar = "St";                                     // Stern
var symbolHour = "h";                                      // Stunde

// Defaultwerte:

var defaultLongitude = 10*DEG;                             // Geographische L�nge (Frankfurt)
var defaultLatitude = 50*DEG;                              // Geographische Breite (Frankfurt)
var defaultDay = 1;                                        // Tag
var defaultMonth = 1;                                      // Monat
var defaultYear = 2000;                                    // Jahr
var defaultTimeZone = 1;                                   // Zeitzone relativ zu UT (h)
