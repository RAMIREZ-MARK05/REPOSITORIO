// Online-Rechner Sternzeit
// Letzte �nderung 22.12.2022

var english = false;                                       // F�r die Reihenfolge beim Datum

// Texte in HTML-Schreibweise:

var text01 = "Datum (UT):";
var text02 = "Uhrzeit (UT):";
var text03 = "Geogr. L&auml;nge:";
var text04 = "Julianisches Datum (JD):";
var text05 = "Mittlere Greenwich-Sternzeit (GMST):";
var text06 = "Mittlere Ortssternzeit (LMST):";
var text07 = "OK";
var text08 = ["\u00F6stlich", "westlich"];

var author = "W. Fendt 2022";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var dateSeparator = ".";                                   // Trennzeichen Datum
var timeSeparator = ":";                                   // Trennzeichen Uhrzeit
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var unitHour = "h";
var unitMinute = "min";
var unitSecond = "s";
var unitDeg = "\u00B0";
var unitArcMin = "'";
var unitArcSec = "''";


