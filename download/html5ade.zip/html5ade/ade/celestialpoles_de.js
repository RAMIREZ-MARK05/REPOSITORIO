// Himmelspole, deutsche Texte
// Letzte �nderung 17.10.2017

// Texte in Unicode-Schreibweise:

var text01 = "\u00C4quator";
var	text02 = "Nordpol";
var text03 = "S\u00FCdpol";
var text04 = "Erdachse";
var text05 = "Horizontebene";
var text06 = "Himmelskugel";
var	text07 = "Zenit";
var text08 = "Himmelsnordpol";
var	text09 = "Himmelss\u00FCdpol";
var text10 = "Norden";
var text11 = "S\u00FCden";

var author = "W. Fendt 1998";
