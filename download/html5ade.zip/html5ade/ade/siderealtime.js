// Online-Rechner Sternzeit
// 21.12.2022 - 22.12.2022

// ****************************************************************************
// * Autor: Walter Fendt (www.walter-fendt.de)                                *
// * Dieses Programm darf - auch in ver�nderter Form - f�r nicht-kommerzielle *
// * Zwecke verwendet und weitergegeben werden, solange dieser Hinweis nicht  *
// * entfernt wird.                                                           *
// **************************************************************************** 

// Sprachabh�ngige Texte sind einer eigenen Datei (zum Beispiel siderealtime_de.js) abgespeichert.

// Konstanten:

var D_DAY = 6;                                             // Tage mit 6 Nachkommastellen
var D_HOUR = 5;                                            // Stunden mit 5 Nachkommastellen
var D_SEC = 1;                                             // Zeitsekunden mit 1 Nachkommastelle
var D_DEG = 4;                                             // Winkelgrad mit 4 Nachkommastellen
var D_ARCSEC = 0;                                          // Winkelsekunden ohne Nachkommastellen

// Attribute:

var ipDay, ipMonth, ipYear;                                // Eingabefelder (Datum)
var ipHour, ipMinute, ipSecond;                            // Eingabefelder (Uhrzeit)
var ipLongDeg, ipLongMin, ipLongSec;                       // Eingabefelder (geographische L�nge)
var chLong;                                                // Auswahlfeld (�stliche/westliche L�nge)
var opJD;                                                  // Ausgabefeld (Julianisches Datum)
var opGMST1, opGMST2;                                      // Ausgabefelder (mittlere Greenwich-Sternzeit, Zeitma�/Gradma�)
var opLMST1, opLMST2;                                      // Ausgabefelder (mittlere Ortssternzeit, Zeitma�/Gradma�)
var bu;                                                    // OK-Button
var timeUT;                                                // UT-Zeit (Verbund)
var long;                                                  // Betrag der geographischen L�nge (Verbund)
var jd;                                                    // Julianisches Datum

// Element der Schaltfl�che (aus HTML-Datei):
// id ..... ID im HTML-Befehl
// text ... Text (optional)

function getElement (id, text) {
  var e = document.getElementById(id);                     // Element
  if (text) e.innerHTML = text;                            // Text festlegen, falls definiert
  return e;                                                // R�ckgabewert
  }
  
// Neues Auswahlfeld:
// id ... ID im HTML-Befehl
// t .... Array von Texten
// i .... Voreingestellter Index
  
function newSelect (id, t, i) {
  var ch = document.getElementById(id);                    // Neues Auswahlfeld
  for (var k=0; k<t.length; k++) {                         // F�r alle Indizes ...
    var o = document.createElement("option");              // Neues option-Element
    o.innerHTML = t[k];                                    // Text festlegen
    ch.add(o);                                             // option-Element hinzuf�gen
    }
  ch.selectedIndex = i;                                    // Startwert Index
  return ch;                                               // R�ckgabewert
  }
  
// Aktivierung bzw. Deaktivierung der Ein- und Ausgabefelder:
  
function enable () {
  ipYear.readOnly = false;                                 // Eingabefeld Jahr
  ipMonth.readOnly = false;                                // Eingabefeld Monat
  ipDay.readOnly = false;                                  // Eingabefeld Tag
  ipHour.readOnly = false;                                 // Eingabefeld Stunde
  ipMinute.readOnly = false;                               // Eingabefeld Minute
  ipSecond.readOnly = false;                               // Eingabefeld Sekunde
  ipLongDeg.readOnly = false;                              // Eingabefeld geogr. L�nge, Grad
  ipLongMin.readOnly = false;                              // Eingabefeld geogr. L�nge, Winkelminuten
  ipLongSec.readOnly = false;                              // Eingabefeld geogr. L�nge, Winkelsekunden
  opJD.readOnly = true;                                    // Ausgabefeld Julianisches Datum
  opGMST1.readOnly = true;                                 // Ausgabefeld Mittlere Greenwich-Sternzeit, Zeitma�
  opGMST2.readOnly = true;                                 // Ausgabefeld Mittlere Greenwich-Sternzeit, Gradma�
  opLMST1.readOnly = true;                                 // Ausgabefeld Mittlere Ortssternzeit, Zeitma�
  opLMST2.readOnly = true;                                 // Ausgabefeld Mittlere Ortssternzeit, Gradma�
  }

// Start:

function start () {
  var d = new Date();                                      // Aktuelle Zeit
  timeUT = {                                               // Verbund f�r UT-Zeit
    year: d.getUTCFullYear(),                              // Jahr (UTC)
    month: d.getUTCMonth()+1,                              // Monat (UTC) 
    day: d.getUTCDate(),                                   // Tag (UTC)
    hour: d.getUTCHours(),                                 // Stunde (UTC)
    minute: d.getUTCMinutes(),                             // Minute (UTC)
    second: d.getUTCSeconds()                              // Sekunde (UTC)
    };                                             
  long = {deg: 10, min: 0, sec: 0};                        // Verbund f�r geographische L�nge
  getElement("ip1a",text01);                               // Erkl�render Text (Datum)
  ipDay = getElement(english?"ip1d":"ip1b");               // Eingabefeld (Tag)
  getElement("ip1c",dateSeparator);                        // Trennzeichen Datum
  ipMonth = getElement(english?"ip1b":"ip1d");             // Eingabefeld (Monat)
  getElement("ip1e",dateSeparator);                        // Trennzeichen Datum
  ipYear = getElement("ip1f");                             // Eingabefeld (Jahr)
  getElement("ip2a",text02);                               // Erkl�render Text (Uhrzeit) 
  ipHour = getElement("ip2b");                             // Eingabefeld (Stunde) 
  getElement("ip2c",unitHour);                             // Einheit (Stunde)
  ipMinute = getElement("ip2d");                           // Eingabefeld (Minute)
  getElement("ip2e",unitMinute);                           // Einheit (Minute)
  ipSecond = getElement("ip2f");                           // Eingabefeld (Sekunde)
  getElement("ip2g",unitSecond);                           // Einheit (Sekunde)
  getElement("ip3a",text03);                               // Erkl�render Text (geogr. L�nge)
  ipLongDeg = getElement("ip3b");                          // Eingabefeld (geogr. L�nge, Winkelgrad)
  getElement("ip3c",unitDeg);                              // Einheit (Winkelgrad)
  ipLongMin = getElement("ip3d");                          // Eingabefeld (geogr. L�nge, Winkelminuten)
  getElement("ip3e",unitArcMin);                           // Einheit (Winkelminuten)
  ipLongSec = getElement("ip3f");                          // Eingabefeld (geogr. L�nge, Winkelsekunden)
  getElement("ip3g",unitArcSec);                           // Einheit (Winkelsekunden) 
  chLong = newSelect("ip3h",text08,0);                     // Auswahlfeld (�stliche/westliche L�nge)
  getElement("op4a",text04);                               // Erkl�render Text (Julianisches Datum)
  opJD = getElement("op4b");                               // Ausgabefeld (Julianisches Datum)
  getElement("op5a",text05);                               // Erkl�render Text (mittlere Greenwich-Sternzeit)
  opGMST1 = getElement("op5b");                            // Ausgabefeld (mittlere Grennwich-Sternzeit, Zeitma�)
  opGMST2 = getElement("op5c");                            // Ausgabefeld (mittlere Greenwich-Sternzeit, Gradma�)
  getElement("op6a",text06);                               // Erkl�render Text (mittlere Ortssternzeit)
  opLMST1 = getElement("op6b");                            // Ausgabefeld (mittlere Ortssternzeit, Zeitma�)
  opLMST2 = getElement("op6c");                            // Ausgabefeld (mittlere Ortssternzeit, Gradma�)  
  bu = getElement("bu",text07);                            // Schaltknopf (OK) 
  getElement("author",author);                             // Autor (und �bersetzer) 
  enable();                                                // Aktivierung bzw. Deaktivierung der Ein- und Ausgabefelder
  
  updateInput();                                           // Eingabefelder aktualisieren
  reaction();                                              // Eingabe, Berechnung und Ausgabe
  
  ipYear.onkeydown = reactionEnter;                        // Reaktion auf Enter-Taste (Eingabe Jahr)
  ipMonth.onkeydown = reactionEnter;                       // Reaktion auf Enter-Taste (Eingabe Monat)
  ipDay.onkeydown = reactionEnter;                         // Reaktion auf Enter-Taste (Eingabe Tag)
  ipHour.onkeydown = reactionEnter;                        // Reaktion auf Enter-Taste (Eingabe Stunde)
  ipMinute.onkeydown = reactionEnter;                      // Reaktion auf Enter-Taste (Eingabe Minute)
  ipSecond.onkeydown = reactionEnter;                      // Reaktion auf Enter-Taste (Eingabe Sekunde)
  ipLongDeg.onkeydown = reactionEnter;                     // Reaktion auf Enter-Taste (Eingabe geogr. L�nge, Grad)
  ipLongMin.onkeydown = reactionEnter;                     // Reaktion auf Enter-Taste (Eingabe geogr. L�nge, Winkelminuten)
  ipLongSec.onkeydown = reactionEnter;                     // Reaktion auf Enter-Taste (Eingabe geogr. L�nge, Winkelsekunden)
  chLong.onchange = reaction;                              // Reaktion auf Auswahlfeld (�stliche/westliche L�nge)
  bu.onclick = reaction;                                   // Reaktion auf Schaltknopf OK
  
  } // Ende der Methode start
  
// Eingabe von Datum und Uhrzeit, Berechnung, Ausgabe:
// Seiteneffekt timeUT, jd
// Wirkung auf Ein- und Ausgabefelder
  
function reaction () {
  timeUT.year = inputNumber(ipYear,0,true,1900,2100);      // Jahr aus Eingabefeld
  timeUT.month = inputNumber(ipMonth,0,true,1,12);         // Monat aus Eingabefeld
  var max = lengthMonth(timeUT.year,timeUT.month);         // Monatsl�nge
  timeUT.day = inputNumber(ipDay,0,true,1,max);            // Tag aus Eingabefeld
  timeUT.hour = inputNumber(ipHour,0,true,0,23);           // Stunde aus Eingabefeld
  timeUT.minute = inputNumber(ipMinute,0,true,0,59);       // Minute aus Eingabefeld
  if (timeUT.minute < 10)                                  // Falls Minutenzahl einstellig ... 
    ipMinute.value = "0"+ipMinute.value;                   // Zweistellige Angabe
  timeUT.second = inputNumber(ipSecond,D_SEC,true,0,59.9); // Sekunde aus Eingabefeld
  if (timeUT.second < 10)                                  // Falls Sekundenzahl einstellig ... 
    ipSecond.value = "0"+ipSecond.value;                   // Zweistellige Angabe  
  jd = julianDateT(timeUT);                                // Julianisches Datum
  opJD.value = ToString(jd,D_DAY,true);                    // Ausgabe des julianischen Datums
  long.deg = inputNumber(ipLongDeg,0,true,0,180);          // Grad L�nge aus Eingabefeld
  long.min = inputNumber(ipLongMin,0,true,0,59);           // Winkelminute L�nge aus Eingabefeld
  long.sec = inputNumber(ipLongSec,D_ARCSEC,true,0,59);    // Winkelsekunde L�nge aus Eingabefeld
  if (long.deg == 180) {                                   // Falls 180� eingetragen ...
    long.min = long.sec = 0;                               // Winkelminuten und -sekunden gleich 0
    ipLongMin.value = "0";                                 // Eingabefeld f�r Winkelminuten aktualisieren
    ipLongSec.value = ToString(0,D_ARCSEC,true);           // Eingabefeld f�r Winkelsekunden aktualisieren
    }
  var t = gmst(timeUT);                                    // Mittlere Greenwich-Sternzeit (Sekunden)
  opGMST1.value = toHourMinSec(t)+" = "+toHours(t);        // Ausgabe im Zeitma�
  opGMST2.value = toDegMinSec(t)+" = "+toDegrees(t);       // Ausgabe im Gradma�
  t = lmst(timeUT);                                        // Mittlere Ortssternzeit (Sekunden)
  opLMST1.value = toHourMinSec(t)+" = "+toHours(t);        // Ausgabe im Zeitma�
  opLMST2.value = toDegMinSec(t)+" = "+toDegrees(t);       // Ausgabe im Gradma�  
  }  
 
// Reaktion auf Tastendruck (nur auf Enter-Taste):
// Seiteneffekt timeUT, jd 
  
function reactionEnter (e) {
  if (e.key && String(e.key) == "Enter"                    // Falls Entertaste (Firefox/Internet Explorer) ...
  || e.keyCode == 13)                                      // Falls Entertaste (Chrome) ...
    reaction();                                            // ... Daten �bernehmen, rechnen, Ausgabe aktualisieren
  }

//-------------------------------------------------------------------------------------------------

// �berpr�fung Schaltjahr:
// y ... Jahr nach astronomischer Z�hlung
// Willk�rliche Festlegung f�r die Zeit vor Christus: Schalttag, falls Jahr nach astronomischer Z�hlung
// durch 4 teilbar
  
function isLeapYear (y) {
  if (y < 1582) return (y%4 == 0);                         // Bis 1581 julianischer Kalender
  if (y%400 == 0) return true;                             // Teilbarkeit durch 400
  if (y%100 == 0) return false;                            // Teilbarkeit durch 100
  if (y%4 == 0) return true;                               // Teilbarkeit durch 4
  return false;                                            // Kein Schaltjahr
  }

// Monatsl�nge:
// y ... Jahr nach astronomischer Z�hlung
// m ... Monat
    
function lengthMonth (y, m) {
  var ly = isLeapYear(y);                                  // Flag f�r Schaltjahr
  if (m == 1) return 31;                                   // Januar
  if (m == 2) return (ly ? 29 : 28);                       // Februar
  if (m == 3) return 31;                                   // M�rz
  if (m == 4) return 30;                                   // April
  if (m == 5) return 31;                                   // Mai
  if (m == 6) return 30;                                   // Juni
  if (m == 7) return 31;                                   // Juli
  if (m == 8) return 31;                                   // August
  if (m == 9) return 30;                                   // September
  if (m == 10) return 31;                                  // Oktober
  if (m == 11) return 30;                                  // November
  if (m == 12) return 31;                                  // Dezember
  return undefined;                                        // Monat nicht im Bereich 1 bis 12
  }
 
// Umwandlung einer Zahl in eine Zeichenkette:
// n ..... Gegebene Zahl
// d ..... Zahl der Stellen (Konstanten f�r Genauigkeit verwenden!)
// fix ... Flag f�r Nachkommastellen (im Gegensatz zu g�ltigen Ziffern)

function ToString (n, d, fix) {
  var s = (fix ? n.toFixed(d) : n.toPrecision(d));         // Zeichenkette mit Dezimalpunkt
  return s.replace(".",decimalSeparator);                  // Eventuell Punkt durch Komma ersetzen
  }
  
// Anpassung der Eingabefelder f�r Datum und Uhrzeit:
// Wirkung auf die Eingabefelder ipDay, ipMonth, ipYear, ipHour, ipMinute, ipSecond, ipLongDeg, ipLongMin, ipLongSec
  
function updateInput () {
  ipDay.value = ToString(timeUT.day,0,true);               // Eingabefeld Tag
  ipMonth.value = ToString(timeUT.month,0,true);           // Eingabefeld Monat
  ipYear.value = ToString(Math.abs(timeUT.year),0,true);   // Eingabefeld Jahr 
  ipHour.value = ToString(timeUT.hour,0,true);             // Eingabefeld Stunde
  ipMinute.value = ToString(timeUT.minute,0,true);         // Eingabefeld Minute
  ipSecond.value = ToString(timeUT.second,D_SEC,true);     // Eingabefeld Sekunde
  ipLongDeg.value = ToString(long.deg,0,true);             // Eingabefeld geogr. L�nge (Grad)
  ipLongMin.value = ToString(long.min,0,true);             // Eingabefeld geogr. L�nge (Winkelminuten)
  ipLongSec.value = ToString(long.sec,D_ARCSEC,true);      // Eingabefeld geogr. L�nge (Winkelsekunden)
  }
  
// Eingabe einer Zahl:
// ef .... Eingabefeld
// d ..... Zahl der Stellen
// fix ... Flag f�r Nachkommastellen (im Gegensatz zu g�ltigen Ziffern)
// min ... Minimum des erlaubten Bereichs
// max ... Maximum des erlaubten Bereichs
// R�ckgabewert: Zahl oder NaN
// Wirkung auf Eingabefeld
  
function inputNumber (ef, d, fix, min, max) {
  var s = ef.value;                                        // Zeichenkette im Eingabefeld
  s = s.replace(",",".");                                  // Eventuell Komma in Punkt umwandeln
  var n = Number(s);                                       // Umwandlung in Zahl, falls m�glich
  if (isNaN(n)) n = 0;                                     // Sinnlose Eingaben als 0 interpretieren 
  if (n < min) n = min;                                    // Falls Zahl zu klein, korrigieren
  if (n > max) n = max;                                    // Falls Zahl zu gro�, korrigieren
  ef.value = ToString(n,d,fix);                            // Eingabefeld eventuell korrigieren
  return n;                                                // R�ckgabewert
  }
  
// �berpr�fung, ob Datum korrekt:
// y ... Jahr (normale Z�hlung ohne Jahr 0)
// m ... Monat
// d ... Tag (einschlie�lich Bruchteil)
  
function isCorrectDate (y, m, d) {
  if (y == 0) return false;                                // R�ckgabewert f�r das Jahr 0
  if (y < 0) y++;                                          // Astronomische Z�hlung
  if (m < 1 || m > 12) return false;                       // Fehler beim Monat
  var dd = Math.floor(d);                                  // Ganzer Tag
  if (dd < 1 || dd > lengthMonth(y,m)) return false;       // Fehler beim Tag
  if (y == 1582 && m == 10 && d > 4 && d < 15)             // Falls �bergangszeit im Oktober 1582 ... 
    return false;                                          // Fehler
  return true;                                             // Korrektes Datum
  }
  
// Julianisches Datum (f�r 0 Uhr UT):
// year .... Jahr (normale Z�hlung ohne Jahr 0)
// month ... Monat (1 bis 12)
// day ..... Tag (einschlie�lich Bruchteil)
// Algorithmus nach Oliver Montenbruck, Grundlagen der Ephemeridenrechnung
  
function julianDate (year, month, day) {
  var c = isCorrectDate(year,month,day);                   // �berpr�fung, ob Datum korrekt
  if (!c) return undefined;                                // R�ckgabewert f�r das Jahr 0
  if (year < 0) year++;                                    // Astronomische Z�hlung
  var y = year, m = month;                                 // Jahr und Monat
  if (m <= 2) {y--; m += 12;}                              // Falls Januar oder Februar, Umnummerierung
  var greg = false;                                        // Flag f�r gregorianischen Kalender, Startwert
  if (y > 1582) greg = true;                               // Nach 1582 Flag setzen
  else if (y == 1582 && m > 10) greg = true;               // F�r November/Dezember 1582 Flag setzen
  else if (y == 1582 && m == 10 && day >= 15) greg = true; // F�r 15. bis 31. Oktober 1582 Flag setzen
  var b = (greg ? Math.floor(y/400)-Math.floor(y/100) : -2); // Hilfsgr��e
  var jd = Math.floor(365.25*y);                           // Summand f�r Jahr
  jd += Math.floor(30.6001*(m+1));                         // Summand f�r Monat
  jd += b+1720996.5+day;                                   // Weitere Summanden
  return jd;                                               // R�ckgabewert
  }
  
// Julianisches Datum:
// u ... UT-Zeit (Verbund mit den Attributen year, month, day, hour, minute, second)
  
function julianDateT (u) {
  var y = u.year;                                          // Jahr
  var mo = u.month;                                        // Monat
  var d = u.day;                                           // Tag (ganzzahlig)
  var h = u.hour;                                          // Stunde
  var mi = u.minute;                                       // Minute
  var se = u.second;                                       // Sekunde
  return julianDate(y,mo,d)+h/24+mi/1440+se/86400;         // R�ckgabewert (Algorithmus Montenbruck)
  }
  
// Mittlere Greenwich-Sternzeit:
// u ... UT-Zeit (Verbund mit den Attributen year, month, day, hour, minute, second)
// R�ckgabewert: Mittlere Greenwich-Sternzeit in Sekunden, Bereich 0 bis 86400

function gmst (u) {
  var jd = julianDateT(u);                                 // Julianisches Datum
  var t = (jd-2451545)/36525;                              // Jahrhunderte seit Standardepoche J2000.0
  var s0 = ((-0.0000062*t+0.093104)*t+8640184.812866)*t+24110.54841; // Sternzeit f�r 0 Uhr UT (Sekunden)
  var n = Math.floor(s0/86400);                            // Anzahl der ganzen Tage
  s0 -= n*86400;                                           // Ganze Tage subtrahieren
  s0 += (u.hour*3600+u.minute*60+u.second)*1.00273790935;  // Ber�cksichtigung der Uhrzeit (UT)
  if (s0 > 86400) s0 -= 86400;                             // Eventuell einen Tag subtrahieren
  return s0;                                               // R�ckgabewert
  }
  
// Mittlere Ortssternzeit:
// u ... UT-Zeit (Verbund mit den Attributen year, month, day, hour, minute, second)
// R�ckgabewert: Mittlere Ortssternzeit in Sekunden, Bereich 0 bis 86400

function lmst (u) {
  var lon = long.deg*240+long.min*4+long.sec/15;           // Betrag der geographischen L�nge (Zeitsekunden)
  if (chLong.selectedIndex == 1) lon = -lon;               // Falls westliche L�nge, Vorzeichenwechsel
  var t = gmst(u)+lon;                                     // Sternzeit (Zeitsekunden)
  if (t > 86400) t -= 86400;                               // Eventuell einen Tag subtrahieren
  if (t < 0) t += 86400;                                   // Eventuell einen Tag addieren
  return t;                                                // R�ckgabewert
  }
 
// Zeichenkette f�r Zeitangabe (Stunden, Minuten, Sekunden): 
// t ... Zeit (Sekunden, Bereich 0 bis 86400)
  
function toHourMinSec (t) {
  var n = Math.floor(t/3600);                              // Zahl der ganzen Stunden
  var s = String(n)+" "+unitHour+" ";                      // Anfang der Zeichenkette (Stunden)
  t -= n*3600;                                             // Restliche Zeit (Sekunden)
  n = Math.floor(t/60);                                    // Zahl der ganzen Minuten
  s += String(n)+" "+unitMinute+" ";                       // Zeichenkette erg�nzen (Minuten)
  t -= n*60;                                               // Restliche Zeit (Sekunden)
  s += ToString(t,D_SEC,true)+" "+unitSecond;              // Zeichenkette erg�nzen (Sekunden)
  return s;                                                // R�ckgabewert
  }
  
// Zeichenkette f�r Zeitangabe (Stunden):
// t ... Zeit (Sekunden, Bereich 0 bis 86400)
  
function toHours (t) {
  return ToString(t/3600,D_HOUR,true)+" "+unitHour;        // R�ckgabewert
  }
  
// Zeichenkette f�r Winkelangabe (Grad, Winkelminuten, Winkelsekunden):
// t ... Zeit (Sekunden, Bereich 0 bis 86400)
  
function toDegMinSec (t) {
  var n = Math.floor(t/240);                               // Zahl der ganzen Winkelgrade (240 s entspricht 1�)
  var s = String(n)+unitDeg+" ";                           // Anfang der Zeichenkette (Winkelgrade)
  t -= n*240;                                              // Restliche Zeit (Sekunden)
  n = Math.floor(t/4);                                     // Zahl der ganzen Winkelminuten (4 s entspricht 1')
  s += String(n)+unitArcMin+" ";                           // Zeichenkette erg�nzen (Winkelminuten)
  t -= n*4;                                                // Restliche Zeit (Sekunden)
  s += ToString(t*15,D_ARCSEC,true)+unitArcSec;            // Zeichenkette erg�nzen (Winkelsekunden)                        
  return s;                                                // R�ckgabewert
  }
  
// Zeichenkette f�r Winkelangabe (Grad):
// t ... Zeit (Sekunden, Bereich 0 bis 86400)
  
function toDegrees (t) {
  return ToString(t/240,D_DEG,true)+unitDeg;               // R�ckgabewert 
  }
           
document.addEventListener("DOMContentLoaded",start,false); // Nach dem Laden der Seite Start-Methode aufrufen

