// Julianisches Datum
// Letzte �nderung 20.12.2022

var english = false;

// Texte in HTML-Schreibweise:

var text01 = "Julianisches Datum berechnen";
var text02 = "Kalenderdatum und Uhrzeit berechnen";

var text03 = "Zeitzone:";
var text07 = "Datum:";
var text09 = "Uhrzeit:";
var text10 = "Julianisches Datum (UTC):";
var text11 = "OK";

var author = "W. Fendt 2022";

// Texte in Unicode-Schreibweise:

var text04 = ["UTC", "UTC + 1 h", "UTC + 2 h"];
var text05 = ["Westeurop\u00E4ische Zeit (WEZ)",
              "Mitteleurop\u00E4ische Zeit (MEZ)",
              "Osteurop\u00E4ische Zeit (OEZ)"];
var text06 = ["Greenwich Mean Time (GMT)",
              "Westeurop\u00E4ische Sommerzeit (WESZ)",
              "Mitteleurop\u00E4ische Sommerzeit (MESZ)"];
var text08 = ["v. Chr.", "n. Chr."];

var errorDate = "Unzul\u00E4ssiges Datum abge\u00E4ndert!";

// Symbole und Einheiten:

var dateSeparator = ".";                                   // Trennzeichen Datum
var timeSeparator = ":";                                   // Trennzeichen Uhrzeit
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var unitHour = "h";
var unitMinute = "min";
var unitSecond = "s";


