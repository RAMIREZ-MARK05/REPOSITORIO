// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Restart";
var text02 = "Next step";
var text03 = ["Pause", "Resume"];                  
var text04 = "1st index of refraction:";
var text05 = "2nd index of refraction:";
var text06 = "Angle of incidence:";

var author = "W. Fendt 1998";
var translator = "Prof. T. Mzoughi 1998";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise:

var text07 = [

  ["A plane wavefront runs",                               // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "diagonally against the",
   "boundary of two media.",
   "The wave has a different",
   "velocity in each medium."],
   
  ["A plane wave front runs",                              // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "perpendicularly against the",
   "boundary of two media.",
   "The wave has a different",
   "velocity in each medium."],
 
  ["Upon arrival of the wavefront",                        // i == 2 (step == 1, n1 > n2) 
   "points along the boundary",
   "behave according to Huygens'",
   "principle. Each point can be",
   "regarded as a spherical",
   "source of light.",
   "In medium 2 these elementary",
   "waves move faster since the",
   "index of refraction is smaller."],
   
  ["Upon arrival of the wavefront",                        // i == 3 (step == 1, n1 < n2) 
   "points along the boundary",
   "behave according to Huygens'",
   "principle. Each point can be",
   "regarded as a spherical",
   "source of light.",
   "In medium 2 these elementary",
   "waves move slower since the",
   "index of refraction is larger."], 

  ["A superposition of all",                               // i == 4 (step == 2, total == false, esp1 > 0) 
   "elementary waves results in a",
   "new plane wave. Note that the",
   "direction of propagation of the",
   "plane wave changes when",
   "moving from medium 1 to 2."], 

  ["A superposition of all",                               // i == 5 (step == 2, total == false, esp1 == 0)
   "elementary waves results in a",
   "new plane wave."],   
   
  ["A superposition of all",                               // i == 6 (step == 2, total == true)
   "elementary waves results in a",
   "new plane wave in medium 1",
   "(reflected wave).",
   "The wave is not transmitted",
   "to medium 2 (total internal",
   "reflection)."],
   
  ["The direction of propagation",                         // i == 7 (step == 3)
   "of the wave is now drawn.",
   "It is the line perpendicular",
   "to the wavefront."],   

  ["A wavefront rarely comes",                             // i == 8 (step == 4)
   "alone!"],
   
  ["If the refraction index of both",                      // i == 9 (n1 == n2)
   "media is the same",
   "nothing special happens."]];
          
var text08 = "Angle of incidence:"; 
var text09 = "Angle of reflection:";
var text10 = "Angle of refraction:"; 
var text11 = "Medium 1";
var text12 = "Medium 2";      
var text13 = ["Critical angle for", "total internal reflection:"];

// Einheiten:

var degreeUnicode = "\u00b0";                              // Grad
