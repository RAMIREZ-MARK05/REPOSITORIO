// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "2 pulleys";
var text02 = "4 pulleys";
var text03 = "6 pulleys";
var text04 = "Weight:";
var text05 = "Weight of the loose pulley(s):";
var text06 = "Necessary force:";
var text07 = "Springscale";
var text08 = "Force vectors";

var author = "W. Fendt 1998";
var translator = "T. Mzoughi 1998";

// Symbole:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Punkt)
var symbolDivision = "&divide;";                           // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                          // Abk�rzung f�r Newton
