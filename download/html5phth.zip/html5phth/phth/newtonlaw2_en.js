// Fahrbahnversuch zum 2. Newtonschen Gesetz, englische Texte (Taha Mzoughi)
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Record data"];
var text03 = "Diagram";
var text04 = "Mass of the wagon:";
var text05 = "Hanging mass:";
var text06 = "Coefficient of friction:";
var text07 = "Data:";

var author = "W. Fendt 1997,&nbsp; T. Mzoughi 1998";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "LB";
var text09 = "(in s)";
var text10 = "(in m)";
var text11 = "Too much friction!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


