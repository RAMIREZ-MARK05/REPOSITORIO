// Reflexion und Brechung von Licht, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = "1st index of refraction:";
var text02 = "2nd index of refraction:";
var text03 = "Angle of incidence:";
var text04 = "Angle of reflection:";
var text05 = "Angle of refraction:";    
var text06 = ["Critical angle for total", "internal reflection:"];

var author = "W. Fendt 1997";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise:

var text07 = [["vacuum", "1"], ["air", "1.0003"],          // Stoffe und Brechungsindizes
    ["water", "1.33"], ["ethanol", "1.36"],
    ["fused quartz", "1.46"], ["benzene", "1.49"], 
    ["crown glass N-K5", "1.52"], ["rock salt", "1.54"], 
    ["flint glass LF5", "1.58"], ["crown glass N-SK4", "1.61"],
    ["flint glass SF6", "1.81"], ["diamond", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                              // Grad
