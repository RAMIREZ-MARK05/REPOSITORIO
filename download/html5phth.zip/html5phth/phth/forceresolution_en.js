// Zerlegung einer Kraft in zwei Komponenten, englische Version
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Magnitude of the given";                       
var text02 = "force:";
var text03 = "Sizes of the angles:";
var text04 = "1st angle:";
var text05 = "2nd angle:";
var text06 = "Magnitudes of the components:";
var text07 = "1st component:";
var text08 = "2nd component:";
var text09 = "Find out components";
var text10 = "Clear construction";

var author = "W. Fendt 2003";
var translator = "";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Punkt)
var degree = "&deg;";                                      // Winkelgrad
var newton = "N";                                          // Einheit Newton (Kraft), HTML-Schreibweise

// Texte in Unicode-Schreibweise:

var text11 = "1st component";                              // Text f�r erste Komponente
var text12 = "2nd component";                              // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                                   // Einheit Newton (Kraft), Unicode-Schreibweise