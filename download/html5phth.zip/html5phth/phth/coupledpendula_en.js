// Gekoppelte Pendel, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";                           
var text02 = ["Start", "Pause", "Resume"];                
var text03 = "Slow motion";
var text04 = "Initial positions:";

var author = "W. Fendt 1998";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise:

var text05 = "Pendulum 1";                                 // Erstes Pendel (links)
var text06 = "Pendulum 2";                                 // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
