// Potentiometerschaltung, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Voltage of the power supply:";
var text02 = "Sliding resistor:";
var text03 = "Position of the sliding contact:";
var text04 = "Resistance of the appliance:";
var text05 = "Indicate voltage";
var text06 = "Indicate amperage";
var author = "W. Fendt 2006";
var translator = "";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "V";                                  // Symbol f�r Spannung
var symbolVoltage2 = "a";                                  // Index f�r Verbraucher
                      
