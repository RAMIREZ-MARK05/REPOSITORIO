// Generator, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Without commutator";
var text02 = "With commutator";
var text03 = "Change direction";
var text04 = ["Start", "Pause", "Resume"];
var text05 = "Direction of movement";
var text06 = "Magnetic field";
var text07 = "Induced current";

var author = "W. Fendt 1998";  
var translator = "";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";                        // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "V";
var symbolResistor = "R";
