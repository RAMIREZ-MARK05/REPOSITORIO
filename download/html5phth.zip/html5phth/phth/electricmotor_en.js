// Gleichstrom-Elektromotor, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Reset";
var text02 = ["Start", "Pause", "Resume"];             
var text03 = "Change direction";
var text04 = "Current direction";
var text05 = "Magnetic field";
var text06 = "Lorentz force";

var author = "W. Fendt 1997";             
var translator = "";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";                        // Umdrehungen pro Minute
