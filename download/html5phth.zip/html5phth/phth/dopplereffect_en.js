// Beispiel zum Doppler-Effekt, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Start again";
var text02 = ["Pause", "Resume"]; 

var author = "W. Fendt 1998";
var translator = "";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                             // Erl�uterungstext
  ["As long as the emergency",
  "ambulance approaches the",
  "person, the intervals between",
  "the arriving wavefronts are",
  "shortened."],
  ["Now the vehicle leaves the",
  "person. So the wavefronts",
  "reach the person in longer",
  "intervals."]];


  

