// Bohrsches Atommodell, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Particle model";
var text02 = "Wave model";
var text03 = "Principal quantum number:";


var author = "W. Fendt 1999"; 
var translator = "";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



