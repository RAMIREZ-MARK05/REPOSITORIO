// Erstes Kepler-Gesetz, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune",
              "Pluto", "Halley's Comet", ""];
var text02 = "Semimajor axis:";
var text03 = "Numerical eccentricity:";
var text04 = "Semiminor axis:";
var text05 = ["Pause", "Resume"];
var text06 = "Slow motion";
var text07 = "Distance from the Sun:";
var text08 = "Currently:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Elliptical orbit";
var text12 = "Axes";
var text13 = "Connecting lines";

var author = "W. Fendt 2000";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text14 = "Sun";
var text15 = "Planet";
var text16 = "Comet";
var text17 = "Perihelion";
var text18 = "Aphelion";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "AU";

