// Stehende Welle, Erkl�rung durch Reflexion, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reflection";
var text02 = "from a fixed end";
var text03 = "from a free end";
var text04 = "Reset";
var text05 = ["Start", "Pause", "Resume"];
var text06 = "Slow motion";
var text07 = "Animation";
var text08 = "Single steps";
var text09 = "Incidenting wave";
var text10 = "Reflected wave";
var text11 = "Resultant standing wave";

var author = "W. Fendt 2003"; 
var translator = "";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "N";
var symbolAntiNode = "A";

