// Stehende L�ngswellen, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Form of tube:";
var text02 = "both sides open";
var text03 = "one side open";
var text04 = "both sides closed";
var text05 = "Vibrational mode:";
var text06 = ["fundamental",  "1st overtone",              // Bezeichnungen der Eigenschwingungen 
              "2nd overtone", "3rd overtone", 
              "4th overtone", "5th overtone"];
var text07 = "Lower";
var text08 = "Higher";
var text09 = "Length of tube:";
var text10 = "Wavelength:";
var text11 = "Frequency:";

var author = "W. Fendt 1998";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                           // Meter
var hertz = "Hz";                                          // Hertz

// Texte in Unicode-Schreibweise:

var text12 = "Displacement of particles";                  // �berschrift des ersten Diagramms
var text13 = "Divergence from average pressure";           // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "N";                                      // Symbol f�r Knoten
var symbolAntinode = "A";                                  // Symbol f�r Bauch

