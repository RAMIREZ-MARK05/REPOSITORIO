// Kombinationen von Widerst�nden, englische Texte
// Letzte �nderung 18.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Voltage of the battery:";
var text03 = "Resistance:";
var text04 = "Add resistor (in series)";
var text05 = "Add resistor (in parallel)";
var text06 = "Meters:";
var text07 = "Voltage";
var text08 = "Amperage";

var author = "W. Fendt 2002";
var translator = "";

// Texte in Unicode-Schreibweise:

var text09 = "Voltage:";
var text10 = "Amperage:";
var text11 = "Resistance:";
var text12 = "Equivalent resistance:";
var text13 = "very small";
var text14 = "very large";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

