// Zerfallsreihen, englische Texte
// Letzte �nderung 26.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Decay chain:";
var text03 = "Next decay";

var author = "W. Fendt 1998"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["Thorium series", "Neptunium series", "Uranium Radium series", "Uranium Actinium series"];          





