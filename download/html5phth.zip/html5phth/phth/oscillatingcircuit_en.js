// Elektromagnetischer Schwingkreis, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pause", "Resume"];
var text03 = "Slow motion (10 x)";
var text04 = "Slow motion (100 x)";
var text05 = "Capacity:";
var text06 = "Inductivity:";
var text07 = "Resistance:";
var text08 = "Maximal voltage:";
var text09 = "Voltage, Amperage";
var text10 = "Energy";

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                                  // Mikrofarad
var henry = "H";                                           // Henry
var ohm = "&Omega;";                                       // Ohm
var volt = "V";                                            // Volt

// Texte in Unicode-Schreibweise:

var text11 = "Oscillation period:";
var text12 = "Electric field energy:";
var text13 = "Magnetic field energy:";
var text14 = "Internal energy:";
var text15 = "Undamped oscillation";
var text16 = "Damped oscillation";
var text17 = "Critical damping";
var text18 = "Overcritical damping";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "V";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                          // Sekunde
var voltUnicode = "V";                                     // Volt
var ampere = "A";                                          // Ampere
var joule = "J";                                           // Joule
