// Leiterschaukel-Versuch zur Lorentzkraft, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "On / Off";
var text02 = "Reverse current";
var text03 = "Turn magnet";
var text04 = "Current direction";
var text05 = "Magnetic field";
var text06 = "Lorentz force";

var author = "W. Fendt 1998";
var translator = "";
