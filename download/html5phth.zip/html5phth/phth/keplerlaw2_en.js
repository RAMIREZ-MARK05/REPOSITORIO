// Zweites Kepler-Gesetz, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "Semimajor axis:";
var text03 = "Numerical eccentricity:";
var text04 = ["Pause", "Resume"];
var text05 = "Slow motion";
var text06 = ["Distance", "from the Sun:"];
var text07 = "Velocity:";
var text08 = "Currently:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Sectors";
var text12 = "Vector of velocity";

var author = "W. Fendt 2000";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune",
              "Pluto", "Halley's Comet", ""];

// Symbole und Einheiten: 

var auUnicode = "AU";
var symbolPeriod = "T";

