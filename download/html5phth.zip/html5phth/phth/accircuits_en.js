// Einfache Wechselstromkreise, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Resistor";
var text02 = "Capacitor";
var text03 = "Coil";
var text04 = "Reset";
var text05 = ["Start", "Pause", "Resume"];          
var text06 = "Slow motion";
var text07 = "Frequency:";
var text08 = "Max. voltage:";
var text09 = "Resistance:";                            
var text10 = "Capacity:";                          
var text11 = "Inductivity:"; 
var text12 = "Max. amperage:"; 

var author = "W. Fendt 1998";                   

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                          // Hertz
var volt = "V";                                            // Volt
var ampere = "A";                                          // Ampere
var milliampere = "mA";                                    // Milliampere
var microampere = "&mu;A";                                 // Mikroampere
var ohm = "&Omega;";                                       // Ohm
var microfarad = "&mu;F";                                  // Mikrofarad
var henry = "H";                                           // Henry

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "V";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
