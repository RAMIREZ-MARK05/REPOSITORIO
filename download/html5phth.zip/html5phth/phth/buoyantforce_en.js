// Messung der Auftriebskraft, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Base area of body:"; 
var text02 = "Height of body:";
var text03 = "Density of body:";
var text04 = "Density of liquid:";   
var text05 = "Draught:";
var text06 = "Replaced volume:"; 
var text07 = "Buoyant force:";
var text08 = "Weight of body:";
var text09 = "Measured force:";
var text10 = "Measuring range:";

var author = "W. Fendt 1998";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Maximum exceeded!";
