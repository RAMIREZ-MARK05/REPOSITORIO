// Interferenz zweier Kreis- oder Kugelwellen, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = ["Pause", "Resume"];                          // Schaltknopf (Pause/Weiter)
var text02 = "Slow motion";
var text03 = "Distance of the two";
var text04 = "sources:";
var text05 = "Wavelength:";

var author = "W. Fendt 1999";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                                     // Zentimeter

// Texte in Unicode-Schreibweise:

var text06 = "Difference of path lengths:";
var text07 = "Constructive interference (maximal amplitude)";
var text08 = "Destructive interference (minimal amplitude)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (Lambda)
