// Spezielle Prozesse eines idealen Gases, englische Texte
// Letzte �nderung 10.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Isobaric process";
var text02 = "Isochoric process";
var text03 = "Isothermal process";
var text04 = "Initial state:";
var text05 = "Pressure:";
var text06 = "Volume:";
var text07 = "Temperature:";
var text08 = "Final state:";
var text09 = "Initial state";
var text10 = "Start";

var author = "W. Fendt 1999";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Work";
var text12 = "Heat";
var text13 = "The internal energy of the gas";
var text14 = "increases.";
var text15 = "The internal energy of the gas";
var text16 = "is constant.";
var text17 = "The internal energy of the gas";
var text18 = "decreases.";
var text19 = "Pressure too small!";
var text20 = "Pressure too big!";
var text21 = "Volume too small!";
var text22 = "Volume too big!";
var text23 = "Temperature too small!";
var text24 = "Temperature too big!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


