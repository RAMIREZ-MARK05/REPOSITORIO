// Ersatzkraft mehrerer Kr�fte, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Number of forces:";
var text02 = "Find out resultant";
var text03 = "Clear construction";

var author = "W. Fendt 1998";
var translator = "";
