// Kr�fte an der schiefen Ebene, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pause", "Resume"];
var text03 = "Slow motion";
var text04 = "Springscale";
var text05 = "Force vectors";
var text06 = "Angle of inclination:";
var text07 = "Weight:";
var text08 = "Parallel component:";
var text09 = "Normal force:";
var text10 = "Coefficient of friction:";
var text11 = "Force of friction:";
var text12 = "Necessary force:";

var author = "W. Fendt 1999";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad
var newton = "N";                                          // Newton
