// Magnetfeld eines Stabmagneten, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Clear field lines";
var text02 = "Turn magnet";

var author = "W. Fendt 2001";
var translator = "";
