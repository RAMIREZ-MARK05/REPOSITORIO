// Photoelektrischer Effekt, serbische Texte (Zlatan Soskic)
// Letzte �nderung 05.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Materijal katode:";
var text03 = "Spektralna linija (Hg):";
var text04 = "Zako&ccaron;ni napon:";
var text05 = "Frekvenca:";
var text06 = ["Energija", "fotona:"];
var text07 = "Izlazni rad:";
var text08 = ["Maksimalna kineti&ccaron;ka energija", "elektrona:"];
var text09 = "Obri&scaron;i merenja";

var author = "W. Fendt 2000,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                            // Volt
var terahertz = "THz";                                     // Terahertz
var electronvolt = "eV";                                   // Elektronenvolt

// Texte in Unicode-Schreibweise:

var text02 = ["Cezijum", "Natrijum"];
var text10 = ["\u017euta", "zelena", "ljubi\u010dasta", "ultraljubi\u010dasta", "ultraljubi\u010dasta"];
var text11 = "[THz]";
var text12 = "[V]";
var text13 = [
             ["Energija ovakvih fotona nije dovoljna za emisiju", "elektrona."],
             ["Uve\u0107aj zako\u010dni napon tako da elektroni", "vi\u0161e ne dolaze na adnodu!"],
             ["Zako\u010dni napon je toliko veliki da se elektroni", "vra\u0107aju na katodu."],
             ["Nastavi sa nizom merenja za slede\u0107u", "spektralnu liniju!"],
             ["Nastavi sa nizom merenja za slede\u0107i", "katodni materijal!"],
             ["Merenja su zavr\u0161ena."]
             ];

var symbolCathode = "K";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
