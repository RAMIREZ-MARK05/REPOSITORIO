// Stehende Welle, Erkl�rung durch Reflexion, serbische Texte (Zlatan Soskic)
// Letzte �nderung 10.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Refleksija";
var text02 = "od fiksiranog kraja";
var text03 = "od slobodnog kraja";
var text04 = "Reset";
var text05 = ["Start", "Pauza", "Nastavak"];
var text06 = "Usporeno";
var text07 = "Neprekidno";
var text08 = "Po koracima";
var text09 = "Upadni talas";
var text10 = "Odbijeni talas";
var text11 = "Rezultuju\u0107i stoje\u0107i talas";

var author = "W. Fendt 2003"; 
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "D";
var symbolAntiNode = "B";

