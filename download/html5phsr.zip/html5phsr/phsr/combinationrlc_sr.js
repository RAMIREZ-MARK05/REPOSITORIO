// Kombinationen von Widerst�nden, Spulen und Kondensatoren, serbische Texte (Zlatan Soskic)
// Letzte �nderung 22.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Izvor naizmeni&ccaron;ne struje:";
var text02 = "Napon:";
var text03 = "Frekvenca:";
var text04 = "Komponenta:";
var text05 = ["Otpornik", "Kalem", "Kondenzator"];
var text06 = ["Otpornost:", "Induktivnost:", "Kapacitet:"];
var text07 = "Zameni";
var text08 = "Dodaj (redno)";
var text09 = "Dodaj (paralelno)";
var text10 = "Ukloni";
var text11 = "Instrumenti:";
var text12 = "Voltmetar";
var text13 = "Ampermetar";

var author = "W. Fendt 2004";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Texte in Unicode-Schreibweise:

var text14 = "Napon:";
var text15 = "Struja:";
var text16 = "Kompleksna impedansa:";
var text17 = "Impedansa:";
var text18 = "Fazni ugao:";
var text19 = "vrlo malo";                                  // Stromst�rke Voltmeter
var text20 = "vrlo malo";                                  // Spannung Amperemeter
var text21 = "vrlo malo";                                  // Impedanz/Widerstand Amperemeter
var text22 = "vrlo veliko";                                // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)