// Zerfallsgesetz der Radioaktivit�t, serbische Texte (Zlatan Soskic)
// Letzte �nderung 14.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Nastavak"];    
var text03 = "Dijagram";  

var author = "W. Fendt 1998";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Texte in Unicode-Schreibweise:

var text04 = "Vreme:";                                      
var text05 = "Neraspadnutih:";
var text06 = "Raspadnutih:";
var text07 = ["jezgara", "jezgro", "jezgara", "jezgara"];    // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
