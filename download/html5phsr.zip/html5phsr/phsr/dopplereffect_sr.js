// Beispiel zum Doppler-Effekt, serbische Texte (Zlatan Soskic)
// Letzte �nderung 10.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Novi start";
var text02 = ["Pauza", "Nastavak"]; 

var author = "W. Fendt 1998";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Texte in Unicode-Schreibweise:              

var text03 = [                                             // Erl�uterungstext
  ["Dok se ambulantna kola",
  "pribli\u017eavaju osobi,",
  "rastojanja me\u0111u dolaze\u0107im",
  "talasnim frontovima se umanjuje."],
  ["Sada se kola udaljavaju od",
  "osobe. Stoga talasni frontovi",
  "sti\u017eu do osobe u du\u017eim",
  "intervalima."]];


  

