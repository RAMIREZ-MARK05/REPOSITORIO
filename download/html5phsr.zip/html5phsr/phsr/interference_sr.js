// Interferenz zweier Kreis- oder Kugelwellen, serbische Texte (Zlatan Soskic)
// Letzte �nderung 10.02.2018

// Texte in HTML-Schreibweise:

var text01 = ["Pauza", "Nastavak"];                   
var text02 = "Usporeno";
var text03 = "Rastojanje me&#273;u";
var text04 = "izvorima:";
var text05 = "Talasna du&zcaron;ina:";

var author = "W. Fendt 1999";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                                

// Texte in Unicode-Schreibweise:

var text06 = "Razlika puteva:";
var text07 = "Konstruktivna interferencija (maksimalna amplituda)";
var text08 = "Destruktivna interferencija (minimalna amplituda)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03BB";                           // Symbol f�r Wellenl�nge (Lambda)
