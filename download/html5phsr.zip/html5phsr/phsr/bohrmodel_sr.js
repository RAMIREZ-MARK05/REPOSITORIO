// Bohrsches Atommodell, serbische Texte (Zlatan Soskic)
// Letzte �nderung 14.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Ccaron;esti&ccaron;ni model";
var text02 = "Talasni model";
var text03 = "Glavni kvantni broj:";


var author = "W. Fendt 1999"; 
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



