// Leiterschaukel-Versuch zur Lorentzkraft, serbische Texte (Zlatan Soskic)
// Letzte �nderung 11.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Uklj. / Isklj.";
var text02 = "Promeni smer I";
var text03 = "Okreni magnet";
var text04 = "Smer struje";
var text05 = "Magnetsko polje";
var text06 = "Lorencova sila";

var author = "W. Fendt 1998";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";
