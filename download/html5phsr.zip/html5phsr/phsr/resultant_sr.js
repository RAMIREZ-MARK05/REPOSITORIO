// Ersatzkraft mehrerer Kr�fte, serbische Texte (Zlatan Soskic)
// Letzte �nderung 06.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Broj sila:";
var text02 = "Odredi rezultantu";
var text03 = "Obrisi crtez";

var author = "W. Fendt 1998";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";
