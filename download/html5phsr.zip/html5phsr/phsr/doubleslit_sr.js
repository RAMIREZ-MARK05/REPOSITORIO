// Interferenz von Licht am Doppelspalt, serbische Texte (Zlatan Soskic)
// Letzte �nderung 14.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Talasna du&zcaron;ina:";
var text02 = "Rastojanje me&#273;u prorezima:";
var text03 = "Ugao:";
var text04 = "Maksimumi:";
var text05 = "Minimumi:";
var text06 = "Relativni intenziteti:";
var text07 = "Interferenciona slika";
var text08 = "Profil intenziteta";

var author = "W. Fendt 2003,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
