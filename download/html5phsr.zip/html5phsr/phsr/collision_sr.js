// Elastischer und unelastischer Sto�, serbische Texte (Zlatan Soskic)
// Letzte �nderung 08.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Elasti&ccaron;ni sudar";
var text02 = "Plasti&ccaron;ni sudar";
var text03 = "Reset";
var text04 = "Start";
var text05 = "Usporeno";
var text06 = "Vagon 1:";
var text07 = "Vagon 2:";
var text08 = "Masa:";
var text09 = "Brzina:";
var text10 = "Brzina";
var text11 = "Koli&ccaron;ina kretanja";
var text12 = "Kineti&ccaron;ka energija";

var author = "W. Fendt 1998,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                         

// Texte in Unicode-Schreibweise:

var text13 = "Vagon 1:";
var text14 = "Vagon 2:";
var text15 = "Brzine pre sudara:";
var text16 = "Brzine posle sudara:";
var text17 = "Koli\u010dine kretanja pre sudara:";
var text18 = "Koli\u010dine kretanja posle sudara:";
var text19 = "Kineti\u010dka energija pre sudara:";
var text20 = "Kineti\u010dka energija posle sudara:";
var text21 = "Ukupna koli\u010dina kretanja:";
var text22 = "Ukupna kineti\u010dka energija:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                   
var kilogramMeterPerSecond = "kg m/s";                
var joule = "J";                                      
