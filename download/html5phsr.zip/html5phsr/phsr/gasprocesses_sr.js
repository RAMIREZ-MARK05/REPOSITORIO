// Spezielle Prozesse eines idealen Gases, serbische Texte (Zlatan Soskic)
// Letzte �nderung 26.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Izobarski proces";
var text02 = "Izohorski proces";
var text03 = "Izotermni proces";
var text04 = "Po&ccaron;etno stanje:";
var text05 = "Pritisak:";
var text06 = "Zapremina:";
var text07 = "Temperatura:";
var text08 = "Krajnje stanje:";
var text09 = "Po&ccaron;etno stanje";
var text10 = "Start";

var author = "W. Fendt 1999,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Rad";
var text12 = "Toplota";
var text13 = "Unutra\u0161nja energija gasa";
var text14 = "raste.";
var text15 = "Unutra\u0161nja energija gasa";
var text16 = "se ne menja.";
var text17 = "Unutra\u0161nja energija gasa";
var text18 = "opada.";
var text19 = "Pritisak premalo!";
var text20 = "Pritisak preveliko!";
var text21 = "Zapremina premalo!";
var text22 = "Zapremina preveliko!";
var text23 = "Temperatura premalo!";
var text24 = "Temperatura preveliko!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


