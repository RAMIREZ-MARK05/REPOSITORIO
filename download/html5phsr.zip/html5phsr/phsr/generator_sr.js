// Generator, serbische Texte (Zlatan Soskic)
// Letzte �nderung 11.02.2018

// Texte in HTML-Schreibweise;

var text01 = "Bez komutatora";
var text02 = "Sa komutatorom";
var text03 = "Promeni smer I";
var text04 = ["Start", "Pauza", "Nastavak"];
var text05 = "Pravac kretanja";
var text06 = "Magnetsko polje";
var text07 = "Indukovana struja";

var author = "W. Fendt 1998";  
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "ob/min";                         // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
