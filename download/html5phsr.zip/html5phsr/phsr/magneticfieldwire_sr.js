// Magnetfeld eines geraden stromdurchflossenen Leiters, serbische Texte (Zlatan Soskic)
// Letzte �nderung 11.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Promeni smer struje";

var author = "W. Fendt 2000";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";
