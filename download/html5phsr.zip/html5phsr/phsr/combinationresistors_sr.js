// Kombinationen von Widerst�nden, serbische Texte (Zlatan Soskic)
// Letzte �nderung 20.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Napon baterije:";
var text03 = "Otpornost:";
var text04 = "Dodaj otpornik (Redna veza)";
var text05 = "Dodaj otpornik (Paralelna veza)";
var text06 = "Instrumenti:";
var text07 = "Voltmetar";
var text08 = "Ampermetar";

var author = "W. Fendt 2002";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Texte in Unicode-Schreibweise:

var text09 = "Napon:";
var text10 = "Struja:";
var text11 = "Otpornost:";
var text12 = "Ekvivalentna otpornost:";
var text13 = "veoma mala";
var text14 = "veoma velika";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

