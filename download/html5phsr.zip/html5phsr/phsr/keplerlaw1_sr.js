// Erstes Kepler-Gesetz, serbische Texte (Zlatan Soskic)
// Letzte �nderung 08.02.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Velika poluosa:";
var text03 = "Num. ekscentricitet:";
var text04 = "Mala poluosa:";
var text05 = ["Pauza", "Nastavak"];
var text06 = "Usporeno";
var text07 = "Udaljenost od Sunca:";
var text08 = "Trenutna:";
var text09 = "Najmanja:";
var text10 = "Najve&cacute;a:";
var text11 = "Elipti&ccaron;na orbita";
var text12 = "Ose";
var text13 = "Potezi";

var author = "W. Fendt 2000,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AJ";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Merkur", "Venera", "Zemlja", "Mars", "Jupiter", "Saturn", "Uran", "Neptun",
              "Pluton", "Halejeva kometa", ""];

var text14 = "Sunce";
var text15 = "Planeta";
var text16 = "Kometa";
var text17 = "Perihel";
var text18 = "Afel";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "AJ";

