// Newtons Wiege, serbische Texte (Zlatan Soskic)
// Letzte �nderung 08.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Start";
var text03 = "Broj loptica:";

var author = "W. Fendt 1997";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";
