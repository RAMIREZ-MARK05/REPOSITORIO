// Kr�fte an der schiefen Ebene, serbische Texte (Zlatan Soskic)
// Letzte �nderung 07.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Nastavak"];
var text03 = "Usporeno";
var text04 = "Dinamometar";
var text05 = "Vektori sila";
var text06 = "Ugao:";
var text07 = "Te&zcaron;ina:";
var text08 = "Paralelna komponenta:";
var text09 = "Normalna komponenta:";
var text10 = "Koeficijent trenja:";
var text11 = "Sila trenja:";
var text12 = "Potrebna sila:";

var author = "W. Fendt 1999,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                               
var newton = "N";                                   
