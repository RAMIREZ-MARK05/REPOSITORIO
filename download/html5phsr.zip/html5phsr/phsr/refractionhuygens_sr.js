// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), serbische Texte (Zlatan Soskic)
// Letzte �nderung 12.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Restart";
var text02 = "Sledeci korak";
var text03 = ["Pauza", "Nastavak"];                  
var text04 = "1. indeks prelamanja:";
var text05 = "2. indeks prelamanja:";
var text06 = "Upadni ugao:";

var author = "W. Fendt 1998";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                

// Texte in Unicode-Schreibweise:

var text07 = [

  ["Ravanski talasni front",                               // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "nailazi pod o\u0161trim uglom",
   "na granicu dve sredine.",
   "Brzine talasa u sredinama",
   "su razli\u010Dite."],
   
  ["Ravanski talasni front",                              // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "nailazi normalno",
   "na granicu dve sredine.",
   "Brzine talasa u sredinama",
   "su razli\u010Dite."],
 
  ["Po nailasku talasnog fronta",                          // i == 2 (step == 1, n1 > n2) 
   "ta\u010Dke duz granice sredina",
   "se pona\u0161aju po Hajgensovom",
   "principu. Svaka ta\u010Dka",
   "je izvor novih sfernih",
   "svetlosnih talasa.",
   "U sredini 2 novostvoreni",
   "talasi se kre\u0107u br\u017Ee jer",
   "ona ima manji indeks prelamanja."],
   
  ["Po nailasku talasnog fronta",                          // i == 3 (step == 1, n1 < n2) 
   "ta\u010Dke du\u017E granice sredina",
   "se pona\u0161aju po Hajgensovom",
   "principu. Svaka ta\u010Dka",
   "je izvor novih sfernih",
   "svetlosnih talasa.",
   "U sredini 2 novostvoreni",
   "talasi se kre\u0107u sporije jer",
   "ona ima veci indeks prelamanja."], 

  ["Superpozicijom svih",                                  // i == 4 (step == 2, total == false, eps1 > 0) 
   "sfernih talasa dobija se a",
   "novi ravanski talas. Uocite da je",
   "pravac prostiranja novog",
   "ravanskog talasa (u sredini 2)",
   "razli\u010Dit od pravca prostiranja",
   "po\u010Detnog ravanskog talasa",
   "(u sredini 1)."],

  ["Superpozicijom svih",                                  // i == 5 (step == 2, total == false, eps1 == 0)
   "sfernih talasa dobija se a",
   "novi ravanski talas."], 
   
  ["Superpozicijom svih",                                  // i == 6 (step == 2, total == true)
   "sfernih talasa dobija se a",
   "novi ravni talas u istoj",
   "sredini (odbijeni talas).",
   "U sredini 2 se ne obrazuje",
   "talas (totalna refleksija)."],
   
  ["Sada se odre\u0111uje pravac",                         // i == 7 (step == 3)
   "prostiranja talasa.",
   "To je prava normalna",
   "na talasni front."], 

  ["Jedan talasni front retko",                            // i == 8 (step == 4)
   "dolazi sam!"],
   
  ["Ako su indeksi prelamanja",                            // i == 9 (n1 == n2)
   "obe sredine isti",
   "ni\u0161ta posebno se ne dogadja."]];
          
var text08 = "Upadni ugao:"; 
var text09 = "Odbojni ugao:";
var text10 = "Prelomni ugao:"; 
var text11 = "Sredina 1";
var text12 = "Sredina 2";      
var text13 = ["Kriti\u010Dni ugao", "totalne refleksije:"];

// Einheiten:

var degreeUnicode = "\u00B0";                       
