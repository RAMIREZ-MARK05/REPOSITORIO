// Zerfallsreihen, serbische Texte (Zlatan Soskic)
// Letzte �nderung 14.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Niz:"; 
var text03 = "Slede\u0107i raspad";

var author = "W. Fendt 1998"; 
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Texte in Unicode-Schreibweise:

var text02 = ["Torijumov niz", "Neptunijumov niz", "Uran-radijumov niz", "Uran-aktinijumov niz"];          





