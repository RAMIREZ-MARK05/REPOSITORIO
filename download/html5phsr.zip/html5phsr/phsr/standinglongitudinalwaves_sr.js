// Stehende L�ngswellen, serbische Texte (Zlatan Soskic, unvollst�ndig!)
// Letzte �nderung 10.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Oblik cevi:";
var text02 = "oba kraja otvorena";
var text03 = "jedan kraj otvoren";
var text04 = "oba kraja zatvorena";
var text05 = "Vibracioni mod:";
var text06 = ["osnovni",  "1. harmonik",                   // Bezeichnungen der Eigenschwingungen 
              "2. harmonik", "3. harmonik", 
              "4. harmonik", "5. harmonik"];
var text07 = "Ni&zcaron;i";
var text08 = "Vi&scaron;i";
var text09 = "Du\u017eina cevi:";
var text10 = "Talasna du\u017eina:";
var text11 = "Frekvenca:";

var author = "W. Fendt 1998,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                           // Meter
var hertz = "Hz";                                          // Hertz

// Texte in Unicode-Schreibweise:

var text12 = "Displacement of particles"; // ???                  // �berschrift des ersten Diagramms
var text13 = "Divergence from average pressure"; // ???           // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "D";                                      // Symbol f�r Knoten
var symbolAntinode = "B";                                  // Symbol f�r Bauch

