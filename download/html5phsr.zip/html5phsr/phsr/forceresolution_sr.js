// Zerlegung einer Kraft in zwei Komponenten, serbische Version (Zlatan Soskic)
// Letzte �nderung 07.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Intenzitet sile koja";                       
var text02 = "se razla&zcaron;e:";
var text03 = "Uglovi:";
var text04 = "1. ugao:";
var text05 = "2. ugao:";
var text06 = "Intenziteti komponenti:";
var text07 = "1. komponenta";
var text08 = "2. komponenta";
var text09 = "Odredi komponente";
var text10 = "Obri&scaron;i crte&zcaron;";

var author = "W. Fendt 2003";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                
var newton = "N";                                     

// Texte in Unicode-Schreibweise:

var text11 = "1. komponenta";                              // Text f�r erste Komponente
var text12 = "2. komponenta";                              // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                            