// Druckdose (hydrostatischer Druck), serbische Texte (Zlatan Soskic)
// Letzte �nderung 06.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Te&ccaron;nost:";
var text03 = "Gustina:";
var text04 = "Dubina:";
var text05 = "Hidrostati&ccaron;ki pritisak:";

var author = "W. Fendt 1999";                              // Autor
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";    // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["nepoznata", "voda", "etanol", "benzol", "tetrahlormetan", "&zcaron;iva"]; 
