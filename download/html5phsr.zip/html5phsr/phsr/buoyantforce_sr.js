// Messung der Auftriebskraft, serbische Texte (Zlatan Soskic)
// Letzte �nderung 08.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Povr&scaron;ina baze tela:"; 
var text02 = "Visina tela:";
var text03 = "Gustina tela:";
var text04 = "Gustina te&ccaron;nosti:";   
var text05 = "Gaz tela:";
var text06 = "Istisnuta zapremina:"; 
var text07 = "Sila potiska:";
var text08 = "Te&zcaron;ina tela:";
var text09 = "Merena sila:";
var text10 = "Merni opseg:";

var author = "W. Fendt 1998,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Prekora\u010denje opsega!";
