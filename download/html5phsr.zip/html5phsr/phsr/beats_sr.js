// Schwebungen, serbische Texte (Zlatan Soskic)
// Letzte �nderung 10.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Nastavak"];
var text03 = "Usporeno";
var text04 = "Frekvencije:";
var text05 = "1. talas:";
var text06 = "2. talas:";

var author = "W. Fendt 2001"; 
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



