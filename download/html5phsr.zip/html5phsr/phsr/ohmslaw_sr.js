// Ohmsches Gesetz, serbische Texte (Zlatan Soskic)
// Letzte �nderung 11.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Maks. napon:";
var text02 = "Maks. struja:";
var text03 = "Uve&cacute;aj otpornost";
var text04 = "Umanji otpornost";
var text05 = "Uve&cacute;aj napon";
var text06 = "Umanji napon";

var author = "W. Fendt 1997";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Prema\u0161en opseg!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
