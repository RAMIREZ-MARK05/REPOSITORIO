// Gleichstrom-Elektromotor, serbische Texte (Zlatan Soskic)
// Letzte �nderung 11.02.2018

// Texte in HTML-Schreibweise;

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Nastavak"];             
var text03 = "Promeni smer I";
var text04 = "Smer struje";
var text05 = "Magnetsko polje";
var text06 = "Elektromagnetska sila";

var author = "W. Fendt 1997";             
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "ob/min";                         // Umdrehungen pro Minute
