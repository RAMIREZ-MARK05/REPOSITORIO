// Kettenkarussell, serbische Texte (Zlatan Soskic)
// Letzte �nderung 08.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Vrte&scaron;ka";
var text02 = "Vrte&scaron;ka sa silama";
var text03 = "Dijagram";
var text04 = "Brojne vrednosti";
var text05 = ["Pauza", "Nastavak"];
var text06 = "Usporeno";
var text07 = "Period:";
var text08 = ["Rastojanje od ta&ccaron;ke vesanja", "do ose rotacije:"]; 
var text09 = "Du&zcaron;ina niti:";
var text10 = "Masa:";

var author = "W. Fendt 1999,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Texte in Unicode-Schreibweise:

var text11 = "Frekvenca:";
var text12 = "Ugaona brzina:";
var text13 = "Polupre\u010dnik:";
var text14 = "Brzina:";
var text15 = "Ugao:";
var text16 = "Te\u017eina:";
var text17 = "Centripetalna sila:";
var text18 = "Sila zatezanja niti:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




