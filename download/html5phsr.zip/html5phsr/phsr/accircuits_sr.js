// Einfache Wechselstromkreise, serbische Texte (Zlatan Soskic)
// Letzte �nderung 12.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Otpornik";
var text02 = "Kondenzator";
var text03 = "Kalem";
var text04 = "Reset";
var text05 = ["Start", "Pauza", "Nastavak"];          
var text06 = "Usporeno";
var text07 = "Frekvenca:";
var text08 = "Maks. napon:";
var text09 = "Otpornost:";                            
var text10 = "Kapacitivnost:";                          
var text11 = "Induktivnost:"; 
var text12 = "Maks. ja&ccaron;ina struje:"; 

var author = "W. Fendt 1998,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                    
var volt = "V";                                      
var ampere = "A";                                    
var milliampere = "mA";                              
var microampere = "&mu;A";                           
var ohm = "&Omega;";                                 
var microfarad = "&mu;F";                            
var henry = "H";                                     

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
