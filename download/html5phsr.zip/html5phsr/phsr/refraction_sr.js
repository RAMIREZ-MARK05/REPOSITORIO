// Reflexion und Brechung von Licht, serbische Texte (Zlatan Soskic)
// Letzte �nderung 12.02.2018

// Texte in HTML-Schreibweise:
    
var text01 = "1. indeks prelamanja:";
var text02 = "2. indeks prelamanja:";
var text03 = "Upadni ugao:";
var text04 = "Odbojni ugao:";
var text05 = "Prelomni ugao:";    
var text06 = ["Najmanji ugao", "totalne refleksije:"];

var author = "W. Fendt 1997,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                  

// Texte in Unicode-Schreibweise:

var text07 = [["vakuum", "1"], ["vazduh", "1.0003"],       // Stoffe und Brechungsindizes
    ["voda", "1.33"], ["etanol", "1.36"],
    ["kvarcno staklo", "1.46"], ["benzol", "1.49"], 
    ["krunsko staklo N-K5", "1.52"], ["kamena so", "1.54"], 
    ["flint staklo LF5", "1.58"], ["krunsko staklo N-SK4", "1.61"],
    ["flint staklo SF6", "1.81"], ["dijamant", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03B5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03B5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00B0";                         
