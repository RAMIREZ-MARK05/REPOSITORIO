// Magnetfeld eines Stabmagneten, serbische Texte (Zlatan Soskic)
// Letzte �nderung 11.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Obri&scaron;i linije polja";
var text02 = "Okreni magnet";

var author = "W. Fendt 2001";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";
