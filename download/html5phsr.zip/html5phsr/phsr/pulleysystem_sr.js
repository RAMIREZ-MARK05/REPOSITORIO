// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, serbische Texte (Zlatan Soskic)
// Letzte �nderung 07.02.2018

// Texte in HTML-Schreibweise:

var text01 = "2 to&ccaron;ka";
var text02 = "4 to&ccaron;ka";
var text03 = "6 to&ccaron;ka";
var text04 = "Te&zcaron;ina:";
var text05 = "Te&zcaron;ina obe&scaron;enih to&ccaron;kova:";
var text06 = "Potrebna sila:";
var text07 = "Dinamometar";
var text08 = "Vektori sila";

var author = "W. Fendt 1998";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                               
