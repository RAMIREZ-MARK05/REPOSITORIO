// Gleichgewicht dreier Kr�fte, serbische Texte (Zlatan Soskic)
// Letzte �nderung 06.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Sile:";
var text02 = "Leva:";
var text03 = "Desna:";
var text04 = "Srednja:";
var text05 = "Paralelogram sila";
var text06 = "Uglovi:";
var text07 = "Leva:";
var text08 = "Desna:";

var author = "W. Fendt 2000";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                                
var newton = "N";                                     