// Zweites Kepler-Gesetz, serbische Texte (Zlatan Soskic)
// Letzte �nderung 08.02.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Velika poluosa:";
var text03 = "Num. ekscentricitet:";
var text04 = ["Pauza", "Nastavak"];
var text05 = "Usporeno";
var text06 = ["Udaljenost", "od Sunca:"];
var text07 = "Brzina:";
var text08 = "Trenutna:";
var text09 = "Najmanja:";
var text10 = "Najve&cacute;a:";
var text11 = "Sektori";
var text12 = "Vektor brzine";

var author = "W. Fendt 2000,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AJ";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Merkur", "Venera", "Zemlja", "Mars", "Jupiter", "Saturn", "Uran", "Neptun",
              "Pluton", "Halejeva kometa", ""];

// Symbole und Einheiten: 

var auUnicode = "AJ";
var symbolPeriod = "T";

