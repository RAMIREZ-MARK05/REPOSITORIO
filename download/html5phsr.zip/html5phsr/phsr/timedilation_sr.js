// Beispiel zur Zeitdilatation, serbische Texte (Zlatan Soskic)
// Letzte �nderung 14.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Umanji brzinu";
var text02 = "Uve&cacute;aj brzinu";
var text03 = "Reset";
var text04 = ["Start", "Pauza", "Nastavak"];

var author = "W. Fendt 1997,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "Rastojanje:";
var text06 = "5 svetlosnih sati";
var text07 = "Brzina:";
var text08 = "Vreme leta (sistem Zemlje):";
var text09 = "sati";
var text10 = "Vreme leta (sistem ):"; // ???