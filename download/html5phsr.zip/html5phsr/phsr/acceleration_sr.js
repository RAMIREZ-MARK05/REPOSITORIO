// Bewegung mit konstanter Beschleunigung, serbische Texte (Zlatan Soskic)
// Letzte �nderung 06.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Nastavak"];
var text03 = "Usporeno";
var text04 = "Po&ccaron;etni polo&zcaron;aj:";
var text05 = "Po&ccaron;etna brzina:";
var text06 = "Ubrzanje:";
var text07 = "Vektor brzine";
var text08 = "Vektor ubrzanja";

var author = "W. Fendt 2000";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Texte in Unicode-Schreibweise:

var text09 = "[s]";                                        // Einheitenangabe f�r Zeit-Achse
var text10 = "[m]";                                        // Einheitenangabe f�r Weg-Achse
var text11 = "[m/s]";                                      // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "[m/s\u00b2]";                                // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                    
var meter = "m";                                     
var meterPerSecond = "m/s";                           
var meterPerSecond2 = "m/s\u00b2";                    
