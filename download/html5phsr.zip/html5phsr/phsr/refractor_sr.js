// Kepler-Fernrohr, serbische Texte (Zlatan Soskic)
// Letzte �nderung 14.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Zcaron;i&zcaron;na daljina:"; 
var text02 = "Objektiv:";
var text03 = "Okular:";
var text04 = "Uglovi:";
var text05 = "Uve&cacute;anje:";

var author = "W. Fendt 2000";
var translator = "Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite

