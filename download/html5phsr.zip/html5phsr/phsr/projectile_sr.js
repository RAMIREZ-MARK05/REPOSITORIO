// Schiefer Wurf, serbische Texte (Zlatan Soskic)
// Letzte �nderung 07.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";                    
var text02 = ["Start", "Pauza", "Nastavak"];          
var text03 = "Usporeno";
var text04 = "Po&ccaron;etna visina:";
var text05 = "Po&ccaron;etna brzina:";
var text06 = "Po&ccaron;etni ugao:";
var text07 = "Masa:"; 
var text08 = "Gravitaciono sila:";
var text09 = "Koordinate";
var text10 = "Brzina";
var text11 = "Ubrzanje";
var text12 = "Sila";
var text13 = "Energija";

var author = "W. Fendt 2000,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                   
var meterPerSecond = "m/s";                       
var meterPerSecond2 = "m/s&sup2;";                 
var kilogram = "kg";                               
var degree = "&deg;";                              

// Texte in Unicode-Schreibweise:

var text14 = "[m]";                                        // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Koordinate:";
var text16 = "(horizontalna)";
var text17 = "(vertikalna)";
var text18 = "Domet:";
var text19 = "Najve\u0107a visina:";
var text20 = "Trajanje leta:";
var text21 = "Komponente brzine:";
var text22 = "Intenzitet brzine:";
var text23 = "Ugao:";
var text24 = "Ubrzanje:";
var text25 = "Sila:";
var text26 = "Kineti\u010Dka energija:";
var text27 = "Potencijalna energija:";
var text28 = "Mehani\u010Dka energija:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                              
var secondUnicode = "s";                             
var meterPerSecondUnicode = "m/s";                   
var meterPerSecond2Unicode = "m/s\u00b2";             
var newtonUnicode = "N";                              
var jouleUnicode = "J";                                
var degreeUnicode = "\u00b0";                          



