// Elektromagnetischer Schwingkreis, serbische Texte (Zlatan Soskic)
// Letzte �nderung 12.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Nastavak"];
var text03 = "Usporeno (10 &times;)";
var text04 = "Usporeno (100 &times;)";
var text05 = "Kapacitivnost:";
var text06 = "Induktivnost:";
var text07 = "Otpornost:";
var text08 = "Maks. napon:";
var text09 = "Napon, ja&ccaron;. struje";
var text10 = "Energija";

var author = "W. Fendt 1999,&nbsp; Z. &Scaron;o&scaron;ki&cacute; 2004";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                         
var henry = "H";                                  
var ohm = "&Omega;";                               
var volt = "V";                                    

// Texte in Unicode-Schreibweise:

var text11 = "Period oscilacija:";
var text12 = "Energija elektri\u010Dnog polja:";
var text13 = "Energija magnetskog polja:";
var text14 = "Toplotna energija:";
var text15 = "Slobodno oscilovanje";
var text16 = "Prigu\u0161eno oscilovanje";
var text17 = "Kriti\u010Dno prigu\u0161enje";
var text18 = "Nadkriti\u010Dno prigu\u0161enje";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                
var voltUnicode = "V";                           
var ampere = "A";                                
var joule = "J";                                 
