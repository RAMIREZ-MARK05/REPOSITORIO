// Position eines Gestirns, litauische Texte und Defaultwerte (A. Kleiva)
// Letzte �nderung 23.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Geogr. ilguma:";
var text03 = "Geogr. platuma:";
var text05 = "Data:";
var text06 = "Laikas:";
var text07 = "Valandos (GMT)";
var text08 = "Rektascencija:";
var text09 = "Deklinacija:";
var text10 = "Stop";
var text11 = ["Prad\u0117ti", "Pauz\u0117", "Prad\u0117ti"];
var text12 = "Parodyti:";

var author = "W. Fendt 1999, A. Kleiva 2003";

// Symbole und Einheiten:

var dateSeparator = "/";
var timeSeparator = ":";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var text02 = ["(ryt\u0173 ilg.)", "(vakar\u0173 ilg.)"];
var text04 = ["(\u0161iaur\u0117s plat.)", "(piet\u0173 plat.)"];
var text13 = ["", "Steb\u0117jimo ru\u0161is", "Horizontas",
              "\u0160iaur\u0117s ta\u0161kas", "Vakar\u0173 ta\u0161kas", "Piet\u0173 ta\u0161kas", "Ryt\u0173 ta\u0161kas", 
              "Zenitas", "Nadiras", "Meridianas", "Auk\u0161\u010dio lankas", 
              "Dangaus \u0161iaurinis polius", "Dangaus pietinis polius", "Dangaus a\u0161is", "Dangaus ekvatorius",
              "Pavasario lygiadienio ta\u0161kas", "Valand\u0173 ratas", "\u017dvaig\u017edinis laikas",
              "Valand\u0173 kampas", "\u017dvaig\u017ed\u0117s", "\u017dvaig\u017ed\u017ei\u0173 kelias",
              "Rektascencija", "Deklinacija", "Azimutas", "Auk\u0161tis", "Natinis trikampis"];
var text14 = "Laikas:";
var text15 = "\u017Dvaig\u017Ed\u017Ei\u0173 laikas:";
var text16 = "Azimutas:";
var text17 = "Valand\u0173 kampas:";
var text18 = "Auk\u0161tis:";

// Symbole und Einheiten:

var symbolObserver = "C";                                  // Beobachtungsort
var symbolNorth = "\u0160";                                // Nordpunkt
var symbolWest = "V";                                      // Westpunkt
var symbolSouth = "P";                                     // S�dpunkt
var symbolEast = "R";                                      // Ostpunkt
var symbolZenith = "Ze";                                   // Zenit
var symbolNadir = "Na";                                    // Nadir
var symbolNorthPole = "\u0160P";                           // Himmelsnordpol
var symbolSouthPole = "PP";                                // Himmelss�dpol
var symbolVernalEquinox = "F";                             // Fr�hlingspunkt
var symbolStar = "St";                                     // Stern
var symbolHour = "h";                                      // Stunde

// Defaultwerte:

var defaultLongitude = 0*DEG;                              // Geographische L�nge (London)
var defaultLatitude = 50*DEG;                              // Geographische Breite (London)
var defaultDay = 1;                                        // Tag
var defaultMonth = 1;                                      // Monat
var defaultYear = 2000;                                    // Jahr
var defaultTimeZone = 0;                                   // Zeitzone relativ zu UT (h)
