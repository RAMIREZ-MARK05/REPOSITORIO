// Himmelspole, litauische Texte (A. Kleiva)
// Letzte �nderung 23.11.2017

// Texte in Unicode-Schreibweise:

var text01 = "Ekvatorius";
var	text02 = "\u0160iaurinis polius";
var text03 = "Pietinis polius";
var text04 = "\u017Dem\u0117s a\u0161is";
var text05 = "Horizontas";
var text06 = "Dangaus skliautas";
var	text07 = "Zenitas";
var text08 = "Dangaus \u0161iaurinis polius";
var	text09 = "Dangaus pietinis polius";
var text10 = "\u0160iaur\u0117";
var text11 = "Piet\u016bs";

var author = "W. Fendt 1998, A. Kleiva 2003";
