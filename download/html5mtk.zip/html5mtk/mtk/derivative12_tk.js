// 1. und 2. Ableitungsfunktion, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 17.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Funksi&yacute;anyn denlemesi:";
var text02 = "f(x) =";
var text03 = "1-nji &ouml;n&uuml;mi";
var text04 = "2-nji &ouml;n&uuml;mi";
var text05 = "&Ccedil;ep &ccedil;&auml;gi:";
var text06 = "Sag &ccedil;&auml;gi:";
var text07 = "Asakky &ccedil;&auml;k:";
var text08 = "&Yacute;okarky &ccedil;&auml;k:";
var text09 = "&Ccedil;ek";

var author = "W. Fendt 1999,&nbsp; PICT Turkmenistan";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text10 = "Incorrect function term!"; // ???
var text11 = "Differentiation error!"; // ???

var symbolX = "x";
var symbolY = "y";
