// Umrechnung von Einheiten, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 16.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Ga&yacute;tar";
var text02 = "Basla";
var text03 = "Yzynlyk";
var text04 = "Me&yacute;dan";
var text05 = "G&ouml;wr&uuml;m";
var text06 = "Massa";
var text07 = "Wagt";
var text08 = "Dereje:";
var text09 = ["1 mesele", 
              "x meseleler"];  
var text10 = ["1 dogry degme", 
              "x dogry degmeler"];        
     
var author = "W. Fendt 2001, &nbsp; PICT Turkmenistan";    // Autor (und �bersetzer)

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

