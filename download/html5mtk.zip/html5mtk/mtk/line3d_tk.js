// Geradengleichung, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 17.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Nokat A:";
var text02 = "Nokat B:";

//var decimalSeparator = ",";

var author = "W. Fendt 1999";
var translator = "PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text03 = "AB \u00E7yzyk kesgitlenmedik!";

var symbolPoint1 = "A";
var symbolPoint2 = "B";
var symbolX = "x_1";
var symbolY = "x_2";
var symbolZ = "x_3";
var symbolPositionVector = "X";
var symbolParameter = "\u03BB";
