// Winkel am Kreis, turkmenische Texte (PICT Turkmenistan, unvollst�ndig!)
// Letzte �nderung 17.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Size of the angles:"; // ???
var text02 = "Merkezd&auml;ki bur&ccedil;:";               // Mittelpunktswinkel
var text03 = "Tegelekd&auml;ki bur&ccedil;:";              // Umfangswinkel
var text04 = "Horda we galtas&yacute;an nokat arasyndaky bur&ccedil;:";

var author = "W. Fendt 1997";
var translator = "PICT Turkmenistan";
