// Einfache geometrische Abbildungen, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 16.01.2018

// Texte in HTML-Schreibweise:

var text02 = "T&auml;ze &ccedil;yzgy";
var text04 = "Gos";
var text05 = "A&yacute;yr";
var text06 = "Surat";

var author = "W. Fendt 1999";
var translator = "PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text01 = ["\u00E7yzygyn sekili",                       // Achsenspiegelung 
              "nokadyn sekili",                            // Punktspiegelung 
              "terjime",                                   // Verschiebung
              "a\u00FDlaw"];                               // Drehung
var text03 = ["nokat",                                     // Punkt
              "\u00E7yzyk",                                // Gerade
              "s\u00F6hle",                                // Halbgerade
              "\u00E7yzygyn segmenti",                     // Strecke
              "t\u00F6werek",                              // Kreis
              "\u00FC\u00E7bur\u00E7luk",                  // Dreieck
              "d\u00F6rtbur\u00E7luk"];                    // Viereck

