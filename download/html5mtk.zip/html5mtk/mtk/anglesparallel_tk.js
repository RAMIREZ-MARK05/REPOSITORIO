// Winkel an parallelen Geraden, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 30.05.2018

// Texte in HTML-Schreibweise:

var text01 = "Degisli bur&ccedil;lar";
var text02 = "Atanak &yacute;atan bur&ccedil;lar";
var text03 = "Bir-tarapla&yacute;yn i&ccedil;ki bur&ccedil;lar";
var text05 = "On-ondan:";
var text06 = "Bur&ccedil;laryn ululygy:";

var author = "W. Fendt 2006";
var translator = "PICT Turkmenistan";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text04 = ["1-nji j\u00FCb\u00FCt bur\u00E7lar", 
              "2-nji j\u00FCb\u00FCt bur\u00E7lar", 
              "3-nji j\u00FCb\u00FCt bur\u00E7lar", 
              "4-nji j\u00FCb\u00FCt bur\u00E7lar"];

var angle1 = ["\u03B1",                                    // Alpha 
              "\u03B2",                                    // Beta
              "\u03B3",                                    // Gamma
              "\u03B4"];                                   // Delta
              
var angle2 = ["\u03B1'",                                   // Alpha Strich 
              "\u03B2'",                                   // Beta Strich
              "\u03B3'",                                   // Gamma Strich
              "\u03B4'"];                                  // Delta Strich
              

