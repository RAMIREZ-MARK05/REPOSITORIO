// Rechnen mit komplexen Zahlen, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 17.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Is ge&ccedil;irme:";                         // Rechenart
var text02 = "Gosma";                                      // Addition
var text03 = "A&yacute;yrma";                              // Subtraktion
var text04 = "K&ouml;peltme";                              // Multiplikation
var text05 = "B&ouml;lme";                                 // Division
var text06 = "Koordinatlar systemasy:";                    // Koordinatensystem
var text07 = "Dekart koordinatlary";                       // Kartesische Koordinaten
var text08 = "Pol&yacute;ar koordinatlary";                // Polarkoordinaten

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1998";
var translator = "PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text09 = "kesgitlenmedik!";                            // Nicht definiert

var symbolOperation = ["+", "\u2212", "\u00D7", "\u00F7"]; // Rechenzeichen
