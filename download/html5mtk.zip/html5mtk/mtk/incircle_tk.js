// Inkreis eines Dreiecks, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 31.01.2021
// Reihenfolge im Zusammenhang mit den Bezeichnungen der Winkelhalbierenden unklar!

// Texte in HTML-Schreibweise:

var text01 = "T&auml;zeden ba&scedil;la";
var text02 = "Indiki &auml;dim";
var author = "W. Fendt 1998"; 
var translator = "PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text03 = [["\u00C7epde \u00FDerle\u015Fen \u015Fekil",                     // step == 0
               "ABC \u00FC\u00E7bur\u00E7lugy g\u00F6rkez\u00FD\u00E4r.",
               "Siz \u015Fol \u00FC\u00E7bur\u00E7lugy\u0148 depelerini",
               "my\u015Fkany\u0148 knopkasyny basyp",
               "hereket etdirip bil\u00FD\u00E4\u0148iz."],
              ["Bu bur\u00E7a degi\u015Fli b_(\u03B1) bissektrisany\u0148",    // step == 1
               "\u00E4hli nokatlary AB we AC",
               "\u00E7yzyklardan de\u0148 aralykda",
               "\u00FDerle\u015Ferler."],
              ["\u015Ee\u00FDlelikde, b_(\u03B2) bissektrisany\u0148",         // step == 2
               "\u00E4hli nokatlary AB we BC",
               "\u00E7yzyklardan de\u0148 aralykda",
               "\u00FDerle\u015F\u00FD\u00E4rler."],
              ["Netijede, bu iki sany",                                        // step == 3
               "bissektrisalary\u0148 biri-biri bilen",
               "birle\u015F\u00FD\u00E4n I nokady AC we BC",
               "\u00E7yzyklardan de\u0148 aralyklarda",
               "\u00FDerle\u015Ferler."],
              ["Di\u00FDmek, bu kesi\u015Fme (I)",                             // step == 4
               "nokady \u00FC\u00E7\u00FCnji b_(\u03B3) bissektrisada",
               "hem \u00FDerle\u015Fmeli."],
              ["I nokat \u00FC\u00E7bur\u00E7lugy\u0148",                      // step == 5
               "hemme \u00FC\u00E7 taraplaryndan",
               "den aralyklarda \u00FDerle\u015Fendigi",
               "\u00FC\u00E7in, \u015Fol I nokadyny\u0148 da\u015Fynda",
               "\u00E4hli \u00FC\u00E7 taraplara deg\u00FD\u00E4n",
               "t\u00F6werek emele gel\u00FD\u00E4r."],
              ["O\u0148a bolsa i\u00E7ine \u00E7yzylan",                       // step == 6
               "t\u00F6werek di\u00FDil\u00FD\u00E4r."]];
               
var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var angle1 = "\u03B1";                                     // alpha
var angle2 = "\u03B2";                                     // beta
var angle3 = "\u03B3";                                     // gamma
var incenter = "I";






