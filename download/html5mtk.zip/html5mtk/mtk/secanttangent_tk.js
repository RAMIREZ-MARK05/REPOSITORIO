// Sekanten- und Tangentensteigung, turkmenische Texte (PICT Turkmenistan, unvollst�ndig!)
// Letzte �nderung 17.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Fixed point:"; // ???
var text02 = "Variable point:"; // ???
var text03 = "Kesiji &ccedil;yzygyn &yacute;apgytlygy:";             // Sekantensteigung
var text04 = "Galtas&yacute;an &ccedil;yzygyn &yacute;apgytlygy:";   // Tangentensteigung

var author = "W. Fendt 1998";
var translator = "PICT Turkmenistan";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var textUndefValue = "kesgitsiz";                          // Text f�r "nicht definiert"
