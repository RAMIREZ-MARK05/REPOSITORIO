// Kugeldreieck, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 17.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Taraplar:";
var text02 = "a = ";
var text03 = "b = ";
var text04 = "c = ";
var text05 = "Taraplaryn jemi: ";
var text06 = "Bur&ccedil;lar:";
var text07 = "&alpha; = ";
var text08 = "&beta; = ";
var text09 = "&gamma; = ";
var text10 = "Bur&ccedil;laryn jemi: ";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1999";
var translator = "PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var symbolA = "A";
var symbolB = "B";
var symbolC = "C";


