// Kreiszahl Pi, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 03.02.2021

// Texte in HTML-Schreibweise:

var text01 = "Depelerin sany:";
var text02 = "Kwadrat";
var text03 = "Altybur&ccedil;luk";
var text04 = "Depelerin gosa sany";
var text05 = "Bir tarapyn uzynlygy";
var text06 = "Tegelek";
var text07 = "Me&yacute;dan";

var author = "W. Fendt 2002";
var translator = "PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ".";

var text11 = "Bir tarapyn uzynlygy (i\u00E7ine \u00E7yzylan k\u00F6pbur\u00E7luk):";
var text12 = "Bir tarapyn uzynlygy (dasyndan \u00E7yzylan k\u00F6pbur\u00E7luk):";
var text13 = "I\u00E7ine \u00E7yzylan k\u00F6pbur\u00E7lugyn tegeleginin uzynlygy:";
var text14 = "Dasyndan \u00E7yzylan k\u00F6pbur\u00E7lugyn tegeleginin uzynlygy:";
var text15 = "I\u00E7ine \u00E7yzylan k\u00F6pbur\u00E7lugyn me\u00FDdany:";
var text16 = "Dasyndan \u00E7yzylan k\u00F6pbur\u00E7lugyn me\u00FDdany:";



