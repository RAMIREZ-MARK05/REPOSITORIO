// Besondere Linien und Kreise im Dreieck, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 16.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Perpendikul&yacute;ar bissektrisa";          // Mittelsenkrechte
var text02 = "Galtas&yacute;an t&ouml;werek";              // Umkreis
var text03 = "Bur&ccedil; bissektrisasy";                  // Winkelhalbierende
var text04 = "I&ccedil;ine &ccedil;yzylan t&ouml;werek";   // Inkreis
var text05 = "Dasyndan &ccedil;yzylan t&ouml;werekler";    // Ankreise
var text06 = "Ortaky parallel &ccedil;yzyklar";            // Mittelparallelen
var text07 = "Mediana";                                    // Seitenhalbierende
var text08 = "Be&yacute;iklik";                            // H�hen
var text09 = "E&yacute;ler &ccedil;yzyk";                  // Euler-Gerade
var text10 = "Feuerbach t&ouml;weregi";                    // Feuerbach-Kreis

var author = "W. Fendt 1998";
var translator = "PICT Turkmenistan";

