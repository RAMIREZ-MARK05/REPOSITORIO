// Umkreis eines Dreiecks, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 31.01.2021

// Texte in HTML-Schreibweise:

var text01 = "T&auml;zeden ba&scedil;la";
var text02 = "Indiki &auml;dim";
var author = "W. Fendt 1997"; 
var translator = "PICT Turkmenistan";

// Texte in Unicode-Schreibweise:

var text03 = [["\u00C7epde \u00FDerle\u015Fen \u015Fekil",                     // step == 0
               "g\u00F6rkez\u00FD\u00E4r ABC \u00FC\u00E7bur\u00E7lugy.",
               "Siz bu \u00FC\u00E7bur\u00E7lugy\u0148 depelerini",
               "s\u00FC\u00FD\u015F\u00FCrip bil\u00FD\u00E4\u0148iz",
               "my\u015Fka\u0148 knopkasyny basyp."],
              ["Orta perpendikul\u00FDary\u0148",                              // step == 1
               "\u00E4hli nokatlary m_(c)",
               "A we B nokatlardan de\u0148",
               "aralykda dur\u00FDarlar."],
              ["\u015Ee\u00FDlelikde m_(a) orta",                              // step == 2
               "perpendikul\u00FDarda \u00FDatan \u00E4hli",
               "nokatlar B we C nokatlardan",
               "de\u0148 da\u015Flykda dur\u00FDarlar."],
              ["Netijede, bu iki sany orta",                                   // step == 3
               "perpendikul\u00FDary\u0148 birle\u015Fdir\u00FD\u00E4n",
               "O nokaty\u0148 A we C \u00E7enli de\u0148",
               "aralygy bol\u00FDar."],
              ["Di\u00FDmek bu kesi\u015Fme (O)",                              // step == 4
               "nokady hem \u00FDerle\u015Fmeli",
               "\u00FC\u00E7\u00FCnji (m_(b)) perpendikul\u00FDarda."],
              ["Bu O nokady\u0148 \u00FC\u00E7bur\u00E7lugy\u0148",            // step == 5
               "hemme 3 depelerine \u00E7enli",
               "de\u0148 aralygy bolan \u00FC\u00E7in",
               "O da\u015Fynda \u00E4hli 3 depelerden",
               "bile a\u00FDlanyp ge\u00E7\u00FD\u00E4n",
               "t\u00F6werek emele gel\u00FD\u00E4r."],
              ["Bu t\u00F6wereg -",                                            // step == 6
               "galta\u015F\u00FDan t\u00F6werekdir."]];
               
var vertex1 = "A";
var vertex2 = "B";
var vertex3 = "C";
var circumcenter = "O";






