// Primzahlentabelle, turkmenische Texte (PICT Turkmenistan, unvollst�ndig)
// Letzte �nderung 29.01.2021

var textError = "Error!"; // ???                           // Text f�r Fehlermeldung
var textPrime = "bu &yacute;&ouml;neke&yacute;.";          // Text f�r Primzahl
var symbolMult = "&times;";                                // Multiplikationszeichen (HTML)
