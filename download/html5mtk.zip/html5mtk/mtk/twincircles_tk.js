// Zwillingskreise des Archimedes, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 29.01.2021

// Texte in HTML-Schreibweise:

var text01 = "K&ouml;mek&ccedil;i &ccedil;yzyklar:";
var text02 = "&ccedil;ep tarap";
var text03 = "sag tarap";

var author = "W. Fendt 2000,&nbsp; PICT Turkmenistan";
