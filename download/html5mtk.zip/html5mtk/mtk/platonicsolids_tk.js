// Platonische K�rper, turkmenische Texte (PICT Turkmenistan, unvollst�ndig!)
// Letzte �nderung 17.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Tetraedr";
var text02 = "Altygyranlyk (kub)";
var text03 = "Oktaedr";
var text04 = "Dodekaedr";
var text05 = "Ikosaedr";
var text06 = "A&yacute;lanma okuny &uuml;&yacute;tget";
var text07 = "Circumscribed Sphere"; // ???
var text08 = "Midsphere"; // ???
var text09 = "Inscribed Sphere"; // ???

var author = "W. Fendt 1998,&nbsp; PICT Turkmenistan";
