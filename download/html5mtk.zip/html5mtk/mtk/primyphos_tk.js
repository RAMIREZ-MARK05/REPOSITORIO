// Primyphos, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 16.01.2018

// Texte in HTML-Schreibweise:

var text01 = "K&ouml;peltme hasyly &yacute;aly g&ouml;rkez:";

var author = "W. Fendt 1998";

var symbolMultiply = "&times;";

// Texte in Unicode-Schreibweise:

var text02 = ["Gutla\u00FDarys!", 
              "Aja\u00FDyp!", 
              "\u00D6r\u00E4n gowy!", 
              "Erbet d\u00E4l!", 
              "Berekella!",
              "G\u00FC\u00FD\u00E7li t\u00E4sir galdyrdy!",
              "Fantastika!"];
              
var text03 = ["O\u00FDuny t\u00E4zeden baslamak islesen,",
              "myskanyn knopkasyny bas!"];

var symbolMultiplyUnicode = "\u00D7";
