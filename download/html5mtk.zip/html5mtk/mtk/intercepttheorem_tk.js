// Strahlensatz, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 17.01.2018

// Texte in HTML-Schreibweise:

var text01 = "V sekil";
var text02 = "X sekil";
var text03 = "Gatnasyk:";

var author = "W. Fendt 2000";
var translator = "PICT Turkmenistan";

// Symbole in Unicode-Schreibweise:

var symbolDivision = ":";

var symbolZ = "Z";
var symbolA1 = "A";
var symbolB1 = "B";
var symbolA2 = "A'";
var symbolB2 = "B'";



