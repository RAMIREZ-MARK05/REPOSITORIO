// Winkelfunktionen am Einheitskreis, turkmenische Texte (PICT Turkmenistan)
// Letzte �nderung 17.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Sinus";
var text02 = "Kosinus";
var text03 = "Tangens";

var author = "W. Fendt 1997";
var translator = "PICT Turkmenistan";

var decimalSeparator = ".";                      // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var symbolSine = "sin";                          // Symbol f�r Sinus
var symbolCosine = "cos";                        // Symbol f�r Cosinus
var symbolTangent = "tan";                       // Symbol f�r Tangens
var undef = "belli d\u00E4l!";                   // F�r Definitionsl�cken der Tangensfunktion
