// Photoelektrischer Effekt, polnische Texte (Barbara Sagnowska, Piotr Sagnowski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Materia&#322; katody:";
var text03 = "Barwa i d&#322;ugo&sacute;&cacute; fali (Hg):";
var text04 = "Napi\u0119cie hamuj\u0105ce:";
var text05 = "Cz&#281;stotliwo&sacute;&cacute;:";
var text06 = ["Energia", "fotonu:"];
var text07 = "Praca wyj&sacute;cia:";
var text08 = ["Maksymalna energia kinetyczna", "elektronu:"];
var text09 = "Usu&nacute; pomiary";

var author = "W. Fendt 2000,&nbsp; ZamKor 2001";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                 
var terahertz = "THz";                           
var electronvolt = "eV";                            

// Texte in Unicode-Schreibweise:

var text02 = ["cez", "s\u00F3d"];
var text10 = ["\u017c\u00F3\u0142ta", "zielona", "fioletowa", "ultrafiolet", "ultrafiolet"];
var text11 = "(w THz)";
var text12 = "(w V)";
var text13 = [
             ["Energia fotonu nie jest wystarczaj\u0105ca", "do spowodowania emisji elektronu."],
             ["Zwi\u0119ksz napi\u0119cie hamuj\u0105ce tak, by", "\u017Caden elektron nie dotar\u0142 do anody!"], 
             ["Napi\u0119cie hamuj\u0105ce jest zu du\u017Ce", "i elektrony wracaj\u0105 do katody."],
             ["Wykonaj kolejny pomiar dla innej", "d\u0142ugo\u015Bci fali!"],
             ["Wykonaj kolejn\u0105 seri\u0119 pomiar\u00F3w", "dla innego materia\u0142u katody!"],
             ["Pomiary s\u0105 zako\u0144czone.", ""]
             ];

var symbolCathode = "C";                           
var symbolAnode = "A";
var symbolFrequency = "\u03BD";
var symbolVoltage = "U";
