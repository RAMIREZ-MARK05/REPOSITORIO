// Beispiel zum Doppler-Effekt, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Od pocz&#261;tku";                           // Zur�ck
var text02 = ["Zatrzymaj",                                 // Pause
             "Wzn&oacute;w"];                              // Weiter

var author = "W. Fendt 1998";
var translator = "ZamKor 2001";

// Texte in Unicode-Schreibweise:                  

var text03 = [ 
             // Dadurch, dass sich der Notarzt-
             // wagen der Person n�hert,",
             // kommen die Wellenfronten
             // in k�rzeren Zeitabst�nden an.
             ["Dop\u00f3ki karetka pogotowia", 
              "zbli\u017ca si\u0119 do przechodnia,",
              "odst\u0119py mi\u0119dzy docieraj\u0105cymi",
              "do niego czo\u0142ami fali s\u0105 kr\u00f3tsze,",
              "a wi\u0119c cz\u0119stotliwo\u015b\u0107 odbieranego",
              "d\u017awi\u0119ku jest wi\u0119ksza."],                                       
              // Wenn sich das Fahrzeug
              // von der Person entfernt,
              // sind die zeitlichen Abst�nde
              // zwischen den eintreffenden
              // Wellenfronten verl�ngert.
             ["Teraz karetka oddala si\u0119", 
              "od przechodnia, wi\u0119c czo\u0142a fali",
              "docieraj\u0105 do przechodnia",
              "rzadziej, zatem cz\u0119stotliwo\u015b\u0107",
              "odbieranego d\u017awi\u0119ku jest mniejsza."]
             ];
  

