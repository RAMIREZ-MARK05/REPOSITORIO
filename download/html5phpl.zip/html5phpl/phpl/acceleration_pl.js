// Bewegung mit konstanter Beschleunigung, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text02 = ["Rozpocznij",                                // Start
              "Zatrzymaj",                                 // Pause
              "Wzn&oacute;w"];                             // Weiter
var text03 = "Spowolnij";                                  // Zeitlupe
var text04 = "Po&#322;o&zdot;enie pocz&#261;tkowe:";       // Anfangsposition
var text05 = "Wsp&oacute;&#322;rz&#281;dna pr&#281;dko&sacute;ci pocz&#261;tkowej:";     // Anfangsgeschwindigkeit
var text06 = "Wsp&oacute;&#322;rz&#281;dna przyspieszenia:";         // Beschleunigung
var text07 = "Pr&#281;dko&sacute;&cacute;";                // Geschwindigkeitsvektor
var text08 = "Przyspieszenie";                             // Beschleunigungsvektor

var author = "W. Fendt 2000";
var translator = "ZamKor 2006";

// Texte in Unicode-Schreibweise:

var text09 = "(s)";                                        // Einheitenangabe f�r Zeit-Achse
var text10 = "(m)";                                        // Einheitenangabe f�r Weg-Achse
var text11 = "(m/s)";                                      // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(m/s\u00b2)";                                // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                     
var meter = "m";                                   
var meterPerSecond = "m/s";                             
var meterPerSecond2 = "m/s\u00b2";                   
