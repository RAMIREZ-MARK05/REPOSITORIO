// Federpendel, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text02 = ["Rozpocznij",                                // Start
              "Zatrzymaj",                                 // Pause
              "Wzn&oacute;w"];                             // Weiter
var text03 = "Spowolnij";                                  // Zeitlupe
var text04 = "Wsp. spr&#281;&zdot;ysto&sacute;ci:";        // Federkonstante
var text05 = "Masa:";                                      // Masse
var text06x = "Warto&sacute;&cacute; przyspieszenia";      // Fallbeschleunigung, zus�tzliche Zeile (1)
var text06 = "grawitacyjnego:";                            // Fallbeschleunigung (2)
var text07 = "Amplituda:";                                 // Amplitude
var text08 = "Wsp&oacute;&#322;rz&#281;dna po&#322;o&zdot;enia";     // Elongation
var text09 = "Wsp&oacute;&#322;rz&#281;dna pr&#281;dko&sacute;ci";   // Geschwindigkeit
var text10 = "Wsp&oacute;&#322;rz&#281;dna przyspieszenia";          // Beschleunigung
var text11 = "Wsp&oacute;&#322;rz&#281;dna si&#322;y";     // Kraft
var text12 = "Energia";

var author = "W. Fendt 1998,&nbsp; ZamKor 2006";   
             

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var newtonPerMeter = "N/m";                           
var kilogram = "kg";                                 
var meterPerSecond2 = "m/s&sup2;";                     
var meter = "m";                                    

// Texte in Unicode-Schreibweise:

var text13 = "Warto\u015b\u0107 maksymalna";               // Maximum
var text14 = "Wsp\u00f3\u0142rz\u0119dna po\u0142o\u017cenia";       // Elongation
var text15 = "Wsp\u00f3\u0142rz\u0119dna pr\u0119dko\u015bci";       // Geschwindigkeit
var text16 = "Wsp\u00f3\u0142rz\u0119dna przyspieszenia";            // Beschleunigung
var text17 = "Wsp\u00f3\u0142rz\u0119dna si\u0142y";                 // Kraft
var text18 = "Energia potencjalna";                        // Potentielle Energie
var text19 = "Energia kinetyczna";                         // Kinetische Energie
var text20 = "Energia ca\u0142kowita";                     // Gesamtenergie
var text21 = "(s)";
var text22 = "(m)";
var text23 = "(m/s)";
var text24 = "(m/s\u00b2)";
var text25 = "(N)";
var text26 = "(J)";
var text27 = "Okres drga\u0144";                           // Schwingungsdauer

// Symbole und Einheiten: 

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                
var meterUnicode = "m";                             
var meterPerSecond = "m/s";                             
var meterPerSecond2Unicode = "m/s\u00b2";            
var newton = "N";                                      
var joule = "J";                                        

