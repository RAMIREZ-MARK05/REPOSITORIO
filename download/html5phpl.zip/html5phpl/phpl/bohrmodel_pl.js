// Bohrsches Atommodell, polnische Texte (ZamKor)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Model orbit kolowych";
var text02 = "Model falowy";
var text03 = "Gl&oacute;wna liczba kwantowa:";


var author = "W. Fendt 1999"; 
var translator = "ZamKor 2002";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



