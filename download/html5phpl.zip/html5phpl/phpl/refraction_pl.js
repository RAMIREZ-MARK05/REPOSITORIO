// Reflexion und Brechung von Licht, polnische Texte (Boguslaw Malanski, Szymon Malanski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = "Wsp. za&#322;am. o&sacute;rodka 1:";
var text02 = "Wsp. za&#322;am. o&sacute;rodka 2:";
var text03 = "K&#261;t padania:";
var text04 = "K&#261;t odbicia:";
var text05 = "K&#261;t za&#322;amania:";    
var text06 = ["", "K\u0105t graniczny:"];

var author = "W. Fendt 1997,&nbsp; ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                

// Texte in Unicode-Schreibweise:

var text07 = [["Pr\u00f3\u017cnia", "1"], ["Powietrze", "1.0003"],   // Stoffe und Brechungsindizes
    ["Woda", "1.33"], ["Etanol", "1.36"],
    ["Szk\u0142o kwarcowe", "1.46"], ["Benzen", "1.49"], 
    ["Szk\u0142o Crown N-K5", "1.52"], ["S\u00f3l kamienna", "1.54"], 
    ["Szk\u0142o Flint LF5", "1.58"], ["Szk\u0142o Crown N-SK4", "1.61"],
    ["Szk\u0142o Flint SF6", "1.81"], ["Diament", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                       
