// Elastischer und unelastischer Sto�, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Zderzenie elastyczne";                       // Elastischer Sto�
var text02 = "Zderzenie nieelastyczne";                    // Unelastischer Sto�
var text03 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text04 = "Rozpocznij";                                 // Start
var text05 = "Spowolnij";                                  // Zeitlupe
var text06 = "Wagon 1:";                                   // Wagen 1
var text07 = "Wagon 2:";                                   // Wagen 2
var text08 = "Masa:";                                      // Masse
var text09 = "Wsp. pr&#281;dko&sacute;ci:";                // Geschwindigkeit (Eingabe)
var text10 = "Pr&#281;dko&sacute;ci i ich wsp&oacute;&#322;rz&#281;dne";       // Geschwindigkeit (Option)
var text11 = "P&#281;dy i ich wsp&oacute;&#322;rz&#281;dne";                   // Impuls (Option)
var text12 = "Energia kinetyczna";                         // Kinetische Energie (Option)

var author = "W. Fendt 1998,&nbsp; ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                         

// Texte in Unicode-Schreibweise:

var text13 = "Wagon 1:";                                   // Wagen 1
var text14 = "Wagon 2:";                                   // Wagen 2
var text15 = "Pr\u0119dko\u015Bci i ich wsp\u00F3\u0142rz\u0119dne przed zderzeniem:";   // Geschwindigkeiten vor dem Sto�
var text16 = "Pr\u0119dko\u015Bci i ich wsp\u00F3\u0142rz\u0119dne po zderzeniu:";       // Geschwindigkeiten nach dem Sto�
var text17 = "P\u0119 i ich wsp\u00F3\u0142rz\u0119dne przed zderzeniem:";               // Impulse vor dem Sto�
var text18 = "P\u0119 i ich wsp\u00F3\u0142rz\u0119dne po zderzeniu:";                   // Impulse nach dem Sto�
var text19 = "Energia kinatyczna przed zderzeniem:";       // Energie vor dem Sto�
var text20 = "Energia kinetyczna po zderzeniu:";           // Energie nach dem Sto�
var text21 = "Ca\u0142kowity:";                            // Gesamtimpuls
var text22 = "Ca\u0142kowita energia kinetyczna:";         // Gesamte kinetische Energie

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                
var kilogramMeterPerSecond = "kg m/s";            
var joule = "J";                                  
