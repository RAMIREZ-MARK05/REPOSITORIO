// Elektromagnetischer Schwingkreis, polnische Texte (ZamKor)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text02 = ["Rozpocznij",                                // Start
             "Zatrzymaj",                                  // Pause
             "Wzn&oacute;w"];                              // Weiter
var text03 = "Spowolnij (10 &times;)";                     // Zeitlupe (10 x)
var text04 = "Spowolnij (100 &times;)";                    // Zeitlupe (100 x)
var text05 = "Pojemno&sacute;&cacute;:";                   // Kapazit�t
var text06 = "Indukcyjno&sacute;&cacute;:";                // Induktivit�t
var text07 = "Op&oacute;r:";                               // Widerstand
var text08 = "Napi&#281;cie maksymalne:";                  // Maximale Spannung
var text09 = "Napi&#281;cie, Nat&#281;&zdot;enie";         // Spannung, Stromst�rke
var text10 = "Energia";                                    // Energie

var author = "W. Fendt 1999,&nbsp; ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                            
var henry = "H";                                    
var ohm = "&Omega;";                                
var volt = "V";                                  

// Texte in Unicode-Schreibweise:

var text11 = "Okres drga\u0144:";                          // Schwingungsdauer
var text12 = "Energia pola elektrycznego:";                // Elektrische Feldenergie
var text13 = "Energia pola magnetycznego:";                // Magnetische Feldenergie
var text14 = "Energia tracona na ciep\u0142o Joule'a:";    // Innere Energie
var text15 = "Dragania niet\u0142umione";                  // Unged�mpfte Schwingung
var text16 = "Drgania t\u0142umione";                      // Ged�mpfte Schwingung
var text17 = "T\u0142umienie krytyczne";                   // Aperiodischer Grenzfall
var text18 = "T\u0142umienie nadkrytyczne";                // Kriechfall

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                 
var voltUnicode = "V";                            
var ampere = "A";                              
var joule = "J";                                   
