// Ersatzkraft mehrerer Kr�fte, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Liczba si&#322;:";                           // Zahl der Einzelkr�fte
var text02 = "Znajd&zacute; wypadkow&#261;";               // Gesamtkraft ermitteln
var text03 = "Usu&nacute; konstrukcj&#281;";               // Konstruktion l�schen

var author = "W. Fendt 1998";
var translator = "ZamKor 2006";
