// Newtons Wiege, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text02 = "Rozpocznij";                                 // Start
var text03 = "Liczba kul:";                                // Zahl der ausgelenkten Kugeln

var author = "W. Fendt 1997";
var translator = "ZamKor 2006";
