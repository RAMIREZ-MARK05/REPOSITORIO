// Druckdose (hydrostatischer Druck), polnische Texte (ZamKor)
// Letzte �nderung 05.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Ciecz:";
var text03 = "G&#281;sto&sacute;&cacute;:";
var text04 = "G&#322;&#281;boko&sacute;&cacute;:";
var text05 = "Ci&sacute;nienie hydrostatyczne:";

var author = "W. Fendt 1999";                              // Autor
var translator = "ZamKor 2006";                            // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["nieznana", "woda", "etanol", "benzen", "tetrachlorometan", "rt\u0119\u0107"]; 
