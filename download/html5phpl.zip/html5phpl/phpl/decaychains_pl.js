// Zerfallsreihen, polnische Texte (ZamKor, WWW-Recherche)
// Letzte �nderung 11.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Szereg promieniotw&oacute;rcze:";
var text03 = "Kolejny rozpad";

var author = "W. Fendt 1998"; 
var translator = "ZamKor 2006";

// Texte in Unicode-Schreibweise:

var text02 = ["Szereg torowy", "Szereg neptunowy", "Szereg uranowy", "Szereg aktynowy"];          





