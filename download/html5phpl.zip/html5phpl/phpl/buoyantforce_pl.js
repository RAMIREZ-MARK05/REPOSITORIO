// Messung der Auftriebskraft, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Pole podstawy klocka:";                      // Grundfl�che des Quaders
var text02 = "Wysoko&sacute;&cacute; klocka:";             // H�he des Quaders
var text03 = "G&#281;sto&sacute;&cacute; klocka:";         // Dichte des Quaders
var text04 = "G&#281;sto&sacute;&cacute; cieczy:";         // Dichte der Fl�ssigkeit
var text05 = "Zanurzenie:";                                // Eintauchtiefe
var text06 = "Obj&#281;to&sacute;&cacute; wypartej cieczy:";    // Verdr�ngtes Volumen
var text07 = "Warto&sacute;&cacute; si&#322;y wyporu:";    // Auftriebskraft
var text08 = "Warto&sacute;&cacute; ci&#281;&zdot;aru klocka:"; // Gewichtskraft
var text09 = "Wskazanie si&#322;omierza:";                 // Gemessene Kraft
var text10 = "Zakres pomiarowy si&#322;omierza:";          // Messbereich

var author = "W. Fendt 1998,&nbsp; ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Przekroczony zakres pomiarowy!";             // Messbereich �berschritten!
