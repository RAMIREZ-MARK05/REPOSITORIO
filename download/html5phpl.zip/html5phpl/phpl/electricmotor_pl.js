// Gleichstrom-Elektromotor, polnische Texte (Jadwiga Salach, Piotr Sagnowski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text02 = ["Rozpocznij",                                // Start
             "Zatrzymaj",                                  // Pause
             "Wzn&oacute;w"];                              // Weiter
var text03 = "Zmie&nacute; kierunek pr&#261;du";           // Umpolen
var text04 = "Kierunek pr&#261;du";                        // Stromrichtung
var text05 = "Pole magnetyczne";                           // Magnetfeld
var text06 = "Si&#322;a elektrodynamiczna";                // Lorentzkraft

var author = "W. Fendt 1997";               
var translator = "ZamKor 2001";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "obr/min";                        // Umdrehungen pro Minute
