// Erstes Kepler-Gesetz, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "D&#322;go&sacute;&cacute; p&oacute;&#322;osi wielkiej:";         // Gro�e Halbachse
var text03 = "Warto&sacute;&cacute; mimo&sacute;rodu:";                        // Numerische Exzentrizit�t
var text04 = "D&#322;go&sacute;&cacute; p&oacute;&#322;osi ma&#322;ej:";       // Kleine Halbachse
var text05 = ["Zatrzymaj",                                                     // Pause 
              "Wzn&oacute;w"];                                                 // Weiter
var text06 = "Spowolnij";                                                      // Zeitlupe
var text07 = "Odleg&#322;o&sacute;&cacute; od S&#322;o&nacute;ca:";            // Entfernung von der Sonne
var text08 = "Odleg&#322;o&sacute;&cacute; chwilowa:";                         // Aktueller Wert
var text09 = "Minimalna:";                                                     // Minimum
var text10 = "Maksymalna:";                                                    // Maximum
var text11 = "Orbita eliptyczna";                                              // Bahnellipse
var text12 = "Osie";                                                           // Achsen
var text13 = "Linie &#322;&#261;cz&#261;ce zogniskami elipsy";                 // Verbindungsstrecken

var author = "W. Fendt 2000,&nbsp; ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "j.a.";                                           // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Merkury", "Wenus", "Ziemia", "Mars", "Jowisz", "Saturn", "Uran", "Neptun",
              "Pluton", "Kometa Halley'a", ""];

var text14 = "S\u0142o\u0144ce";                           // Sonne
var text15 = "Planeta";                                    // Planet
var text16 = "Kometa";                                     // Komet
var text17 = "Peryhelium";                                 // Perihel
var text18 = "Aphelium";                                   // Aphel

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "j.a.";

