// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), polnische Texte (Barbara Sagnowska, Piotr Sagnowski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Od pocz&#261;tku";                           // Neustart
var text02 = "Nast&#281;pny krok";                         // N�chster Schritt
var text03 = ["Zatrzymaj", "Wzn&oacute;w"];                // Pause/Weiter                  
var text04 = "Wsp. za&#322;am. o&sacute;rodka 1:";         // 1. Brechungsindex
var text05 = "Wsp. za&#322;am. o&sacute;rodka 2:";         // 2. Brechungsindex
var text06 = "K&#261;t padania:";                          // Einfallswinkel

var author = "W. Fendt 1998";
var translator = "ZamKor 2001";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad

// Texte in Unicode-Schreibweise:

var text07 = [
  ["Czo\u0142o fali dochodzi",                             // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "do granicy dw\u00F3ch o\u015Brodk\u00F3w.",
   "Szybko\u015Bci rozchodzenia si\u0119 fali",
   "w tych o\u015Brodkach s\u0105 r\u00F3\u017Cne."],
   
  ["Promie\u0144 fali (prostopad\u0142y do",               // i == 1 (step == 0, n1 != n2, eps1 == 0) 
   "czo\u0142a fali) pada pod k\u0105tem 0 st.",
   "na granic\u0119 dw\u00F3ch o\u015Brodk\u00F3w.",
   "Szybko\u015Bci rozchodzenia si\u0119 fali",
   "w tych o\u015Brodkach s\u0105 r\u00F3\u017Cne."],
   
  ["Ka\u017Cdy punkt o\u015Brodka, do",                    // i == 2 (step == 1, n1 > n2) 
   "kt\u00F3rego dochodzi fala, staje",
   "si\u0119 \u017Ar\u00F3d\u0142em nowej fali kulistej",
   "(zgodnie z zasad\u0105 Huygensa).",
   "(W programie rozpatrujemy tylko",
   "punkty na granicy obu o\u015Brodk\u00F3w.)",
   "W o\u015Brodku 2 fale elementarne",
   "poruszaj\u0105 si\u0119 szybciej, ni\u017C",
   "w o\u015Brodku 1, zgodnie z przyj\u0119tymi",
   "warto\u015Bciami wsp\u00F3\u0142czynnik\u00F3w",
   "za\u0142amania."],
   
  ["Ka\u017Cdy punkt na granicy o\u015Brodk\u00F3w,",      // i == 3 (step == 1, n1 < n2)
   "do kt\u00F3rego dochodzi fala, staje",
   "si\u0119 \u017Ar\u00F3d\u0142em nowej fali kulistej",
   "(zgodnie z zasad\u0105 Huygensa).",
   "(W programie rozpatrujemy tylko",
   "punkty na granicy obu o\u015Brodk\u00F3w.)",
   "W o\u015Brodku 2 fale elementarne",
   "poruszaj\u0105 si\u0119 wolniej, ni\u017C",
   "w o\u015Brodku 1, zgodnie z przyj\u0119tymi",
   "warto\u015Bciami wsp\u00F3\u0142czynnik\u00F3w",
   "za\u0142amania."],
   
  ["Wskutek nak\u0142adania si\u0119 fal",                 // i == 4 (step == 2, total == false, eps1 > 0)
   "elementarnych w ka\u017Cdym o\u015Brodku",
   "powstaje nowa fala p\u0142aska.",
   "Zauwa\u017C, \u017Ce kierunek rozchodzenia",
   "si\u0119 nowej fali w ka\u017Cdym o\u015Brodku",
   "jest inny."], 
   
  ["Na skutek interferencji fal",                          // i == 5 (step == 2, total == false, eps1 == 0)
   "elementarnych w ka\u017Cdym o\u015Brodku",
   "powstaje fala p\u0142aska."],  
   
  ["Wskutek nak\u0142adania si\u0119 fal",                 // i == 6 (step == 2, total == true)
   "elementarnych w o\u015Brodku 1",
   "powstaje nowa fala p\u0142aska",
   "(fala odbita).",
   "W o\u015Brodku 2 taka fala",
   "nie powstaje (ca\u0142kowite",
   "odbicie wewn\u0119trzne)."], 
   
  ["W tym kroku pokazano kierunek",                        // i == 7 (step == 3)
   "rozchodzenia si\u0119 fali, czyli",
   "promie\u0144 fali. Jest on prostopad\u0142y",
   "do powierzchni falowej fali",
   "odbitej i za\u0142amanej."],
   
  ["Najcz\u0119\u015bciej nie mamy do czynienia",          // i == 8 (step == 4)
   "z pojedynczym impulsem falowym.",
   "Na rysunku przedstawiono",
   "kolejne powierzchnie falowe."],
   
  ["Je\u017Celi wsp\u00F3\u0142czynniki za\u0142amania",   // i == 9 (n1 == n2)
   "obu o\u015Brodk\u00F3w s\u0105 jednakowe (fala",
   "w obu o\u015Brodkach rozchodzi si\u0119",
   "z t\u0105 sam\u0105 szybko\u015Bci\u0105), fala nie",
   "zauwa\u017Ca zmiany o\u015Brodka."]];
          
var text08 = "K\u0105t padania:";                          // Einfallswinkel 
var text09 = "K\u0105t odbicia:";                          // Reflexionswinkel
var text10 = "K\u0105t za\u0142amania:";                   // Brechungswinkel
var text11 = "O\u015Brodek 1";                             // Medium 1
var text12 = "O\u015Brodek 2";                             // Medium 2
var text13 = ["K\u0105t graniczny dla",                    // Grenzwinkel der Totalreflexion (1)
  "ca\u0142kowitego wewn\u0119trznego odbicia:"];          // Grenzwinkel der Totalreflexion (2)

// Einheiten:

var degreeUnicode = "\u00b0";                              // Grad
