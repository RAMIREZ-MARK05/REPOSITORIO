// Gleichgewicht dreier Kr�fte, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Si&#322;y:";                                 // Kr�fte
var text02 = "w lewo:";                                    // Links
var text03 = "w prawo:";                                   // Rechts
var text04 = "w d&oacute;&#322;:";                         // Unten
var text05 = "R&oacute;wnoleg&#322;obok si&#322;";         // Kr�fteparallelogramm
var text06 = "K&#261;ty:";                                 // Winkel
var text07 = "w lewo:";                                    // Links
var text08 = "w prawo:";                                   // Rechts

var author = "W. Fendt 2000";
var translator = "ZamKor 2006";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                                     // Symbol f�r Grad
var newton = "N";                                     
