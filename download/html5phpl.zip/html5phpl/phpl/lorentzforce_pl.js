// Leiterschaukel-Versuch zur Lorentzkraft, polnische Texte (Barbara Sagnowska, Piotr Sagnowski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "W&#322;&#261;cz / Wy&#322;&#261;cz";         // Ein / Aus
var text02 = "Zmie&nacute; kier. pr&#261;du";              // Umpolen
var text03 = "Odwr&oacute;&cacute; magnes";                // Magnet umdrehen
var text04 = "Kierunek pr&#261;du";                        // Stromrichtung
var text05 = "Pole magnetyczne";                           // Magnetfeld
var text06 = "Si&#322;a elektrodynamiczna";                // Lorentzkraft

var author = "W. Fendt 1998";
var translator = "ZamKor 2001";
