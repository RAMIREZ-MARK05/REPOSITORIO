// Magnetfeld eines geraden stromdurchflossenen Leiters, polnische Texte (Boguslaw und Szymon Malanski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Zmie&nacute; kierunek pr&#261;du";           // Umpolen

var author = "W. Fendt 2000";
var translator = "B., S. Mala&nacute;ski 2005";
