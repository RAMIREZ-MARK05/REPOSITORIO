// Kr�fte an der schiefen Ebene, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text02 = ["Rozpocznij",                                // Start
              "Zatrzymaj",                                 // Pause
              "Wzn&oacute;w"];                             // Weiter
var text03 = "Spowolnij";                                  // Zeitlupe
var text04 = "Si&#322;omierz";                             // Federwaage
var text05 = "Si&#322;y";                                  // Kraftvektoren
var text06 = "K&#261;t nachylenia:";                       // Neigungswinkel
var text07 = "Ci&#281;&zdot;ar:";                          // Gewichtskraft
var text08 = "Sk&#322;adowa r&oacute;wnoleg&#322;a:";      // Hangabtriebskraft
var text09 = "Sk&#322;adowa prostopad&#322;a:";            // Normalkraft
var text10 = "Wsp&oacute;&#322;czynnik tarcia:";           // Reibungszahl
var text11 = "Si&#322;a tarcia:";                          // Reibungskraft
var text12 = "Si&#322;a r&oacute;wnowa&zdot;&#261;ca:";    // Zugkraft

var author = "W. Fendt 1999,&nbsp; ZamKor 2006";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                    
var newton = "N";                     
