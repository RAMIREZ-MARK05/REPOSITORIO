// Kettenkarussell, polnische Texte (Barbara Sagnowska, Piotr Sagnowski, ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Karuzela";
var text02 = "Karuzela z si&#322;ami";
var text03 = "R&oacute;wnoleg&#322;obok si&#322;";
var text04 = "Warto&sacute;ci liczbowe";
var text05 = ["Zatrzymaj", " Wzn&oacute;w"];
var text06 = "Spowolnienie";
var text07 = "Okres:";
var text08 = ["Odleg&#322;o&sacute;&cacute; mi&#281;dzy punktem zaczepienia", 
              "a osi&#261; obrotu:"]; 
var text09 = "D&#322;ugo&sacute;&cacute; linek:";
var text10 = "Masa kulki:";

var author = "W. Fendt 1999,&nbsp; ZamKor 2001";

// Texte in Unicode-Schreibweise:

var text11 = "Cz\u0119stotliwo\u015b\u0107:";
var text12 = "Szybko\u015b\u0107 k\u0105towa:";
var text13 = "Promie\u0144:";
var text14 = "Szybko\u015b\u0107 liniowa:";
var text15 = "K\u0105t odchylenia:";
var text16 = "Warto\u015b\u0107 ci\u0119\u017caru kulki:";
var text17 = "Warto\u015b\u0107 si\u0142y do\u015brodkowej:";
var text18 = "Warto\u015b\u0107 si\u0142y napi\u0119cia nici:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




