// Zerfallsgesetz der Radioaktivit�t, polnische Texte (Barbara Sagnowska, Piotr Sagnowski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text02 = ["Rozpocznij",                                // Start
              "Zatrzymaj",                                 // Pause
              "Wzn&oacute;w"];                             // Weiter    
var text03 = "Diagram";                                    // Diagramm

var author = "W. Fendt 1998";
var translator = "ZamKor 2001";

// Texte in Unicode-Schreibweise:

var text04 = "Czas:";                                      // Zeit                                      
var text05 = "Zosta\u0142o:";                              // Noch nicht zerfallen
var text06 = "Rozpad\u0142o si\u0119:";                    // Schon zerfallen
var text07 = ["j\u0105der", "j\u0105dro", "j\u0105der", "j\u0105der"];         // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
