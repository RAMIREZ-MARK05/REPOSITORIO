// Interferenz zweier Kreis- oder Kugelwellen, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = ["Zatrzymaj",                                 // Pause
             "Wzn&oacute;w"];                              // Weiter
var text02 = "Spowolnienie";                               // Zeitlupe
var text03 = "Odleg&#322;o&sacute;&cacute; mi&#281;dzy &zacute;r&oacute;d&#322;ami";     // Entfernung der beiden Wellenzentren (1)
var text04 = "fal:";                                                                     // Entfernung der beiden Wellenzentren (2)
var text05 = "D&#322;ugo&sacute;&cacute; fali:";           // Wellenl�nge

var author = "W. Fendt 1999";
var translator = "ZamKor 2001";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                               

// Texte in Unicode-Schreibweise:

var text06 = "R\u00f3\u017cnica odleg\u0142o\u015bci od \u017ar\u00f3de\u0142:";         // Gangunterschied
var text07 = "Maksymalne wzmocnienie";                     // Konstruktive Interferenz (Amplitude maximal)
var text08 = "Maksymalne os\u0142abienie";                 // Destruktive Interferenz (Amplitude minimal)

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (Lambda)
