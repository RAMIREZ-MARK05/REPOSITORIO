// Stehende Welle, Erkl�rung durch Reflexion, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Odbicie";                                    // Reflexion
var text02 = "koniec zamocowany";                          // am festen Ende
var text03 = "koniec swobodny";                            // am losen Ende
var text04 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text05 = ["Rozpocznij",                                // Start
             "Zatrzymaj",                                  // Pause
             "Wzn&oacute;w"];                              // Weiter
var text06 = "Spowolnij";                                  // Zeitlupe
var text07 = "Animacja";                                   // Animation
var text08 = "Pojedyncze kroki";                           // Einzelschritte
var text09 = "Fala padaj&#261;ca";                         // Einfallende Welle
var text10 = "Fala odbita";                                // Reflektierte Welle
var text11 = "Wypadkowa fala stoj&#261;ca";                // Resultierende stehende Welle

var author = "W. Fendt 2003"; 
var translator = "ZamKor 2006";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "W";
var symbolAntiNode = "S";

