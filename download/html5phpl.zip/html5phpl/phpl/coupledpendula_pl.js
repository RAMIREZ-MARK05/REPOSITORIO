// Gekoppelte Pendel, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck                           
var text02 = ["Rozpocznij",                                // Start
              "Zatrzymaj",                                 // Pause
              "Wzn&oacute;w"];                             // Weiter
var text03 = "Spowolnij";                                  // Zeitlupe
var text04 = "Wsp&oacute;&#322;rz&#281;dna po&#322;o&zdot;enia pocz&#261;tkowego:";      // Anfangspositionen

var author = "W. Fendt 1998";
var translator = "ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                             

// Texte in Unicode-Schreibweise:

var text05 = "Wahad\u0142o 1";                             // Erstes Pendel (links)
var text06 = "Wahad\u0142o 2";                             // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
