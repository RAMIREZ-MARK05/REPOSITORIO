// Zweites Kepler-Gesetz, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:
    
var text02 = "D&#322;go&sacute;&cacute; p&oacute;&#322;osi wielkiej:";         // Gro�e Halbachse
var text03 = "Warto&sacute;&cacute; mimo&sacute;rodu:";                        // Numerische Exzentrizit�t
var text04 = ["Zatrzymaj",                                                     // Pause
              "Wzn&oacute;w"];                                                 // Weiter
var text05 = "Spowolnij";                                                      // Zeitlupe
var text06 = ["Odleg&#322;o&sacute;&cacute;",                                  // Entfernung von der Sonne (1)
              "od S&#322;o&nacute;ca:"];                                       // Entfernung von der Sonne (2)
var text07 = "Szybko&sacute;&cacute;";                                         // Geschwindigkeit
var text08 = "Chwilowa:";                                                      // Aktueller Wert
var text09 = "Minimalna:";                                                     // Minimum
var text10 = "Maksymalna:";                                                    // Maximum
var text11 = "Sektory";                                                        // Sektoren
var text12 = "Pr&#261;dko&sacute;&cacute;";                                    // Geschwindigkeitsvektor

var author = "W. Fendt 2000,&nbsp; ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "j.a.";                                           // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Merkury", "Wenus", "Ziemia", "Mars", "Jowisz", "Saturn", "Uran", "Neptun",
              "Pluton", "Kometa Halley'a", ""];

// Symbole und Einheiten: 

var auUnicode = "j.a.";
var symbolPeriod = "T";

