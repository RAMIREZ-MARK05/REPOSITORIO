// Einfache Wechselstromkreise, polnische Texte (ZamKor)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Opornik";                                    // Widerstand (Bauteil)
var text02 = "Kondensator";                                // Kondensator
var text03 = "Zwojnica";                                   // Spule
var text04 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text05 = ["Rozpocznij",                                // Start
             "Zatrzymaj",                                  // Pause
             "Wzn&oacute;w"];                              // Weiter
var text06 = "Spowolnij";                                  // Zeitlupe
var text07 = "Cz&#281;stotliwo&sacute;&cacute;:";          // Frequenz
var text08 = "Napi&#281;cie maks.:";                       // Maximale Spannung
var text09 = "Op&oacute;r:";                               // Widerstand (Gr��e)
var text10 = "Pojemno&sacute;&cacute;:";                   // Kapazit�t                          
var text11 = "Indukcyjno&sacute;&cacute;:";                // Induktivit�t 
var text12 = "Nat&#281;&zdot;enie maks.:";                 // Maximale Stromst�rke 

var author = "W. Fendt 1998,&nbsp; ZamKor 2006";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                   
var volt = "V";                                 
var ampere = "A";                                
var milliampere = "mA";                       
var microampere = "&mu;A";                      
var ohm = "&Omega;";                              
var microfarad = "&mu;F";                        
var henry = "H";                                    

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
