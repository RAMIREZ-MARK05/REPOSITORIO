// Kombinationen von Widerst�nden, Spulen und Kondensatoren, polnische Texte (ZamKor)
// Letzte �nderung 21.03.2020

// Texte in HTML-Schreibweise:

var text01 = "&Zacute;r&oacute;d&#322;o napi&#281;cia przemiennego:";
var text02 = "Napi&#281;cie skuteczne:";
var text03 = "Cz&#281;stotliwo&sacute;&cacute;:";
var text04 = "Elementy obwodu:";
var text05 = ["Opornik", "Zwojnica", "Kondensator"];
var text06 = ["Op&oacute;r (rezystancja):", "Indukcyjno&sacute;&cacute;:", "Pojemno&sacute;&cacute;:"];
var text07 = "Zamie&nacute;";
var text08 = "Dodaj (szeregowo)";
var text09 = "Dodaj (r&oacute;wnolegle)";
var text10 = "Usu&nacute;";
var text11 = "Poka&zdot;:";
var text12 = "Napi&#281;cie skuteczne";
var text13 = "Nat&#281;&zdot;enie skuteczne";

var author = "W. Fendt 2004";
var translator = "ZamKor 2006";

// Texte in Unicode-Schreibweise:

var text14 = "Napi\u0119cie skuteczne:";
var text15 = "Nat\u0119\u017cenie skuteczne:";
var text16 = "Zawada zespolona:";
var text17 = "Zawada:";
var text18 = "Przesuni\u0119cie fazowe:";
var text19 = "bardzo ma\u0142e";                           // Stromst�rke Voltmeter
var text20 = "bardzo ma\u0142e";                           // Spannung Amperemeter
var text21 = "bardzo ma\u0142e";                           // Impedanz/Widerstand Amperemeter
var text22 = "bardzo du\u017ce";                           // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)