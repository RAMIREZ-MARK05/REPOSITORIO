// Schiefer Wurf, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck                    
var text02 = ["Rozpocznij",                                // Start
              "Zatrzymaj",                                 // Pause
              "Wzn&oacute;w"];                             // Weiter
var text03 = "Spowolnienie";                               // Zeitlupe
var text04 = "Wysoko&sacute;&cacute; pocz&#261;tkowa:";    // Ausgangsh�he
var text05 = "Szybko&sacute;&cacute; pocz&#261;tkowa:";    // Anfangsgeschwindigkeit
var text06 = "K&#261;t nachylenia:";                       // Winkel
var text07 = "Masa:";                                      // Masse
var text08 = "Przyspieszenie grawitacyjne:";               // Fallbeschleunigung
var text09 = "Wsp&oacute;&#322;rz&#281;dne";               // Position
var text10 = "Pr&#281;dko&sacute;&cacute;";                // Geschwindigkeit
var text11 = "Przyspieszenie";                             // Beschleunigung
var text12 = "Si&#322;a";                                  // Kraft
var text13 = "Energia";                                    // Energie

var author = "W. Fendt 2000,&nbsp; ZamKor 2006";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                    
var meterPerSecond = "m/s";                          
var meterPerSecond2 = "m/s&sup2;";                 
var kilogram = "kg";                               
var degree = "&deg;";                                  

// Texte in Unicode-Schreibweise:

var text14 = "(m)";                                        // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Wsp\u00F3\u0142rz\u0119dne:";                // Position
var text16 = "(pozioma)";                                  // waagrecht
var text17 = "(pionowa)";                                  // senkrecht
var text18 = "Zasi\u0119g rzutu:";                         // Wurfweite
var text19 = "Wys. maks.:";                                // Maximale H�he
var text20 = "Czas:";                                      // Dauer
var text21 = "Wsp\u00F3\u0142rz\u0119dne wektora pr\u0119dko\u015bci:";        // Geschwindigkeitskomponenten
var text22 = "Warto\u015b\u0107 wektora pr\u0119dko\u015bci:";                 // Geschwindigkeitsbetrag
var text23 = "K\u0105t nachylenia:";                       // Winkel
var text24 = "Przyspieszenie:";                            // Beschleunigung
var text25 = "Si\u0142a:";                                 // Kraft
var text26 = "Energia kinetyczna:";                        // Kinetische Energie
var text27 = "Energia potencjalna:";                       // Potentielle Energie
var text28 = "Energia ca\u0142kowita:";                    // Gesamtenergie

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                               
var secondUnicode = "s";                                 
var meterPerSecondUnicode = "m/s";                    
var meterPerSecond2Unicode = "m/s\u00b2";           
var newtonUnicode = "N";                          
var jouleUnicode = "J";                             
var degreeUnicode = "\u00b0";             



