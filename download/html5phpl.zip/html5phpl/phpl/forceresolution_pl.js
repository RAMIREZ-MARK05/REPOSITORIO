// Zerlegung einer Kraft in zwei Komponenten, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Warto&sacute;&cacute; danej";                // Betrag der gegebenen Kraft (1)
var text02 = "si&#322;y:";                                 // Betrag der gegebenen Kraft (2)
var text03 = "K&#261;ty:";                                 // Winkelgr��en
var text04 = "K&#261;t 1:";                                // 1. Winkel
var text05 = "K&#261;t 2:";                                // 2. Winkel
var text06 = "Warto&sacute;ci si&#322; sk&#322;adowych:";  // Betr�ge der Kraftkomponenten
var text07 = "Sk&#322;adowa 1:";                           // 1. Komponente
var text08 = "Sk&#322;adowa 2:";                           // 2. Komponente
var text09 = "Znajd&zacute; sk&#322;adowe";                // Komponenten ermitteln
var text10 = "Usu&nacute; konstrukcj&#281;";               // Konstruktion l�schen

var author = "W. Fendt 2003";
var translator = "ZamKor 2006";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                
var newton = "N";                                 

// Texte in Unicode-Schreibweise:

var text11 = "Sk\u0142adowa 1";                            // Text f�r erste Komponente
var text12 = "Sk\u0142adowa 2";                            // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                      