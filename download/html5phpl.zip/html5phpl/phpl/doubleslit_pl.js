// Interferenz von Licht am Doppelspalt, polnische Texte (Boguslaw Malanski, Szymon Malanski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "D&#322;ugo&sacute;&cacute; fali:";
var text02 = "Odst&#281;p mi&#281;dzy szczelinami:";
var text03 = "K&#261;t:";
var text04 = "Maksima:";
var text05 = "Minima:";
var text06 = "Wzgl&#281;dne nat&#281;&zdot;enie:";
var text07 = "Obraz interferencyjny";
var text08 = "Wykres nat&#281;&zdot;enia";

var author = "W. Fendt 2003,&nbsp; B., S. Mala&nacute;ski 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
