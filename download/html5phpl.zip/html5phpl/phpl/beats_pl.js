// Schwebungen, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text02 = ["Rozpocznij",                                // Start
             "Zatrzymaj",                                  // Pause
             "Wzn&oacute;w"];                              // Weiter
var text03 = "Spowolnij";                                  // Zeitlupe
var text04 = "Cz&#281;stotliwo&sacute;ci:";                // Frequenzen
var text05 = "fala 1:";                                    // 1. Welle
var text06 = "fala 2:";                                    // 2. Welle

var author = "W. Fendt 2001"; 
var translator = "ZamKor 2006";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



