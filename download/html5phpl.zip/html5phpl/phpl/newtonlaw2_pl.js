// Fahrbahnversuch zum 2. Newtonschen Gesetz, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Wyczy&sacute;&cacute;";
var text02 = ["Rozpocznij", "Zapisz dane"];
var text03 = "Diagram";
var text04 = "Masa w&oacute;zka:";
var text05 = "Masa obci&#261;&zdot;nika:";
var text06 = "Wsp&oacute;&#322;czynnik tarcia:";
var text07 = "Dane:";

var author = "W. Fendt 1997,&nbsp; ZamKor 2001";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "F";
var text09 = "(s)";
var text10 = "(m)";
var text11 = "Zbyt du\u017Ce tarcie!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


