// Generator, polnische Texte (Barbara Sagnowska, Piotr Sagnowski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise;

var text01 = "Bez komutatora";                             // Ohne Kommutator
var text02 = "Z komutatorem";                              // Mit Kommutator
var text03 = "Zmie&nacute; kier. obrotu";                  // Umgekehrte Richtung
var text04 = ["Rozpocznij",                                // Start
             "Zatrzymaj",                                  // Pause
             "Wzn&oacute;w"];                              // Weiter
var text05 = "Kierunek obrotu";                            // Bewegungsrichtung
var text06 = "Pole magnetyczne";                           // Magnetfeld
var text07 = "Indukowany pr&#261;d";                       // Induzierter Strom";

var author = "W. Fendt 1998";  
var translator = "ZamKor 2001";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "obr/min";                        // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
