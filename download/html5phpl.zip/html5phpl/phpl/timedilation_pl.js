// Beispiel zur Zeitdilatation, polnische Texte (ZamKor)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Zmniejsz szybko&sacute;&cacute;";
var text02 = "Zwi&#281;ksz szybko&sacute;&cacute;";
var text03 = "Przywr&oacute;&cacute;";
var text04 = ["Start", "Zatrzymaj", "Wzn&oacute;w"];

var author = "W. Fendt 1997,&nbsp; ZamKor 2001";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "Odleg\u0142o\u015b\u0107:";
var text06 = "5 godzin \u015bwietlnych";
var text07 = "Szybko\u015b\u0107:";
var text08 = "Czas lotu (uk\u0142ad Ziemi):";
var text09 = "godz.";
var text10 = "Czas lotu (uk\u0142ad statku):";