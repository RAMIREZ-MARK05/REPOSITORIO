// Magnetfeld eines Stabmagneten, polnische Texte (Boguslaw und Szymon Malanski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Usu&nacute; linie pola";                     // Feldlinien l�schen
var text02 = "Obr&oacute;&cacute; magnes";                 // Magnet umdrehen

var author = "W. Fendt 2001";
var translator = "B., S. Mala&nacute;ski 2005";
