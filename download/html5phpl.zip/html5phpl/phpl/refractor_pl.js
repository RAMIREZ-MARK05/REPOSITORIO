// Kepler-Fernrohr, polnische Texte (ZamKor)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Ogniskowa:"; 
var text02 = "Objektyw:";
var text03 = "Okular:";
var text04 = "K&#261;ty:";
var text05 = "Powi&#281;kszenie:";

var author = "W. Fendt 2000";
var translator = "ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite
