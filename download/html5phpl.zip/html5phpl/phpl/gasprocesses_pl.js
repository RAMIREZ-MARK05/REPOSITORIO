// Spezielle Prozesse eines idealen Gases, polnische Texte
// Letzte �nderung 17.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Przemiana izobaryczna";
var text02 = "Przemiana izochoryczna";
var text03 = "Przemiana izotermiczna";
var text04 = "Stan pocz&#261;tkowy:";
var text05 = "Ci&sacute;nienie:";
var text06 = "Obj&#281;to&sacute;&cacute;:";
var text07 = "Temperatura:";
var text08 = "Stan ko&nacute;cowy:";
var text09 = "Stan pocz&#261;tkowy";
var text10 = "Start";

var author = "W. Fendt 1999,&nbsp; B., S. Mala&nacute;ski 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Praca";
var text12 = "Ciep\u0142o";
var text13 = "Energia wewn\u0119trzna gazu";
var text14 = "ro\u015bnie.";
var text15 = "Energia wewn\u0119trzna gazu";
var text16 = "nie zmienia si\u0119.";
var text17 = "Energia wewn\u0119trzna gazu";
var text18 = "maleje.";
var text19 = "Ci\u015bnienie za ma\u0142e!";
var text20 = "Ci\u015bnienie za du\u017ce!";
var text21 = "Obj\u0119to\u015b\u0107 za ma\u0142a!";
var text22 = "Obj\u0119to\u015b\u0107 za du\u017ca!";
var text23 = "Temperatura za ma\u0142a!";
var text24 = "Temperatura za du\u017ca!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


