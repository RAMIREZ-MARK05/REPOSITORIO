// Stehende L�ngswellen, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Rura:";                                      // Rohrform
var text02 = "oba ko&nacute;ce otwarte";                   // beidseitig offen
var text03 = "jeden koniec otwarty";                       // einseitig offen
var text04 = "oba ko&nacute;ce zamkni&#281;te";            // beidseitig geschlossen
var text05 = "Cz&#281;stotliwo&sacute;&cacute;:";          // Eigenschwingung
var text06 = ["podstawowa",                                // Grundschwingung
             "pierwsza harmoniczna",                       // 1. Oberschwingung
             "druga harmoniczna",                          // 2. Oberschwingung
             "trzecia harmoniczna",                        // 3. Oberschwingung
             "czwarta harmoniczna",                        // 4. Oberschwingung
             "pi&#261;ta harmoniczna"];                    // 5. Oberschwingung
var text07 = "Ni&zdot;sza";                                // Tiefer
var text08 = "Wy&zdot;a";                                  // H�her
var text09 = "D&#322;ugo&sacute;&cacute; rury:";           // Rohrl�nge
var text10 = "D&#322;ugo&sacute;&cacute; fali:";           // Wellenl�nge
var text11 = "Cz&#281;stotliwo&sacute;&cacute;:";          // Frequenz

var author = "W. Fendt 1998,&nbsp; ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                      
var hertz = "Hz";                                   

// Texte in Unicode-Schreibweise:

var text12 = "Elongation of particles";                    // Elongation der Teilchen ???
var text13 = "Difference from average pressure";           // Abweichung vom mittleren Druck ???

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "W";                                      // Symbol f�r Knoten
var symbolAntinode = "S";                                  // Symbol f�r Bauch

