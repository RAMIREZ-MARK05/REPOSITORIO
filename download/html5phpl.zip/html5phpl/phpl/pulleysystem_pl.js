// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "2 kr&#261;&zdot;ki";                         // 2 Rollen
var text02 = "4 kr&#261;&zdot;ki";                         // 4 Rollen
var text03 = "6 kr&#261;&zdot;k&oacute;w";                 // 6 Rollen
var text04 = "Warto&sacute;&cacute; ci&#281;&zdot;aru zawieszonego cia&#322;a:";         // Gewicht der Last
var text05 = "Warto&sacute;&cacute; ci&#281;&zdot;ar dolnego wielokr&#261;&zdot;ka:";    // Gewicht der losen Flasche
var text06 = "Warto&sacute;&cacute; si&#322;y r&oacute;wnowa&zdot;&#261;cej:";           // Ben�tigte Kraft
var text07 = "Si&#322;omierz";                             // Federwaage
var text08 = "Si&#322;y";                                  // Kraftvektoren

var author = "W. Fendt 1998";
var translator = "ZamKor 2006";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                   
