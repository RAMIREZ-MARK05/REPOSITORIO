// Resonanz, polnische Texte (ZamKor)
// Letzte �nderung 21.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";                     // Zur�ck
var text02 = ["Rozpocznij",                                // Start
              "Zatrzymaj",                                 // Pause
              "Wzn&oacute;w"];                             // Weiter
var text03 = "Spowolnij";                                  // Zeitlupe
var text04 = "Wahad&#322;o:";                              // Resonator
var text05 = "Wsp&oacute;&#322;czynnik spr&#281;&zdot;ysto&sacute;ci:";        // Federkonstante
var text06 = "Masa:";                                      // Masse
var text07 = "Wsp. t&#322;umienia:";                       // D�mpfung
var text08 = "Wymuszenie:";                                // Erreger
var text09 = "Cz&#281;stotliwo&sacute;&cacute; wymuszaj&#261;ca:";             // Kreisfrequenz
var text10 = "Wykres wsp&oacute;&#322;rz&#281;dnej po&#322;o&zdot;enia";       // Diagramm Elongation
var text11 = "Wykres zale&zdot;no&sacute;ci amplitudy waha&nacute; "           // Diagramm Amplitude (1)
           + " od cz&#281;sto&sacute;ci wzbudzaj&#261;cej";                    // Diagramm Amplitude (2)
var text12 = "Wykres przsuni&#281;cia fazowego";                               // Diagramm Phasenunterschied

var author = "W. Fendt 1998,&nbsp; ZamKor 2006";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                                   
var newtonPerMeter = "N/m";                          
var perSecond = "1/s";                               
var radPerSecond = "rad/s";                        

// Texte in Unicode-Schreibweise:

var text13 = "Katastrofa rezonansowa!";                    // Resonanzkatastrophe
var text14 = "(Symulacja nierealistyczna!)";               // Simulation nicht mehr realistisch

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz (omega)
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz (omega_0)
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                              
var radPerSecondUnicode = "rad/s";               


