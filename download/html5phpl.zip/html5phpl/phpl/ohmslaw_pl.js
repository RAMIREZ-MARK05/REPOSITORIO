// Ohmsches Gesetz, polnische Texte (Barbara Sagnowska, Piotr Sagnowski)
// Letzte �nderung 22.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Zakres woltomierza:";
var text02 = "Zakres amperomierza:";
var text03 = "Zwi&#281;ksz R";
var text04 = "Zmniejsz R";
var text05 = "Zwi&#281;ksz U";
var text06 = "Zmniejsz U";

var author = "W. Fendt 1997";
var translator = "ZamKor 2001";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Przekroczona warto\u015B\u0107 maksymalna!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
