// Kombinationen von Widerst�nden, polnische Texte
// Letzte �nderung 18.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Przywr&oacute;&cacute;";
var text02 = "Si&#322;a elektromotoryczna &zacute;r&oacute;d&#322;a:";
var text03 = "Op&oacute;r:";
var text04 = "Dodaj opornik (Po&#322;&#261;czenie szeregowe)";
var text05 = "Dodaj opornik (Po&#322;&#261;czenie r&oacute;wnoleg&#322;e)";
var text06 = "Poka&zdot;:";
var text07 = "Napi&#281;cie";
var text08 = "Nat&#281;&zdot;enie";

var author = "W. Fendt 2002";
var translator = "ZamKor 2006";

// Texte in Unicode-Schreibweise:

var text09 = "Napi\u0119cie:";
var text10 = "Nat\u0119\u017Cenie:";
var text11 = "Op\u00F3r:";
var text12 = "Op\u00F3r zast\u0119pczy:";
var text13 = "bardzo ma\u0142y";
var text14 = "bardzo du\u017Cy";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

