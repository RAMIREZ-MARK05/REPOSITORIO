// Leiterschaukel-Versuch zur Lorentzkraft, spanische Texte (Juan Munoz)
// Letzte �nderung 13.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Conectar / Desconectar";
var text02 = "Invertir Corriente";
var text03 = "Invertir Im&aacute;n";
var text04 = "Corriente";
var text05 = "Campo Magn&eacute;tico";
var text06 = "Fuerza de Lorentz";

var author = "W. Fendt 1998";
var translator = "J. Mu&ntilde;oz 1999";
