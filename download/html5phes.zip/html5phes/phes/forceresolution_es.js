// Zerlegung einer Kraft in zwei Komponenten, spanische Version (Mario Alberto G�mez Garc�a)
// Letzte �nderung 12.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Magnitud de la";                       
var text02 = "fuerza:";
var text03 = "Medida de los &aacute;ngulos:";
var text04 = "&aacute;ngulo 1:";
var text05 = "&aacute;ngulo 2:";
var text06 = "Magnitudes de las componentes:";
var text07 = "componente 1:";
var text08 = "componente 2:";
var text09 = "Calcular las componentes";
var text10 = "Borrar diagrama";

var author = "W. Fendt 2003";
var translator = "M. A. G&oacute;mez Garc&iacute;a 2003";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Winkelgrad
var newton = "N";                                          // Einheit Newton (Kraft), HTML-Schreibweise

// Texte in Unicode-Schreibweise:

var text11 = "componente 1";                               // Text f�r erste Komponente
var text12 = "componente 2";                               // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                                   // Einheit Newton (Kraft), Unicode-Schreibweise