// Zerfallsreihen, spanische Texte (Juan Mu�oz)
// Letzte �nderung 27.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Cadena de desintegraci&oacute;n:";
var text03 = "Siguiente Desintegraci&oacute;n";

var author = "W. Fendt 1998"; 
var translator = "J. Mu&ntilde;oz 1999";

// Texte in Unicode-Schreibweise:

var text02 = ["Serie Torio", "Serie Neptunio", "Serie Uranio Radio", "Serie Uranio Actinio"];          





