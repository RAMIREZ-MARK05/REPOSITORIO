// Magnetfeld eines Stabmagneten, spanische Texte (Jos� Miguel Zamarro)
// Letzte �nderung 13.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Borrar l&iacute;neas de campo";
var text02 = "Girar im&aacute;n";

var author = "W. Fendt 2001";
var translator = "J. M. Zamarro 2001";
