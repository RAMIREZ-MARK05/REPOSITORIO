// Newtons Wiege, spanische Texte (Jos� Miguel Zamarro)
// Letzte �nderung 12.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Inicio";
var text02 = "Comenzar";
var text03 = "N&uacute;mero de part&iacute;culas:";

var author = "W. Fendt 1997";
var translator = "J. M. Zamarro 2001";
