// Magnetfeld eines geraden stromdurchflossenen Leiters, spanische Texte (Jos� Miguel Zamarro)
// Letzte �nderung 13.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Invertir la corriente";

var author = "W. Fendt 2000";
var translator = "J. M. Zamarro 2001";
