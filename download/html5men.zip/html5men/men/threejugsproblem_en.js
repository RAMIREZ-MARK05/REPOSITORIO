// Milchkannenr�tsel, englische Texte
// Letzte �nderung 08.07.2015

var unit0 = "pints";                                  // Volumeneinheit, Anzahl 0
var unit1 = "pint";                                   // Volumeneinheit, Anzahl 1
var unit2 = "pints";                                  // Volumeneinheit, Anzahl 2
var unit3 = "pints";                                  // Volumeneinheit, Anzahl mindestens 3
var text1 = "Congratulations!";                       // Text f�r Gratulation
var text2 = "If you want to play the game again:";    // Text f�r Neustart, 1. Zeile
var text3 = "One mouse click is enough!";             // Text f�r Neustart, 2. Zeile
