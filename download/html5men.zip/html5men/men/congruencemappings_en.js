// Einfache geometrische Abbildungen, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text02 = "New sketch";
var text04 = "Add";
var text05 = "Delete";
var text06 = "Image";

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var text01 = ["line reflection", "point reflection", "translation", "rotation"];
var text03 = ["point", "line", "ray", "line segment", "circle", "triangle", "quadrilateral"];

