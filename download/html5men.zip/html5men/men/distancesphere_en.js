// Abstand zweier Punkte auf einer Kugeloberfl�che, englische Texte
// Letzte �nderung 16.01.2021

// Texte in HTML-Schreibweise:

var text01 = "Radius:";
var text02 = "Point A:";
var text03 = "Point B:";
var text04 = "Distance:";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 2021";
var translator = "";

// Texte in Unicode-Schreibweise:

var text11 = ["longitude (E)", "longitude (W)"];
var text12 = ["latitude (N)", "latitude (S)"];

var symbolA = "A";
var symbolB = "B";
var symbolN = "N";
var symbolS = "S";

var degree = "\u00B0"
var kilometer = "km";


