// Rechner f�r Galois-Felder, englische Texte
// Letzte �nderung 13.08.2022

// Texte in HTML-Schreibweise:

var text01 = "Order:";
var text02 = "Characteristic:";
var text03 = "Addition";
var text04 = "Subtraction";
var text05 = "Multiplication";
var text06 = "Division";
var text07 = "Additive inverse";
var text08 = "Multiplicative inverse";

var text11 = "1st summand:";
var text12 = "2nd summand:";
var text13 = "Sum:";
var text21 = "Minuend:";
var text22 = "Subtrahend:";
var text23 = "Difference:";
var text31 = "1st factor:";
var text32 = "2nd factor:";
var text33 = "Product:";
var text41 = "Dividend:";
var text42 = "Divisor:";
var text43 = "Quotient:";
var text51 = "Given element:";
var text52 = "Inverse element:";
var text61 = "Given element:";
var text62 = "Inverse element:";
var undef = "n. def.";

var author = "W. Fendt 2022";

// Texte in Unicode-Schreibweise:

var text09 = "#1 is a root of the polynomial #2.";         // Bemerkung zur Wurzel
var symbolAdd = "+";                                       // Pluszeichen
var symbolSub = "\u2212";                                  // Minuszeichen
var symbolMul = "\u00D7";                                  // Multiplikationszeichen
var symbolDiv = "\u00F7";                                  // Divisionszeichen
var symbolArg = "x";                                       // Symbol f�r Argument einer einstelligen Verkn�pfung
var symbolNeg = "\u2212x";                                 // Symbol f�r inverses Element bez�glich Addition
var root = "\u03B1";                                       // Symbol f�r Wurzel
var varPoly = "x";                                         // Variable f�r Polynome



