// Abakus, englische Texte
// Letzte �nderung 06.08.2023

// Texte in HTML-Schreibweise:

var text01 = "Number of digits:";
var text02 = "Decimal notation:";
var text03 = "Roman numeral notation:";

var author = "W. Fendt 2023";
var translator = "";





