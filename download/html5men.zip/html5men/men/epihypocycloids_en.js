// Epizykloiden und Hypozykloiden, englische Texte
// Letzte �nderung 24.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Epicycloid";
var text02 = "Hypocycloid";
var text03 = "Ratio of the radii:";
var text04 = "Reset";
var text05 = ["Start", "Pause", "Resume"];  

var author = "W. Fendt 2017";    

// Texte in Unicode-Schreibweise:

var text06 = "Special case: Cardioid";  
var text07 = "Special case: Nephroid";
var text08 = "Special case: Circle diameter (Cardano circles)";
var text09 = "Special case: Deltoid";
var text10 = "Special case: Astroid";                   




