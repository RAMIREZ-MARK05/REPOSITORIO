// Regelm��ige Vielecke, englische Texte
// Letzte �nderung 27.04.2018

// Texte in HTML-Schreibweise:

var text11 = "Number of vertices:";
var text12 = "Circumcircle";
var text13 = "Incircle";
var text14 = "Triangles";
var text15 = "Diagonals";

var text21 = "Schl&auml;fli symbol:";

var author = "W. Fendt 2018";
var translator = "";





