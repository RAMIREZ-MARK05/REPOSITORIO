// T�rme von Hanoi, englische Texte
// Letzte �nderung 07.02.2022

// Texte in HTML-Schreibweise:

var text01 = "Number of disks:";
var text02 = "Reset";
var text03 = "Own solution";
var text04 = "Automatic solution";
var text05 = ["Start", "Pause", "Resume"];
var text06 = "Move";
var text07 = "Congratulations!";
var text08 = "The problem is solved.";

var author = "W. Fendt 2022";
var translator = "";

