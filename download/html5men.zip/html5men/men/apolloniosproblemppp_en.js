// Apollonios-Problem PPP, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text02 = ["A circle which passes through all", 
              "three points (the circumcircle of",
              "the corresponding triangle) is",
              "searched."];
var text04 = "Number of solutions:"; 
          
var author = "W. Fendt 2008"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var namePoint1 = "P_1";
var namePoint2 = "P_2";
var namePoint3 = "P_3";

