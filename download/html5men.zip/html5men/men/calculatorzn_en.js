// Rechnen mit Restklassen, englische Texte
// Letzte �nderung 26.07.2022

// Texte in HTML-Schreibweise:

var text01 = "Congruence classes modulo";
var text02 = "Addition";
var text03 = "Subtraction";
var text04 = "Multiplication";
var text05 = "Division";
var text06 = "Additive inverse";
var text07 = "Multiplicative inverse";
var text11 = "1st summand:";
var text12 = "2nd summand:";
var text13 = "Sum:";
var text21 = "Minuend:";
var text22 = "Subtrahend:";
var text23 = "Difference:";
var text31 = "1st factor:";
var text32 = "2nd factor:";
var text33 = "Product:";
var text41 = "Dividend:";
var text42 = "Divisor:";
var text43 = "Quotient:";
var text51 = "Given element:";
var text52 = "Inverse element:";
var text61 = "Given element:";
var text62 = "Inverse element:";
var undef = "n. def.";

var author = "W. Fendt  2022";

// Texte in Unicode-Schreibweise:

var symbolAdd = "+";
var symbolSub = "\u2212";
var symbolMul = "\u00D7";
var symbolDiv = "\u00F7";
var symbolNeg = "\u2212x";



