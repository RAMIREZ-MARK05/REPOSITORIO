// Kugeldreieck, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Sides:";
var text02 = "a = ";
var text03 = "b = ";
var text04 = "c = ";
var text05 = "Sum of sides: ";
var text06 = "Angles:";
var text07 = "&alpha; = ";
var text08 = "&beta; = ";
var text09 = "&gamma; = ";
var text10 = "Sum of angles: ";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

var author = "W. Fendt 1999";
var translator = "";

// Texte in Unicode-Schreibweise:

var symbolA = "A";
var symbolB = "B";
var symbolC = "C";


