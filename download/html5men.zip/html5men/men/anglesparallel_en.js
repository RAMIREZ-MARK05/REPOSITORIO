// Winkel an parallelen Geraden, englische Texte
// Letzte �nderung 05.04.2018

// Texte in HTML-Schreibweise:

var text01 = "Corresponding angles";
var text02 = "Alternate angles";
var text03 = "One-sided interior angles";
var text05 = "Decimals:";
var text06 = "Sizes of the angles:";

var author = "W. Fendt 2006";
var translator = "";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text04 = ["1st pair of angles", "2nd pair of angles", "3rd pair of angles", "4th pair of angles"];

var angle1 = ["\u03B1",                                    // Alpha 
              "\u03B2",                                    // Beta
              "\u03B3",                                    // Gamma
              "\u03B4"];                                   // Delta
              
var angle2 = ["\u03B1'",                                   // Alpha Strich 
              "\u03B2'",                                   // Beta Strich
              "\u03B3'",                                   // Gamma Strich
              "\u03B4'"];                                  // Delta Strich
              

