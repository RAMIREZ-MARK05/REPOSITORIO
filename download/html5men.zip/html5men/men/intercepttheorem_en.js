// Strahlensatz, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "V figure";
var text02 = "X figure";
var text03 = "Ratio:";

var author = "W. Fendt 2000";
var translator = "";

// Symbole in Unicode-Schreibweise:

var symbolDivision = ":";

var symbolZ = "Z";
var symbolA1 = "A";
var symbolB1 = "B";
var symbolA2 = "A'";
var symbolB2 = "B'";



