// Ber�hrkreise, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Given:";
var text02 = "Two points";
var text03 = "Point and line";
var text04 = "Point and circle";
var text05 = "Two lines";
var text06 = "Line and circle";
var text07 = "Two circles";

var author = "W. Fendt 2017";

