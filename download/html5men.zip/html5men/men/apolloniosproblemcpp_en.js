// Apollonios-Problem CPP, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Selection of solutions (red):";
var text02 = ["The check mark means external", 
              "tangency of the given circle."];
var text03 = ["Type 1:",
              "Type 2:"];   
var text04 = "Number of solutions:";  
         
var author = "W. Fendt 2008"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var nameCircle1 = "c";
var namePoint1 = "P_1";
var namePoint2 = "P_2";

