// Winkel am Kreis, englische Texte
// Letzte �nderung 28.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Size of the angles:";
var text02 = "Central angle:";
var text03 = "Inscribed angle:";
var text04 = "Angle between chord and tangent:";

var author = "W. Fendt 1997";
var translator = "";
