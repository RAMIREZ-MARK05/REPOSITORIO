// 15-Puzzle, englische Texte
// Letzte �nderung 25.07.2023

// Texte in HTML-Schreibweise:

var text01 = "Initial position";
var text02 = "Random position";
var text03 = "Moves:";
var text04 = ["Congratulations!", "You have solved the puzzle."];

var author = "W. Fendt 2023";
var translator = "";



