// Tangenten von Funktionsgraphen, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Equation of the function:";
var text02 = "f(x) =";
var text03 = "Left border:";
var text04 = "Right border:";
var text05 = "Lower border:";
var text06 = "Upper border:";
var text07 = "Draw";

var author = "W. Fendt 2017";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text08 = "Incorrect function term!";
var text09 = "Differentiation error!";

var symbolX = "x";
var symbolY = "y";
