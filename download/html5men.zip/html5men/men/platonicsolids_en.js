// Platonische K�rper, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Tetrahedron";
var text02 = "Hexahedron (Cube)";
var text03 = "Octahedron";
var text04 = "Dodecahedron";
var text05 = "Icosahedron";
var text06 = "Change position";
var text07 = "Circumscribed Sphere";
var text08 = "Midsphere";
var text09 = "Inscribed Sphere";

var author = "W. Fendt 1998";
