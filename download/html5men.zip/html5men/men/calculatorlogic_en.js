// Online-Rechner Aussagenlogik, englische Texte
// Letzte �nderung 19.08.2021

// Texte in HTML-Schreibweise:

var text01 = "Clear";
var text02 = "Clear all";
var text03 = "Number of variables:";
var text04 = "Variable:";
var author = "W. Fendt 2021";

// Texte in Unicode-Schreibweise:

var text05 = "Term:";
var text06 = "Comment:";
var text07 = "Truth table:";
var text08 = "Disjunctive normal form:";
var text09 = "Conjunctive normal form:";

var variables = ["x", "y", "z"];                           // Array-Gr��e variabel

var symbolFalse = "0";
var symbolTrue = "1";

var empty = "Empty term";
var variable = "Variable";
var constant = "Constant";
var negation = "Negation";
var brack = "Bracket";
var conjunction = "Conjunction (AND function)";
var disjunction = "Disjunction (OR function)";
var implication = "Implication";
var equivalence = "Equivalence";

var symbolNegation = "\u00AC";
var symbolConjunction = "\u2227";
var symbolDisjunction = "\u2228";
var symbolImplication = "\u21D2";
var symbolEquivalence = "\u21D4";

// Fehlermeldungen:

var syntaxOK = "Syntax okay!";
var missNeg = "Negation incomplete!";
var missCon1 = "Conjunction: First operand missing!";
var missCon2 = "Conjunction incomplete!";
var missDis1 = "Disjunction: First operand missing!";
var missDis2 = "Disjunction incomplete!";
var missImp1 = "Implication: First operand missing!";
var missImp2 = "Implication incomplete!";
var missEqu1 = "Equivalence: First operand missing!";
var missEqu2 = "Equivalence incomplete!";
var openBracket = "Bracket incomplete!";
var emptyBracket = "Empty bracket!";
var closingBracket = "Closing bracket pointless!";
var missingBracket = "Bracket missing!";

var unknownError = "Unintelligible!";




