// Gerade Strophoide, englische Texte
// Letzte �nderung 09.11.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pause", "Resume"];  

var author = "W. Fendt 2020";    

                




