// Zahlenpyramide, englische Texte
// Letzte �nderung 01.05.2023

// Texte in HTML-Schreibweise:

var text01 = "Clear";
var text02 = "Size:";
var text03 = "Number:";
var text04 = "Apply";
var text05 = ["Show solution", "Hide solution"];


var author = "W. Fendt 2023";
var translator = "";

// Texte in Unicode-Schreibweise:

var select2 = ["Own problem", "Randomly generated problem"];
var select3 = ["Natural numbers", "Integer numbers"];

var text11 = "Contradictory inputs!";
var text12 = "Redundant number!";
var text13 = "Error!";
var text14 = "No solution with integer numbers!";
var text15 = "No solution with natural numbers!";

var text21 = "Matrix not quadratic!";
var text22 = "Number not integer!";

