// Kreisspiegelung, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "New sketch";
var text03 = "Add";
var text04 = "Delete";
var text05 = "Image";

var author = "W. Fendt 2017";
var translator = "";

// Texte in Unicode-Schreibweise:

var text02 = ["point", "line", "ray", "line segment", "circle", "triangle", "quadrilateral"];

