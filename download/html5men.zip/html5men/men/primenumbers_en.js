// Primzahlentabelle, englische Texte
// Letzte �nderung 18.10.2015

var textError = "Error!";                                  // Text f�r Fehlermeldung
var textPrime = "is prime.";                               // Text f�r Primzahl
var symbolMult = "&times;";                                // Multiplikationszeichen (HTML)
