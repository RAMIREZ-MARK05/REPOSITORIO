// Algebra-Rechner, englische Texte
// Letzte �nderung 17.08.2020

// Texte in HTML-Schreibweise:

var text01 = "Clear";
var text02 = "Clear all";
var text03 = "Fraction:";                                  // text04 siehe unten!
var text05 = "Decimal fraction:";                          // text06 siehe unten!
var text07 = "Fractional term:";                           // text08 siehe unten!
var text09 = "Power:";                                     // text10 siehe unten!
var text12 = "Variable:";                                  // text13 siehe unten!
var author = "W. Fendt 2020";

// Texte in Unicode-Schreibweise:

var text04 = ["", "numerator", "denominator"];
var text06 = ["", "decimal part", "period"];
var text08 = ["", "new fractional term", "edit numerator", "edit denominator", "close fractional term"];
var text10 = ["", "new exponent", "edit exponent", "close exponent"];
var text11 = ["result as fraction", "result as mixed number", "result as decimal fraction"];
var text13 = ["", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", 
                  "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];

var text21 = "String:";
var text22 = "Term:";
var text23 = "Type:";
var text24 = "Comment:";
var text25 = "Result:";
var text26 = "Factorized:";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMinus = "\u2212";                                // Minuszeichen
var symbolMult = "\u00D7";                                 // Multiplikationszeichen
var symbolDiv = "\u00F7";                                  // Divisionszeichen

// Termarten:

var empty = "Empty term";
var variable = "Variable";
var natNum = "Natural number";
var fracNum = "Fraction or mixed number";
var decNum = "Decimal fraction";
var plus = "Plus expression";
var minus = "Minus expression";
var brack = "Bracket";
var perc = "Percentage";
var sum = "Sum";
var diff = "Difference";
var prod = "Product";
var prod0 = "Product without multiplication sign";
var quot = "Quotient";
var fracTerm = "Fractional term";
var pow = "Power";

// Fehlermeldungen:

var syntaxOK = "Syntax okay!";
var leadingZero = "Leading zero!";
var missingSummand = "Second summand missing!";
var missingSubtrahend = "Subtrahend missing!";
var missingFactor1 = "First factor missing!";
var missingFactor2 = "Second factor missing!";
var missingDividend = "Dividend missing!";
var missingDivisor = "Divisor missing!";
var missingNumerator = "Numerator missing!";
var openNumerator = "Numerator not finished!";
var missingDenominator = "Denominator missing!";
var openDenominator = "Denominator not finished!";
var missingBase = "Base missing!";
var missingExponent = "Exponent missing!";
var openExponent = "Exponent not finished!";
var openPlus = "Plus expression incomplete!";
var openMinus = "Minus expression incomplete!";
var openBracket = "Bracket incomplete!";
var emptyBracket = "Empty bracket!";
var closingBracket = "Closing bracket pointless!";
var missingBracket = "Bracket missing!";
var missingInteger = "Integer missing!";
var missingFractionalPart = "Decimal part missing!";
var missingPeriod = "Period missing!";
var incompleteFactorization = "Factorization possibly incomplete!";

var runtimeOK = "No runtime error!";
var divisionByZero = "Division by zero!";
var notIntegerExponent = "Exponent not integer!";
var tooBigExponent = "Exponent too big!";

var unknownError = "Unintelligible!";


