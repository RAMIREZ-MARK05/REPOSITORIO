// Online-Rechner Legendre-Symbol, englische Texte
// Letzte �nderung 25.07.2023

// Texte in HTML-Schreibweise:

var text01 = "1st number:";
var text02 = "2nd number:";
var text03 = "OK";
var text04 = "Legendre symbol (Jacobi symbol, Kronecker symbol):";
var text05 = "Jacobi symbol (Kronecker symbol):";
var text06 = "Kronecker symbol:";

var author = "W. Fendt 2023";
var translator = "";

// Texte in Unicode-Schreibweise:

var text11 = "#1 is a quadratic residue modulo #2.";
var text12 = "#1 is a quadratic nonresidue modulo #2.";
var text13 = "#1 and #2 are not relatively prime.";
var text14 = "#1\u00B2 = #2 \u2261 #3 mod #4";
var text15 = "The is no integer x with x\u00B2 \u2261 #1 mod #2."; 

var symbolGCD = "gcd";
var symbolMul = "\u00D7";
var symbolNeg = "\u2212";

var error = "Error";





