// Apollonios-Problem CCC, englische Texte
// Letzte �nderung 27.11.2017

// Texte in HTML-Schreibweise:

var text01 = "Selection of solutions (red):";
var text02 = ["(Those of the given circles (black)", 
              "which exclude the solution circle", 
              "are checked.)"];
var text03 = ["Type 1:",
              "Type 2:",
              "Type 3:",
              "Type 4:",
              "Type 5:",
              "Type 6:",
              "Type 7:",
              "Type 8:"];   
var text04 = "Number of solutions:";           
var author = "W. Fendt 2008"; 
var translator = "";

// Texte in Unicode-Schreibweise:

var nameCircle1 = "c_1";
var nameCircle2 = "c_2";
var nameCircle3 = "c_3";

