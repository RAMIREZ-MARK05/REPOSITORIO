// Primyphos, englische Texte
// Letzte �nderung 28.02.2020

// Texte in HTML-Schreibweise:

var text01 = "Write as a product:";

var author = "W. Fendt 1998";

var symbolMultiply = "&times;";

// Texte in Unicode-Schreibweise:

var text02 = ["Congratulations!", 
              "Great!", 
              "Excellent!", 
              "Not bad!", 
              "Well done!", 
              "Impressive!",
              "Fantastic!"];
              
var text03 = ["If you want to start the game again,",
              "press the mouse button!"];

var symbolMultiplyUnicode = "\u00D7";
