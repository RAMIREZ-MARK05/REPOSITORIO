// Himmelspole, englische Texte
// Letzte �nderung 20.11.2017

// Texte in Unicode-Schreibweise:

var text01 = "Equator";
var	text02 = "North Pole";
var text03 = "South Pole";
var text04 = "Earth's Axis";
var text05 = "Horizontal Plane";
var text06 = "Celestial Sphere";
var	text07 = "Zenith";
var text08 = "North Celestial Pole";
var	text09 = "South Celestial Pole";
var text10 = "North";
var text11 = "South";

var author = "W. Fendt 1998";
