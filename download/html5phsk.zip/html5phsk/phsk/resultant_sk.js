// Ersatzkraft mehrerer Kr�fte, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Po&ccaron;et p&ocirc;sobiacich s&iacute;l:";
var text02 = "Ur&ccaron;i&tcaron; v&yacute;slednicu";
var text03 = "Zmaza&tcaron; kon&scaron;trukciu";

var author = "W. Fendt 1998";
var translator = "A. &Scaron;utta 2015";
