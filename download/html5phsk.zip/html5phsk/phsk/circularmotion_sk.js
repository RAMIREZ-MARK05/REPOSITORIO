// Kreisbewegung mit konstanter Winkelgeschwindigkeit, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];
var text03 = "Spomalenie";
var text04 = "Polomer:";
var text05 = "Peri&oacute;da:";
var text06 = "Hmotnos&tcaron;:";
var text07 = "Poloha";
var text08 = "R&yacute;chlos&tcaron;";
var text09 = "Zr&yacute;chlenie";
var text10 = "Sila";

var author = "W. Fendt 2007";
var translator = "A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                    
var second = "s";                                   
var kilogram = "kg";                                

// Texte in Unicode-Schreibweise:

var text11 = "Okam\u017Eit\u00E1 v\u00FDchylka:";          // Position
var text12 = "Okam\u017Eit\u00E1 r\u00FDchlos\u0165:";     // Geschwindigkeit
var text13 = "Uhlov\u00E1 r\u00FDchlos\u0165:";            // Winkelgeschwindigkeit
var text14 = "Dostrediv\u00E9 zr\u00FDchlenie:";           // Zentripetalbeschleunigung
var text15 = "Dostrediv\u00E1 sila:";                      // Zentripetalkraft
var text16 = "(s)";
var text17 = "(m)";
var text18 = "(m/s)";
var text19 = "(m/s\u00b2)";
var text20 = "(N)";
var text21 = "(x-ov\u00E1 zlo\u017Eka)";                   // x-Komponente
var text22 = "(y-ov\u00E1 zlo\u017Eka)";                   // y-Komponente
var text23 = "(celkov\u00E1 ve\u013Ekos\u0165)";           // Betrag

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03c9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "m";                             
var meterPerSecond = "m/s";                          
var meterPerSecond2 = "m/s\u00b2";                  
var newton = "N";                                   
var radPerSecond = "rad/s";                         




