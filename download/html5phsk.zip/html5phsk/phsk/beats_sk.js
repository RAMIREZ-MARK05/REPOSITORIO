// Schwebungen, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];
var text03 = "Spomalenie";
var text04 = "Frekvencia:";
var text05 = "1. kmitanie:";
var text06 = "2. kmitanie:";

var author = "W. Fendt 2001"; 
var translator = "A. &Scaron;utta 2015";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



