// Generator, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise;

var text01 = "Altern\u00E1tor (bez komut\u00E1tora)";
var text02 = "Dynamo (s komut\u00E1torom)";
var text03 = "Zmeni\u0165 smer";
var text04 = ["\u0160tart", "Zastavi\u0165", "\u010Ealej"];
var text05 = "Smer pohybu";
var text06 = "Magnetick\u00E9 pole";
var text07 = "Indukovan\u00FD pr\u00FAd";

var author = "W. Fendt 1998";  
var translator = "A. &Scaron;utta 2015";


// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "ot. / min";                      // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
