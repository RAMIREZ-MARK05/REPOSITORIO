// Bewegung mit konstanter Beschleunigung, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];
var text03 = "Spomalenie";
var text04 = "Za&ccaron;iato&ccaron;n&aacute; poloha:";
var text05 = "Za&ccaron;iato&ccaron;n&aacute; r&yacute;chlos&tcaron;:";
var text06 = "Zr&yacute;chlenie:";
var text07 = "Vektor okam&zcaron;itej r&yacute;chlosti";
var text08 = "Vektor zr&yacute;chlenia";

var author = "W. Fendt 2000";
var translator = "A. &Scaron;utta 2015";

// Texte in Unicode-Schreibweise:

var text09 = "(s)";                                        // Einheitenangabe f�r Zeit-Achse
var text10 = "(m)";                                        // Einheitenangabe f�r Weg-Achse
var text11 = "(m/s)";                                      // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(m/s\u00b2)";                                // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                    
var meter = "m";                                     
var meterPerSecond = "m/s";                          
var meterPerSecond2 = "m/s\u00b2";                   
