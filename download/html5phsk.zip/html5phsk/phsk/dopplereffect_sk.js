// Beispiel zum Doppler-Effekt, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; &scaron;tart";
var text02 = ["Pauza", "Pokra&ccaron;ova&tcaron;"]; 

var author = "W. Fendt 1998";
var translator = "A. &Scaron;utta 2015";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                        
  ["Pok\u00FDm sa sanitka",
   "bl\u00ED\u017Ei k osobe",
   "s\u00FA medzery medzi",
   "vlnoplochami",
   "skr\u00E1ten\u00E9."],
  ["Teraz vozidlo op\u00FA\u0161\u0165a",
   "osobu, preto vlny",
   "prilietaj\u00FA vo v\u00E4\u010D\u0161\u00EDch",
   "pauz\u00E1ch."]];
  

