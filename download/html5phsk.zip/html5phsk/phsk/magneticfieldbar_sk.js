// Magnetfeld eines Stabmagneten, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Odstr&aacute;in&tcaron; induk&ccaron;n&eacute; &ccaron;iary";
var text02 = "Oto&ccaron;enie magetov";

var author = "W. Fendt 2001";
var translator = "A. &Scaron;utta 2016";
