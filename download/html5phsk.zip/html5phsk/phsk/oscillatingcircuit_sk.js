// Elektromagnetischer Schwingkreis, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["&Scaron;tart", "Pauza", "Pokra&ccaron;ova&tcaron;"];
var text03 = "Spomalenie (10 &times;)";
var text04 = "Spomalenie (100 &times;)";
var text05 = "Kapacita:";                                  // Kapazit�t
var text06 = "Induk&ccaron;nos&tcaron;:";                  // Induktivit�t
var text07 = "Odpor:";                                     // Widerstand
var text08 = "Max. nap&auml;tie:";                         // Maximale Spannung
var text09 = "Nap&auml;tie, pr&uacute;d";                  // Spannung, Stromst�rke
var text10 = "Energia";

var author = "W. Fendt 1999,&nbsp; A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                            
var henry = "H";                                     
var ohm = "&Omega;";                                 
var volt = "V";                                      

// Texte in Unicode-Schreibweise:

var text11 = "Peri\u00F3da:";                              // Schwingungsdauer
var text12 = "Elektrick\u00E1 energia:";                   // Elektrische Energie
var text13 = "Magnetick\u00E1 energia:";                   // Magnetische Energie
var text14 = "Vn\u00FAtorn\u00E1 energia:";                // Innere Energie
var text15 = "Netlmen\u00E9 oscil\u00E1cie";               // Unged�mpfte Schwingung
var text16 = "Tlmen\u00E9 oscil\u00E1cie";                 // Ged�mpfte Schwingung
var text17 = "Medzn\u00E9 tlmenie";                        // Aperiodischer Grenzfall
var text18 = "Pretlmen\u00FD pr\u00EDpad";                 // Kriechfall

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                   
var voltUnicode = "V";                              
var ampere = "A";                                   
var joule = "J";                                    
