// Interferenz zweier Kreis- oder Kugelwellen, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = ["Zastavi&tcaron;", "&Dcaron;alej"];          // Schaltknopf (Pause/Weiter)
var text02 = "Spomalenie";                                 // Zeitlupe
var text03 = "Vz&aacute;jomn&aacute; vzdialenos&tcaron;";  // Gangunterschied
var text04 = "zdrojov:";
var text05 = "Vlnov&aacute; d&lacute;&zcaron;ka:";         // Wellenl�nge

var author = "W. Fendt 1999";
var translator = "A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                               

// Texte in Unicode-Schreibweise:

var text06 = "Dr\u00E1hov\u00FD rozdiel:";
var text07 = "Kon\u0161trukt\u00EDvna interferencia (maxim\u00E1lna amplit\u00FAda)";
var text08 = "De\u0161trukt\u00EDvna interferencia (minim\u00E1lna amplit\u00FAda)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03BB";                           // Symbol f�r Wellenl�nge (Lambda)
