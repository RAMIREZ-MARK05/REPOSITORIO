// Leiterschaukel-Versuch zur Lorentzkraft, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Zapn&uacute;&tcaron; / Vypn&uacute;&tcaron;";
var text02 = "Opa&ccaron;n&yacute; pr&uacute;d";
var text03 = "Oto&ccaron;it magnet";
var text04 = "Smer&nbsp;pr&uacute;du";
var text05 = "Magnetick&eacute; pole";
var text06 = "Lorentzova sila";

var author = "W. Fendt 1998";
var translator = "A. &Scaron;utta 2015";
