// Stehende L�ngswellen, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Prevedenie trubice:";                        // Rohrform
var text02 = "oba konce otvoren&eacute;";                  // beidseitig offen
var text03 = "jeden koneic uzavret&yacute;";               // einseitig offen
var text04 = "oba konce uzavret&eacute;";                  // beidseitig geschlossen
var text05 = "Vibra&ccaron;n&yacute; m&oacute;d:";
var text06 = ["z&aacute;kladn&yacute;", "1. harmonick&yacute;",      // Bezeichnungen der Eigenschwingungen 
              "2. harmonick&yacute;", "3. harmonick&yacute;", 
              "4. harmonick&yacute;", "5. harmonick&yacute;"];
var text07 = "Ni&zcaron;&scaron;&iacute; m&oacute;d";      // Tiefer
var text08 = "Vy&scaron;&scaron;&iacute; m&oacute;d";      // H�her
var text09 = "D&lacute;&zcaron;ka trubice:";               // Rohrl�nge
var text10 = "Vlnov&aacute; d&lacute;&zcaron;ka:";         // Wellenl�nge
var text11 = "Frekvencia:";                                // Frequenz

var author = "W. Fendt 1998,&nbsp; A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                     
var hertz = "Hz";                                    

// Texte in Unicode-Schreibweise:

var text12 = "V\u00FDchylky \u010Dast\u00EDc";             // �berschrift des ersten Diagramms
var text13 = "Odch\u00FDlka od stredn\u00E9ho tlaku";      // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "U";                                      // Symbol f�r Knoten
var symbolAntinode = "K";                                  // Symbol f�r Bauch

