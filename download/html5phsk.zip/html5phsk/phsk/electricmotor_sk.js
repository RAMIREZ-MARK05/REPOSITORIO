// Gleichstrom-Elektromotor, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise;

var text01 = "Reset";
var text02 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];             
var text03 = "Opa&ccaron;n&yacute; pr&uacute;d";           // Umpolen
var text04 = "Smer pr&uacute;du";                          // Stromrichtung
var text05 = "Magnetick&eacute; pole";                     // Magnetfeld
var text06 = "Lorentzova sila";                            // Lorentzkraft

var author = "W. Fendt 1997";               
var translator = "A. &Scaron;utta 2015";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "ot./min";                        // Umdrehungen pro Minute
