// Gekoppelte Pendel, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";                           
var text02 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];                
var text03 = "Spomalenie";                                 // Zeitlupe
var text04 = "Po&ccaron;iato&ccaron;n&aacute; poz&iacute;cia:";  // Anfangspositionen

var author = "W. Fendt 1998";
var translator = "A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                               

// Texte in Unicode-Schreibweise:

var text05 = "Kyvadlo 1";                                  // Erstes Pendel (links)
var text06 = "Kyvadlo 2";                                  // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
