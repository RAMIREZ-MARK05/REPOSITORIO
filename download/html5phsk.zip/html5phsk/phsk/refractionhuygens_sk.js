// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Spusti&tcaron; znova";                       // Neustart
var text02 = "Nasleduj&uacute;ci krok";                    // N�chster Schritt
var text03 = ["Zastavi&tcaron;", "&Dcaron;alej"];          // Pause/Weiter
var text04 = "1. index lomu:";                             // 1. Brechungsindex
var text05 = "2. index lomu:";                             // 2. Brechungsindex
var text06 = "Uhol dopadu:";                               // Einfallswinkel

var author = "W. Fendt 1998";
var translator = "A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                 

// Texte in Unicode-Schreibweise:

var text07 = [

  ["Rovinn\u00E1 vlna dopad\u00E1 pod zadan\u00FDm",                 // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "uhlom na rozhranie dvoch prostred\u00ED.",
   "Vlnenie m\u00E1 v ka\u017Edom z t\u00FDchto",
   "prostred\u00ED in\u00FA r\u00FDchlos\u0165 \u0161\u00EDrenia."],
   
  ["Rovinn\u00E1 vlna dopad\u00E1 kolmo",                            // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "na rozhranie dvoch prostred\u00ED.",
   "Vlnenie m\u00E1 v ka\u017edom z t\u00FDchto",
   "prostred\u00ED in\u00FA r\u00FDchlos\u0165 \u0161\u00EDrenia."],
   
  ["Po dopade vlnoplochy sa body",                                   // i == 2 (step == 1, n1 > n2)
   "na rozhran\u00ED chovaj\u00FA pod\u013Ea",
   "Huygensovho princ\u00EDpu. Ka\u017ed\u00FD bod",
   "sa st\u00E1va zdrojom element\u00E1rnej",
   "gu\u013Eovej vlnoplochy vlnenia.",
   "V 2. prostred\u00ED sa element\u00E1rne",
   "vlny \u0161\u00EDria rychlej\u0161ie, preto je tu",
   "index lomu men\u0161\u00ED."],
   
  ["Po dopade vlnoplochy sa body",                                   // i == 3 (step == 1, n1 < n2)
   "na rozhran\u00ED chovaj\u00FA pod\u013Ea",
   "Huygensovho princ\u00EDpu. Ka\u017ed\u00FD bod",
   "sa st\u00E1va zdrojom element\u00E1rnej",
   "gu\u013Eovej vlnoplochy vlnenia.",
   "V 2. prostred\u00ED sa element\u00E1rne",
   "vlny \u0161\u00EDria pomal\u0161ie, preto je tu",
   "index lomu v\u00E4\u010D\u0161\u00ED."],
   
  ["Nov\u00E1 rovinn\u00E1 vlnoplocha vznikne",                      // i == 4 (step == 2, total == false, eps1 > 0)
   "superpoz\u00EDciou (zlo\u017Een\u00EDm) v\u0161etk\u00FDch",
   "element\u00E1rn\u00FDch vlnopl\u00F4ch.",
   "V\u0161imnite si zmeny smeru",
   "\u0161\u00EDrenia vlnenia pri prechode",
   "rozhran\u00EDm medzi prostrediami 1 a 2."], 
   
  ["Nov\u00E1 rovinn\u00E1 vlnoplocha vznikne",                      // i == 5 (step == 2, total == false, eps1 == 0)
   "superpozic\u00ED (zlo\u017Een\u00EDm) v\u0161etk\u00FDch",
   "element\u00E1rn\u00FDch vlnopl\u00F4ch.",
   "V 1. prostred\u00ED je zn\u00E1zornen\u00E1",
  "odrazn\u00E1 vlna, v 2. prostred\u00ED",
  "naopak vlna lomen\u00E1."],
   
  ["Nov\u00E1 rovinn\u00E1 vlnoplocha vznikne",                      // i == 6 (step == 2, total == true)
   "superpoz\u00EDciou (zlo\u017Een\u00EDm) v\u0161etk\u00FDch",
   "element\u00E1rn\u00FDch vlnopl\u00F4ch len",
   "v 1. prostred\u00ED (odrazen\u00E1 vlna).",
   "Naopak v 2. prostred\u00ED sa vlnenie",
   "\u010Falej v\u00F4bec ne\u0161\u00EDri (doch\u00E1dza",
   "k \u00FApln\u00E9mu odrazu vlnenia)."],
   
  ["Teraz je vyzna\u010Den\u00FD smer \u0161\u00EDrenia vlnenia",   // i == 7 (step == 3)
   "(smer l\u00FA\u010Dov). Je to smer kolm\u00FD",
   "na vlnoplochu."],
   
  ["Obvykle v\u0161ak nedopad\u00E1 len",                          // i == 8 (step == 4)
   "jedin\u00E1 vlnoplocha, ale je jich viac."],

  ["Ak sa shoduj\u00FA indexy lomu,",                             // i == 9 (n1 == n2)
   "ni\u010D zvl\u00E1\u0161tneho sa nestane."]];
        
var text08 = "uhol dopadu:";                               // Einfallswinkel 
var text09 = "uhol odrazu:";                               // Reflexionswinkel
var text10 = "uhol lomu:";                                 // Brechungswinkel
var text11 = "1. prostredie";                              // Medium 1
var text12 = "2. prostredie";                              // Medium 2
var text13 = ["Medzn\u00FD uhol", "\u00FApln\u00E9ho odrazu:"]; // Grenzwinkel der Totalreflexion

// Einheiten:

var degreeUnicode = "\u00B0";                           
