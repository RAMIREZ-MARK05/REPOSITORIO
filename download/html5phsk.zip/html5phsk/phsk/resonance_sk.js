// Resonanz, slowakische Texte (August�n �utta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];
var text03 = "Spomalenie";
var text04 = "Buden&yacute; oscil&aacute;tor:";
var text05 = "Tuhos&tcaron; pru&zcaron;iny:";
var text06 = "Hmotnos&tcaron;:";
var text07 = "Tlmenie:";
var text08 = "Zdroj budenia:";
var text09 = "Uhlov&aacute; frekvencia:";
var text10 = "Graf okam&zcaron;itej v&yacute;chylky";
var text11 = "Graf amplit&uacute;dy";
var text12 = "Graf f&aacute;zy";

var author = "W. Fendt 1998,&nbsp; A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                                 
var newtonPerMeter = "N/m";                          
var perSecond = "1/s";                               
var radPerSecond = "rad/s";                           

// Texte in Unicode-Schreibweise:

var text13 = "Prekro\u010Denie medze!";
var text14 = "(Simul\u00E1cia na\u010Falej nie je realistick\u00E1!)";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                               
var radPerSecondUnicode = "rad/s";                   


