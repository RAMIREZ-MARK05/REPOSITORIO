// Newtons Wiege, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Sprachabh�ngige Texte sind einer eigenen Datei (zum Beispiel newtoncradle_de.js) abgespeichert.

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "&Scaron;tart";
var text03 = "Po&ccaron;et vych&yacute;len&yacute;ch g&uacute;&lcaron;:";

var author = "W. Fendt 1997";
var translator = "A. &Scaron;utta 2015";
