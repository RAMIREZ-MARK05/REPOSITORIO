// Ohmsches Gesetz, slowakische Texte (Augustin Sutta)
// Letzte �nderung 19.02.2021

// Texte in HTML-Schreibweise:

var text01 = "Maxim\u00E1lne nap\u00E4tie:";
var text02 = "Maxim\u00E1lny pr\u00FAd:";
var text03 = "Odpor zv\u00E4\u010D\u0161i\u0165";
var text04 = "Odpor zmen\u0161i\u0165";
var text05 = "Nap\u00E4tie zv\u00E4\u010D\u0161i\u0165";
var text06 = "Nap\u00E4tie zmen\u0161i\u0165";

var author = "W. Fendt 1997";
var translator = "A. \u0160utta 2016";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Maximum exceeded!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma)
var ohm = "\u03A9";
