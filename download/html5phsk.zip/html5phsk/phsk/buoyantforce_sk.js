// Messung der Auftriebskraft, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Podstava telesa:"; 
var text02 = "V&yacute;&scaron;ka telesa:";
var text03 = "Hustota telesa:";
var text04 = "Hustota kvapaliny:";   
var text05 = "Ponorenie:";
var text06 = "Ponoren&yacute; objem:"; 
var text07 = "Vztlakov&aacute; sila:";
var text08 = "Tia&zcaron;ov&aacute; sila:";
var text09 = "Meran&aacute; sila:";
var text10 = "Rozsah silomeru:";

var author = "W. Fendt 1998,&nbsp;  A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Rozsah prekro\u010Den\u00FD!";
