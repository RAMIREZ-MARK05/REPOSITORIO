// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "2 kladky";
var text02 = "4 kladky";
var text03 = "6 kladiek";
var text04 = "Tia&zcaron; n&aacute;kladu:";
var text05 = "Tia&zcaron; vo&lcaron;n&yacute;ch kladiek:";
var text06 = "Potrebn&aacute; sila:";
var text07 = "silomer";
var text08 = "vektor sily";

var author = "W. Fendt 1998";
var translator = "A. &Scaron;utta 2015";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                             
