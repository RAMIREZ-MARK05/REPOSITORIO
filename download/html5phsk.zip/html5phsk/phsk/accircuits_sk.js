// Einfache Wechselstromkreise, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rezistor";                                   // Widerstand
var text02 = "Kondenz&aacute;tor";                         // Kondensator
var text03 = "Cievka";                                     // Spule
var text04 = "Reset";
var text05 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];          
var text06 = "Spomalenie";                                 // Zeitlupe
var text07 = "Frekvencia:";                                // Frequenz
var text08 = "Max. nap&atilde;tie:";                       // Maximale Spannung
var text09 = "Odpor:";                                     // Widerstand
var text10 = "Kapacita:";                                  // Kapazit�t                          
var text11 = "Induk&ccaron;nos&tcaron;:";                  // Induktivit�t
var text12 = "Max. pr&uacute;d:";                          // Maximale Stromst�rke 

var author = "W. Fendt 1998,&nbsp; A. &Scaron;utta 2015";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                   
var volt = "V";                                     
var ampere = "A";                                   
var milliampere = "mA";                             
var microampere = "&mu;A";                          
var ohm = "&Omega;";                                
var microfarad = "&mu;F";                           
var henry = "H";                                    

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
