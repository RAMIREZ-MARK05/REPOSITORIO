// Interferenz von Licht am Doppelspalt, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Vlnov\u00E1 d&#314;&#382;ka:";
var text02 = "Vzdialenos&#357; \u0161trrb&#237;n:";
var text03 = "Uhol:";
var text04 = "Maxim&#225;:";
var text05 = "Minim&#225;:";
var text06 = "Relat&#237;vna intenzita:";
var text07 = "Difrak\u010Dn&#253; obrazec";
var text08 = "Graf intenzity";

var author = "W. Fendt 2003, &nbsp; A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
