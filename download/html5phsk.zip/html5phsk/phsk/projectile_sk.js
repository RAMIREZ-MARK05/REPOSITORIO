// Schiefer Wurf, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";                    
var text02 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];          
var text03 = "Spomalenie";
var text04 = "Za&ccaron;iato&ccaron;n&aacute; v&yacute;&scaron;ka:";
var text05 = "Za&ccaron;iato&ccaron;n&aacute; r&yacute;chlos&tcaron;:";
var text06 = "Eleva&ccaron;n&yacute; uhol:";
var text07 = "Hmotnos&tcaron;:"; 
var text08 = "Tia&zcaron;ov&eacute; zr&yacute;chlenie:";
var text09 = "S&uacute;radnice";
var text10 = "R&yacute;chlos&tcaron;";
var text11 = "Zr&yacute;chlenie";
var text12 = "Sila";
var text13 = "Energia";

var author = "W. Fendt 2000,&nbsp; A. &Scaron;utta 2015";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                  
var meterPerSecond = "m/s";                       
var meterPerSecond2 = "m/s&sup2;";                
var kilogram = "kg";                              
var degree = "&deg;";                             

// Texte in Unicode-Schreibweise:

var text14 = "(m)";                                        // Einheitenangabe f�r Koordinatenachsen 
var text15 = "S\u00FAradnice:";                            // Position
var text16 = "(vodorovne)";                                // waagrecht
var text17 = "(zvisle)";                                   // senkrecht
var text18 = "Dolet:";                                     // Wurfweite
var text19 = "Maxim\u00E1lna v\u00FD\u0161ka:";            // Maximale H�he
var text20 = "Doba letu:";                                 // Wurfdauer
var text21 = "Zlo\u017Eky r\u00FDchlosti:";                // Geschwindigkeitskomponenten
var text22 = "Ve\u013Ekos\u0165 r\u00FDchlosti:";          // Geschwindigkeitsbetrag
var text23 = "Uhol:";                                      // Winkel
var text24 = "Zr\u00FDchlenie:";                           // Beschleunigung
var text25 = "Sila:";                                      // Kraft
var text26 = "Pohybov\u00E1 energia:";                     // Kinetische Energie
var text27 = "Polohov\u00E1 energia:";                     // Potentielle Energie
var text28 = "Celkov\u00E1 energia:";                      // Gesamtenergie

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                                 
var secondUnicode = "s";                                
var meterPerSecondUnicode = "m/s";                      
var meterPerSecond2Unicode = "m/s\u00b2";               
var newtonUnicode = "N";                                
var jouleUnicode = "J";                                 
var degreeUnicode = "\u00b0";                           



