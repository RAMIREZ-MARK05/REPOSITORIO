// Erstes Kepler-Gesetz, slowakische Texte (August�n �utta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Hlavn&aacute; polos:";
var text03 = "Numerick&aacute; excentricita:";
var text04 = "Ved&lcaron;aj&scaron;ia polos:";
var text05 = ["Pauza", "&Dcaron;alej"];
var text06 = "Spomalenie";
var text07 = "Vzdialenos&tcaron; od Slnka:";
var text08 = "Aktu&aacute;lna hodnota:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Eliptick&aacute; dr&aacute;ha";
var text12 = "Osi";
var text13 = "Spojnice s ohniskami";

var author = "W. Fendt 2000,&nbsp; A. &Scaron;utta 2016";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Merk\u00FAr", "Venu\u0161a", "Zem", "Mars", "Jupiter", "Saturn", "Ur\u00E1n", "Nept\u00FAn",
              "Pluto", "Halleyho Kom\u00E9ta", ""];

var text14 = "Slnko";
var text15 = "Plan\u00E9ta";
var text16 = "Kom\u00E9ta";
var text17 = "Perih\u00E9lium";
var text18 = "Af\u00E9lium";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "AU";

