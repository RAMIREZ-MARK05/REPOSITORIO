// Elastischer und unelastischer Sto�, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Pru&#382;n&aacute; zr&aacute;&#382;ka";
var text02 = "Nepru&#382;n&aacute; zr&aacute;&#382;ka";
var text03 = "Reset";
var text04 = "&Scaron;tart";
var text05 = "Spomalenie";
var text06 = "Voz&iacute;k 1:";
var text07 = "Voz&iacute;k 2:";
var text08 = "Hmotnos&tcaron;:";
var text09 = "R&yacute;chlos&tcaron;:";
var text10 = "R&yacute;chlos&tcaron;";
var text11 = "Hybnos&tcaron;";
var text12 = "Kinetick&aacute; energia";

var author = "W. Fendt 1998,&nbsp; A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                         

// Texte in Unicode-Schreibweise:

var text13 = "Voz\u00EDk 1:";
var text14 = "Voz\u00EDk 2:";
var text15 = "R\u00FDchlos\u0165 pred zr\u00E1\u017Ekou:";
var text16 = "R\u00FDchlos\u0165 po zr\u00E1\u017Eke:";
var text17 = "Hybnos\u0165 pred zr\u00E1\u017Ekou:";
var text18 = "Hybnos\u0165 po zr\u00E1\u017Eke:";
var text19 = "Energia pred zr\u00E1\u017Ekou:";
var text20 = "Energia po zr\u00E1\u017Eke:";
var text21 = "Celkov\u00E1 hybnos\u0165:";
var text22 = "Celkov\u00E1 kinetick\u00E1 energia:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                     
var kilogramMeterPerSecond = "kg m/s";                 
var joule = "J";                                       
