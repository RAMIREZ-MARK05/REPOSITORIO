// Stehende Welle, Erkl�rung durch Reflexion, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Odraz";
var text02 = "pevn&yacute; koniec";
var text03 = "vo&lcaron;n&yacute; koniec";
var text04 = "Reset";
var text05 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];
var text06 = "Spomalenie";
var text07 = "Anim&aacute;cia";
var text08 = "Krokovanie";
var text09 = "Dopadaj&uacute;ce vlnenie";
var text10 = "Odrazen&eacute; vlnenie";
var text11 = "V&yacute;sledn&eacute; stojat&eacute; vlnenie";

var author = "W. Fendt 2003";
var translator = "A. &Scaron;utta 2016"; 

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "U";
var symbolAntiNode = "K";

