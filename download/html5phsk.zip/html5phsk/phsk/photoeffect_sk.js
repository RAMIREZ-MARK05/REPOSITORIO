// Photoelektrischer Effekt, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Materi&aacute;l kat&oacute;dy:";
var text03 = "Spektr&aacute;lna &ccaron;iara (Hg):";
var text04 = "Brzdn&eacute; nap&auml;tie:";
var text05 = "Frekvencia:";
var text06 = ["Energia jedn&eacute;ho", "fot&oacute;nu:"];
var text07 = "V&yacute;stupn&aacute; pr&aacute;ca:";
var text08 = ["Maxim&aacute;lna kinetick&aacute; energia", "jedn&eacute;ho elektr&oacute;nu:"];
var text09 = "Vymaza&tcaron; v&yacute;sledky merania";

var author = "W. Fendt 2000,&nbsp; A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                      
var terahertz = "THz";                               
var electronvolt = "eV";                             

// Texte in Unicode-Schreibweise:

var text02 = ["c\u00E9zium", "sod\u00EDk"];
var text10 = ["\u017Elt\u00E1", "zelen\u00E1", "fialov\u00E1", "ultrafialov\u00E1", "ultrafialov\u00E1"];
var text11 = "(THz)";
var text12 = "(V)";
var text13 = [
             ["Energia fot\00F3nov nie je dosta\u010Duj\u00EDca", "na uvo\u013Enenie elektr\u00F3nov."],
             ["Zvy\u0161ujte brzdn\u00E9 nap\u00E4tie, a\u017E prestan\u00FA", "elektr\u00F3ny dopada\u0165 na an\u00F3du."], 
             ["Brzdn\u00E9 nap\u00E4tie je tak ve\u013Ek\u00E9, \u017Ee sa", "elektr\u00F3ny vracaj\u00ED na kat\u00F3du."],
             ["Spravte \u010Fal\u0161ie meranie pre in\u00FA", "spektr\u00E1lnu \u010Diaru."],
             ["Spravte \u010Fal\u0161ie meranie pre in\u00FD", "materi\u00E1l kat\u00F3dy."],
             ["Meranie bolo dokon\u010Den\u00E9.", ""]
             ];

var symbolCathode = "K";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
