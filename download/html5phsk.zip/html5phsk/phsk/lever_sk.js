// Hebelgesetz, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in Unicode-Schreibweise:

var text01 = "\u013Davoto\u010Div\u00FD moment sily:";
var text02 = "Pravoto\u010Div\u00FD moment sily:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "M_1";                              // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "M_2";                             // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

var newton = "N";
var meter = "m";

var author = "W. Fendt 1997,  A. \u0160utta 2016";         // Autor (und �bersetzer)
