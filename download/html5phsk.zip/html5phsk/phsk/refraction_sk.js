// Reflexion und Brechung von Licht, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:
    
var text01 = "1. index lomu:";
var text02 = "2. index lomu:";
var text03 = "uhol dopadu:";
var text04 = "uhol odrazu:";
var text05 = "uhol lomu:";    
var text06 = ["medzn&yacute; uhol", "&uacute;pln&eacute;ho odrazu:"];

var author = "W. Fendt 1997,&nbsp; A. &Scaron;utta 2015";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                              

// Texte in Unicode-Schreibweise:

var text07 = [["v\u00E1kuum", "1"], ["vzduch", "1.0003"],  // Stoffe und Brechungsindizes
    ["voda", "1.33"], ["lieh (etanol)", "1.36"],
    ["kremi\u010Dit\u00E9 sklo", "1.46"], ["benzol", "1.49"], 
    ["optick\u00E9 sklo N-K5", "1.52"], ["so\u013E kamenn\u00E1", "1.54"], 
    ["flintov\u00E9 sklo LF5", "1.58"], ["optick\u00E9 sklo N-SK4", "1.61"],
    ["flintov\u00E9 sklo SF6", "1.81"], ["diamant", "2.42"],
    ["", ""]]; 
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03B1";                               // Symbol f�r Einfallswinkel (Alpha)
var symbolAngle2 = "\u03B2";                               // Symbol f�r Brechungswinkel (Beta)
var degreeUnicode = "\u00B0";                        
