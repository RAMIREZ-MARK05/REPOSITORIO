// Beispiel zur Zeitdilatation, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Zn&iacute;&zcaron;i&tcaron; r&yacute;chlos&tcaron;";              // Geschwindigkeit vermindern
var text02 = "Zv&yacute;&scaron;i&tcaron; r&yacute;chlos&tcaron;";              // Geschwindigkeit vergr��ern
var text03 = "Reset";
var text04 = ["&Scaron;tart", "Pauza", "Pokra&ccaron;ova&tcaron;"];

var author = "W. Fendt 1997,&nbsp; A. &Scaron;utta 2015";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "Vzdialenos\u0165:";                          // Flugstrecke
var text06 = "5 sv. hod\u00EDn";                           // 5 Lichtstunden
var text07 = "R\u00FDchlos\u0165:";                        // Geschwindigkeit
var text08 = "Doba letu (na Zemi):";                       // Flugdauer (Erd-System)
var text09 = "hod.";                                       // Stunden
var text10 = "Doba letu (v rakete):";                      // Flugdauer (Raketen-System)