// Magnetfeld eines geraden stromdurchflossenen Leiters, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Zmeni&tcaron; smer pr&uacute;du";

var author = "W. Fendt 2000";
var translator = "A. &Scaron;utta 2015";
