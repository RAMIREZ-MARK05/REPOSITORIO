// Gleichgewicht dreier Kr�fte, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Vektory s&iacute;l:";
var text02 = "&Lcaron;av&aacute; sila:";
var text03 = "Prav&aacute; sila:";
var text04 = "Doln&aacute; sila:";
var text05 = "Rovnobe&zcaron;n&iacute;k";
var text06 = "Uhly:";
var text07 = "V&lcaron;avo:";
var text08 = "Vpravo:";

var author = "W. Fendt 2000";
var translator = "A. &Scaron;utta 2015";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                           
var newton = "N";                       
