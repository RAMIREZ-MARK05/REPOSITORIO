// Zweites Kepler-Gesetz, slowakische slovakische Texte (August�n �utta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Hlavn&aacute; polos:";
var text03 = "Numerick&aacute; excentricita:";
var text04 = ["Pauza", "Pokra&ccaron;ova&tcaron;"];
var text05 = "Spomalene";
var text06 = ["Vzdialenos&tcaron;", "od Slnka:"];
var text07 = "R&yacute;chlos&tcaron;:";
var text08 = "Aktu&aacute;lna hodnota:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Oblasti";
var text12 = "Vektor r&yacute;chlosti";

var author = "W. Fendt 2000,&nbsp; A. &Scaron;utta 2016";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Merk\u00FAr", "Venu\u0161a", "Zem", "Mars", "Jupiter", "Saturn", "Ur\u00E1n", "Nept\u00FAn",
              "Pluto", "Halleyho kom\u00E9ta", ""];

// Symbole und Einheiten: 

var auUnicode = "AU";
var symbolPeriod = "T";

