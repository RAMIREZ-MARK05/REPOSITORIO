// Kr�fte an der schiefen Ebene, slowakische Texte (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];
var text03 = "Spomalenie";
var text04 = "Silomer";
var text05 = "Vektory s&iacute;l";
var text06 = "Sklon roviny:";
var text07 = "Tia&zcaron;ov&aacute; sila:";
var text08 = "Sila rovnobe&zcaron;n&aacute;:";
var text09 = "Sila norm&aacute;lov&aacute;:";
var text10 = "S&uacute;&ccaron;. vle&ccaron;. trenia:";
var text11 = "Trecia sila:";
var text12 = "&Tcaron;a&zcaron;n&aacute; sila:";

var author = "W. Fendt 1999,&nbsp;  A. &Scaron;utta 2016";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                            
var newton = "N";                               
