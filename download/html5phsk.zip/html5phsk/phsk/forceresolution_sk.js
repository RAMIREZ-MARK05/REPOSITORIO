// Zerlegung einer Kraft in zwei Komponenten, slowakische Version (Augustin Sutta)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Ve&lcaron;kos&tcaron; rozkladanej";                       
var text02 = "sily:";
var text03 = "Ve&lcaron;kosti uhlov:";
var text04 = "1. uhol:";
var text05 = "2. uhol:";
var text06 = "Ve&lcaron;kosti zlo&zcaron;iek:";
var text07 = "1. zlo&zcaron;ka:";
var text08 = "2. zlo&zcaron;ka:";
var text09 = "Rozlo&zcaron;i&tcaron; do zlo&zcaron;iek";
var text10 = "Zmaza&tcaron; kon&scaron;trukciu";

var author = "W. Fendt 2003";
var translator = "A. &Scaron;utta 2015";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                            
var newton = "N";                                

// Texte in Unicode-Schreibweise:

var text11 = "1. zlo\u017eka";                             // Text f�r erste Komponente
var text12 = "2. zlo\u017eka";                             // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                        