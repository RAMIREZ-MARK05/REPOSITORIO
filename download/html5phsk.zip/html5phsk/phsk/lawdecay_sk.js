// Zerfallsgesetz der Radioaktivit�t, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["&Scaron;tart", "Zastavi&tcaron;", "&Dcaron;alej"];    
var text03 = "Diagram";  

var author = "W. Fendt 1998";
var translator = "A. &Scaron;utta 2015";

// Texte in Unicode-Schreibweise:

var text04 = "\u010Cas:";                                  // Zeit                                   
var text05 = "E\u0161te nerozpadnut\u00FDch:";
var text06 = "U\u017E rozpadnut\u00FDch:";
var text07 = ["jadier", "jadro", "jadr\u00E1", "jadier"];  // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
