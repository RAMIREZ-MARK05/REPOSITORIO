// Bohrsches Atommodell, slowakische Texte (Augustin Sutta)
// Letzte �nderung 26.02.2018

// Texte in HTML-Schreibweise:

var text01 = "\u010Casticov\u00FD obraz";
var text02 = "Vlnov\u00FD obraz";
var text03 = "Hlavn\u00E9 kvantov\u00E9 \u010D\u00EDslo:";


var author = "W. Fendt 1999"; 
var translator = "A. \u0160utta 2016";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



