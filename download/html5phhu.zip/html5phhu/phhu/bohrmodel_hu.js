// Bohrsches Atommodell, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 05.02.2018

// Texte in HTML-Schreibweise:

var text01 = "R&eacute;szecske modell";
var text02 = "Hull&aacute;m modell";
var text03 = "F&#337;kvantumsz&aacute;m:";


var author = "W. Fendt 1999."; 
var translator = "Ser&eacute;nyi T. 2004.";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



