// Interferenz zweier Kreis- oder Kugelwellen, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 02.02.2018

// Texte in HTML-Schreibweise:

var text01 = ["Sz&uuml;net", "Folytat"];                          // Schaltknopf (Pause/Weiter)
var text02 = "Lass&iacute;t";
var text03 = "A k&eacute;t forr&aacute;s";
var text04 = "t&aacute;vols&aacute;ga:";
var text05 = "Hull&aacute;mhossz:";

var author = "W. Fendt 1999.";
var translator = "Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                                

// Texte in Unicode-Schreibweise:

var text06 = "\u00DAtk\u00FCl\u00F6nbs\u00E9g:";
var text07 = "Konstrukt\u00EDv interferencia (maxim\u00E1lis amplitud\u00F3)";
var text08 = "Destrukt\u00EDv interferencia (minim\u00E1lis amplitud\u00F3)";

// Symbole:

var symbolPhaseDifference = "\u0394";                      // Symbol f�r Phasendifferenz (Delta)
var symbolWavelength = "\u03BB";                           // Symbol f�r Wellenl�nge (Lambda)
