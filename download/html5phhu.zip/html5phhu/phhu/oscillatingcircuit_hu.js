// Elektromagnetischer Schwingkreis, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 04.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];
var text03 = "Lass&iacute;t (10 &times;)";
var text04 = "Lass&iacute;t (100 &times;)";
var text05 = "Kapacit&aacute;s:";
var text06 = "Induktivit&aacute;s:";
var text07 = "Ellen&aacute;ll&aacute;s:";
var text08 = "Max. fesz&uuml;lts&eacute;g:";
var text09 = "Fesz&uuml;lts&eacute;g, &Aacute;ram";
var text10 = "Energia";

var author = "W. Fendt 1999.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                           
var henry = "H";                                    
var ohm = "&Omega;";                               
var volt = "V";                                    

// Texte in Unicode-Schreibweise:

var text11 = "Rezg\u00E9sid\u0151:";
var text12 = "Elektromos mez\u0151 energi\u00E1ja:";
var text13 = "M\u00E1gneses mez\u0151 energi\u00E1ja:";
var text14 = "Bels\u0151 energia:";
var text15 = "Csillap\u00EDtatlan rezg\u0151mozg\u00E1s";
var text16 = "Csillap\u00EDtott rezg\u0151mozg\u00E1s";
var text17 = "Kritikus csillap\u00EDt\u00E1s";
var text18 = "Szuperkritikus csillap\u00EDt\u00E1s";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                 
var voltUnicode = "V";                             
var ampere = "A";                                  
var joule = "J";                                    
