// Fahrbahnversuch zum 2. Newtonschen Gesetz, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 31.01.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = ["Ind&iacute;t", "Adatr&ouml;gz&iacute;t&eacute;s"];
var text03 = "Diagram";
var text04 = "A kocsi t&ouml;mege:";
var text05 = "Felf&uuml;ggesztett test t&ouml;mege:";
var text06 = "S&uacute;rl&oacute;d&aacute;si egy&uuml;tthat&oacute;:";
var text07 = "Adat:";

var author = "W. Fendt 1997.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "&mu;";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "OK";
var text09 = "(s)";
var text10 = "(m)";
var text11 = "T\u00FAl nagy s\u00FArl\u00F3d\u00E1s!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


