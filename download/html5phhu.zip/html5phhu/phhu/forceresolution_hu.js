// Zerlegung einer Kraft in zwei Komponenten, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 30.01.2018

// Texte in HTML-Schreibweise:

var text01 = "";                       
var text02 = "Az er&#337; nagys&aacute;ga:";
var text03 = "Sz&ouml;gnagy&aacute;sgok:";
var text04 = "1. sz&ouml;g:";
var text05 = "2. sz&ouml;g:";
var text06 = "A komponensek nagys&aacute;ga:";
var text07 = "1. komponens:";
var text08 = "2. komponens:";
var text09 = "Komponensek keres&eacute;se";
var text10 = "T&ouml;rl&eacute;s";

var author = "W. Fendt 2003.";
var translator = "Ser&eacute;nyi T. 2004.";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                 
var newton = "N";                                     

// Texte in Unicode-Schreibweise:

var text11 = "1. komponens";                               // Text f�r erste Komponente
var text12 = "2. komponens";                               // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                               