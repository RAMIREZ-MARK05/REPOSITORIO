// Zerfallsgesetz der Radioaktivit�t, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 05.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];    
var text03 = "Diagramm";  

var author = "W. Fendt 1998.";
var translator = "Ser&eacute;nyi T. 2004.";

// Texte in Unicode-Schreibweise:

var text04 = "Id\u0151:";                                      
var text05 = "M\u00E9g nem bomlott:";
var text06 = "M\u00E1r elbomlott:";
var text07 = ["atommag", "atommag", "atommag", "atommag"]; // Singular/Plural usw. (0, 1, 2, mehr als 2)

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolHalfLife = "T";                                  // Symbol f�r Halbwertszeit
var symbolQuotient = "N/N_0";                              // Symbol f�r Bruchteil der unzerfallenen Kerne
