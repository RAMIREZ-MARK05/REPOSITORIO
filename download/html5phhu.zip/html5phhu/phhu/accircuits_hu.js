// Einfache Wechselstromkreise, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 04.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Ellen&aacute;ll&aacute;s";
var text02 = "Kondenz&aacute;tor";
var text03 = "Tekercs";
var text04 = "&Uacute;jra";
var text05 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];          
var text06 = "Lass&iacute;t";
var text07 = "Frekvencia:";
var text08 = "Max. fesz&uuml;lts&eacute;g:";
var text09 = "Ellen&aacute;ll&aacute;s:";                            
var text10 = "Kapacit&aacute;s:";                          
var text11 = "Induktivit&aacute;s:"; 
var text12 = "Max. &aacute;ram:"; 

var author = "W. Fendt 1998.,&nbsp; Ser&eacute;nyi T. 2004.";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                    
var volt = "V";                                      
var ampere = "A";                                    
var milliampere = "mA";                              
var microampere = "&mu;A";                           
var ohm = "&Omega;";                                 
var microfarad = "&mu;F";                            
var henry = "H";                                      

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
