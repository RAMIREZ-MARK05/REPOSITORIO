// Kepler-Fernrohr, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 04.02.2018

// Texte in HTML-Schreibweise:

var text01 = "F&oacute;kuszt&aacute;vols&aacute;g:"; 
var text02 = "Objekt&iacute;v:";
var text03 = "Okul&aacute;r:";
var text04 = "Sz&ouml;gek:";
var text05 = "Nagy&iacute;t&aacute;s:";

var author = "W. Fendt 2000.";
var translator = "Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite

