// Kr�fte an der schiefen Ebene, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 31.01.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];
var text03 = "Lass&iacute;t";
var text04 = "Sk&aacute;la";
var text05 = "Er&#337;vektor";
var text06 = "Hajl&aacute;ssz&ouml;g:";
var text07 = "S&uacute;ly:";
var text08 = "P&aacute;rhuzamos komponens:";
var text09 = "Nyom&oacute;er&#337;:";
var text10 = "S&uacute;rl&oacute;d&aacute;si egy&uuml;tthat&oacute;:";
var text11 = "S&uacute;rl&oacute;d&aacute;si er&#337;:";
var text12 = "Sz&uuml;ks&eacute;ges er&#337;:";

var author = "W. Fendt 1999.,&nbsp; Ser&eacute;nyi T. 2004.";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                
var newton = "N";                                     
