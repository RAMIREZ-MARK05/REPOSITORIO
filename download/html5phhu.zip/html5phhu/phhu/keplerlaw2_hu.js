// Zweites Kepler-Gesetz, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 01.02.2018

// Texte in HTML-Schreibweise:
    
var text02 = "F&eacute;l nagytengely:";
var text03 = "Lapults&aacute;g:";
var text04 = ["Sz&uuml;net", "Folytat"];
var text05 = "Lass&iacute;t";
var text06 = ["T&aacute;vols&aacute;g", "Napt&oacute;l:"];
var text07 = "Sebess&eacute;g:";
var text08 = "Pillanatnyi:";
var text09 = "Minim&aacute;lis:";
var text10 = "Maxim&aacute;lis:";
var text11 = "Szektorok";
var text12 = "Sebess&eacute;g vektor";

var author = "W. Fendt 2000.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "CsE";                                            // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Merk\u00FAr", "V\u00E9nusz", "F\u00F6ld", "Mars", "Jupiter", "Szaturnusz", "Ur\u00E1nusz", "Neptunusz",
              "Pl\u00FAt\u00F3", "Halley-\u00FCst\u00F6k\u00F6s", ""];

// Symbole und Einheiten: 

var auUnicode = "CsE";
var symbolPeriod = "T";

