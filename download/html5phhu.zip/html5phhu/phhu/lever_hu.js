// Hebelgesetz, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 30.01.2018

// Texte in Unicode-Schreibweise:

var text01 = "Bal oldali forgat\u00F3nyomat\u00E9k:";
var text02 = "Jobb oldali forgat\u00F3nyomat\u00E9k:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "M_1";                              // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "M_2";                             // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

var newton = "N";
var meter = "m";

var author = "W. Fendt 1997.,\u0020 Ser\u00E9nyi T. 2004.";     // Autor (und �bersetzer)
