// Bewegung mit konstanter Beschleunigung, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 30.01.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];
var text03 = "Lass&iacute;t";
var text04 = "Kezdeti hely:";
var text05 = "Kezdeti sebess&eacute;g:";
var text06 = "Gyorsul&aacute;s:";
var text07 = "Sebess&eacute;g vektor";
var text08 = "Gyorsul&aacute;s vektor";

var author = "W. Fendt 2000.";
var translator = "Ser&eacute;nyi T. 2004.";

// Texte in Unicode-Schreibweise:

var text09 = "(s)";                                        // Einheitenangabe f�r Zeit-Achse
var text10 = "(m)";                                        // Einheitenangabe f�r Weg-Achse
var text11 = "(m/s)";                                      // Einheitenangabe f�r Geschwindigkeits-Achse
var text12 = "(m/s\u00b2)";                                // Einheitenangabe f�r Beschleunigungs-Achse

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPosition = "x";                                  // Symbol f�r Ortskoordinate
var second = "s";                                       
var meter = "m";                                        
var meterPerSecond = "m/s";                             
var meterPerSecond2 = "m/s\u00b2";                      
