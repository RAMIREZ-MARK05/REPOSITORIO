// Schwebungen, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 02.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];
var text03 = "Lass&iacute;t";
var text04 = "Frekvenci&aacute;k:";
var text05 = "1. hull&aacute;m:";
var text06 = "2. hull&aacute;m:";

var author = "W. Fendt 2001."; 
var translator = "Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



