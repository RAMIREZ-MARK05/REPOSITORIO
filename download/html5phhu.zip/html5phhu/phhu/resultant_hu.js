// Ersatzkraft mehrerer Kr�fte, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 30.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Er&#337;k sz&aacute;ma:";
var text02 = "Ered&#337; meghat&aacute;roz&aacute;sa";
var text03 = "T&ouml;rl&eacute;s";

var author = "W. Fendt 1998.";
var translator = "Ser&eacute;nyi T. 2004.";
