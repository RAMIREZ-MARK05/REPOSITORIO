// Generator, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 03.02.2018

// Texte in HTML-Schreibweise;

var text01 = "Kommut&aacute;tor n&eacute;lk&uuml;l";
var text02 = "Kommut&aacute;torral";
var text03 = "Ir&aacute;ny v&aacute;lt&aacute;s";
var text04 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];
var text05 = "Forg&aacute;s ir&aacute;nya";
var text06 = "M&aacute;gneses mez&#337;";
var text07 = "Induk&aacute;lt &aacute;ram";

var author = "W. Fendt 1998.";  
var translator = "Ser&eacute;nyi T. 2004.";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "ford./perc";                     // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
