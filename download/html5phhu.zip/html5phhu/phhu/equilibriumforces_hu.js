// Gleichgewicht dreier Kr�fte, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Er&#337;k:";
var text02 = "Bal:";
var text03 = "Jobb:";
var text04 = "Als&oacute;:";
var text05 = "Paralelogramma";
var text06 = "Sz&ouml;gek:";
var text07 = "Bal:";
var text08 = "Jobb:";

var author = "W. Fendt 2000.";
var translator = "Ser&eacute;nyi T. 2004.";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                            
var newton = "N";                                   
