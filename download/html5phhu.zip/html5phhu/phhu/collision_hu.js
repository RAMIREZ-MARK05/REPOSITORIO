// Elastischer und unelastischer Sto�, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 31.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Rugalmas &uuml;tk&ouml;z&eacute;s";
var text02 = "Rugalmatlan &uuml;tk&ouml;z&eacute;s";
var text03 = "&Uacute;jra";
var text04 = "Ind&iacute;t";
var text05 = "Lass&iacute;t";
var text06 = "1-es kocsi:";
var text07 = "2-es kocsi:";
var text08 = "T&ouml;meg:";
var text09 = "Sebess&eacute;g:";
var text10 = "Sebess&eacute;g";
var text11 = "Impulzus";
var text12 = "Mozg&aacute;si energia";

var author = "W. Fendt 1998.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                           

// Texte in Unicode-Schreibweise:

var text13 = "1-es kocsi:";
var text14 = "2-es kocsi:";
var text15 = "\u00DCtk\u00F6z\u00E9s el\u0151tti sebess\u00E9gek:";
var text16 = "\u00DCtk\u00F6z\u00E9s ut\u00E1ni sebess\u00E9gek:";
var text17 = "\u00DCtk\u00F6z\u00E9s el\u0151tti impulzusok:";
var text18 = "\u00DCtk\u00F6z\u00E9s ut\u00E1ni impulzusok:";
var text19 = "Mozg\u00E1si energia az \u00FCtk\u00F6z\u00E9s el\u0151tt:";
var text20 = "Mozg\u00E1si energia az \u00FCtk\u00F6z\u00E9s ut\u00E1n:";
var text21 = "Teljes impulzus:";
var text22 = "Teljes mozg\u00E1si energia:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                      
var kilogramMeterPerSecond = "kg m/s";                  
var joule = "J";                                        
