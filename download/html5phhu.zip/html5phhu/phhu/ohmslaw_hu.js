// Ohmsches Gesetz, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 03.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Max. fesz&uuml;lts&eacute;g:";
var text02 = "Max. &aacute;ram:";
var text03 = "R n&ouml;vel&eacute;se";
var text04 = "R cs&ouml;kkent&eacute;se";
var text05 = "U n&ouml;vel&eacute;se";
var text06 = "U cs&ouml;kkent&eacute;se";

var author = "W. Fendt 1997.";
var translator = "Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "Maximum!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
