// Zerfallsreihen, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 05.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Boml&aacute;si sor:";
var text03 = "K&ouml;vetkez&#337; boml&aacute;s";

var author = "W. Fendt 1998."; 
var translator = "Ser&eacute;nyi T. 2004.";

// Texte in Unicode-Schreibweise:

var text02 = ["T\u00F3rium sor", "Nept\u00FAnium sor", "Ur\u00E1n R\u00E1dium sor", "Ur\u00E1n Akt\u00EDnium sor"];          





