// Leiterschaukel-Versuch zur Lorentzkraft, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 03.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Be / Ki";
var text02 = "Ford&iacute;t: &aacute;ram";
var text03 = "Ford&iacute;t: m&aacute;gnes";
var text04 = "&Aacute;ramir&aacute;ny";
var text05 = "M&aacute;gneses mez&#337;";
var text06 = "Lorentz-er&#337;";

var author = "W. Fendt 1998.";
var translator = "Ser&eacute;nyi T. 2004.";
