// Erstes Kepler-Gesetz, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 01.02.2018

// Texte in HTML-Schreibweise:
    
var text02 = "F&eacute;l nagytengely:";
var text03 = "Lapults&aacute;g:";
var text04 = "F&eacute;l kistengely:";
var text05 = ["Sz&uuml;net", "Folytat"];
var text06 = "Lass&iacute;t";
var text07 = "Napt&aacute;vols&aacute;g:";
var text08 = "Pillanatnyi:";
var text09 = "Minim&aacute;lis:";
var text10 = "Maxim&aacute;lis:";
var text11 = "Ellipszis p&aacute;lya";
var text12 = "Tengely";
var text13 = "Vez&eacute;rsug&aacute;r";

var author = "W. Fendt 2000.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "CsE";                                            // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Merk\u00FAr", "V\u00E9nusz", "F\u00F6ld", "Mars", "Jupiter", "Szaturnusz", "Ur\u00E1nusz", "Neptunusz",
              "Pl\u00FAt\u00F3", "Halley-\u00FCst\u00F6k\u00F6s", ""];
var text14 = "Nap";
var text15 = "Bolyg\u00F3";
var text16 = "\u00DCst\u00F6k\u00F6s";
var text17 = "Perihelium";
var text18 = "Apohelium";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "CsE";

