// Photoelektrischer Effekt, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 05.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Kat&oacute;d anyaga:";
var text03 = "Spektrum vonal (Hg):";
var text04 = "Ellenfesz&uuml;lts&eacute;g:";
var text05 = "Frekvencia:";
var text06 = ["Foton", "energi&aacute;ja:"];
var text07 = "Kil&eacute;p&eacute;si munka:";
var text08 = ["Elektron maxim&aacute;lis mozg&aacute;si", "energi&aacute;ja:"];
var text09 = "M&eacute;r&eacute;s t&ouml;rl&eacute;se";

var author = "W. Fendt 2000.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                      
var terahertz = "THz";                               
var electronvolt = "eV";                             

// Texte in Unicode-Schreibweise:

var text02 = ["c\u00E9zium", "n\u00E1trium"];
var text10 = ["s\u00E1rga", "z\u00F6ld", "k\u00E9k", "ultraibolya", "ultraibolya"];
var text11 = "(THz)";
var text12 = "(V)";
var text13 = [
             ["A foton energi\u00E1ja nem elegend\u0151 az elektron", "kibocs\u00E1jt\u00E1s\u00E1hoz."],
             ["N\u00F6veld a fesz\u00FClts\u00E9get, am\u00EDg az elektronok nem", "\u00E9rhetik el az an\u00F3dot!"],
             ["A fesz\u00F6lts\u00E9g olyan nagy, hogy az elektronok", "visszazuhannak a kat\u00F3dba."],
             ["Pr\u00F3b\u00E1lj ki egy m\u00E1sik spektrumvonalat egy \u00FAj", "k\u00EDs\u00E9rletben!"],
             ["V\u00E9gezz el egy \u00FAj k\u00EDs\u00E9rletsort egy m\u00E1sik", "anyag\u00FA kat\u00F3ddal!"],
             ["A m\u00E9r\u00E9seknek v\u00E9ge."]
             ];

var symbolCathode = "C";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
