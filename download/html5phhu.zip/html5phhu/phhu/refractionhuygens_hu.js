// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 04.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra ind&iacute;t";
var text02 = "K&ouml;vetkez&#337; l&eacute;p&eacute;s";
var text03 = ["Sz&uuml;net", "Folytat"];                  
var text04 = "1. t&ouml;r&eacute;smutat&oacute;:";
var text05 = "2. t&ouml;r&eacute;smutat&oacute;:";
var text06 = "Bees&eacute;si sz&ouml;g:";

var author = "W. Fendt 1998.";
var translator = "Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                               

// Texte in Unicode-Schreibweise:

var text07 = [

  ["S\u00EDk hull\u00E1mfront esik",                       // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "ferd\u00E9n a k\u00F6zeghat\u00E1rra",
   "A hull\u00E1m terjed\u00E9si",
   "sebess\u00E9ge k\u00FCl\u00F6nb\u00F6z\u0151 a",
   "k\u00E9t k\u00F6zegben."],
   
  ["S\u00EDk hull\u00E1mfront esik",                       // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "mer\u0151legesen a k\u00F6zegek",
   "hat\u00E1r\u00E1ra. A hull\u00E1m",
   "terjed\u00E9si sebess\u00E9ge",
   "k\u00F6zegenk\u00E9nt k\u00FCl\u00F6nb\u00F6z\u0151."],
   
  ["A hull\u00E1mfront meg\u00E9rke-",                     // i == 2 (step == 1, n1 > n2) 
   "z\u00E9sekor a hat\u00E1r pontjai",
   "elemi hull\u00E1mforr\u00E1sk\u00E9nt",
   "viselkednek, a Huygens",
   "elv szerint.",
   "A 2. k\u00F6zegben az elemi",
   "hull\u00E1mok gyorsabban",
   "terjednek, hiszen ott",
   "a t\u00F6r\u00E9smutat\u00F3 kisebb."],
   
  ["A hull\u00E1mfront meg\u00E9rke-",                     // i == 3 (step == 1, n1 < n2) 
   "z\u00E9sekor a hat\u00E1r pontjai",
   "elemi hull\u00E1mforr\u00E1sk\u00E9nt",
   "viselkednek, a Huygens",
   "elv szerint.",
   "A 2. k\u00F6zegben az elemi",
   "hull\u00E1mok lassaban",
   "terjednek, hiszen ott",
   "a t\u00F6r\u00E9smutat\u00F3 nagyobb."],
   
  ["Az elemi hull\u00E1mok",                               // i == 4 (step == 2, total == false, eps1 > 0) 
   "szuperpoz\u00EDci\u00F3jak\u00E9nt",
   "s\u00EDkhull\u00E1mfront kelet-",
   "kezik: az 1. k\u00F6zegben",
   "a visszavert, a 2. k\u00F6-",
   "zegben a megt\u00F6rt hull\u00E1m."],
   
  ["Az elemi hull\u00E1mok",                               // i == 5 (step == 2, total == false, eps1 == 0)
   "szuperpoz\u00EDci\u00F3jak\u00E9nt",
   "s\u00EDkhull\u00E1mfront kelet-",
   "kezik: az 1. k\u00F6zegben",
   "a visszavert, a 2. k\u00F6-",
   "zegben a megt\u00F6rt hull\u00E1m."],
   
  ["Az elemi hull\u00E1mok",                               // i == 6 (step == 2, total == true)
   "szuperpoz\u00EDci\u00F3jak\u00E9nt",
   "az 1. k\u00F6zegben vissza-",
   "vert s\u00EDkhull\u00E1m keletkezik.",
   "De a 2. k\u00F6zegben nem",
   "alakul ki hull\u00E1mfront",
   "(teljes visszaver\u0151d\u00E9s)."],

  ["Felrajzoltuk a terjed\u00E9s",                         // i == 7 (step == 3)
   "ir\u00E1ny\u00E1t, azt az ir\u00E1nyt,",
   "amely mer\u0151leges a",
   "hull\u00E1mfrontra."],
   
  ["A hullamfront \u00E1ltal\u00E1ban",                    // i == 8 (step == 4)
   "nem egyed\u00FCl \u00E9rkezik!"], 

  ["Ha a k\u00E9t k\u00F6zeg",                             // i == 9 (n1 == n2)
   "t\u00F6r\u00E9smutat\u00F3ja azonos",
   "akkor semmi k\u00FCl\u00F6n\u00F6s",
   "nem t\u00F6rt\u00E9nik."]];
          
var text08 = "Bees\u00E9si sz\u00F6g:"; 
var text09 = "Visszaver\u0151d\u00E9si sz\u00F6g:";
var text10 = "T\u00F6r\u00E9si sz\u00F6g:"; 
var text11 = "1. k\u00F6zeg";
var text12 = "2. k\u00F6zeg";      
var text13 = ["Teljes visszaver\u0151d\u00E9s", "hat\u00E1rsz\u00F6ge:"];

// Einheiten:

var degreeUnicode = "\u00b0";                          
