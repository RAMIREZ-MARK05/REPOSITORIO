// Spezielle Prozesse eines idealen Gases, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 16.10.2019

// Texte in HTML-Schreibweise:

var text01 = "Izob&aacute;r folyamat";
var text02 = "Izochor folyamat";
var text03 = "Izoterm folyamat";
var text04 = "Kezdeti &aacute;llapot:";
var text05 = "Nyom&aacute;s:";
var text06 = "T&eacute;rfogat:";
var text07 = "H&#337;m&eacute;rs&eacute;klet:";
var text08 = "V&eacute;gs&#337; &aacute;llapot:";
var text09 = "Kezdeti &aacute;llapot";
var text10 = "Ind&iacute;t";

var author = "W. Fendt 1999,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Munka";
var text12 = "H\u0151";
var text13 = "A g\u00E1z bels\u0151 energi\u00E1ja";
var text14 = "n\u00F6vekszik.";
var text15 = "A g\u00E1z bels\u0151 energi\u00E1ja";
var text16 = "\u00E1lland\u00F3.";
var text17 = "A g\u00E1z bels\u0151 energi\u00E1ja";
var text18 = "cs\u00F6kken.";
var text19 = "Nyom\u00E1s t\u00FAl kicsi!";
var text20 = "Nyom\u00E1s t\u00FAl nagy!";
var text21 = "T\u00E9rfogat t\u00FAl kicsi!";
var text22 = "T\u00E9rfogat t\u00FAl nagy!";
var text23 = "H\u0151m\u00E9rs\u00E9klet t\u00FAl kicsi!";
var text24 = "H\u0151m\u00E9rs\u00E9klet t\u00FAl nagy!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


