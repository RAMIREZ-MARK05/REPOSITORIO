// Messung der Auftriebskraft, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 01.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Alapter&uuml;let:"; 
var text02 = "Testmagass&aacute;g:";
var text03 = "A test s&#369;r&#369;s&eacute;ge:";
var text04 = "A folyad&eacute;k s&#369;r&#369;s&eacute;ge:";   
var text05 = "Bemer&uuml;l&eacute;si m&eacute;lys&eacute;g:";
var text06 = "Kiszor&iacute;tott t&eacute;rfogat:"; 
var text07 = "Felhajt&oacute;er&#337;:";
var text08 = "Test s&uacute;lya:";
var text09 = "M&eacute;rt er&#337;:";
var text10 = "M&eacute;r&eacute;si tartom&aacute;ny:";

var author = "W. Fendt 1998.&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Maximum!";
