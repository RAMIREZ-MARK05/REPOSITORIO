// Interferenz von Licht am Doppelspalt, ungarische Texte (Ser�nyi Tam�s, unvollst�ndig!)
// Letzte �nderung 05.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Hull&aacute;mhossz:";
var text02 = "A k&eacute;t r&eacute;s t&aacute;vols&aacute;ga:";
var text03 = "Sz&ouml;g:";
var text04 = "Maxima:"; // ???
var text05 = "Minima:"; // ???
var text06 = "Relat&iacute;v intenzit&aacute;st:";
var text07 = "Interference pattern"; // ???
var text08 = "Intensity profile";    // ???

var author = "W. Fendt 2003.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
