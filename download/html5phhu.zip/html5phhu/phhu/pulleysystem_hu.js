// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 30.01.2018

// Texte in HTML-Schreibweise:

var text01 = "2 csiga";
var text02 = "4 csiga";
var text03 = "6 csiga";
var text04 = "S&uacute;ly:";
var text05 = "A mozg&oacute; csiga(k) s&uacute;lya:";
var text06 = "A sz&uuml;ks&eacute;ges er&#337;:";
var text07 = "Sk&aacute;la";
var text08 = "Er&#337;vektor";

var author = "W. Fendt 1998.";
var translator = "Ser&eacute;nyi T. 2004.";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                 
