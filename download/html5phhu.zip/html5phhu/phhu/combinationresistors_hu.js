// Kombinationen von Widerst�nden, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 19.02.2020

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = "Telep kapocsfesz&uuml;lts&eacute;ge:";
var text03 = "Ellen&aacute;ll&aacute;s:";
var text04 = "Ellen&aacute;ll&aacute;s hozz&aacute;ad&aacute;sa (Soros kapcsol&aacute;s)";
var text05 = "Ellen&aacute;ll&aacute;s hozz&aacute;ad&aacute;sa (P&aacute;rhuzamos kapcsol&aacute;s)";
var text06 = "M&#369;szerek:";
var text07 = "Fesz&uuml;lts&eacute;gm&eacute;r&#337;";
var text08 = "&Aacute;ramm&eacute;r&#337;";

var author = "W. Fendt 2002.";
var translator = "Ser&eacute;nyi T. 2004.";

// Texte in Unicode-Schreibweise:

var text09 = "Fesz\u00FClts\u00E9gm\u00E9r\u0151:";
var text10 = "\u00C1ramm\u00E9r\u0151:";
var text11 = "Ellen\u00E1ll\u00E1s:";
var text12 = "Ered\u0151 ellen\u00E1ll\u00E1s:";
var text13 = "t\u00FAl kicsi";
var text14 = "very large"; // ???

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00D7";                                 // Multiplikationszeichen

