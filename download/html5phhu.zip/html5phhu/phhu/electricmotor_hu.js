// Gleichstrom-Elektromotor, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 03.02.2018

// Texte in HTML-Schreibweise;

var text01 = "&Uacute;jra";
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];             
var text03 = "Ford&iacute;t";
var text04 = "&Aacute;ramir&aacute;ny";
var text05 = "M&aacute;gneses mez&#337;";
var text06 = "Lorentz-er&#337;";

var author = "W. Fendt 1997.";             
var translator = "Ser&eacute;nyi T. 2004.";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "ford./perc";                     // Umdrehungen pro Minute
