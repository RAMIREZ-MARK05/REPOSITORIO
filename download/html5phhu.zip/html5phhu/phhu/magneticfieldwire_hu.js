// Magnetfeld eines geraden stromdurchflossenen Leiters, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 03.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Ford&iacute;t";

var author = "W. Fendt 2000.";
var translator = "Ser&eacute;nyi T. 2004.";
