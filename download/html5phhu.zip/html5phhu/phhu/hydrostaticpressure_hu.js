// Druckdose (hydrostatischer Druck), ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 05.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Folyad&eacute;k:";
var text03 = "S&#369;r&#369;s&eacute;g:";
var text04 = "M&eacute;lys&eacute;g:";
var text05 = "Hidrosztatikai nyom&aacute;s:";

var author = "W. Fendt 1999";                              // Autor
var translator = "Ser&eacute;nyi T. 2004";                 // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["ismeretlen", "v\u00EDz", "ethanol", "benzol", "sz\u00E9ntetraklorid", "higany"]; 
