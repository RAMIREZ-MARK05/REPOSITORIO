// Stehende Welle, Erkl�rung durch Reflexion, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 02.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Visszaver&#337;d&eacute;s:";
var text02 = "r&ouml;gz&iacute;tett v&eacute;gr&#337;l";
var text03 = "szabad v&eacute;gr&#337;l";
var text04 = "&Uacute;jra";
var text05 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];
var text06 = "Lass&uacute; mozg&aacute;s";
var text07 = "Anim&aacute;ci&oacute;";
var text08 = "L&eacute;p&eacute;sk&ouml;z";
var text09 = "Bees&#337; hull&aacute;m";
var text10 = "Visszavert hull&aacute;m";
var text11 = "Ered&#337; &aacute;ll&oacute;hull&aacute;m";

var author = "W. Fendt 2003."; 
var translator = "Ser&eacute;nyi T. 2004.";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "Cs";
var symbolAntiNode = "D";

