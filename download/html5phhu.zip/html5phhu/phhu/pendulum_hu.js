// Fadenpendel, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 01.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];
var text03 = "Lass&iacute;t";
var text04 = "Hossz:";
var text05x = "";                                          // Zus�tzliche Zeile!
var text05 = "Gyorsul&aacute;s:";
var text06 = "T&ouml;meg:";
var text07 = "Amplitud&oacute;:";
var text08 = "Kit&eacute;r&eacute;s";
var text09 = "Sebess&eacute;g";
var text10 = "Gyorsul&aacute;s";
var text11 = "Er&#337;";
var text12 = "Energia";

var author = "W. Fendt 1998.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var meter = "m";                                  
var meterPerSecond2 = "m/s&sup2;";                 
var kilogram = "kg";                               
var degree = "&deg;";                              

// Texte in Unicode-Schreibweise:

var text13 = "Maximum";
var text14 = "Kit\u00E9r\u00E9s";
var text15 = "Sebess\u00E9g"; 
var text16 = "Gyorsul\u00E1s (tangenci\u00E1lis komponens)";
var text17 = "Er\u0151 (tangenci\u00E1lis komponens)";
var text18 = "Potenci\u00E1lis energia";
var text19 = "Mozg\u00E1si energia";
var text20 = "Teljes energia";
var text21 = "(s)";
var text22 = "(m)";
var text23 = "(m/s)";
var text24 = "(m/s\u00b2)";
var text25 = "(N)";
var text26 = "(J)";
var text27 = "Peri\u00F3dusid\u0151";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolTangential = "tang";                             // Symbol f�r tangential
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "pot";                               // Symbol f�r potentiell
var symbolKinetic = "kin";                                 // Symbol f�r kinetisch
var second = "s";                                  
var meterUnicode = "m";                            
var meterPerSecond = "m/s";                         
var meterPerSecond2Unicode = "m/s\u00b2";           
var newton = "N";                                   
var joule = "J";                                    


