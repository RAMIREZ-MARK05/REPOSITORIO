// Schiefer Wurf, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 31.01.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";                    
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];          
var text03 = "Lass&uacute; mozg&aacute;s";
var text04 = "Kezdeti magass&aacute;g:";
var text05 = "Kezd&#337;sebess&eacute;g:";
var text06 = "Hajl&aacute;ssz&ouml;g:";
var text07 = "T&ouml;meg:"; 
var text08 = "Gravit&aacute;ci&oacute;s gyorsul&aacute;s:";
var text09 = "Koordin&aacute;t&aacute;k";
var text10 = "Sebess&eacute;g";
var text11 = "Gyorsul&aacute;s";
var text12 = "Er&#337;";
var text13 = "Energia";

var author = "W. Fendt 2000.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                     
var meterPerSecond = "m/s";                          
var meterPerSecond2 = "m/s&sup2;";                   
var kilogram = "kg";                                 
var degree = "&deg;";                                

// Texte in Unicode-Schreibweise:

var text14 = "(m)";                                        // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Koordin\u00E1t\u00E1k:";
var text16 = "(v\u00EDzszintes)";
var text17 = "(f\u00FCgg\u0151leges)";
var text18 = "V\u00EDzszintes t\u00E1vols\u00E1g:";
var text19 = "Max. magass\u00E1g:";
var text20 = "Id\u0151:";
var text21 = "Sebess\u00E9gkomponensek:";
var text22 = "Sebess\u00E9g nagys\u00E1g:";
var text23 = "Hajl\u00E1ssz\u00F6g:";
var text24 = "Gyorsul\u00E1s:";
var text25 = "Er\u0151:";
var text26 = "Mozg\u00E1si energia:";
var text27 = "Potenci\u00E1lis energia:";
var text28 = "Teljes energia:";

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                              
var secondUnicode = "s";                             
var meterPerSecondUnicode = "m/s";                   
var meterPerSecond2Unicode = "m/s\u00b2";            
var newtonUnicode = "N";                             
var jouleUnicode = "J";                              
var degreeUnicode = "\u00b0";                        



