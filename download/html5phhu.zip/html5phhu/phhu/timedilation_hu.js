// Beispiel zur Zeitdilatation, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Sebess&eacute;g cs&ouml;kkent&eacute;s";
var text02 = "Sebess&eacute;g n&ouml;vel&eacute;s";
var text03 = "&Uacute;jra";
var text04 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];

var author = "W. Fendt 1997.,&nbsp; Ser&eacute;nyi T. 2004.";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "T\u00E1vols\u00E1g:";
var text06 = "5 f\u00E9ny\u00F3ra";
var text07 = "Sebess\u00E9g:";
var text08 = "Rep\u00FCl\u00E9si id\u0151 (f\u00F6ldi rendszerben):";
var text09 = "\u00F3ra";
var text10 = "Rep\u00FCl\u00E9si id\u0151 (\u0171rhaj\u00F3 rendszerben):";