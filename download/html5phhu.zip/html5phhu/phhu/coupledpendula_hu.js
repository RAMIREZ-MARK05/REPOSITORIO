// Gekoppelte Pendel, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 01.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";                           
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];                
var text03 = "Lass&iacute;t";
var text04 = "Kezdeti hely:";

var author = "W. Fendt 1998.";
var translator = "Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                            

// Texte in Unicode-Schreibweise:

var text05 = "1. inga";                                    // Erstes Pendel (links)
var text06 = "2. inga";                                    // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
