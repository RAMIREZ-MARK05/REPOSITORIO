// Resonanz, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 02.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = ["Ind&iacute;t", "Sz&uuml;net", "Folytat"];
var text03 = "Lass&iacute;t";
var text04 = "Rezon&aacute;tor:";
var text05 = "Rug&oacute; &aacute;lland&oacute;:";
var text06 = "T&ouml;meg:";
var text07 = "Csillap&iacute;t&aacute;s:";
var text08 = "Gerjeszt&eacute;s:";
var text09 = "Sz&ouml;gsebess&eacute;g:";
var text10 = "Kit&eacute;r&eacute;s diagram";
var text11 = "Amplitud&oacute; diagram";
var text12 = "F&aacute;zisk&uuml;l&ouml;nbs&eacute;g diagram";

var author = "W. Fendt 1998.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                               
var newtonPerMeter = "N/m";                        
var perSecond = "1/s";                             
var radPerSecond = "rad/s";                        

// Texte in Unicode-Schreibweise:

var text13 = "Rezonancia katasztr\u00F3fa!";
var text14 = "(A szimul\u00E1ci\u00F3 nem \u00E9rv\u00E9nyes!)";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                               
var radPerSecondUnicode = "rad/s";                   


