// Kettenkarussell, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 01.02.2018

// Texte in HTML-Schreibweise:

var text01 = "K&ouml;rhinta";
var text02 = "K&ouml;rhinta az er&#337;kkel";
var text03 = "V&aacute;zlat";
var text04 = "Sz&aacute;madatok";
var text05 = ["Sz&uuml;net", "Folytat"];
var text06 = "Lass&iacute;t";
var text07 = "Peri&oacute;dus id&#337;:";
var text08 = ["A felf&uuml;ggeszt&eacute;sek &eacute;s a forg&aacute;stengely", "k&ouml;z&ouml;tti t&aacute;vols&aacute;g:"]; 
var text09 = "A l&aacute;ncok hossza:";
var text10 = "T&ouml;meg:";

var author = "W. Fendt 1999.,&nbsp; Ser&eacute;nyi T. 2004.";

// Texte in Unicode-Schreibweise:

var text11 = "Frekvencia:";
var text12 = "Sz\u00F6gsebess\u00E9g:";
var text13 = "Sug\u00E1r:";
var text14 = "Sebess\u00E9g:";
var text15 = "Sz\u00F6g:";
var text16 = "S\u00FAly:";
var text17 = "Centripet\u00E1lis er\u0151:";
var text18 = "K\u00F6t\u00E9ler\u0151:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




