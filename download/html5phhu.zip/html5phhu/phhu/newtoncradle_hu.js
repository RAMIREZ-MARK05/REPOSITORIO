// Newtons Wiege, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 31.01.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jra";
var text02 = "Ind&iacute;t";
var text03 = "Goly&oacute;k sz&aacute;ma:";

var author = "W. Fendt 1997.";
var translator = "Ser&eacute;nyi T. 2004.";
