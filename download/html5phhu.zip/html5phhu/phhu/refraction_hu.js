// Reflexion und Brechung von Licht, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 04.02.2018

// Texte in HTML-Schreibweise:
    
var text01 = "1. t&ouml;r&eacute;smutat&oacute;:";
var text02 = "2. t&ouml;r&eacute;smutat&oacute;:";
var text03 = "Bees&eacute;si sz&ouml;g:";
var text04 = "Visszaver&#337;d&eacute;si sz&ouml;g:";
var text05 = "T&ouml;r&eacute;si sz&ouml;g:";    
var text06 = ["A teljes visszaver&#337;d&eacute;s", "sz&ouml;ge:"];

var author = "W. Fendt 1997.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                   

// Texte in Unicode-Schreibweise:

var text07 = [["v\u00E1kuum", "1"], ["leveg\u0151", "1.0003"],       // Stoffe und Brechungsindizes
    ["v\u00EDz", "1.33"], ["etanol", "1.36"],
    ["kvarc", "1.46"], ["benzol", "1.49"], 
    ["korona \u00FCveg N-K5", "1.52"], ["k\u0151s\u00F3", "1.54"], 
    ["flint \u00FCveg LF5", "1.58"], ["korona \u00FCveg N-SK4", "1.61"],
    ["flint \u00FCveg SF6", "1.81"], ["gy\u00E9m\u00E1nt", "2.42"],
    ["", ""]];
    
// Symbole und Einheiten: 

var symbolAngle1 = "\u03b5";                               // Symbol f�r Einfallswinkel (Epsilon)
var symbolAngle2 = "\u03b5'";                              // Symbol f�r Brechungswinkel (Epsilon Strich)
var degreeUnicode = "\u00b0";                           
