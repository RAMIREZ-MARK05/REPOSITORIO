// Stehende L�ngswellen, ungarische Texte (Ser�nyi Tam�s, unvollst�ndig)
// Letzte �nderung 02.02.2018

// Texte in HTML-Schreibweise:

var text01 = "A cs&#337; t&iacute;pusa:";
var text02 = "mindk&eacute;t v&eacute;g&eacute;n nyitott";
var text03 = "egyik v&eacute;g&eacute;n nyitott";
var text04 = "mindk&eacute;t v&eacute;g&eacute;n z&aacute;rt";
var text05 = "Rezg&eacute;si m&oacute;dus:";
var text06 = ["alap",  "1. felharmonikus",                 // Bezeichnungen der Eigenschwingungen 
              "2. felharmonikus", "3. felharmonikus", 
              "4. felharmonikus", "5. felharmonikus"];
var text07 = "Alacsonyabb";
var text08 = "Magasabb";
var text09 = "A cs&#337; hossza:";
var text10 = "Hull&aacute;mhossz:";
var text11 = "Frekvencia:";

var author = "W. Fendt 1998.,&nbsp; Ser&eacute;nyi T. 2004.";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                     
var hertz = "Hz";                                    

// Texte in Unicode-Schreibweise:

var text12 = "Displacement of particles"; // ???           // �berschrift des ersten Diagramms
var text13 = "Divergence from average pressure"; // ???    // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "Cs";                                     // Symbol f�r Knoten
var symbolAntinode = "D";                                  // Symbol f�r Bauch

