// Magnetfeld eines Stabmagneten, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 03.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Er&#337;vonalak t&ouml;rl&eacute;se";
var text02 = "Ford&iacute;t";

var author = "W. Fendt 2001.";
var translator = "Ser&eacute;nyi T. 2004.";
