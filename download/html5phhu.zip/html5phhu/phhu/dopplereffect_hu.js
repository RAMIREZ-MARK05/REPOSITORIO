// Beispiel zum Doppler-Effekt, ungarische Texte (Ser�nyi Tam�s)
// Letzte �nderung 02.02.2018

// Texte in HTML-Schreibweise:

var text01 = "&Uacute;jraind&iacute;t&aacute;s";
var text02 = ["Sz&uuml;net", "Tov&aacute;bb"]; 

var author = "W. Fendt 1998.";
var translator = "Ser&eacute;nyi T. 2004.";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                             // Erl�uterungstext
  ["Am\u00EDg a ment\u0151aut\u00F3 k\u00F6zeledik",
   "a j\u00E1r\u00F3kel\u0151h\u00F6z, a hozz\u00E1",
   "\u00E9rkez\u0151 hull\u00E1mfrontok s\u0171r\u0171bben",
   "k\u00F6vetik egym\u00E1st."],
  ["Amint a ment\u0151aut\u00F3 elhagyja",
   "a gyalogost, a hull\u00E1mfrontok",
   "ritk\u00E1bban \u00E9rkeznek hozz\u00E1."]];


  

