// Rutherford-Streuung, englische Texte
// Letzte �nderung 16.06.2020

// Texte in HTML-Schreibweise:

var text01 = "Clear trajectories";                    
var text02 = "Start";          
var text03 = "Scattering nucleus:";
var text04 = "Atomic number:";
var text05 = "Alpha particle:";
var text06 = "Velocity:";
var text07 = "Impact parameter:";
var text08 = "Deflection angle:";
var text09 = "Minimal distance:";
var text10 = "Asymptotes, impact parameter";
var text11 = "Asymptotes, deflection angle";


var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var femtometer = "fm";
var kilometerPerSecond = "km/s";
var degree = "\u00B0";




