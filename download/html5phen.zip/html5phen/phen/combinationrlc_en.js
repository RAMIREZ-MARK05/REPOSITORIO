// Kombinationen von Widerst�nden, Spulen und Kondensatoren, englische Texte
// Letzte �nderung 21.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Voltage source:";
var text02 = "Voltage:";
var text03 = "Frequency:";
var text04 = "Component:";
var text05 = ["Resistor", "Inductor", "Capacitor"];
var text06 = ["Resistance:", "Inductivity:", "Capacity:"];
var text07 = "Replace";
var text08 = "Add (in series)";
var text09 = "Add (in parallel)";
var text10 = "Remove";
var text11 = "Meters:";
var text12 = "Voltage";
var text13 = "Amperage";

var author = "W. Fendt 2004";
var translator = "";

// Texte in Unicode-Schreibweise:

var text14 = "Voltage:";
var text15 = "Amperage:";
var text16 = "Complex impedance:";
var text17 = "Impedance:";
var text18 = "Phase angle:";
var text19 = "very small";                                 // Stromst�rke Voltmeter
var text20 = "very small";                                 // Spannung Amperemeter
var text21 = "very small";                                 // Impedanz/Widerstand Amperemeter
var text22 = "very large";                                 // Impedanz/Widerstand Voltmeter

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)