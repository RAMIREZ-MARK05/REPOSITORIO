// Wheatstonesche Br�ckenschaltung, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "New measurement";
var text02 = "Comparable resistor:";
var text03 = "Sliding resistor:";
var text04 = "Position of the sliding contact:";
var text05 = "Voltage of the power supply:";
var text06 = "Resistance of the meter:";
var text07 = "Calculate resistance";
var text08 = "Indicate voltage";
var text09 = "Indicate amperage";
var author = "W. Fendt 2006";

// Texte in Unicode-Schreibweise:

var text10 = ["Move the sliding contact",
  	          "until the amperage is zero!"];
var text11 = "Now the resistance can be calculated.";         

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var milliampere = "mA";
var ohm = "\u03A9";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00D7";                              
