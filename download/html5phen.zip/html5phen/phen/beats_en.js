// Schwebungen, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pause", "Resume"];
var text03 = "Slow motion";
var text04 = "Frequencies:";
var text05 = "1st wave:";
var text06 = "2nd wave:";

var author = "W. Fendt 2001"; 
var translator = "";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



