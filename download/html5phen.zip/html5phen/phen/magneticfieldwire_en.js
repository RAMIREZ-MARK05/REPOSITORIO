// Magnetfeld eines geraden stromdurchflossenen Leiters, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reverse current";

var author = "W. Fendt 2000";
var translator = "";
