// Kettenkarussell, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Carousel";
var text02 = "Carousel with forces";
var text03 = "Sketch";
var text04 = "Numerical values";
var text05 = ["Pause", "Resume"];
var text06 = "Slow motion";
var text07 = "Period:";
var text08 = ["Distance between suspensions", "and axis of rotation:"]; 
var text09 = "Length of the strings:";
var text10 = "Mass:";

var author = "W. Fendt 1999";

// Texte in Unicode-Schreibweise:

var text11 = "Frequency:";
var text12 = "Angular velocity:";
var text13 = "Radius:";
var text14 = "Velocity:";
var text15 = "Angle:";
var text16 = "Weight:";
var text17 = "Centripetal force:";
var text18 = "Tension in the string:";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";




