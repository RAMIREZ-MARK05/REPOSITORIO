// Bilderzeugung Sammellinse, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:
    
var text01 = "Focal length:";
var text02 = "Object distance:";
var text03 = "Object height:";
var text04 = "Image distance:";
var text05 = "Image height:";    
var text06 = "Kind of image:"
var text07 = ["real", "virtual"];
var text08 = ["inverted", "upright"];
var text09 = ["reduced", "equal dimension", "magnified", "infinitely magnified"];
var text10 = "Principal light rays";
var text11 = "Bundle of light rays";
var text12 = "Emphasize:";

var author = "W. Fendt 2008";

// Symbole und Einheiten:

var centimeter = "cm";
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text13 = ["object", 
              "object distance", 
              "object height",
              "lens", 
              "lens plane", 
              "optical axis",
              "focal points", 
              "focal length", 
              "image", 
              "image distance", 
              "image height",
              "screen"];
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "o";
var symbolGG = "O"; 
var symbolB = "i";
var symbolBB = "I";


