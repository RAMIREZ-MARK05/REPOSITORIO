// Elastischer und unelastischer Sto�, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Elastic collision";
var text02 = "Ineleastic collision";
var text03 = "Reset";
var text04 = "Start";
var text05 = "Slow motion";
var text06 = "Wagon 1:";
var text07 = "Wagon 2:";
var text08 = "Mass:";
var text09 = "Velocity:";
var text10 = "Velocity";
var text11 = "Momentum";
var text12 = "Kinetic energy";

var author = "W. Fendt 1998";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                                // Abk�rzung f�r Meter pro Sekunde

// Texte in Unicode-Schreibweise:

var text13 = "Wagon 1:";
var text14 = "Wagon 2:";
var text15 = "Velocities before the collision:";
var text16 = "Velocities after the collision:";
var text17 = "Momenta before the collision:";
var text18 = "Momenta after the collision:";
var text19 = "Kinetic energy before the collision:";
var text20 = "Kinetic energy after the collision:";
var text21 = "Total momentum:";
var text22 = "Total kinetic energy:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                         // Abk�rzung f�r Meter pro Sekunde
var kilogramMeterPerSecond = "kg m/s";                     // Abk�rzung f�r Kilogramm mal Meter pro Sekunde
var joule = "J";                                           // Abk�rzung f�r Joule
