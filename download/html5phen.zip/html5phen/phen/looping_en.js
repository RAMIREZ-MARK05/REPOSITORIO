// Loopingbahn, englische Texte
// Letzte �nderung 09.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pause", "Resume"];
var text03 = "Slow motion (5 &times;)";
var text04 = "Slow motion (50 &times;)";
var text05 = "Radius:";
var text06 = "Initial height:";
var text07 = "Gravitational acceleration:";
var text08 = "Mass:";
var text09 = "Velocity";
var text10 = "Weight, contact force";
var text11 = "Tangential force, radial force";
var text12 = "Total force";

var author = "W. Fendt 2020";                              // Autor
var translator = "";                                       // �bersetzer

// Texte in Unicode-Schreibweise:

var text13 = "Velocity:";
var text14 = "Weight:";
var text15 = "Contact force:";
var text16 = "Tangential force:";
var text17 = "Radial force:";
var text18 = "Total force:";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

var second = "s";                               
var meter = "m";                                 
var meterPerSecond = "m/s";                        
var meterPerSecond2 = "m/s\u00b2";         
var kilogram = "kg";
var newton = "N";    


