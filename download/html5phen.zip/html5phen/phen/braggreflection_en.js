// Schwebungen, englische Texte
// Letzte �nderung 13.03.2021

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pause", "Resume"];
var text03 = "Slow motion";
var text04 = "Interplanar distance:";
var text05 = "Wavelength:";
var text06 = "Glancing angle:";
var text07 = "Number of lattice planes:";
var text08 = "Path difference:";

var author = "W. Fendt 2021";
var translator = "";

// Text in Unicode-Schreibweise:

var text09 = "Bragg condition fulfilled!";

// Einheiten und Symbole:

var decimalSeparator = ".";
var picometer = "pm";
var degree = "\u00B0";
var symbolDeltaS = "\u0394s";
var symbolLambda = "\u03BB";