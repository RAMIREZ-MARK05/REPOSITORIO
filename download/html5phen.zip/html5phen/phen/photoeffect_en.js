// Photoelektrischer Effekt, englische Texte
// Letzte �nderung 12.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Cathode material:";
var text02 = ["cesium", "sodium"];
var text03 = "Spectral line (Hg):";
var text04 = "Retarding voltage:";
var text05 = "Frequency:";
var text06 = ["Energy of a", "photon:"];
var text07 = "Work function:";
var text08 = ["Maximal kinetic energy", "of an electron:"];
var text09 = "Clear measurements";

var author = "W. Fendt 2000";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                            // Volt
var terahertz = "THz";                                     // Terahertz
var electronvolt = "eV";                                   // Elektronenvolt

// Texte in Unicode-Schreibweise:

var text10 = ["yellow", "green", "violet", "ultraviolet", "ultraviolet"];
var text11 = "(in THz)";
var text12 = "(in V)";
var text13 = [
             ["The energy of a photon is not enough for the emission", "of an electron."],
             ["Increase the retarding voltage so much that no more", "electrons reach the anode!"],
             ["The retarding voltage is so big that the electrons", "return to the cathode."],
             ["Go ahead with a new measurement for another", "spectral line!"],
             ["Go ahead with a new series of measurements for", "another cathode material!"],
             ["The measurements are finished."]
             ];

var symbolCathode = "C";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
