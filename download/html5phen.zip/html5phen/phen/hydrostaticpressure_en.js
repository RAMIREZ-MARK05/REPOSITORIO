// Druckdose (hydrostatischer Druck), englische Texte
// Letzte �nderung 02.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Liquid:";
var text03 = "Density:";
var text04 = "Depth:";
var text05 = "Hydrostatic pressure:";

var author = "W. Fendt 1999";                              // Autor
var translator = "";                                       // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["unknown", "water", "ethanol", "benzene", "tetrachloromethane", "mercury"]; 
