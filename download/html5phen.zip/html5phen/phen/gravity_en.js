// Gravitation, englische Texte
// Letzte �nderung 29.12.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";                    
var text02 = ["Start", "Pause", "Resume"];
var text03 = "Slow motion";
var text04 = "Distance:";
var text05 = "Mass 1:";
var text06 = "Velocity 1:";
var text07 = "Mass 2:";
var text08 = "Velocity 2:";

var text09 = "Circular orbit";
var text10 = "Parabolic trajectory";

var author = "W. Fendt 2020";                              // Autor (und �bersetzer)

// Texte in Unicode-Schreibweise:

var textSelect = ["",
              "Orbit data",
              "Position",
              "Distance",
              "Velocity",
              "Acceleration",
              "Force",
              "Energy",
              "Angular momentum",
              "Orbital period"];
              
var text11 = "Type of orbit:";
var text12 = ["line",
              "ellipse", 
              "circle (ellipse)", 
              "ellipse", 
              "parabola", 
              "hyperbola"];
var text13 = ["Semi-major axes:",
              "Radii:",
              "Semi-major axes:",
              "Semi-latus rectum:",
              "Transverse semi-axes:"];
var text14 = "Eccentricity:";

var text21 = "Angles of position:";
var text22 = "Coordinates:";

var text31 = "Distance:";

var text41 = "Magnitudes of velocity:";
var text42 = "Components of velocity:";

var text51 = "Magnitudes of acceleration:";
var text52 = "Components of acceleration:";

var text61 = "Magnitudes of force:";
var text62 = "Components of force:";

var text71 = "Total energy:";
var text72 = "Potential energy:";
var text73 = "Kinetic energy:";

var text81 = "Total angular momentum:";
var text82 = "Single angular momenta:";

var text91 = "Period:";

var text101 = "Time:";
var text102 = "Minimum:";
var text103 = "Maximum:";
var text104 = "Minima:";
var text105 = "Maxima:";

var undef = "undefined";
var inf = "infinite";
var body1 = "body 1";
var body2 = "body 2";

// Symbole und Einheiten (Unicode-Schreibweise):

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var power10 = "\u00D7 10";                                 // Mal 10 hoch
var kilogram = "kg";
var second = "s";
var minute = "min";
var hour = "h";
var day = "d";
var year = "a";
var meter = "m";
var meterPerSecond = "m/s";
var meterPerSecond2 = "m/s\u00B2";
var newton = "N";
var joule = "J";
var kilogramMeter2PerSecond = "kg m\u00B2 / s";
var degree = "\u00B0";

var symbolAE1 = "a_E1";                                    // Gro�e Halbachse (Ellipse) f�r K�rper 1
var symbolAE2 = "a_E2";                                    // Gro�e Halbachse (Ellipse) f�r K�rper 2
var symbolAH1 = "a_H1";                                    // Reelle Halbachse (Hyperbel) f�r K�rper 1
var symbolAH2 = "a_H2";                                    // Reelle Halbachse (Hyperbel) f�r K�rper 2
var symbolR1 = "r_1";                                      // Radius (Kreis) f�r K�rper 1
var symbolR2 = "r_2";                                      // Radius (Kreis) f�r K�rper 2
var symbolHP1 = "p_1";                                     // Halbparameter (Parabel) f�r K�rper 1
var symbolHP2 = "p_2";                                     // Halbparameter (Parabel) f�r K�rper 2
var symbolEpsilon = "\u03B5";                              // Numerische Exzentrizit�t
var symbolTime = "t";                                      // Aktuelle Zeit
var symbolPhi1 = "\u03C6_1";                               // Positionswinkel von K�rper 1
var symbolPhi2 = "\u03C6_2";                               // Positionswinkel von K�rper 2

var symbolX1 = "x_1";                                      // x-Koordinate von K�rper 1
var symbolY1 = "y_1";                                      // y-Koordinate von K�rper 1
var symbolX2 = "x_2";                                      // x-Koordinate von K�rper 2
var symbolY2 = "y_2";                                      // y-Koordinate von K�rper 2

var symbolD = "d";                                         // Abstand
var symbolDMin = "d_min";                                  // Minimaler Abstand
var symbolDMax = "d_max";                                  // Maximaler Abstand

var symbolV1 = "v_1";                                      // Geschwindigkeit von K�rper 1
var symbolV2 = "v_2";                                      // Geschwindigkeit von K�rper 2
var symbolV1Min = "v_1 min";                               // Minimale Geschwindigkeit von K�rper 1 
var symbolV2Min = "v_2 min";                               // Minimale Geschwindigkeit von K�rper 2
var symbolV1Max = "v_1 max";                               // Maximale Geschwindigkeit von K�rper 1
var symbolV2Max = "v_2 max";                               // Maximale Geschwindigkeit von K�rper 2
var symbolV1x = "v_1x";                                    // Geschwindigkeit von K�rper 1 in x-Richtung
var symbolV1y = "v_1y";                                    // Geschwindigkeit von K�rper 1 in y-Richtung
var symbolV2x = "v_2x";                                    // Geschwindigkeit von K�rper 2 in x-Richtung
var symbolV2y = "v_2y";                                    // Geschwindigkeit von K�rper 2 in y-Richtung

var symbolA1 = "a_1";                                      // Beschleunigung von K�rper 1
var symbolA2 = "a_2";                                      // Beschleunigung von K�rper 2
var symbolA1Min = "a_1 min";                               // Minimale Beschleunigung von K�rper 1
var symbolA2Min = "a_2 min";                               // Minimale Beschleunigung von K�rper 2 
var symbolA1Max = "a_1 max";                               // Maximale Beschleunigung von K�rper 1
var symbolA2Max = "a_2 max";                               // Maximale Beschleunigung von K�rper 1 
var symbolA1Tang = "a_1 tang";                             // Tangentiale Beschleunigung von K�rper 1
var symbolA1Rad = "a_1 rad";                               // Radiale Beschleunigung von K�rper 1
var symbolA2Tang = "a_2 tang";                             // Tangentiale Beschleunigung von K�rper 2
var symbolA2Rad = "a_2 rad";                               // Radiale Beschleunigung von K�rper 2

var symbolF1 = "F_1";                                      // Kraft auf K�rper 1
var symbolF2 = "F_2";                                      // Kraft auf K�rper 2
var symbolFMin = "F_min";                                  // Minimale Kraft
var symbolFMax = "F_max";                                  // Maximale Kraft
var symbolF1Tang = "F_1 tang";                             // Tangentiale Kraft auf K�rper 1
var symbolF1Rad = "F_1 rad";                               // Radiale Kraft auf K�rper 1
var symbolF2Tang = "F_2 tang";                             // Tangentiale Kraft auf K�rper 2
var symbolF2Rad = "F_2 rad";                               // Radiale Kraft auf K�rper 2

var symbolEnergy = "E";                                    // Gesamtenergie
var symbolEnergyPot = "E_pot";                             // Potentielle Energie
var symbolEnergy1Kin = "E_1 kin";                          // Kinetische Energie von K�rper 1
var symbolEnergy2Kin = "E_2 kin";                          // Kinetische Energie von K�rper 2

var symbolAngMom = "L";                                    // Gesamtdrehimpuls
var symbolAngMom1 = "L_1";                                 // Drehimpuls von K�rper 1
var symbolAngMom2 = "L_2";                                 // Drehimpuls von K�rper 2

var symbolPeriod = "T";                                    // Umlaufdauer






