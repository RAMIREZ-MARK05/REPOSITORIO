// Beispiel zur Zeitdilatation, englische Texte (Prof. Taha Mzoughi)
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Reduce speed";
var text02 = "Increase speed";
var text03 = "Reset";
var text04 = ["Start", "Pause", "Resume"];

var author = "W. Fendt 1997,&nbsp; T. Mzoughi 1998";

var decimalSeparator = ".";

// Texte in Unicode-Schreibweise:

var text05 = "Distance:";
var text06 = "5 light hours";
var text07 = "Speed:";
var text08 = "Flying time (earth system):";
var text09 = "hours";
var text10 = "Flying time (spaceship system):";