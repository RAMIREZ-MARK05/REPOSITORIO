// Kepler-Fernrohr, englische Texte
// Letzte �nderung 08.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Focal lengths:"; 
var text02 = "Objective:";
var text03 = "Eyepiece:";
var text04 = "Angles:";
var text05 = "Magnification:";

var author = "W. Fendt 2000";
var translator = "";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite

