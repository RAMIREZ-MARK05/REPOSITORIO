// Gleichgewicht dreier Kr�fte, englische Texte
// Letzte �nderung 07.12.2017

// Texte in HTML-Schreibweise:

var text01 = "Forces:";
var text02 = "Left:";
var text03 = "Right:";
var text04 = "Below:";
var text05 = "Parallelogram of forces";
var text06 = "Angles:";
var text07 = "Left:";
var text08 = "Right:";

var author = "W. Fendt 2000";
var translator = "";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Punkt)
var degree = "\u00b0";                                     // Symbol f�r Grad
var newton = "N";                                          // Abk�rzung f�r Newton
