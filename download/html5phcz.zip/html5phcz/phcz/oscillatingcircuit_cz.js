// Elektromagnetischer Schwingkreis, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "Pokra&ccaron;ovat"];
var text03 = "Zpomalen&ecaron; (10 &times;)";
var text04 = "Zpomalen&ecaron; (100 &times;)";
var text05 = "Kapacita:";                                  // Kapazit�t
var text06 = "Induk&ccaron;nost:";                         // Induktivit�t
var text07 = "Odpor:";                                     // Widerstand
var text08 = "Max. nap&ecaron;t&iacute;:";                 // Maximale Spannung
var text09 = "Nap\u0115t&iacute;, proud";                  // Spannung, Stromst�rke
var text10 = "Energie";

var author = "W. Fendt 1999,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)       
var microfarad = "&mu;F";                              
var henry = "H";                                        
var ohm = "&Omega;";                                    
var volt = "V";                                         

// Texte in Unicode-Schreibweise:

var text11 = "Perioda:";                                   // Schwingungsdauer
var text12 = "Elektrick\u00E1 energie:";                   // Elektrische Energie
var text13 = "Magnetick\u00E1 energie:";                   // Magnetische Energie
var text14 = "Vnit\u0159n\u00ED energie:";                 // Innere Energie
var text15 = "Netlumen\u00E9 oscilace";                    // Unged�mpfte Schwingung
var text16 = "Tlumen\u00E9 oscilace";                      // Ged�mpfte Schwingung
var text17 = "Mezn\u00ED tlumen\u00ED";                    // Aperiodischer Grenzfall
var text18 = "P\u0159etlumen\u00FD p\u0159\u00EDpad";      // Kriechfall

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
var second = "s";                                      
var voltUnicode = "V";                                  
var ampere = "A";                                       
var joule = "J";                                         
