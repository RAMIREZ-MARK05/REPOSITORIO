// Federpendel, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Zastavit", "D&aacute;le"];         // Start/Pause/Weiter 
var text03 = "Zpomalen&ecaron;";                           // Zeitlupe
var text04 = "Tuhost pru&zcaron;iny:";                     // Federkonstante
var text05 = "Hmotnost:";                                  // Masse
var text06 = "T&iacute;hov&eacute; zrychlen&iacute;:";     // Fallbeschleunigung
var text07 = "Amplituda:";                                 // Amplitude
var text08 = "V&yacute;chylka";                            // Elongation
var text09 = "Rychlost";                                   // Geschwindigkeit
var text10 = "Zrychlen&iacute;";                           // Beschleunigung
var text11 = "S&iacute;la";                                // Kraft
var text12 = "Energie";

var author = "W. Fendt 1998,&nbsp; M. Pano&scaron; 2005";   
             

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var newtonPerMeter = "N/m";                      
var kilogram = "kg";                              
var meterPerSecond2 = "m/s&sup2;";                
var meter = "m";                                  

// Texte in Unicode-Schreibweise:

var text13 = "Maximum";
var text14 = "Okam\u017Eit\u00E1 v\u00FDchylka";           // Momentane Elongation
var text15 = "Rychlost";                                   // Geschwindigkeit
var text16 = "Zrychlen\u00ED";                             // Beschleunigung
var text17 = "S\u00EDla";                                  // Kraft
var text18 = "Potenci\u00E1ln\u00ED energie";              // Potentielle Energie
var text19 = "Kinetick\u00E1 energie";                     // Kinetische Energie
var text20 = "Celkov\u00E1 energie";                       // Gesamtenergie
var text21 = "(s)";
var text22 = "(m)";
var text23 = "(m/s)";
var text24 = "(m/s\u00b2)";
var text25 = "(N)";
var text26 = "(J)";
var text27 = "Perioda";                                    // Schwingungsdauer

// Symbole und Einheiten: 

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "p";                                 // Symbol f�r potentiell
var symbolKinetic = "k";                                   // Symbol f�r kinetisch
var second = "s";                                
var meterUnicode = "m";                          
var meterPerSecond = "m/s";                      
var meterPerSecond2Unicode = "m/s\u00b2";         
var newton = "N";                                 
var joule = "J";                                  

