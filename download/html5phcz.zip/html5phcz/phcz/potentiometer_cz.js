// Potentiometerschaltung, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Nap&aacute;jec&iacute; nap&ecaron;t&iacute; zdroje:";
var text02 = "Prom&ecaron;nn&yacute; rezistor:";
var text03 = "Pozice jezdce rezistoru:";
var text04 = "Odpor spot&rcaron;ebi&ccaron;e:";
var text05 = "Zobrazit nap&ecaron;t&iacute;";
var text06 = "Zobrazit proudy";
var author = "W. Fendt 2006";
var translator = "M. Pano&scaron; 2009";

// Texte in Unicode-Schreibweise:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var symbolVoltage1 = "U";                                  // Symbol f�r Spannung
var symbolVoltage2 = "V";                                  // Index f�r Verbraucher
                      
