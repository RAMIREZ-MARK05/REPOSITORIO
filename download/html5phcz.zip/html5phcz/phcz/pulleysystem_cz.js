// Gew�hnlicher Flaschenzug mit gerader Rollenzahl, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "2 kladky";
var text02 = "4 kladky";
var text03 = "6 kladek";
var text04 = "T&iacute;ha n&aacute;kladu:";
var text05 = "T&iacute;ha voln&yacute;ch kladek:";
var text06 = "Pot&rcaron;ebn&aacute; s&iacute;la:";
var text07 = "silom&ecaron;r";
var text08 = "vektor s&iacute;ly";

var author = "W. Fendt 1998";
var translator = "M. Pano&scaron; 2005";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolDivision = ":";                                  // Symbol f�r Division
var symbolForce = "F";                                     // Symbol f�r Kraft
var newton = "N";                                      
