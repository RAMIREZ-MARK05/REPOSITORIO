// Rutherford-Streuung, tschechische Texte (Miroslav Panos)
// Letzte �nderung 15.06.2020

// Texte in HTML-Schreibweise:

var text01 = "Smazat trajektorie &ccaron;&aacute;stic";                    
var text02 = "Start";          
var text03 = "Rozptylov&eacute; atomov&eacute; j&aacute;dro:";
var text04 = "Atomov&eacute; &ccaron;&iacute;slo:";
var text05 = "&Ccaron;&aacute;stice alfa:";
var text06 = "Rychlost:";
var text07 = "Sr&aacute;&zcaron;kov&yacute; parametr:";
var text08 = "&Uacute;hel rozptylu:";
var text09 = "Minim&aacute;ln&iacute; vzd&aacute;lenost:";
var text10 = "Asymptoty, Sr&aacute;&zcaron;kov&yacute; parametr";
var text11 = "Asymptoty, &Uacute;hel rozptylu";


var author = "W. Fendt 2020";                              // Autor
var translator = "M. Pano&scaron; 2020";                   // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var femtometer = "fm";
var kilometerPerSecond = "km/s";
var degree = "\u00B0";




