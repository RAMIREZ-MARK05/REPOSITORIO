// Wheatstonesche Br�ckenschaltung, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Nov&eacute; m&ecaron;&rcaron;en&iacute;";
var text02 = "Zn&aacute;m&yacute; rezistor:";
var text03 = "Prom&ecaron;nn&yacute; rezistor:";
var text04 = "Pozice jezdce rezistoru:";
var text05 = "Nap&aacute;jec&iacute; nap&ecaron;t&iacute; zdroje:";
var text06 = "Odpor m&ecaron;&rcaron;. p&rcaron;&iacute;stroje:";
var text07 = "Spo&ccaron;&iacute;tej odpor";
var text08 = "Zobrazit nap&ecaron;t&iacute;";
var text09 = "Zobrazit proudy";
var author = "W. Fendt 2006,&nbsp; M. Pano&scaron; 2009";

// Texte in Unicode-Schreibweise:

var text10 = ["Posouvej jezdcem rezistoru",
  	          "dokud proud amp\u00E9rmetrem nen\u00ED nulov\u00FD!"];
var text11 = "Nyn\u00ED m\u016F\u017Ee b\u00FDt ur\u010Den odpor nezn\u00E1m\u00E9ho rezistoru.";         

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";
var milliampere = "mA";
var ohm = "\u03A9";
var symbolUnknown = "?";
var symbolResistance1 = "R";
var symbolResistance2 = "x"; 
var symbolMult = "\u00D7";                              
