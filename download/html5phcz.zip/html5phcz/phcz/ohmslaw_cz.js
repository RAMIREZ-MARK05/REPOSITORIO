// Ohmsches Gesetz, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Max. nap&ecaron;t&iacute;:";
var text02 = "Max. proud:";
var text03 = "Zv&ecaron;t&scaron;it odpor";
var text04 = "Zmen&scaron;it odpor";
var text05 = "Zv&yacute;&scaron;it nap&ecaron;t&iacute;";
var text06 = "Sn&iacute;&zcaron;it nap&ecaron;t&iacute;";

var author = "W. Fendt 1997";
var translator = "M. Pano&scaron; 2005";

// Symbole und Einheiten:

var symbolVoltage = "U";
var symbolAmperage = "I";
var symbolMilli = "m";
var volt = "V";
var ampere = "A";

// Texte in Unicode-Schreibweise:

var text07 = "P\u0159ekro\u010Den rozsah!";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var ohm = "\u03A9";
