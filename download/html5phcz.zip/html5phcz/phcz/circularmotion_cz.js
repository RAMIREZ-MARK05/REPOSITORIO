// Kreisbewegung mit konstanter Winkelgeschwindigkeit, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Zastavit", "D&aacute;le"];
var text03 = "Zpomalen&ecaron;";
var text04 = "Polom&ecaron;r:";
var text05 = "Perioda:";
var text06 = "Hmotnost:";
var text07 = "Poloha";
var text08 = "Rychlost";
var text09 = "Zrychlen&iacute;";
var text10 = "S&iacute;la";

var author = "W. Fendt 2007";
var translator = "M. Pano&scaron; 2009";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                      
var second = "s";                                      
var kilogram = "kg";                                   

// Texte in Unicode-Schreibweise:

var text11 = "Okam\u017Eit\u00E1 v\u00FDchylka:";          // Position
var text12 = "Okam\u017Eit\u00E1 rychlost:";               // Geschwindigkeit
var text13 = "\u00DAhlov\u00E1 rychlost:";                 // Winkelgeschwindigkeit
var text14 = "Dost\u0159ediv\u00E9 zrychlen\u00ED:";       // Zentripetalbeschleunigung
var text15 = "Dost\u0159ediv\u00E1 s\u00EDla:";            // Zentripetalkraft
var text16 = "(s)";
var text17 = "(m)";
var text18 = "(m/s)";
var text19 = "(m/s\u00b2)";
var text20 = "(N)";
var text21 = "(x-ov\u00E1 slo\u017Eka)";                   // x-Komponente
var text22 = "(y-ov\u00E1 slo\u017Eka)";                   // y-Komponente
var text23 = "(celkov\u00E1 velikost)";                    // Betrag

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r x-Koordinate
var symbolY = "y";                                         // Symbol f�r y-Koordinate
var symbolsXY = "x, y";                                    // Symbole f�r x- und y-Koordinate zusammen
var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAngVel = "\u03c9";                               // Symbol f�r Winkelgeschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolForce = "F";                                     // Symbol f�r Kraft
var meterUnicode = "m";                              
var meterPerSecond = "m/s";                          
var meterPerSecond2 = "m/s\u00b2";                   
var newton = "N";                                    
var radPerSecond = "rad/s";                          




