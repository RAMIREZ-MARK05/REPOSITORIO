// Magnetfeld eines Stabmagneten, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Smazat induk\u010Dn\u00ED \u010D\u00E1ry";
var text02 = "Oto\u010Dit magnet";

var author = "W. Fendt 2001";
var translator = "M. Pano\u0161 2016";
