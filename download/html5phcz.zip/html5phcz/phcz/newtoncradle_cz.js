// Newtons Wiege, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Start";
var text03 = "Po&ccaron;et vych&yacute;len&yacute;ch koul&iacute;:";

var author = "W. Fendt 1997";
var translator = "M. Pano&scaron; 2005";
