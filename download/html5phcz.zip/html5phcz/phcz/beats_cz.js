// Schwebungen, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Zastavit", "D\u00E1le"];
var text03 = "Zpomalen\u0115";
var text04 = "Frekvence:";
var text05 = "1. kmit\u00E1n\u00ED:";
var text06 = "2. kmit\u00E1n\u00ED:";

var author = "W. Fendt 2001"; 
var translator = "M. Pano&scaron; 2005";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



