// Stehende L�ngswellen, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Proveden&iacute; trubice:";                  // Rohrform
var text02 = "oba konce otev&rcaron;en&eacute;";           // beidseitig offen
var text03 = "jeden konec uzav&rcaron;en&yacute;";         // einseitig offen
var text04 = "oba konce uzav&rcaron;en&eacute;";           // beidseitig geschlossen
var text05 = "Vybra&ccaron;n&iacute; m&oacute;d:";
var text06 = ["z&aacute;kladn&iacute;",   "1. harmonick&yacute;",    // Bezeichnungen der Eigenschwingungen 
              "2. harmonick&yacute;", "3. harmonick&yacute;", 
              "4. harmonick&yacute;", "5. harmonick&yacute;"];
var text07 = "Ni&zcaron;&scaron;&iacute; m&oacute;d";      // Tiefer
var text08 = "Vy&scaron;&scaron;&iacute; m&oacute;d";      // H�her
var text09 = "D&eacute;lka trubice:";                      // Rohrl�nge
var text10 = "Vlnov&aacute; d&eacute;lka:";                // Wellenl�nge
var text11 = "Frekvence:";                                 // Frequenz

var author = "W. Fendt 1998,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                     
var hertz = "Hz";                                     

// Texte in Unicode-Schreibweise:

var text12 = "V\u00FDchylky \u010D\u00E1stic";             // �berschrift des ersten Diagramms
var text13 = "Odchylka od st\u0159edn\u00EDho tlaku";      // �berschrift des zweiten Diagramms

// Symbole:

var symbolPosition = "x";                                  // Symbol f�r Positionsvariable
var symbolDeltaX = "\u0394x";                              // Symbol f�r Auslenkung
var symbolDeltaP = "\u0394p";                              // Symbol f�r Druckunterschied 
var symbolNode = "U";                                      // Symbol f�r Knoten
var symbolAntinode = "K";                                  // Symbol f�r Bauch

