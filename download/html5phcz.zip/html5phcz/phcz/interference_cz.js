// Interferenz zweier Kreis- oder Kugelwellen, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = ["Zastavit", "D&aacute;le"];                  // Schaltknopf (Pause/Weiter)
var text02 = "Zpomalen&ecaron;";                           // Zeitlupe
var text03 = "Vz&aacute;jemn&aacute; vzd&aacute;lenost";   // Gangunterschied
var text04 = "zdroj&uring;:";
var text05 = "Vlnov&aacute; d&eacute;lka:";                // Wellenl�nge

var author = "W. Fendt 1999";
var translator = "M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                                 

// Texte in Unicode-Schreibweise:

var text06 = "Dr\u00E1hov\u00FD rozd\u00EDl:";
var text07 = "Konstruktivn\u00ED interference (maxim\u00E1ln\u00ED amplituda)";
var text08 = "Destruktivn\u00ED interference (minim\u00E1ln\u00ED amplituda)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (Lambda)
