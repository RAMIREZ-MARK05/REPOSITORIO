// Kettenkarussell, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Koloto&ccaron;";
var text02 = "Koloto&ccaron; se s&iacute;lami";
var text03 = "N&aacute;&ccaron;rtek";
var text04 = "&Ccaron;&iacute;seln&eacute; hodnoty";
var text05 = ["Zastavit", "D&aacute;le"];
var text06 = "Zpomalen&ecaron;";
var text07 = "Perioda:";
var text08 = ["Vzd&aacute;lenost &uacute;chyt&uring;", "od osy rotace:"]; 
var text09 = "D&eacute;lka z&aacute;v&ecaron;su:";
var text10 = "Hmotnost:";

var author = "W. Fendt 1999,&nbsp; M. Pano&scaron; 2016";

// Texte in Unicode-Schreibweise:

var text11 = "Frekvence:";
var text12 = "\u00DAhlov\u00E1 rychlost:";
var text13 = "Polom\u011Br:";
var text14 = "Rychlost:";
var text15 = "\u00DAhel:";
var text16 = "T\u00EDhov\u00E1 s\u00EDla:";
var text17 = "Dost\u0159ediv\u00E1 s\u00EDla:";
var text18 = "Zat\u00ED\u017Een\u00ED z\u00E1v\u011Bsu:";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var second = "s";
var meter = "m";
var kilogram = "kg";
var hertz = "Hz";
var radPerSecond = "rad/s";
var meterPerSecond = "m/s";
var degree = "\u00B0";
var newton = "N";
