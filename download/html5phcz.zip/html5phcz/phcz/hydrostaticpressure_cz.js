// Druckdose (hydrostatischer Druck), tschechische Texte 
// Letzte �nderung 27.02.2019

// Texte in HTML-Schreibweise:

var text01 = "Kapalina:";
var text03 = "Hustota:";
var text04 = "Hloubka:";
var text05 = "Hydrostatick&yacute; tlak:";

var author = "W. Fendt 1999";                              // Autor
var translator = "M. Pano&scaron; 2005";                   // �bersetzer

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var gramPerCentimeter3 = "g/cm&sup3;";
var centimeter = "cm";
var hectoPascal = "hPa";

// Texte in Unicode-Schreibweise:

var text02 = ["nezn\u00E1m\u00E1", "voda", "etanol (l\u00EDh)", "benzen", "tetrachl\u00F3r (tetrachlormethan)", "rtu\u0165"]; 
