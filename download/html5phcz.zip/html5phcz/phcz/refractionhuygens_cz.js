// Reflexion und Brechung von Lichtwellen (Huygens-Prinzip), tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Spustit znova";                              // Neustart
var text02 = "N&aacute;sleduj&iacute;c&iacute; krok";      // N�chster Schritt
var text03 = ["Zastavit", "D&aacute;le"];                  // Pause/Weiter
var text04 = "1. index lomu:";                             // 1. Brechungsindex
var text05 = "2. index lomu:";                             // 2. Brechungsindex
var text06 = "&Uacute;hel dopadu:";                        // Einfallswinkel

var author = "W. Fendt 1998";
var translator = "M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                           

// Texte in Unicode-Schreibweise:

var text07 = [

  ["Rovinn\u00E1 vlna dopad\u00E1 pod zadan\u00FDm",                 // i == 0 (step == 0, n1 != n2, eps1 > 0)
   "\u00FAhlem na rozhran\u00ED dvou prost\u0159ed\u00ED.",
   "Vln\u0115n\u00ED m\u00E1 v ka\u017ed\u00E9m z t\u0115chto",
   "prost\u0159ed\u00ED jinou rychlost \u0161\u00ED\u0159en\u00ED."],
   
  ["Rovinn\u00E1 vlna dopad\u00E1 kolmo",                            // i == 1 (step == 0, n1 != n2, eps1 == 0)
   "na rozhran\u00ED dvou prost\u0159ed\u00ED.",
   "Vln\u0115n\u00ED m\u00E1 v ka\u017ed\u00E9m z t\u0115chto",
   "prost\u0159ed\u00ED jinou rychlost \u0161\u00ED\u0159en\u00ED."],
   
  ["Po dopadu vlnoplochy se body",                                   // i == 2 (step == 1, n1 > n2)
   "na rozhran\u00ED chovaj\u00ED podle",
   "Huygensova principu. Ka\u017ed\u00FD bod",
   "se st\u00E1v\u00E1 zdrojem element\u00E1rn\u00ED",
   "kulov\u00E9 vlnoplochy vln\u0115n\u00ED.",
   "V 2. prost\u0159ed\u00ED se element\u00E1rn\u00ED",
   "vlny \u0161\u00ED\u0159\u00ED rychleji, proto\u017ee je zde",
   "index lomu men\u0161\u00ED."],
   
  ["Po dopadu vlnoplochy se body",                                   // i == 3 (step == 1, n1 < n2)
   "na rozhran\u00ED chovaj\u00ED podle",
   "Huygensova principu. Ka\u017ed\u00FD bod",
   "se st\u00E1v\u00E1 zdrojem element\u00E1rn\u00ED",
   "kulov\u00E9 vlnoplochy vln\u0115n\u00ED.",
   "V 2. prost\u0159ed\u00ED se element\u00E1rn\u00ED",
   "vlny \u0161\u00ED\u0159\u00ED pomaleji, proto\u017ee je zde",
   "index lomu v\u011Bt\u0161\u00ED."],
   
  ["Nov\u00E1 rovinn\u00E1 vlnoplocha vznikne",                      // i == 4 (step == 2, total == false, esp1 > 0)
   "superpozic\u00ED (slo\u017Een\u00EDm) v\u0161ech",
   "element\u00E1rn\u00EDch vlnoploch.",
   "V\u0161imn\u0115te si zm\u0115ny sm\u0115ru",
   "\u0161\u00ED\u0159en\u00ED vln\u0115n\u00ED p\u0159i p\u0159echodu",
   "rozhran\u00ED mezi prost\u0159ed\u00EDmi 1 a 2."], 
   
  ["Nov\u00E1 rovinn\u00E1 vlnoplocha vznikne",                      // i == 5 (step == 2, total == false, esp1 == 0)
   "superpozic\u00ED (slo\u017Een\u00EDm) v\u0161ech",
   "element\u00E1rn\u00EDch vlnoploch.",
   "V 1. prost\u0159ed\u00ED je zn\u00E1zorn\u011Bna",
  "odra\u017Een\u00E1 vlna, v 2. prost\u0159ed\u00ED",
  "naopak vlna lomen\u00E1."],
   
  ["Nov\u00E1 rovinn\u00E1 vlnoplocha vznikne",                      // i == 6 (step == 2, total == true)
   "superpozic\u00ED (slo\u017Een\u00EDm) v\u0161ech",
   "element\u00E1rn\u00EDch vlnoploch pouze",
   "v 1. prost\u0159ed\u00ED (odra\u017een\u00E1 vlna).",
   "Naopak v 2. prost\u0159ed\u00ED se vln\u0115n\u00ED",
   "d\u00E1le v\u016Fbec ne\u0161\u00ED\u0159\u00ED (doch\u00E1z\u00ED",
   "k \u00FApln\u00E9mu odrazu vln\u0115n\u00ED)."],
   
  ["Nyn\u00ED je vyzna\u010den sm\u0115r \u0161\u00ED\u0159en\u00ED vln\u0115n\u00ED",   // i == 7 (step == 3)
   "(sm\u011Br paprsk\u016F). Je to sm\u0115r kolm\u00FD",
   "na vlnoplochu."],
   
  ["Obvykle v\u0161ak nedopad\u00E1 pouze",                          // i == 8 (step == 4)
   "jedin\u00E1 vlnoplocha, ale je jich v\u00EDce."],

  ["Pokud se shoduj\u00ED indexy lomu,",                             // i == 9 (n1 == n2)
   "nic zvl\u00E1\u0161tn\u00EDho se ned\u011Bje."]];
        
var text08 = "\u00FAhel dopadu:";                                    // Einfallswinkel 
var text09 = "\u00FAhel odrazu:";                                    // Reflexionswinkel
var text10 = "\u00FAhel lomu:";                                      // Brechungswinkel
var text11 = "1. prost\u0159ed\u00ED";                               // Medium 1
var text12 = "2. prost\u0159ed\u00ED";                               // Medium 2
var text13 = ["Mezn\u00ED \u00FAhel", "\u00FApln\u00E9ho odrazu:"];  // Grenzwinkel der Totalreflexion

// Einheiten:

var degreeUnicode = "\u00b0";                              // Grad
