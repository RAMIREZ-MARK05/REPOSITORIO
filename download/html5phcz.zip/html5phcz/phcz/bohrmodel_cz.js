// Bohrsches Atommodell, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "&Ccaron;asticov&yacute; model";
var text02 = "Vlnov&yacute; model";
var text03 = "Hlavn&iacute; kvantov&eacute; &ccaron;&iacute;slo:";


var author = "W. Fendt 1999"; 
var translator = "M. Pano&scaron; 2016";                  

// Symbole in Unicode-Schreibweise:

var symbolN = "n";                                         // Hauptquantenzahl
var symbolR = "r";                                         // Bahnradius
var symbolE = "E";                                         // Gesamtenergie
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

// Einheiten:

var meter = "m";                       
var joule = "J";
var electronVolt = "eV";



