// Kepler-Fernrohr, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Ohniskov\u00E1 vzd\u00E1lenost:"; 
var text02 = "Objektiv:";
var text03 = "Okul\u00E1r:";
var text04 = "Pozorovac\u00ED \u00FAhel:";
var text05 = "Zv\u0115t\u0161en\u00ED:";

var author = "W. Fendt 2000";
var translator = "M. Pano\u0161 2016";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";   
var degree = "&deg;";             

// Texte in Unicode-Schreibweise:

var symbolFocalLength = "f";                               // Symbol f�r Brennweite
