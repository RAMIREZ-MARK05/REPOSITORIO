// Bilderzeugung Sammellinse, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.1.2018

// Texte in HTML-Schreibweise:
    
var text01 = "Ohniskov&aacute; vzd&aacute;lenost:";
var text02 = "P&rcaron;edm&ecaron;tov&aacute; vzd&aacute;l.:";
var text03 = "V&yacute;&scaron;ka p&rcaron;edm&ecaron;tu:";
var text04 = "Obrazov&aacute; vzd&aacute;lenost:";
var text05 = "V&yacute;&scaron;ka obrazu:";    
var text06 = "Vlastnosti obrazu:"
var text07 = ["skute&ccaron;n&yacute;", "zd&aacute;nliv&yacute;"];
var text08 = ["p&rcaron;evr&aacute;cen&yacute;", "p&rcaron;&iacute;m&yacute;"];
var text09 = ["zmen&scaron;en&yacute;", "stejn&ecaron; velik&yacute;", "zv&ecaron;t&scaron;en&yacute;", "nekone&ccaron;n&ecaron; zv&ecaron;t&scaron;en&yacute;"];
var text10 = "V&yacute;znamn&eacute; paprsky";
var text11 = "Sv&ecaron;teln&yacute; svazek";
var text12 = "Zv&yacute;raznit:";

var author = "W. Fendt 2008,&nbsp; M. Pano&scaron; 2016";

// Symbole und Einheiten:

var centimeter = "cm";
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text13 = ["P\u0159edm\u011Bt", 
              "P\u0159edm\u011Btov\u00E1 vzd\u00E1lenost", 
              "V\u00FD\u0161ka p\u0159edm\u011Btu",
              "\u010Co\u010Dka", 
              "Rovina \u010Do\u010Dky", 
              "Optick\u00E1 osa",
              "Ohniska", 
              "Ohniskov\u00E9 vzd\u00E1lenosti", 
              "Obraz", 
              "Obrazov\u00E1 vzd\u00E1lenost", 
              "V\u00FD\u0161ka obrazu",
              "Matnice"];
              
// Symbole und Einheiten:

var symbolF = "f";
var symbolG = "a";
var symbolGG = "y"; 
var symbolB = "a'";
var symbolBB = "y'";


