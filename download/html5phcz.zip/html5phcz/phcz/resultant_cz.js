// Ersatzkraft mehrerer Kr�fte, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.1.2018

// Texte in HTML-Schreibweise:

var text01 = "Po&ccaron;et p&uring;sob&iacute;c&iacute;ch sil:";
var text02 = "Ur&ccaron;it v&yacute;slednici";
var text03 = "Smazat konstrukci";

var author = "W. Fendt 1998";
var translator = "M. Pano&scaron; 2005";
