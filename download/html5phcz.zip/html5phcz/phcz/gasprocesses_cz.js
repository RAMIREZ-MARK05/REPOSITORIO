// Spezielle Prozesse eines idealen Gases, tschechische Texte (Miroslav Panos)
// Letzte �nderung 24.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Izobarick&yacute; d&ecaron;j";
var text02 = "Izochorick&yacute; d&ecaron;j";
var text03 = "Izotermick&yacute; d&ecaron;j";
var text04 = "Po&ccaron;&aacute;te&ccaron;n&iacute; stav:";
var text05 = "Tlak:";
var text06 = "Objem:";
var text07 = "Teplota:";
var text08 = "Koncov&yacute; stav:";
var text09 = "Po&ccaron;&aacute;te&ccaron;n&iacute; stav";
var text10 = "Start";

var author = "W. Fendt 1999,&nbsp; M. Pano&scaron; 2020";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:

var text11 = "Pr\u00E1ce";
var text12 = "Teplo";
var text13 = "Vnit\u0159n\u00ED energie plynu";
var text14 = "vzr\u016Fst\u00E1.";
var text15 = "Vnit\u0159n\u00ED energie plynu";
var text16 = "je stejn\u00E1.";
var text17 = "Vnit\u0159n\u00ED energie plynu";
var text18 = "kles\u00E1.";
var text19 = "P\u0159\u00EDli\u0161 n\u00EDzk\u00FD tlak!";
var text20 = "P\u0159\u00EDli\u0161 vysok\u00FD tlak!";
var text21 = "P\u0159\u00EDli\u0161 mal\u00FD objem!";
var text22 = "P\u0159\u00EDli\u0161 velk\u00FD objem!";
var text23 = "P\u0159\u00EDli\u0161 n\u00EDzk\u00E1 teplota!";
var text24 = "P\u0159\u00EDli\u0161 vysok\u00E1 teplota!";

// Symbole und Einheiten:

var symbolPressure = "p";
var symbolVolume = "V";
var symbolTemperature = "T";
var kiloPascal = "kPa";
var decimeter3 = "dm\u00B3";
var kelvin = "K";


