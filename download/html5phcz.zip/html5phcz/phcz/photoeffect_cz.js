// Photoelektrischer Effekt, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Materi&aacute;l katody:";
var text03 = "Spektr&aacute;ln&iacute; &ccaron;&aacute;ra (Hg):";
var text04 = "Brzdn&eacute; nap&ecaron;t&iacute;:";
var text05 = "Frekvence:";
var text06 = ["Energie jednoho", "fotonu:"];
var text07 = "V&yacute;stupn&iacute; pr&aacute;ce:";
var text08 = ["Maxim&aacute;ln&iacute; kinetick&aacute; energie", "jednoho elektronu:"];
var text09 = "Vymazat v&yacute;sledky m&ecaron;&rcaron;en&iacute;";

var author = "W. Fendt 2000,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var volt = "V";                                       
var terahertz = "THz";                                 
var electronvolt = "eV";                               

// Texte in Unicode-Schreibweise:

var text02 = ["cesium", "sod\u00EDk"];
var text10 = ["\u017Elut\u00E1", "zelen\u00E1", "fialov\u00E1", "ultrafialov\u00E1", "ultrafialov\u00E1"];
var text11 = "(THz)";
var text12 = "(V)";
var text13 = [
             ["Energie foton\u016F nen\u00ED dosta\u010Duj\u00EDc\u00ED", "pro uvoln\u011Bn\u00ED elektron\u016F."],
             ["Zvy\u0161ujte brzdn\u00E9 nap\u011Bt\u00ED, a\u017E p\u0159estanou", "elektrony dopadat na anodu."], 
             ["Brzdn\u00E9 nap\u011Bt\u00ED je tak velk\u00E9, \u017Ee se", "elektrony vracej\u00ED na katodu."],
             ["Prove\u010Fte dal\u0161\u00ED m\u011B\u0159en\u00ED pro jinou", "spektr\u00E1ln\u00ED \u010D\u00E1ru."],
             ["Prove\u010Fte dal\u0161\u00ED m\u011B\u0159en\u00ED pro jin\u00FD", "materi\u00E1l katody."],
             ["M\u011B\u0159en\u00ED bylo dokon\u010Deno.", ""]
             ];

var symbolCathode = "K";                           
var symbolAnode = "A";
var symbolFrequency = "f";
var symbolVoltage = "U";
