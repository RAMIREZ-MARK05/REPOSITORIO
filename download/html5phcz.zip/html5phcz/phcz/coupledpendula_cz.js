// Gekoppelte Pendel, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";                           
var text02 = ["Start", "Zastavit", "D&aacute;le"];                
var text03 = "Zpomalen&ecaron;";                           // Zeitlupe
var text04 = "Po&ccaron;&aacute;te&ccaron;n&iacute; pozice:";  // Anfangspositionen

var author = "W. Fendt 1998";
var translator = "M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                  

// Texte in Unicode-Schreibweise:

var text05 = "Kyvadlo 1";                                  // Erstes Pendel (links)
var text06 = "Kyvadlo 2";                                  // Zweites Pendel (rechts)

// Symbole:

var symbolTime = "t";                                      // Symbol f�r Zeit
