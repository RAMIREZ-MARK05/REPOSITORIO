// Kombinationen von Widerst�nden, tschechische Texte (Miroslav Panos)
// Letzte �nderung 24.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = "Nap&ecaron;t&iacute; baterie:";
var text03 = "Odpor:";
var text04 = "P&rcaron;ipojit (s&eacute;riov&ecaron;)";
var text05 = "P&rcaron;ipojit (paraleln&ecaron;)";
var text06 = "M&ecaron;&rcaron;ic&iacute; p&rcaron;&iacute;stroje:";
var text07 = "Voltmetr";
var text08 = "Amp&eacute;rmetr";

var author = "W. Fendt 2002";
var translator = "M. Pano&scaron; 2020";

// Texte in Unicode-Schreibweise:

var text09 = "Nap\u011Bt\u00ED:";
var text10 = "El. proud:";
var text11 = "Odpor:";
var text12 = "Celkov\u00FD odpor:";
var text13 = "je p\u0159\u00EDli\u0161 mal\u00FD";
var text14 = "je p\u0159\u00EDli\u0161 velk\u00FD";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMult = "\u00B7";                                 // Multiplikationszeichen
