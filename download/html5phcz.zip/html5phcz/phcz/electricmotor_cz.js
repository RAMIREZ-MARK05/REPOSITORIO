// Gleichstrom-Elektromotor, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise;

var text01 = "Reset";
var text02 = ["Start", "Zastavit", "D&aacute;le"];             
var text03 = "Opa&ccaron;n&yacute; proud";                 // Umpolen
var text04 = "Sm&ecaron;r proudu";                         // Stromrichtung
var text05 = "Magnetick&eacute; pole";                     // Magnetfeld
var text06 = "Lorentzova s&iacute;la";                     // Lorentzkraft

var author = "W. Fendt 1997";               
var translator = "M. Pano&scaron; 2005";                                       

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "ot./min";                        // Umdrehungen pro Minute
