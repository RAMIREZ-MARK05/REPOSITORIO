// Looping, deutsche Texte, tschechische Texte (Miroslav Panos)
// Letzte �nderung 24.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "D&aacute;le"];
var text03 = "Zpomaln&ecaron; (5&times;)";
var text04 = "Zpomaln&ecaron; (50&times;)";
var text05 = "Polom&ecaron;r:";
var text06 = "Po&ccaron;&aacute;te&ccaron;n&iacute; v&yacute;&scaron;ka:";
// Falls n�tig, Variable text06x f�r zus�tzliche Zeile!
var text07 = "T&iacute;hov&eacute; zrychlen&iacute;:";
var text08 = "Hmotnost:";
var text09 = "Rychlost";
var text10 = "T&iacute;hov&aacute; s&iacute;la, S&iacute;la od podlo&zcaron;ky";
var text11 = "Te&ccaron;n&aacute; s&iacute;la, Dost&rcaron;ediv&aacute; s&iacute;la";
var text12 = "V&yacute;slednice sil";

var author = "W. Fendt 2020";                              // Autor
var translator = "M. Pano&scaron; 2020";                                       // �bersetzer

// Texte in Unicode-Schreibweise:

var text13 = "Rychlost:";
var text14 = "T\u00EDhov\u00E1 s\u00EDla:";
var text15 = "S\u00EDla od podlo\u017Eky:";
var text16 = "Te\u010Dn\u00E1 s\u00EDla:";
var text17 = "Dost\u0159ediv\u00E1 s\u00EDla:";
var text18 = "V\u00FDslednice sil:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var second = "s";                               
var meter = "m";                                 
var meterPerSecond = "m/s";                        
var meterPerSecond2 = "m/s\u00b2";         
var kilogram = "kg";
var newton = "N";    


