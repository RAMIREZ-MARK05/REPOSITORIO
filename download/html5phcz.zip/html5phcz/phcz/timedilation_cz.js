// Beispiel zur Zeitdilatation, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Sn&iacute;&zcaron;it rychlost";              // Geschwindigkeit vermindern
var text02 = "Zv&yacute;&scaron;it rychlost";              // Geschwindigkeit vergr��ern
var text03 = "Reset";
var text04 = ["Start", "Pauza", "Pokra&ccaron;ovat"];

var author = "W. Fendt 1997,&nbsp; M. Pano&scaron; 2005";

var decimalSeparator = ",";

// Texte in Unicode-Schreibweise:

var text05 = "Vzd\u00E1lenost:";                           // Flugstrecke
var text06 = "5 sv. hodin";                                // 5 Lichtstunden
var text07 = "Rychlost:";                                  // Geschwindigkeit
var text08 = "Doba letu (na Zemi):";                       // Flugdauer (Erd-System)
var text09 = "hod.";                                       // Stunden
var text10 = "Doba letu (v raket\u0115):";                 // Flugdauer (Raketen-System)