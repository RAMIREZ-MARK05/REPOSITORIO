// Elastischer und unelastischer Sto�, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Pru&#382;n&aacute; sr&aacute;&#382;ka";
var text02 = "Nepru&#382;n&aacute; sr&aacute;&#382;ka";
var text03 = "Reset";
var text04 = "Start";
var text05 = "Zpomalen&#283;";
var text06 = "Voz&iacute;k 1:";
var text07 = "Voz&iacute;k 2:";
var text08 = "Hmotnost:";
var text09 = "Rychlost:";
var text10 = "Rychlost";
var text11 = "Hybnost";
var text12 = "Kinetick&aacute; energie";

var author = "W. Fendt 1998,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";
var meterPerSecond = "m/s";                         

// Texte in Unicode-Schreibweise:

var text13 = "Voz\u00EDk 1:";
var text14 = "Voz\u00EDk 2:";
var text15 = "Rychlost p\u0159ed sr\u00E1\u017Ekou:";
var text16 = "Rychlost po sr\u00E1\u017Ece:";
var text17 = "Hybnost p\u0159ed sr\u00E1\u017Ekou:";
var text18 = "Hybnost po sr\u00E1\u017Ece:";
var text19 = "Energie p\u0159ed sr\u00E1\u017Ekou:";
var text20 = "Energie po sr\u00E1\u017Ece:";
var text21 = "Celkov\u00E1 hybnost:";
var text22 = "Celkov\u00E1 kinetick\u00E1 energie:";

// Symbole und Einheiten:

var meterPerSecondUnicode = "m/s";                    
var kilogramMeterPerSecond = "kg m/s";                
var joule = "J";                                       
