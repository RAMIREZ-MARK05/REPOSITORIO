// Bragg-Reflexion, deutsche Texte
// Letzte �nderung 19.08.2021

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Pauza", "D\u00E1le"];
var text03 = "Zpomalen\u011B";
var text04 = "Vzd\u00E1lenost rovin m\u0159\u00ED\u017Eky:";
var text05 = "Vlnov\u00E1 d\u00E9lka:";
var text06 = "\u00DAhel dopadu:";
var text07 = "Po\u010Det rovin:";
var text08 = "Dr\u00E1hov\u00FD rozd\u00EDl:";

var author = "W. Fendt 2021";
var translator = "M. Pano&scaron; 2021";

// Text in Unicode-Schreibweise:

var text09 = "Braggova podm\u00EDnka spln\u011Bna!";

// Einheiten und Symbole:

var decimalSeparator = ",";
var picometer = "pm";
var degree = "\u00B0";
var symbolDeltaS = "\u0394s";
var symbolLambda = "\u03BB";