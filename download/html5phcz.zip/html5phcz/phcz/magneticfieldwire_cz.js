// Magnetfeld eines geraden stromdurchflossenen Leiters, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Zm&ecaron;nit sm&ecaron;r proudu";

var author = "W. Fendt 2000";
var translator = "M. Pano&scaron; 2005";
