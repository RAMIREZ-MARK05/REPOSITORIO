// Gleichgewicht dreier Kr�fte, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Vektory sil:";
var text02 = "Lev&aacute; s&iacute;la:";
var text03 = "Prav&aacute; s&iacute;la:";
var text04 = "Doln&iacute; s&iacute;la:";
var text05 = "Rovnob&ecaron;&zcaron;n&iacute;k";
var text06 = "&Uacute;hly:";
var text07 = "Vlevo:";
var text08 = "Vpravo:";

var author = "W. Fendt 2000";
var translator = "M. Pano&scaron; 2005";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "\u00b0";                                 
var newton = "N";                                      
