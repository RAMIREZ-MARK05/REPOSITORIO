// Einfache Wechselstromkreise, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Rezistor";                                   // Widerstand
var text02 = "Kondenz&aacute;tor";                         // Kondensator
var text03 = "C&iacute;vka";                               // Spule
var text04 = "Reset";
var text05 = ["Start", "Zastavit", "D&aacute;le"];          
var text06 = "Zpomalen&ecaron;";                           // Zeitlupe
var text07 = "Frekvence:";                                 // Frequenz
var text08 = "Max. nap&ecaron;t&iacute;:";                 // Maximale Spannung
var text09 = "Odpor:";                                     // Widerstand
var text10 = "Kapacita:";                                  // Kapazit�t                          
var text11 = "Induk&ccaron;nost:";                         // Induktivit�t
var text12 = "Max. proud:";                                // Maximale Stromst�rke 

var author = "W. Fendt 1998,&nbsp; M. Pano&scaron; 2005";                   

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var hertz = "Hz";                                     
var volt = "V";                                       
var ampere = "A";                                     
var milliampere = "mA";                               
var microampere = "&mu;A";                            
var ohm = "&Omega;";                                  
var microfarad = "&mu;F";                             
var henry = "H";                                      

// Symbole in Unicode-Schreibweise:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolPeriod = "T";                                    // Symbol f�r Periode
var symbolVoltage = "U";                                   // Symbol f�r Spannung
var symbolAmperage = "I";                                  // Symbol f�r Stromst�rke
