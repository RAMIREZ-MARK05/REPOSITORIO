// Leiterschaukel-Versuch zur Lorentzkraft, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Zapnout / Vypnout";
var text02 = "Opa&ccaron;n&yacute; proud";
var text03 = "Oto&ccaron;it magnet";
var text04 = "Sm&ecaron;r&nbsp;proudu";
var text05 = "Magnetick&eacute; pole";
var text06 = "Lorentzova s&iacute;la";

var author = "W. Fendt 1998";
var translator = "M. Pano&scaron; 2005";
