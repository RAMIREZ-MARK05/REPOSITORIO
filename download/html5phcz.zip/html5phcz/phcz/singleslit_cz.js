// Beugung von Licht am Einfachspalt, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Vlnov&aacute; d&eacute;lka:";
var text02 = "&Scaron;&iacute;&rcaron;ka &scaron;t&ecaron;rbiny:";
var text03 = "&Uacute;hel:";
var text04 = "Maxima:";
var text05 = "Minima:";
var text06 = "Relativn&iacute; intenzita:";
var text07 = "Difrak&ccaron;n&iacute; obrazec";
var text08 = "Graf intenzity";

var author = "W. Fendt 2003,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
