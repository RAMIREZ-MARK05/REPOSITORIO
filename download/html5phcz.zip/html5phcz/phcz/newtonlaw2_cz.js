// Fahrbahnversuch zum 2. Newtonschen Gesetz, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Zaznamenat &uacute;daje"];
var text03 = "Prolo&zcaron;en&iacute; k&rcaron;ivkou";
var text04 = "Hmotnost voz&iacute;ku:";
var text05 = "Hmotnost z&aacute;va&zcaron;&iacute;:";
var text06 = "Sou&ccaron;initel smykov&eacute;ho t&rcaron;en&iacute;:";
var text07 = "Tabulka hodnot:";

var author = "W. Fendt 1997,&nbsp; M. Pano&scaron; 2016";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolMass1 = "M";
var symbolMass2 = "m";
var symbolCoefficientFriction = "f";
var gram = "g";

// Texte in Unicode-Schreibweise:

var text08 = "SZ";
var text09 = "(s)";
var text10 = "(m)";
var text11 = "T\u0159en\u00ED je p\u0159\u00EDli\u0161 velk\u00E9!";

// Symbole und Einheiten:

var symbolTime = "t";
var symbolDisplacement = "s";
var symbolAcceleration = "a";
var meter = "m";
var second = "s";
var meterPerSecond2 = "m/s\u00B2";


