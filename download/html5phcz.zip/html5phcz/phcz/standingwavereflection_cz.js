// Stehende Welle, Erkl�rung durch Reflexion, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Odraz";
var text02 = "pevn\u00FD konec";
var text03 = "voln\u00FD konec";
var text04 = "Reset";
var text05 = ["Start", "Zastavit", "D\u00E1le"];
var text06 = "Zpomalen\u0115";
var text07 = "Animace";
var text08 = "Krokov\u00E1n\u00ED";
var text09 = "Dopadaj\u00EDc\u00ED vln\u011Bn\u00ED";
var text10 = "Odra\u017Een\u00E9 vln\u011Bn\u00ED";
var text11 = "V\u00FDsledn\u00E9 stojat\u00E9 vln\u011Bn\u00ED";

var author = "W. Fendt 2003"; 
var translator = "M. Pano&scaron; 2005";

// Texte in Unicode-Schreibweise:        

var text12 = ["T/4", "T/8", "T/12", "T/24"];          

// Symbole und Einheiten:

var symbolPeriod = "T";
var symbolNode = "U";
var symbolAntiNode = "K";

