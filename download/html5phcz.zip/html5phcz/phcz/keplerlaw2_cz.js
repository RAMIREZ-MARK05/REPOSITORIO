// Zweites Kepler-Gesetz, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Hlavn\u00ED poloosa:";
var text03 = "Excentricita:";
var text04 = ["Zastavit", "D\u00E1le"];
var text05 = "Zpomalen\u0115";
var text06 = ["Vzd\u00E1lenost;", "od Slunce:"];
var text07 = "Rychlost:";
var text08 = "Okam\u017Cit\u00E1 hodnota:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Oblasti opsan\u00E9";
var text12 = "Vektor rychlosti";

var author = "W. Fendt 2000,&nbsp; M. Pano\u0161 2016";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit
var kilometerPerSecond = "km/s";

// Texte in Unicode-Schreibweise:

var text01 = ["Merkur", "Venu\u0161e", "Zem\u0115", "Mars", "Jupiter", "Saturn", "Uran", "Neptun",
              "Pluto", "Halleyova kometa", ""];

// Symbole und Einheiten: 

var auUnicode = "AU";
var symbolPeriod = "T";

