// Erstes Kepler-Gesetz, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:
    
var text02 = "Hlavn\u00ED poloosa:";
var text03 = "Excentricita:";
var text04 = "Vedlej\u0161\u00ED polosa:";
var text05 = ["Zastavit", "D\u00E1le"];
var text06 = "Zpomalen\u0115";
var text07 = "Vzd\u00E1lenost od Slunce:";
var text08 = "Okam\u017Cit\u00E1 hodnota:";
var text09 = "Minimum:";
var text10 = "Maximum:";
var text11 = "Eliptick&aacute; trajektorie";
var text12 = "Osy";
var text13 = "Spojnice s ohnisky";

var author = "W. Fendt 2000,&nbsp; M. Pano\u0161 2016";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var au = "AU";                                             // Astronomische Einheit

// Texte in Unicode-Schreibweise:

var text01 = ["Merkur", "Venu\u0161e", "Zem\u0115", "Mars", "Jupiter", "Saturn", "Uran", "Neptun",
              "Pluto", "Halleyova kometa", ""];

var text14 = "Slunce";
var text15 = "Planeta";
var text16 = "Kometa";
var text17 = "Perih\u00E9lium";
var text18 = "Af\u00E9lium";

// Symbole und Einheiten: 

var symbolFocus1 = "F";
var symbolFocus2 = "F'";
var auUnicode = "AU";

