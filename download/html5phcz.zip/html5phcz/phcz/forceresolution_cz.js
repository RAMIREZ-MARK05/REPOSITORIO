// Zerlegung einer Kraft in zwei Komponenten, tschechische Version (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Velikost rozkl&aacute;dan&eacute;";                       
var text02 = "s&iacute;ly:";
var text03 = "Velikosti &uacute;hl&uring;:";
var text04 = "1. &uacute;hel:";
var text05 = "2. &uacute;hel:";
var text06 = "Velikosti slo&zcaron;ek:";
var text07 = "1. slo&zcaron;ka:";
var text08 = "2. slo&zcaron;ka:";
var text09 = "Rozlo&zcaron;it do slo&zcaron;ek";
var text10 = "Smazat konstrukci";

var author = "W. Fendt 2003";
var translator = "M. Pano&scaron; 2005";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                 
var newton = "N";                                     

// Texte in Unicode-Schreibweise:

var text11 = "1. slo\u017eka";                             // Text f�r erste Komponente
var text12 = "2. slo\u017eka";                             // Text f�r zweite Komponente

// Symbole und Einheiten:

var newtonUnicode = "N";                               