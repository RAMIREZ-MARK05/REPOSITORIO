// Kombinationen von Widerst�nden, Spulen und Kondensatoren, tschechische Texte (Miroslav Panos)
// Letzte �nderung 24.03.2020

// Texte in HTML-Schreibweise:

var text01 = "Zdroj nap&ecaron;t&iacute;:";
var text02 = "Nap&ecaron;t&iacute;:";
var text03 = "Frekvence:";
var text04 = "Sou&ccaron;&aacute;stka:";
var text06 = ["Odpor:", "Induk\u010Dnost:", "Kapacita:"];
var text07 = "Zam&ecaron;nit";
var text08 = "P&rcaron;ipojit (s&eacute;riov&ecaron;)";
var text09 = "P&rcaron;ipojit (paraleln&ecaron;)";
var text10 = "Odebrat";
var text11 = "M&ecaron;&rcaron;ic&iacute; p&rcaron;&iacute;stroje:";
var text12 = "Voltmetr";
var text13 = "Amp&eacute;rmetr";

var author = "W. Fendt 2004";
var translator = "M. Pano&scaron; 2020";

// Texte in Unicode-Schreibweise:

var text05 = ["Rezistor", "C\u00EDvka", "Kondenz\u00E1tor"];
var text14 = "Nap\u011Bt\u00ED:";
var text15 = "El. proud:";
var text16 = "Impedance:";
var text17 = "Impedance (velikost):";
var text18 = "F\u00E1zov\u00FD posun:";
var text19 = "p\u0159\u00EDli\u0161 mal\u00FD";
var text20 = "p\u0159\u00EDli\u0161 velk\u00FD";

var volt = "V";
var ampere = "A";
var ohm = "\u03A9";
var hertz = "Hz";
var henry = "H";
var microfarad = "\u03bcF";

// Symbole:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)