// Hebelgesetz, Tschechische Texte (Miroslav Panos)
// Letzte �nderung: 27.01.2018

// Texte in Unicode-Schreibweise:

var text01 = "Levoto\u010Div\u00FD moment s\u00EDly:";
var text02 = "Pravoto\u010Div\u00FD moment s\u00EDly:";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var symbolTorqueLeft = "M_1";                              // Symbol f�r linksseitiges Drehmoment
var symbolTorqueRight = "M_2";                             // Symbol f�r rechtsseitiges Drehmoment
var symbolAdd = "+";                                       // Additionszeichen
var symbolMult = "\u00B7";                                 // Multiplikationszeichen

var newton = "N";
var meter = "m";

var author = "W. Fendt 1997,  M. Pano\u0161 2016";         // Autor (und �bersetzer)
