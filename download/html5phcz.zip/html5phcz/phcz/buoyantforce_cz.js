// Messung der Auftriebskraft, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Podstava t\u0115lesa:"; 
var text02 = "V\u00FD\u0161ka t\u0115lesa:";
var text03 = "Hustota t\u0115lesa:";
var text04 = "Hustota kapaliny:";   
var text05 = "Pono\u0159en\u00ED:";
var text06 = "Pono\u0159en\u00FD objem:"; 
var text07 = "Vztlakov\u00E1 s\u00EDla:";
var text08 = "T\u00EDhov\u00E1 s\u00EDla:";
var text09 = "M\u0115\u0159en\u00E1 s\u00EDla:";
var text10 = "Rozsah silom\u0115ru:";

var author = "W. Fendt 1998,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";
var centimeter3 = "cm&sup3;";
var centimeter2 = "cm&sup2;";
var gramPerCentimeter3 = "g/cm&sup3;";
var newton = "N";                  

// Texte in Unicode-Schreibweise:

var text11 = "Rozsah p\u0159ekro\u010Den!";
