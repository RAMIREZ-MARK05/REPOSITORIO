// Interferenz von Licht am Doppelspalt, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Vlnov\u00E1 d\u00E9lka:";
var text02 = "Vzd\u00E1lenost \u0161t\u011Brbin:";
var text03 = "\u00DAhel:";
var text04 = "Maxima:";
var text05 = "Minima:";
var text06 = "Relativn\u00ED intenzita:";
var text07 = "Difrak\u010Dn\u00ED obrazec";
var text08 = "Graf intenzity";

var author = "W. Fendt 2003,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt) 

var nanometer = "nm";
var degree = "&deg;";

// Texte in Unicode-Schreibweise:

var symbolOrder = "k";                                     // Symbol f�r Ordnung eines Maximums oder Minimums
var degreeUnicode = "\u00B0";
