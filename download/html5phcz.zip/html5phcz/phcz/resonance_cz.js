// Resonanz, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Zastavit", "D\u00E1le"];
var text03 = "Zpomalen\u0115";
var text04 = "Buzen\u00FD oscil\u00E1tor:";
var text05 = "Tuhost pru\u017Einy:";
var text06 = "Hmotnost:";
var text07 = "Tlumen\u00ED:";
var text08 = "Zdroj buzen\u00ED:";
var text09 = "\u00DAhlov\u00E1 frekvence:";
var text10 = "Graf okam\u017Eit\u00E9 v\u00FDchylky";
var text11 = "Graf amplitudy";
var text12 = "Graf f\u00E1ze";

var author = "W. Fendt 1998,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var kilogram = "kg";                                  
var newtonPerMeter = "N/m";                           
var perSecond = "1/s";                                
var radPerSecond = "rad/s";                           

// Texte in Unicode-Schreibweise:

var text13 = "P\u0159ekro\u010Den\u00ED mez\u00ED!";
var text14 = "(Simulace nad\u00E1le nen\u00ED realistick\u00E1!)";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongationExciter = "y_E";                       // Symbol f�r Elongation der Erregerschwingung
var symbolElongationResonator = "y_R";                     // Symbol f�r Elongation der Resonatorschwingung
var symbolAmplitudeExciter = "A_E";                        // Symbol f�r Amplitude der Erregerschwingung
var symbolAmplitudeResonator = "A";                        // Symbol f�r Amplitude der Resonatorschwingung
var symbolAngularFrequency = "\u03C9";                     // Symbol f�r Kreisfrequenz
var symbolAngularFrequencyResonance = "\u03C9_0";          // Symbol f�r Resonanz-Kreisfrequenz
var symbolPi = "\u03C0";                                   // Symbol f�r Kreiszahl (pi)
var symbolPhaseDifference = "\u0394\u03C6";                // Symbol f�r Phasendifferenz (Delta phi)
var centimeter = "cm";                                 
var radPerSecondUnicode = "rad/s";                     


