// Fadenpendel, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Zastavit", "D&aacute;le"];
var text03 = "Zpomalen&ecaron;";
var text04 = "D&eacute;lka z&aacute;v&ecaron;su:";         // Pendell�nge
// Falls n�tig, Variable text05x f�r zus�tzliche Zeile!
var text05 = "T&iacute;hov&eacute; zrychlen&iacute;:";     // Fallbeschleunigung
var text06 = "Hmotnost:";                                  // Masse
var text07 = "Max. v&yacute;chylka:";                      // Amplitude
var text08 = "V&yacute;chylka";                            // Elongation
var text09 = "Rychlost";                                   // Geschwindigkeit
var text10 = "Zrychlen&iacute;";                           // Beschleunigung
var text11 = "S&iacute;la";                                // Kraft
var text12 = "Energie";

var author = "W. Fendt 1998,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)

var meter = "m";                                      
var meterPerSecond2 = "m/s&sup2;";                    
var kilogram = "kg";                                  
var degree = "&deg;";                                 

// Texte in Unicode-Schreibweise:

var text13 = "Maximum";
var text14 = "V\u00FDchylka";                              // Elongation
var text15 = "Rychlost";                                   // Geschwindigkeit 
var text16 = "Zrychlen\u00ED (te\u010Dn\u00E1 slo\u017Cka)"; // Beschleunigung (tangentiale Komponente)
var text17 = "S\u00EDla (te\u010Dn\u00E1 slo\u017Cka)";    // Kraft (tangentiale Komponente)
var text18 = "Potenci\u00E1ln\u00ED energie";              // Potentielle Energie
var text19 = "Kinetick\u00E1 energie";                     // Kinetische Energie
var text20 = "Celkov\u00E1 energie";                       // Gesamtenergie
var text21 = "(s)";
var text22 = "(m)";
var text23 = "(m/s)";
var text24 = "(m/s\u00b2)";
var text25 = "(N)";
var text26 = "(J)";
var text27 = "Perioda";

// Symbole und Einheiten:

var symbolTime = "t";                                      // Symbol f�r Zeit
var symbolElongation = "s";                                // Symbol f�r Elongation
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var symbolAcceleration = "a";                              // Symbol f�r Beschleunigung
var symbolTangential = "tg";                               // Symbol f�r tangential
var symbolForce = "F";                                     // Symbol f�r Kraft
var symbolEnergy = "E";                                    // Symbol f�r Energie
var symbolPotential = "p";                                 // Symbol f�r potentiell
var symbolKinetic = "k";                                   // Symbol f�r kinetisch
var second = "s";                                     
var meterUnicode = "m";                               
var meterPerSecond = "m/s";                           
var meterPerSecond2Unicode = "m/s\u00b2";             
var newton = "N";                                     
var joule = "J";                                      


