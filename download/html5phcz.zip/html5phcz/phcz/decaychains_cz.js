// Zerfallsreihen, tschechische Texte (Miroslav Pano�)
// Letzte �nderung 25.02.2018

// Texte in HTML-Schreibweise:

var text01 = "Rozpadov&aacute; &rcaron;ada:";
var text03 = "N&aacute;sleduj&iacute;c&iacute; p&rcaron;em&ecaron;na";

var author = "W. Fendt 1998"; 
var translator = "M. Pano&scaron; 2018";

// Texte in Unicode-Schreibweise:

var text02 = ["Thoriov\u00E1 \u0159ada", 
              "Neptuniov\u00E1 \u0159ada", 
              "Uran-radiov\u00E1 \u0159ada", 
              "Uran-aktiniov\u00E1 \u0159ada"];          





