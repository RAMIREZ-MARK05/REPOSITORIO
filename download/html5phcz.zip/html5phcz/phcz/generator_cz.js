// Generator, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise;

var text01 = "Altern\u00E1tor (bez komut\u00E1toru)";
var text02 = "Dynamo (s komut\u00E1torem)";
var text03 = "Zm\u011Bnit sm\u011Br";
var text04 = ["Start", "Zastavit", "D\u00E1le"];
var text05 = "Sm\u011Br pohybu";
var text06 = "Magnetick\u00E9 pole";
var text07 = "Indukovan\u00FD proud";

var author = "W. Fendt 1998";  
var translator = "M. Pano&scaron; 2005";                                     

// Symbole und Einheiten:
                                    
var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "ot. / min";                          // Umdrehungen pro Minute

// Texte in Unicode-Schreibweise:

var symbolTime = "t";
var symbolVoltage = "U";
var symbolResistor = "R";
