// Schiefer Wurf, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";                    
var text02 = ["Start", "Zastavit", "D&aacute;le"];          
var text03 = "Zpomalen&ecaron;";
var text04 = "Po&ccaron;&aacute;te&ccaron;n&iacute; v&yacute;&scaron;ka:";
var text05 = "Po&ccaron;&aacute;te&ccaron;n&iacute; rychlost:";
var text06 = "Eleva&ccaron;n&iacute; &uacute;hel:";
var text07 = "Hmotnost:"; 
var text08 = "T&iacute;hov&eacute; zrychlen&iacute;:";
var text09 = "Sou&rcaron;adnice";
var text10 = "Rychlost";
var text11 = "Zrychlen&iacute;";
var text12 = "S&iacute;la";
var text13 = "Energie";

var author = "W. Fendt 2000,&nbsp; M. Pano&scaron; 2005";

// Symbole und Einheiten:  

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var meter = "m";                                     
var meterPerSecond = "m/s";                          
var meterPerSecond2 = "m/s&sup2;";                    
var kilogram = "kg";                                  
var degree = "&deg;";                                 

// Texte in Unicode-Schreibweise:

var text14 = "(m)";                                        // Einheitenangabe f�r Koordinatenachsen 
var text15 = "Sou\u0159adnice:";                           // Position
var text16 = "(vodorovn\u011B)";                           // waagrecht
var text17 = "(svisle)";                                   // senkrecht
var text18 = "Dolet:";                                     // Wurfweite
var text19 = "Maxim\u00E1ln\u00ED v\u00FD\u0161ka:";       // Maximale H�he
var text20 = "Doba letu:";                                 // Wurfdauer
var text21 = "Slo\u017Eky rychlosti:";                     // Geschwindigkeitskomponenten
var text22 = "Velikost rychlosti:";                        // Geschwindigkeitsbetrag
var text23 = "\u00DAhel:";                                 // Winkel
var text24 = "Zrychlen\u00ED:";                            // Beschleunigung
var text25 = "S\u00EDla:";                                 // Kraft
var text26 = "Pohybov\u00E1 energie:";                     // Kinetische Energie
var text27 = "Polohov\u00E1 energie:";                     // Potentielle Energie
var text28 = "Celkov\u00E1 energie:";                      // Gesamtenergie

// Symbole und Einheiten:

var symbolX = "x";                                         // Symbol f�r waagrechte Koordinate
var symbolY = "y";                                         // Symbol f�r senkrechte Koordinate
var symbolVelocity = "v";                                  // Symbol f�r Geschwindigkeit
var meterUnicode = "m";                              
var secondUnicode = "s";                             
var meterPerSecondUnicode = "m/s";                   
var meterPerSecond2Unicode = "m/s\u00b2";             
var newtonUnicode = "N";                              
var jouleUnicode = "J";                               
var degreeUnicode = "\u00b0";                         



