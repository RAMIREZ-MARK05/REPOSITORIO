// Beispiel zum Doppler-Effekt, tschechische Texte (Miroslav Panos)
// Letzte �nderung 28.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Nov&yacute; start";
var text02 = ["Pauza", "Pokra&ccaron;ovat"]; 

var author = "W. Fendt 1998";
var translator = "M. Pano&scaron; 2005";

// Texte in Unicode-Schreibweise:                  

var text03 = [                                        
  ["Dokud se sanitka",
   "bl\u00ED\u017E\u00ED k osob\u0115",
   "jsou mezery mezi",
   "vlnoplochami",
   "zkr\u00E1cen\u00E9."],
  ["Nyn\u00ED vozidlo opou\u0161t\u00ED",
   "osobu, tak vlny",
   "p\u0159ilet\u00ED ve v\u0115t\u0161\u00EDch",
   "pauz\u00E1ch."]];
  

