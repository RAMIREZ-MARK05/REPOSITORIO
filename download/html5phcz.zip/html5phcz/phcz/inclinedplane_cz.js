// Kr�fte an der schiefen Ebene, tschechische Texte (Miroslav Panos)
// Letzte �nderung 27.01.2018

// Texte in HTML-Schreibweise:

var text01 = "Reset";
var text02 = ["Start", "Zastavit", "D\u00E1le"];
var text03 = "Zpomalen\u0115";
var text04 = "Silom\u0115r";
var text05 = "Vektory sil";
var text06 = "Skon roviny:";
var text07 = "T\u00EDhov\u00E1 s\u00EDla:";
var text08 = "S\u00EDla rovnob\u0115\u017En\u00E1:";
var text09 = "S\u00EDla norm\u00E1lov\u00E1:";
var text10 = "Sou\u010D. smyk. t\u0159en\u00ED:";
var text11 = "T\u0159ec\u00ED s\u00EDla:";
var text12 = "Ta\u017En\u00E1 s\u00EDla:";

var author = "W. Fendt 1999,&nbsp; M. Pano&scaron; 2005";

var decimalSeparator = ",";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                
var newton = "N";                                     
